﻿using System;
using System.Text;

namespace BGEE_revisions
{
    // Offset	Size (data type)	Description
    // 0x0000	4 (strref)	Actor response text (i.e. what the non-player character says to the party)
    // 0x0004	4 (dword)	Index of the first transition corresponding to this state (i.e. the index in the transition table of the first potential response the party can make in this state).
    // 0x0008	4 (dword)	Number of transitions corresponding to this state (i.e. how many possible responses are there to this state). A consecutive range of transitions in the transition table are assigned to this state, starting from 'first', as given by the previous field, ranging up to (but not including) 'first'+'count'.
    // 0x000c	4 (dword)	Trigger for this state (as index into the state trigger table), or 0xFFFFFFFF if no trigger is used for this state.
    
    internal class DlgStateTable
    {
        internal static int size = 16; // header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal int actorResponseText; // string reference in TLK file
        internal int indexOfFirstTransition;
        internal int numberOfTransitions;
        internal int triggerForState;

        internal DlgStateTable(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            actorResponseText = ConvertToIntData();
            indexOfFirstTransition = ConvertToIntData();
            numberOfTransitions = ConvertToIntData();
            triggerForState = ConvertToIntData();

            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }

        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(actorResponseText);
            CopyBytesToArray(indexOfFirstTransition);
            CopyBytesToArray(numberOfTransitions);
            CopyBytesToArray(triggerForState);

            return byteArray;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine("actorResponseText:\t" + actorResponseText);
            Console.WriteLine("indexOfFirstTransition:\t" + indexOfFirstTransition);
            Console.WriteLine("numberOfTransitions:\t" + numberOfTransitions);
            Console.WriteLine("triggerForState:\t" + triggerForState);
        }
    }
}