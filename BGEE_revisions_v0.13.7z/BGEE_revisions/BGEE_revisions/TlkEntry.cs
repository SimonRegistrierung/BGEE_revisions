﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal class TlkEntry
    {
        internal static int size = 26; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal short bitField;
        internal String soundResName;
        internal int volumeVariance;
        internal int pitchVariance;
        internal int offsetToString;
        internal int stringLength;
        //
        internal String textString;
        internal byte[] textByteData;
        //
        internal int index;

        internal TlkEntry(byte[] byteArray, int baseOffset)
        {
            this.baseOffset = baseOffset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            bitField = ConvertToShortData();
            soundResName = ConvertToStringData(8);
            volumeVariance = ConvertToIntData();
            pitchVariance = ConvertToIntData();
            offsetToString = ConvertToIntData();
            stringLength = ConvertToIntData();
            
            this.byteArray = null; // clear the byteList;
        }

        internal TlkEntry(String textString, short bitField, int offsetToString) // when creating a new tlk entry, not for decompiling an existing tlk file
        {
            this.bitField = bitField;
            soundResName = new string(new char[8]);
            volumeVariance = 0;
            pitchVariance = 0;
            this.offsetToString = offsetToString;
            stringLength = textString.Length;

            byteArray = null;
            
            this.textString = textString;
            textByteData = null;
            textByteData = new byte[textString.Length];
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(textString), 0, textByteData, 0, stringLength);
        }

        internal void SetIndex(int index)
        {
            this.index = index;
        }
        
        internal void GetStringData(byte[] byteArray, int offsetToString)
        {
            // Console.WriteLine("            " + offsetToString);
            // Console.WriteLine("            " + stringLength);
            textString = Encoding.ASCII.GetString(byteArray, offsetToString, stringLength);
            this.offsetToString = offsetToString;
            textByteData = AddByteData(byteArray);
            // stringLength = textString.Length;
            // Console.WriteLine(textString);
        }

        internal byte[] AddByteData(byte[] originalByteArray)
        {
            byte[] byteData = new byte[stringLength];
            System.Buffer.BlockCopy(originalByteArray, offsetToString, byteData,0,stringLength);
            return byteData;
        }
        
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }
        
        internal byte[] GetByteData(int offsetToStringSection)
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(bitField);
            CopyBytesToArray(soundResName, 8);
            
            CopyBytesToArray(volumeVariance);
            CopyBytesToArray(pitchVariance);

            CopyBytesToArray(offsetToString - offsetToStringSection); // offset is relative to the string section, not absolute to the full file size!
            
            CopyBytesToArray(stringLength);
            
            // Console.WriteLine(arrayOffset);

            return byteArray;
        }

        internal void CopyBytesToArray(String variable, int byteSize)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, byteSize);
            // System.Buffer.BlockCopy(new byte[8], 0, byteArray, arrayOffset, byteSize);
            arrayOffset += byteSize;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            // System.Buffer.BlockCopy(BitConverter.GetBytes(0), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void UpdateInstance(int offsetDelta, int newLength, String newString)
        {
            offsetToString = offsetToString + offsetDelta;
            textString = newString;
            stringLength = newLength;
            textByteData = new byte[stringLength];
            
            int compensation = 0;
            if (Encoding.ASCII.GetBytes(textString).Length < stringLength)
            {
                compensation = stringLength - Encoding.ASCII.GetBytes(textString).Length;
            }
            else if (Encoding.ASCII.GetBytes(textString).Length > stringLength)
            {
                textByteData = new byte[Encoding.ASCII.GetBytes(textString).Length];
            }
            
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(textString), 0, textByteData, 0, stringLength - compensation);
        }

        internal void UpdateInstance(int offsetDelta)
        {
            offsetToString = offsetToString + offsetDelta;
        }

        internal void PrintValues()
        {
            Console.WriteLine("bitField:\t" + bitField);
            Console.WriteLine("soundResName:\t" + soundResName);
            Console.WriteLine("volumeVariance:\t" + volumeVariance);
            Console.WriteLine("pitchVariance:\t" + pitchVariance);
            Console.WriteLine("offsetToStringSection:\t" + offsetToString);
            Console.WriteLine("stringLength:\t" + stringLength);
        }
    }
}