﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        struct QuestEntryTriplet
        {
            internal int strRef;
            internal String replStr;
            internal Boolean isExact;
            internal QuestEntryTriplet(int strRef, String replStr, Boolean isExact)
            {
                this.strRef = strRef;
                this.replStr = replStr;
                this.isExact = isExact;
            }
        }
        internal static void RunLua()
        {
            // FIX ERRONEOUS STR REFS IN THE QUEST ENTRIES
            ArrayList questEntryTriplets = new ArrayList();

            questEntryTriplets.Add(new QuestEntryTriplet(31317, "Edwin and Dynaheir", true));
            questEntryTriplets.Add(new QuestEntryTriplet(31291, "Aldeth Sashenstar", true));
            questEntryTriplets.Add(new QuestEntryTriplet(31313, "Dryad of the Cloudpeaks", true));
            questEntryTriplets.Add(new QuestEntryTriplet(31350, "Entar's Son", true));
            questEntryTriplets.Add(new QuestEntryTriplet(31279, "A Hidden Base in the Cloakwood", true));
            
            if (ContainsCaseInsensitive(currentLuaFileInfo.Name, "BGEE.lua"))
            {
                String content = FileOperations.ReadFileAsString(currentLuaFileInfo.FullName);
                foreach (QuestEntryTriplet questEntryTriplet in questEntryTriplets)
                {
                    // Console.WriteLine("got here");
                    Regex pattern = new Regex(@"(?<=^\s*create(Quest|Entry)\s*\(\s*)" + questEntryTriplet.strRef + @"(?=(\s\)|,\s).*$)", RegexOptions.Multiline);
                    MatchCollection mc = pattern.Matches(content);
                    Boolean firstRun = true;
                    int delta = 0;
                    foreach (Match m in mc)
                    {
                        // Console.WriteLine(m.Value.ToString());
                        // Console.WriteLine(FindExactTlkEntry(questEntryTriplet.replStr).ToString());
                        if (firstRun)
                        {
                            // Console.WriteLine(delta);
                            content = content.Remove(m.Index, m.Length).Insert(m.Index, FindExactTlkEntry(questEntryTriplet.replStr).ToString().Trim());
                            firstRun = false;
                        }
                        else
                        {
                            // CALCULATE NEW DELTA
                            if (FindExactTlkEntry(questEntryTriplet.replStr).ToString().Length > m.Value.Length)
                            {
                                delta += FindExactTlkEntry(questEntryTriplet.replStr).ToString().Length - m.Value.Length;
                            }
                            else if (FindExactTlkEntry(questEntryTriplet.replStr).ToString().Length < m.Value.Length)
                            {
                                delta -= m.Value.Length - FindExactTlkEntry(questEntryTriplet.replStr).ToString().Length;
                            }
                            // SET CONTENT
                            content = content.Remove(m.Index + delta, m.Length).Insert(m.Index + delta, FindExactTlkEntry(questEntryTriplet.replStr).ToString().Trim());
                            
                        }
                    }
                }
                FileOperations.WriteFileAsString(content, luaOutputPath + "/" + currentLuaFileInfo.Name);
            }
        }

        internal static int FindReplaceLuaQuestStrRef(int strRefToFind, String replStr, Boolean isExact)
        {
            if (isExact)
            {
                return FindExactTlkEntry(replStr);
            }
            else
            {
                return FindFirstMatchingTlkEntry(replStr);
            }
        }
    }
}