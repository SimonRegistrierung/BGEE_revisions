﻿using System;
using System.Text;

namespace BGEE_revisions
{
    public class AreSong
    {
        internal static int size = 144; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal int daySong;
        internal int nightSong;
        internal int winSong;
        internal int battleSong;
        internal int loseSong;
        internal int altMusic1;
        internal int altMusic2;
        internal int altMusic3;
        internal int altMusic4;
        internal int altMusic5;
        internal String mainDayAmbient1;
        internal String mainDayAmbient2;
        internal int mainDayAmbientVolume;
        internal String mainNightAmbient1;
        internal String mainNightAmbient2;
        internal int mainNightAmbientVolume;
        internal int unused1;
        internal byte[] unused2;


        internal AreSong(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            daySong = ConvertToIntData();
            nightSong = ConvertToIntData();
            winSong = ConvertToIntData();
            battleSong = ConvertToIntData();
            loseSong = ConvertToIntData();
            altMusic1 = ConvertToIntData();
            altMusic2 = ConvertToIntData();
            altMusic3 = ConvertToIntData();
            altMusic4 = ConvertToIntData();
            altMusic5 = ConvertToIntData();
            mainDayAmbient1 = ConvertToStringData(8);
            mainDayAmbient2 = ConvertToStringData(8);
            mainDayAmbientVolume = ConvertToIntData();
            mainNightAmbient1 = ConvertToStringData(8);
            mainNightAmbient2 = ConvertToStringData(8);
            mainNightAmbientVolume = ConvertToIntData();
            unused1 = ConvertToIntData();
            unused2 = ConvertToUnknownData(60);
            
            size = baseOffset - offset;
            // Console.WriteLine(size);
            
            this.byteArray = null; // clear the byteList;
        }

        internal double ConvertToDoubleData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToDouble(byteArray, currentOffset);
        }
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(daySong);
            CopyBytesToArray(nightSong);
            CopyBytesToArray(winSong);
            CopyBytesToArray(battleSong);
            CopyBytesToArray(loseSong);
            CopyBytesToArray(altMusic1);
            CopyBytesToArray(altMusic2);
            CopyBytesToArray(altMusic3);
            CopyBytesToArray(altMusic4);
            CopyBytesToArray(altMusic5);
            CopyBytesToArray(mainDayAmbient1);
            CopyBytesToArray(mainDayAmbient2);
            CopyBytesToArray(mainDayAmbientVolume);
            CopyBytesToArray(mainNightAmbient1);
            CopyBytesToArray(mainNightAmbient2);
            CopyBytesToArray(mainNightAmbientVolume);
            CopyBytesToArray(unused1);
            CopyBytesToArray(unused2);
            
            return byteArray;
        }

        internal void CopyBytesToArray(double variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}