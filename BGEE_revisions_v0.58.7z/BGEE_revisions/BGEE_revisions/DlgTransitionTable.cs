﻿using System;
using System.Text;

namespace BGEE_revisions
{
    // Offset	Size (data type)	Description
    // 0x0000	4 (dword)	Flags:
        // bit 0: 1=Associated text, 0=no associated text
        // bit 1: 1=Trigger, 0=no trigger
        // bit 2: 1=Action, 0=no action
        // bit 3: 1=Terminates dialog, 0=has "next node" information
        // bit 4: 1=Journal entry, 0=no journal entry
        // bit 5: Interrupt
        // bit 6: Add Unsolved Quest Journal entry (BG2)
        // bit 7: Add Journal note (BG2)
        // bit 8: Add Solved Quest Journal entry (BG2)
        // bit 9: 1=Immediate execution of script actions, 0=Delayed execution of script actions (BGEE)
        // bit 10: Clear actions (BGEE)
    // 0x0004	4 (strref)	If flags bit 0 was set, this is the text associated with the transition (i.e. what the player character says)
    // 0x0008	4 (strref)	If flags bit 4 was set, this is the text that goes into your journal after you have spoken.
    // 0x000c	4 (dword)	If flags bit 1 was set, this is the index of this transition's trigger within the transition trigger table.
    // 0x0010	4 (dword)	If flags bit 2 was set, this is the index of this transition's action within the action table.
    // 0x0014	8 (resref)	If flags bit 3 was not set, this is the resource name of the DLG resource which contains the next state in the conversation.
    // 0x001c	4 (dword)	If flags bit 3 was not set, this is the index of the next state within the DLG resource specified by the previous field. Control transfers to that state after the party has followed this transition.
    
    internal class DlgTransitionTable
    {
        internal static int size = 32; // header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal int flags;
        internal int transitionText; // string reference in TLK file
        internal int journalText; // string reference in TLK file
        internal int transitionTriggerIndex;
        internal int transitionActionIndex;
        internal String dlgResourceName;
        internal int dlgResourceIndex;

        internal DlgTransitionTable(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            flags = ConvertToIntData();
            transitionText = ConvertToIntData();
            journalText = ConvertToIntData();
            transitionTriggerIndex = ConvertToIntData();
            transitionActionIndex = ConvertToIntData();
            dlgResourceName = ConvertToStringData(8);
            dlgResourceIndex = ConvertToIntData();

            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }

        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(flags);
            CopyBytesToArray(transitionText);
            CopyBytesToArray(journalText);
            CopyBytesToArray(transitionTriggerIndex);
            CopyBytesToArray(transitionActionIndex);
            CopyBytesToArray(dlgResourceName);
            CopyBytesToArray(dlgResourceIndex);

            return byteArray;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine("flags:\t" + flags);
            Console.WriteLine("transitionText:\t" + transitionText);
            Console.WriteLine("journalText:\t" + journalText);
            Console.WriteLine("transitionTriggerIndex:\t" + transitionTriggerIndex);
            Console.WriteLine("transitionActionIndex:\t" + transitionActionIndex);
            Console.WriteLine("dlgResourceName:\t" + dlgResourceName);
            Console.WriteLine("dlgResourceIndex:\t" + dlgResourceIndex);
        }
    }
}