﻿using System;
using System.Text;

namespace BGEE_revisions
{
    internal class ItmExtHeader
    {
        internal static int size = 56; // header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal byte attackType;
        internal byte idReq;
        internal byte location;
        internal byte altDiceSides;
        internal String useIcon;
        internal byte targetType;
        internal byte targetCount;
        internal short range;
        internal byte launcher;
        internal byte altDiceThrown;
        internal byte speed;
        internal byte altDmgBonus;
        internal short thacoBonus;
        internal byte diceSides;
        internal byte primaryType;
        internal byte diceThrown;
        internal byte secondaryType;
        internal short dmgBonus;
        internal short dmgType;
        internal short abilitiesCount;
        internal short abilitiesIndex;
        internal short maxCharges;
        internal short onDepletion;
        internal int flags;
        internal short projectileAnimation;
        internal short animProbOverhand;
        internal short animProbBackhand;
        internal short animProbThrust;
        internal short isArrow;
        internal short isBolt;
        internal short isBullet;

        internal ItmExtHeader(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            attackType = ConvertToByteData();
            idReq = ConvertToByteData();
            location = ConvertToByteData();
            altDiceSides = ConvertToByteData();
            useIcon = ConvertToStringData(8);
            targetType = ConvertToByteData();
            targetCount = ConvertToByteData();
            range = ConvertToShortData();
            launcher = ConvertToByteData();
            altDiceThrown = ConvertToByteData();
            speed = ConvertToByteData();
            altDmgBonus = ConvertToByteData();
            thacoBonus = ConvertToShortData();
            diceSides = ConvertToByteData();
            primaryType = ConvertToByteData();
            diceThrown = ConvertToByteData();
            secondaryType = ConvertToByteData();
            dmgBonus = ConvertToShortData();
            dmgType = ConvertToShortData();
            abilitiesCount = ConvertToShortData();
            abilitiesIndex = ConvertToShortData();
            maxCharges = ConvertToShortData();
            onDepletion = ConvertToShortData();
            flags = ConvertToIntData();
            projectileAnimation = ConvertToShortData();
            animProbOverhand = ConvertToShortData();
            animProbBackhand = ConvertToShortData();
            animProbThrust = ConvertToShortData();
            isArrow = ConvertToShortData();
            isBolt = ConvertToShortData();
            isBullet = ConvertToShortData();

            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }

        internal ItmExtHeader(
            byte attackType, 
            byte idReq,
            byte location,
            byte altDiceSides,
            String useIcon,
            byte targetType,
            byte targetCount,
            short range,
            byte launcher,
            byte altDiceThrown,
            byte speed,
            byte altDmgBonus,
            short thacoBonus,
            byte diceSides,
            byte primaryType,
            byte diceThrown,
            byte secondaryType,
            short dmgBonus,
            short dmgType,
            short abilitiesCount,
            short abilitiesIndex,
            short maxCharges,
            short onDepletion,
            int flags,
            short projectileAnimation,
            short animProbOverhand,
            short animProbBackhand,
            short animProbThrust,
            short isArrow,
            short isBolt,
            short isBullet
        )
        {
            this.attackType = attackType;
            this.idReq = idReq;
            this.location = location;
            this.altDiceSides = altDiceSides;
            this.useIcon = useIcon;
            this.targetType = targetType;
            this.targetCount = targetCount;
            this.range = range;
            this.launcher = launcher;
            this.altDiceThrown = altDiceThrown;
            this.speed = speed;
            this.altDmgBonus = altDmgBonus;
            this.thacoBonus = thacoBonus;
            this.diceSides = diceSides;
            this.primaryType = primaryType;
            this.diceThrown = diceThrown;
            this.secondaryType = secondaryType;
            this.dmgBonus = dmgBonus;
            this.dmgType = dmgType;
            this.abilitiesCount = abilitiesCount;
            this.abilitiesIndex = abilitiesIndex;
            this.maxCharges = maxCharges;
            this.onDepletion = onDepletion;
            this.flags = flags;
            this.projectileAnimation = projectileAnimation;
            this.animProbOverhand = animProbOverhand;
            this.animProbBackhand = animProbBackhand;
            this.animProbThrust = animProbThrust;
            this.isArrow = isArrow;
            this.isBolt = isBolt;
            this.isBullet = isBullet;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(attackType);
            CopyBytesToArray(idReq);
            CopyBytesToArray(location);
            CopyBytesToArray(altDiceSides);
            CopyBytesToArray(useIcon);
            CopyBytesToArray(targetType);
            CopyBytesToArray(targetCount);
            CopyBytesToArray(range);
            CopyBytesToArray(launcher);
            CopyBytesToArray(altDiceThrown);
            CopyBytesToArray(speed);
            CopyBytesToArray(altDmgBonus);
            CopyBytesToArray(thacoBonus);
            CopyBytesToArray(diceSides);
            CopyBytesToArray(primaryType);
            CopyBytesToArray(diceThrown);
            CopyBytesToArray(secondaryType);
            CopyBytesToArray(dmgBonus);
            CopyBytesToArray(dmgType);
            CopyBytesToArray(abilitiesCount);
            CopyBytesToArray(abilitiesIndex);
            CopyBytesToArray(maxCharges);
            CopyBytesToArray(onDepletion);
            CopyBytesToArray(flags);
            CopyBytesToArray(projectileAnimation);
            CopyBytesToArray(animProbOverhand);
            CopyBytesToArray(animProbBackhand);
            CopyBytesToArray(animProbThrust);
            CopyBytesToArray(isArrow);
            CopyBytesToArray(isBolt);
            CopyBytesToArray(isBullet);

            return byteArray;
        }
        
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine(attackType);
            Console.WriteLine(idReq);
            Console.WriteLine(location);
            Console.WriteLine(altDiceSides);
            Console.WriteLine(useIcon, 8);
            Console.WriteLine(targetType);
            Console.WriteLine(targetCount);
            Console.WriteLine(range);
            Console.WriteLine(launcher);
            Console.WriteLine(altDiceThrown);
            Console.WriteLine(speed);
            Console.WriteLine(altDmgBonus);
            Console.WriteLine(thacoBonus);
            Console.WriteLine(diceSides);
            Console.WriteLine(primaryType);
            Console.WriteLine(diceThrown);
            Console.WriteLine(secondaryType);
            Console.WriteLine(dmgBonus);
            Console.WriteLine(dmgType);
            Console.WriteLine(abilitiesCount);
            Console.WriteLine(abilitiesIndex);
            Console.WriteLine(maxCharges);
            Console.WriteLine(onDepletion);
            Console.WriteLine(flags);
            Console.WriteLine(projectileAnimation);
            Console.WriteLine(animProbOverhand);
            Console.WriteLine(animProbBackhand);
            Console.WriteLine(animProbThrust);
            Console.WriteLine(isArrow);
            Console.WriteLine(isBolt);
            Console.WriteLine(isBullet);
        }
    }
}