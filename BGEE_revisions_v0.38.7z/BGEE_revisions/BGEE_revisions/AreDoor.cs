﻿using System;
using System.Text;

namespace BGEE_revisions
{
    public class AreDoor
    {
        internal static int size = 200; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String name;
        internal String wedId;
        internal int flags;
        internal int indexFirstVertexOpen;
        internal short countVerticesOpen;
        internal short countVerticesClosed;
        internal int indexFirstVertexClosed;
        internal short minBoundingBoxOpenLeft;
        internal short minBoundingBoxOpenTop;
        internal short minBoundingBoxOpenRight;
        internal short minBoundingBoxOpenBottom;
        internal short minBoundingBoxClosedLeft;
        internal short minBoundingBoxClosedTop;
        internal short minBoundingBoxClosedRight;
        internal short minBoundingBoxClosedBottom;
        internal int indexFirstVertexImpededOpen;
        internal short countVerticesImpededOpen;
        internal short countVerticesImpededClosed;
        internal int indexFirstVertexImpededClosed;

        internal short hp;
        internal short ac;
        internal String doorOpenSound;
        internal String doorCloseSound;
        internal int cursorIndex;
        internal short trapDetectionDifficulty;
        internal short trapRemovalDifficulty;
        internal short doorTrapped;
        internal short trapDetected;
        internal short trapLaunchTargetXCoordinate;
        internal short trapLaunchTargetYCoordinate;
        internal String keyItem;
        internal String doorScript;
        internal int detectionDifficulty;
        internal int lockDifficulty;
        internal short openLocationX;
        internal short openLocationY;
        internal short closeLocationX;
        internal short closeLocationY;
        internal int lockpickString;
        internal byte[] travelTriggerName;
        internal int dialogSpeakerName;
        internal String dialogResRef;
        internal byte[] unknown;

        internal AreDoor(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            name = ConvertToStringData(32);
            wedId = ConvertToStringData(8);
            flags = ConvertToIntData();
            indexFirstVertexOpen = ConvertToIntData();
            countVerticesOpen = ConvertToShortData();
            countVerticesClosed = ConvertToShortData();
            indexFirstVertexClosed = ConvertToIntData();
            minBoundingBoxOpenLeft = ConvertToShortData();
            minBoundingBoxOpenTop = ConvertToShortData();
            minBoundingBoxOpenRight = ConvertToShortData();
            minBoundingBoxOpenBottom = ConvertToShortData();
            minBoundingBoxClosedLeft = ConvertToShortData();
            minBoundingBoxClosedTop = ConvertToShortData();
            minBoundingBoxClosedRight = ConvertToShortData();
            minBoundingBoxClosedBottom = ConvertToShortData();
            indexFirstVertexImpededOpen = ConvertToIntData();
            countVerticesImpededOpen = ConvertToShortData();
            countVerticesImpededClosed = ConvertToShortData();
            indexFirstVertexImpededClosed = ConvertToIntData();

            hp = ConvertToShortData();
            ac = ConvertToShortData();
            doorOpenSound = ConvertToStringData(8);
            doorCloseSound = ConvertToStringData(8);
            cursorIndex = ConvertToIntData();
            trapDetectionDifficulty = ConvertToShortData();
            trapRemovalDifficulty = ConvertToShortData();
            doorTrapped = ConvertToShortData();
            trapDetected = ConvertToShortData();
            trapLaunchTargetXCoordinate = ConvertToShortData();
            trapLaunchTargetYCoordinate = ConvertToShortData();
            keyItem = ConvertToStringData(8);
            doorScript = ConvertToStringData(8);
            detectionDifficulty = ConvertToIntData();
            lockDifficulty = ConvertToIntData();
            openLocationX = ConvertToShortData();
            openLocationY = ConvertToShortData();
            closeLocationX = ConvertToShortData();
            closeLocationY = ConvertToShortData();
            lockpickString = ConvertToIntData();
            travelTriggerName = ConvertToUnknownData(24);
            dialogSpeakerName = ConvertToIntData();
            dialogResRef = ConvertToStringData(8);
            unknown = ConvertToUnknownData(8);
            
            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }

        internal double ConvertToDoubleData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToDouble(byteArray, currentOffset);
        }
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(name);
            CopyBytesToArray(wedId);
            CopyBytesToArray(flags);
            CopyBytesToArray(indexFirstVertexOpen);
            CopyBytesToArray(countVerticesOpen);
            CopyBytesToArray(countVerticesClosed);
            CopyBytesToArray(indexFirstVertexClosed);
            CopyBytesToArray(minBoundingBoxOpenLeft);
            CopyBytesToArray(minBoundingBoxOpenTop);
            CopyBytesToArray(minBoundingBoxOpenRight);
            CopyBytesToArray(minBoundingBoxOpenBottom);
            CopyBytesToArray(minBoundingBoxClosedLeft);
            CopyBytesToArray(minBoundingBoxClosedTop);
            CopyBytesToArray(minBoundingBoxClosedRight);
            CopyBytesToArray(minBoundingBoxClosedBottom);
            CopyBytesToArray(indexFirstVertexImpededOpen);
            CopyBytesToArray(countVerticesImpededOpen);
            CopyBytesToArray(countVerticesImpededClosed);
            CopyBytesToArray(indexFirstVertexImpededClosed);
            CopyBytesToArray(hp);
            CopyBytesToArray(ac);
            CopyBytesToArray(doorOpenSound);
            CopyBytesToArray(doorCloseSound);
            CopyBytesToArray(cursorIndex);
            CopyBytesToArray(trapDetectionDifficulty);
            CopyBytesToArray(trapRemovalDifficulty);
            CopyBytesToArray(doorTrapped);
            CopyBytesToArray(trapDetected);
            CopyBytesToArray(trapLaunchTargetXCoordinate);
            CopyBytesToArray(trapLaunchTargetYCoordinate);
            CopyBytesToArray(keyItem);
            CopyBytesToArray(doorScript);
            CopyBytesToArray(detectionDifficulty);
            CopyBytesToArray(lockDifficulty);
            CopyBytesToArray(openLocationX);
            CopyBytesToArray(openLocationY);
            CopyBytesToArray(closeLocationX);
            CopyBytesToArray(closeLocationY);
            CopyBytesToArray(lockpickString);
            CopyBytesToArray(travelTriggerName);
            CopyBytesToArray(dialogSpeakerName);
            CopyBytesToArray(dialogResRef);
            CopyBytesToArray(unknown);
            
            return byteArray;
        }

        internal void CopyBytesToArray(double variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}