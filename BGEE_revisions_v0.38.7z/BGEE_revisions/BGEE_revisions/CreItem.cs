﻿using System;
using System.Text;

namespace BGEE_revisions
{
    internal class CreItem
    {
        internal static int size = 20; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal int arrayOffset;
        internal StringBuilder stringBuilder;

        internal String resource;
        internal short duration;
        internal short charges1;
        internal short charges2;
        internal short charges3;
        internal int flags;
        
        internal CreItem(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            resource = ConvertToStringData(8);
            duration = ConvertToShortData();
            charges1 = ConvertToShortData();
            charges2 = ConvertToShortData();
            charges3 = ConvertToShortData();
            flags = ConvertToIntData();
            
            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }
        
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal long ConvertToLongData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 8; // increase baseOffset 8 bytes
            return BitConverter.ToInt64(byteArray, currentOffset);
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }
        
        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(resource);
            CopyBytesToArray(duration);
            CopyBytesToArray(charges1);
            CopyBytesToArray(charges2);
            CopyBytesToArray(charges3);
            CopyBytesToArray(flags);
            
            return byteArray;
        }
        
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(long variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
        
        internal void PrintValues()
        {
            Console.WriteLine(resource);
            Console.WriteLine(duration);
            Console.WriteLine(charges1);
            Console.WriteLine(charges2);
            Console.WriteLine(charges3);
            Console.WriteLine(flags);
        }
    }
}