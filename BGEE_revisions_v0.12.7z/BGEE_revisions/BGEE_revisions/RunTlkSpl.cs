﻿using System;
using System.IO;
using System.Text;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlkSpl()
        {
            // make buff spells AOE
            identifiers = new String[] {
                 "Aid",
                 "Barkskin",
                 "Bless",
                 "Blood Rage",
                 "Cat's Grace",
                 // "Cure Disease",
                 "Chaotic Commands",
                 "Champion's Strength",
                 // "Cure Light Wounds",
                 // "Cure Medium Wounds",
                 // "Cure Moderate Wounds",
                 // "Cure Serious Wounds",
                 // "Cure Critical Wounds",
                 "Death Ward",
                 "Defensive Harmony",
                 "Detect Evil",
                 "Emotion, Courage",
                 "Emotion, Hope",
                 "Enchanted Weapon",
                 "Free Action", 
                 "Exaltation",
                 "Haste",
                 "Improved Haste",
                 // "Improved Invisibility",
                 // "Invisibility",
                 "Invisibility, 10' Radius",
                 "Lesser Restoration",
                 "Luck",
                 "Greater Restoration",
                 "Mass Invisibility",
                 "Negative Plane Protection",
                 "Non-Detection",
                 "Prayer",
                 "Protection From Acid",
                 "Protection From Cold",
                 "Protection From Electricity",
                 "Protection From Energy",
                 "Protection From Evil",
                 "Protection From Evil, 10' Radius",
                 "Protection From Fire",
                 "Protection From Lightning",
                 "Protection From Magic Energy",
                 "Protection From Magical Weapons",
                 "Protection From Normal Missiles",
                 "Protection From Normal Weapons",
                 "Protection From Petrification",
                 "Protection From The Elements",
                 "Recitation",
                 "Regeneration",
                 "Remove Fear",
                 "Resist Fear",
                 "Resist Fire and Cold",
                 "Righteous Wrath of the Faithful",
                 "Spirit Armor",
                 "Spirit Ward",
                 "Spiritual Clarity",
                 "Strength",
                 "Strength of One",
                 "Undead Ward"
             };
            
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", "30-ft. radius");
             }
            
             // make healing spells ranged spells
             identifiers = new String[]{
                 "Cause Light Wounds",
                 "Cause Medium Wounds",
                 "Cause Moderate Wounds",
                 "Cause Serious Wounds",
                 "Cause Critical Wounds",
                 "Cure Light Wounds",
                 "Cure Medium Wounds",
                 "Cure Moderate Wounds",
                 "Cure Serious Wounds",
                 "Cure Critical Wounds",
                 "Heal",
                 "Improved Invisibility",
                 "Invisibility",
                 "Neutralize Poison",
                 "Slow Poison",
                 "Cause Disease",
                 "Cure Disease",
                 "Remove Curse",
                 "Remove Paralysis"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", "30 ft.");
             }
            
             // un-nerf poison weapon
             identifiers = new String[]{
                 "Poison Weapon"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"Each successful hit within the next 5 rounds will inject poison into the target.*and also immediately suffers 6 poison damage \(no save\)", 
                     "Each successful hit within the next 5 rounds will inject poison into the target. The target will suffer 1 poison damage every 2 seconds for an increasing total poison duration and saving throw penalty, depending on the level of the caster:\n\n1st - 12 seconds, Save vs. Death at +1 negates\n6th - 18 seconds, Save vs. Death negates\n11th - 24 seconds, Save vs. Death at -1 negates\n16th - 30 seconds, Save vs. Death at -2 negates\n21st - 36 seconds, Save vs. Death at -3 negates");
             }
            
             // increase time of kai
             identifiers = new String[]{
                 "Kai"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"All successful attacks within the.*",
                     "All successful attacks within the next 60 seconds deal maximum damage. Additionally the caster gains a +1 bonus to THAC0 and damage.");
             }
             
             // offensive spin
             identifiers = new String[]{
                 "Offensive Spin"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"During the next 4 rounds.*", 
                     "During the next 6 rounds, the caster gains a +2 bonus to hit and damage and all attacks deal maximum damage for the duration of the ability.");            
             }
            
             // increase time of friends
             identifiers = new String[]{
                 "Friends"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 hour");
             }
            
             // Larloch's Minor Drain
             identifiers = new String[]{
                 "Larloch's Minor Drain"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "Special");
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"With this spell, the wizard drains the life force from a target and adds it to <PRO_HISHER> own. The target creature suffers 4 damage, while the Mage gains 4 Hit Points. If the Mage goes over <PRO_HISHER> maximum Hit Point total with this spell, <PRO_HESHE> loses any extra Hit Points after 1 turn.", 
                     "The target creature suffers 4 damage + 2 damage every 2 levels (max. 16 damage at level 13), while the Mage gains those Hit Points. If the Mage goes over <PRO_HISHER> maximum Hit Point total with this spell, <PRO_HESHE> loses any extra Hit Points after 1 turn.");
             }
            
             // increase time of protection from evil
             identifiers = new String[]{
                 "Protection From Evil"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 turn/level");
             }
            
             // charm person
             identifiers = new String[]{
                 "Charm Person"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"\+3 modifier", "+2 modifier");
             }
            
             // scale burning hands
             identifiers = new String[]{
                 "Burning Hands"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Any creature in the area of the flames suffers 1d3 points of damage, \+2 points for each level of the caster, to a maximum of 1d3\+20 points of fire damage.", 
                     "Any creature in the area of the flames suffers 1d6 points of damage + 1d6 points for each level of the caster up to a maximum damage to 12d3 at level 12.");
             }
            
             // Chill Touch CONVERSION TO DIMENSION JUMP
             identifiers = new String[]{
                 "Chill Touch"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Instant");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Sight of the Caster"); // change desc
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1"); // change desc
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Caster"); // change desc
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "None"); // change desc
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"\(Necromancy\)", 
                     "(Alteration)");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When the caster completes this spell, a blue glow.*", 
                     "When this spell is cast, a dimensional portal opens up in front of the caster, which he immediately steps through. Upon passing through the portal, the caster finds himself at his chosen destination. The caster always arrives at exactly the spot desired, and the dimensional door doesn't allow anyone or anything else to pass through. Spells about to be cast upon the wizard will fail, and missiles about to hit him will instead hit thin air. This spell is similar to the level 4 spell Dimension Door in that it can teleport the caster instantly. However the range is limited - the caster has to be able to spot the intended space to be transported to.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Dimension Jump"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Dimension Jump"); // change spell name itself
             }
            
             // increase time of chromatic orb
             identifiers = new String[]{
                 "Chromatic Orb"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", "Spell");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell causes a 2-ft. diameter sphere to appear in the caster's hand.*", 
                     "This spell causes a 2-foot-diameter sphere to appear in the caster's hand. When thrown, the sphere heads unerringly towards its target. The sphere inflicts magic damage and causes different effects depending upon its color. As the level of the caster improves, both the damage inflicted and number of colors known increases. The color of any given orb is chosen randomly from the colors known at the wizard's level; hence the possible status effects increase with the caster's level. The orb is occasionally even multicolored, causing multiple effects. The victim can save vs. spell against all special effects but gets no save against the damage. All special effects last for 5 rounds.\n\n1st level: 1d4 damage; White - Light (-4 penalty to saving throws)\n3rd level: 1d6 damage; Aquamarine - Magnetism (-4 penalty to AC)\n5th level: 1d8 damage; Red - Pain (target bleeds for 1d10 for the next 5 rounds)\n7th level: 1d10 damage; Green - Poison (1 hp/3 seconds)\n9th level: 2d6 damage; Yellow - Blindness\n11th level: 2d8 damage; Violet - Slow\n13th level: 2d10 damage; Blue - Paralysis\n15th level: 2d10 damage; Rainbow - Increased chance of affecting the target with more than 1 status effect (each requiring a separate save)");
             }
            
             // increase time of Luck
             identifiers = new String[]{
                 "Luck"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 hour");
             }
            
             // change Knock
             identifiers = new String[]{
                 "Knock"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The Knock spell opens locked, held, or wizard-locked doors. It opens secret doors as well as locked boxes or chests. It does not raise barred gates or similar impediments.", 
                     "The Knock spell creates a magical force that the wizard creates through his/her hand motions. Once released, it pushes forward, harming foes or objects alike. If aimed at a creature, it has to save vs. Spell at a -1 penalty or take 2d4 crushing damage +1d2 every 2 levels of the caster (max. 8d4 at level 15) and be knocked unconcious for 1 round + 2 seconds every 2 levels of the caster (max. 24 seconds at level 15). If the creature successfully saves, the sleep effect is negated and it takes only half the damage. If directed at objects, the Knock spell opens locked, held, or wizard-locked doors. It opens secret doors as well as locked boxes or chests. It does not raise barred gates or similar impediments, as the force is of insuffient strength to deal with these kind of obstacles.");
             }
            
             // change Snilloc's Snowball Swarm
             identifiers = new String[]{
                 "Snilloc's Snowball Swarm"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"doing 1d3 points of cold damage per level, up to a maximum of 8d3 points at level 8. Against fire-using or fire-dwelling creatures, it inflicts 1d6 points of cold damage per level, up to a maximum of 8d6 points at level 8.", 
                     "doing 4d6 points of cold damage per level, + 3 points of cold damage per level up to a maximum of 4d6 + 30 points at level 10.");
             }
            
             // change Web
             identifiers = new String[]{
                 @"Web( )?\n\(Evocation\)"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"Saving Throw vs. Spell with a -2", 
                     "Saving Throw vs. Paralyzation");
             }
            
             // DETECT EVIL CONVERSION TO RESIST ELEMENTS (WIZARD ONLY)
             identifiers = new String[]{
                 @"Detect Evil\n\(Divination\)\n\nLevel: 2"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
                 
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
            
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Caster"); // change desc
                 
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5"); // change desc
                 
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "15-ft. radius"); // change desc
                 
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "None"); // change desc
                 
                 EditTlkExistingEntry(identifier, 
                     "This spell discovers emanations of evil from any creature. Any evil creature within the range of the spell will glow red briefly.", 
                     "By casting this spell, the caster confers a partial resistance to the elements fire, ice and lightning to all surrounding allied creatures. The amount of resistance gained depends on the caster's level: At level 1, the resistance is 20%. For every additional level another 2% is added, for a maximum of 50% resistance at level 16. The duration of the spell equally increases: It starts with 2 turns and is raised by 2 rounds per level of the caster, capping at 1 hour at level 16.");
                 
                 EditTlkExistingEntry(identifier, 
                     identifier, "Resist Elements\n(Alteration)"); // change spell name in desc
            
                 // THE NAME ITSELF IS CHANGED IN THE SPL BATCHER! (SPECIAL CASE)
             }
            
             // Know Alignment CONVERSION to Know Opponent
             identifiers = new String[]{
                 "Know Alignment"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", "Special"); // change desc
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 turn + 6 rounds / 2 levels"); // change desc
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", "2"); // change desc
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", "30-ft. radius"); // change desc
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", "None"); // change desc
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"A Know Alignment spell enables the Mage to exactly read the aura of a creature. If the creature rolls a successful Saving Throw vs. Spell, the caster learns nothing about that particular creature from the casting. When a character is hit by this spell, he will glow red if evil, green if good, and white if neutral. Certain magical devices negate the power of the Know Alignment spell.", 
                     "When 'Know Opponent' is cast, the caster's eyes glow with magical energy, enabling him to read the aura of a creature, and determine the creature's strengths and weaknesses. For the duration of the spell, the target's physical resistances are lowered by 10% and all attacks against the target creature are made with a +2 bonus to the attack roll. Certain magical devices negate the power of the Know Opponent spell, and the spell has no effect on creatures who don't emanate auras, such as constructs. Magic resistance does not affect this spell."); // change desc
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Know Opponent"); // change spell name in desc
                 
                 EditTlkExistingEntry(identifier + @"\Z", identifier, "Know Opponent"); // change name of spell
            
             }
            
             // increase time of mirror image
             identifiers = new String[]{
                 "Mirror Image"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 hour");
                 EditTlkExistingEntry(identifier + @"( )?\n", @"2 to 8 exact duplicates", "2 to 8 exact duplicates (2 images at level 3 up to 8 images at level 21)");
             }
            
             // infravision conversion to true strike
             identifiers = new String[]{
                 "Infravision"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Personal");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 4 rounds/2 levels");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Caster");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Upon the casting of this spell the recipient gains the ability to see with infravision, just as an elf or a dwarf would. This effect lasts for the duration of the spell or until dispelled.", 
                     "This spell grants the caster otherworldly sight, resulting in preternatural accuracy for a short period. While the spell is in effect attack rolls are made with a +1 THAC0 bonus + 1 THAC0 bonus per 4 levels of the caster (up to a maximum of +5 THAC0 bonus at level 13) and the chance to score critical hits is increased by 5%.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "True Strike"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "True Strike"); // change spell name itself
             }
            
             // improve armor
             identifiers = new String[]{
                 "Armor"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"By means of this spell, the wizard creates a magical field of force that serves as if it were scale mail armor \(AC 6\).", 
                     "This spells creates a magical field of force, which sets the caster's armor class to 6. The armor class will improve by 1 every 3 levels, until level 10, where it reaches AC 3."
                 );
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Magical Armor"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Magical Armor"); // change spell name itself
             }
            
             // increase time of Sleep
             identifiers = new String[]{
                 "Sleep"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"All creatures to be affected by the Sleep spell must be within a 15-ft. radius. Creatures in the area of effect must make a Saving Throw vs. Death with a -3 penalty or fall asleep. Monsters with 5 Hit Dice or more are unaffected. Attacks against sleeping opponents never miss.", 
                     "All creatures in the area of effect must make a Saving Throw vs. Spell or fall asleep. Attacks against sleeping opponents never miss, however sleeping opponents will awake, when struck.");
             }
            
             // increase time of blur
             identifiers = new String[]{
                 "Blur"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 hour");
             }
            
             // increase time of Shield
             identifiers = new String[]{
                 "Shield"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "2 hours");
             }
             
             // change BLINDNESS
             identifiers = new String[]{
                 "Blindness"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", "-4 penalty", "-10 penalty");
             }
            
             // change reflected image
             identifiers = new String[]{
                 "Reflected Image"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The image will disappear with a successful Dispel Magic, when attacked, or when the spell's duration expires.", 
                     "The image is immune to all types of damage and will only disappear with dispelling or anti-illusionary spells, or when the spell's duration expires.");
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "2 turns + 1 turn/5 levels (max. 5 turns at level 16");
             }
            
             // change deafness
             identifiers = new String[]{
                 "Deafness"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Saving Throw vs. Spell", 
                     "Saving Throw vs. Breath");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Deafened spellcasters have a 50% chance to miscast any spells. This deafness can be done away with by means of a Dispel Magic spell or a Cure Disease spell.", 
                     "For 3 rounds, spellcasters will be shaken by their inability to hear and not be able to cast any spells. After this, deafened spellcasters have a 50% chance to miscast spells. This deafness will endure indefinitely and can be done away only with by means of a Dispel Magic spell or a Cure Disease spell.");
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "2 turns + 1 turn/5 levels (max. 5 turns at level 16");
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", "10-ft. radius");
             }
            
             // change unluck
             identifiers = new String[]{
                 "Unluck"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"The target receives a -1 penalty to their Saving Throws, attack rolls, and minimum damage/healing rolls as well as -5% to all thieving skills. Furthermore, damage dice for all effects outside a weapon's base damage is increased by 1. For example, a 6d6 fireball will do 7d6 damage, and a flaming long sword that deals 1d8\+2 slashing plus 1d3 fire damage will deal 1d8\+2 slashing plus 1d4 fire damage instead. There is no Saving Throw for this spell, although magic resistance may stop it.", 
                     "The target receives a -3 penalty to their Saving Throws, attack rolls, and minimum damage/healing rolls as well as -50% to all thieving skills. Furthermore, damage dice for all effects outside a weapon's base damage is increased by 3. There is no Saving Throw for this spell, although magic resistance may stop it.");
             }
            
             // change power word sleep
             identifiers = new String[]{
                 "Power Word, Sleep"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"The creature targeted must have less than 20 Hit Points and gets no Saving Throw. Magically sleeping opponents can be attacked with substantial bonuses. The Sleep effect will last for 5 rounds. This spell has no effect on creatures with more than 20 Hit Points.", 
                     "If the creature targeted has less than 20 Hit Points, it gets no Saving Throw. Else, the target must Save vs. Spell at a -1 penalty. The Sleep effect will last for 5 rounds.");
             }
            
             // change decastave
             identifiers = new String[]{
                 "Decastave"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 turn + 2 rounds/level");
             }
             
             // change vocalize
             identifiers = new String[]{
                 "Vocalize"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "12 hours");
             }
            
             // change ray of enfeeblement
             identifiers = new String[]{
                 "Ray of Enfeeblement"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"The victim is reduced to a Strength of 5 for the duration of the spell unless a Save vs. Spell is made. This spell does not affect combat bonuses due to magical items, and those conferring increased Strength function normally. However the target receives all of the penalties for a 5 Strength such as attack and damage penalties as well as lower weight allowance.",  
                     "The victim is reduced to a Strength of 5, suffers a -5 penalty to attack and damage rolls and has its movement speed reduced by 50% unless they make a successful saving throw vs. Paralyzation penalty.");
             }
            
             // change detect invisibility
             identifiers = new String[]{
                 "Detect Invisibility"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "5 rounds");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"In addition, this spell enables the wizard to detect hidden or concealed creatures \(e.g., Thieves hiding in shadows, halflings in underbrush, and so on\).",  
                     "Instantly and once each round for 5 rounds after the spell is cast, all concealed enemies within the area of effect will become visible to the caster and his allies. In addition, this spell enables the wizard to detect hidden or concealed creatures (e.g., Thieves hiding in shadows, halflings in underbrush, and so on).");
             }
            
             // Melf's Acid Arrow
             identifiers = new String[]{
                 "Melf's Acid Arrow"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"2d4",  
                     "3d4");
             }
            
             // change spell thrust
             identifiers = new String[]{
                 "Spell Thrust"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", "10-ft. radius");
             }
            
             // Lightning Bolt
             identifiers = new String[]{
                 "Lightning Bolt"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Upon casting this spell, the wizard releases a powerful stroke of electrical energy that inflicts 1d6 points of damage per level of the caster \(maximum damage of 10d6\) to each creature within its area of effect. A successful Saving Throw vs. Spell reduces this damage to half \(round fractions down\). If the lightning bolt intersects with a wall, it will bounce until it reaches its full length.", 
                     "Upon casting this spell, the wizard releases a powerful stroke of electrical energy that inflicts 5d6 points of base damage + 1d6 per level of the caster (maximum damage of 12d6) to each creature within its area of effect. A successful Saving Throw vs. Spell reduces this damage to half (round fractions down).");            
             }
             
             // Lance of Disruption
             identifiers = new String[]{
                 "Lance of Disruption"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"5d4", 
                     "5d6");            
             }
            
             // change clairvoyance
             identifiers = new String[]{
                 "Clairvoyance"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"The Clairvoyance spell empowers the wizard to see in <PRO_HISHER> mind the geographical features and buildings of the region <PRO_HESHE> is currently exploring. It extends to a great range, but cannot reveal creatures or their movements.", 
                     "This spell grants an unnatural perception of things to come. Once Clairvoyance is cast, the caster receives instantaneous warnings of impending danger or harm. He becomes impossible to surprise and cannot be backstabbed. In addition, the spell gives a general idea of what action might be taken to best protect oneself, granting a +2 insight bonus to AC and saves vs. breath. The effects last for the duration of the spell, and cannot be dispelled.");
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 hour + 6 rounds/3 levels");
             }   
            
             // hold person
             identifiers = new String[]{
                 @"Hold Person( )?\n\(Enchantment/Charm\)\n\nLevel: 3"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"Those who save vs. Spell at -1", 
                     "Those who save vs. Paralyze at -1");
             }
            
             // vampiric touch
             identifiers = new String[]{
                 "Vampiric Touch"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"When this spell is cast, the target loses 1d6 Hit Points for every 2 caster levels, to a maximum drain of 6d6 for a 12th-level caster.", 
                     "When this spell is cast, the target loses 2d6 Hit Points at caster level 6 + 1d6 for every 2 caster levels thereafter, to a maximum drain of 8d6 for a 18th-level caster.");
             }
            
             // wraithform conversion to animate dead 
             identifiers = new String[]{
                 "Wraithform"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"\(Alteration, Illusion\)", 
                     "(Necromancy)");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "8 hours");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30 ft.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Special");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, the wizard and all of <PRO_HISHER> gear become insubstantial. The caster is subject only to magical or special attacks, including those by weapons of \+1 or better enchantment, or by creatures otherwise able to affect those struck only by magical weapons. The wizard also gains 25% resistance to magic damage. While in wraithform, the caster cannot cast either arcane or divine spells", 
                     "This spell causes a skeleton warrior to rise and serve the caster under any conditions. The type of skeleton warrior that appears depends upon the level of the priest casting the spell.\n  1st - 2nd: 1x 3 HD skeleton warrior wielding a long sword.\n  3rd - 4th: 2x 3 HD skeleton warriors wielding a long sword.\n  5th - 6th: 1x 5 HD skeleton warrior wielding a long sword +1.\n  7th - 8th: 2x 5 HD skeleton warriors wielding a long sword +1.\n  9th - 10th: 1x 7 HD skeleton warrior wielding a bastard sword +1.\n  11th - 12th: 2x 7 HD skeleton warriors wielding a bastard sword +1.\n  13th - 14th: 1x 9 HD skeleton warrior wielding a two-handed sword +1.\n  abov 14th: 2x 9 HD skeleton warriors wielding a two-handed sword +1.\nThe skeleton warrior can follow the caster, remain in an area and attack any creature entering the place, etc. It remains animated until it is destroyed in combat, 8 hours pass, or it is turned. This spell cannot be dispelled.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Animate Dead"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Animate Dead"); // change spell name itself
             }
             
             // Ghost Armor
             identifiers = new String[]{
                 "Ghost Armor"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "6 hours");
             }
            
             // Slow
             identifiers = new String[]{
                 "Slow"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"penalty of -4. Creatures save at -4 vs. Spell.",
                     "penalty of -2. Creatures save at -2 vs. Spell.");
             }
             
             // Haste
             identifiers = new String[]{
                 "Haste"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5 rounds + 1 round/level");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, all creatures affected.*",
                     "When this spell is cast, all creatures affected will move at 150% of their base speed, receive 150% of their regular attacks per round and gain an attack speed bonus of 2. Thus, a creature moving at 6 and attacking twice per round would move at 9 and attack three times per round.\n\nThis spell is not cumulative with itself or with other similar magic. Spellcasting and spell effects are not affected. Note that this spell negates the effects of a Slow spell.");
             }
            
             // hold undead
             identifiers = new String[]{
                 "Hold Undead"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Saving Throws", 
                     "Saving Throws vs. Paralyze at -1");
             }
            
             // Minor Spell Deflection
             identifiers = new String[]{
                 "Minor Spell Deflection"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 1 round/level");
             }
            
             // Otiluke's Resilient Sphere conversion to Protection from Poison
             identifiers = new String[]{
                 "Otiluke's Resilient Sphere"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "7");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Touch");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30-ft. Radius  ");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(Alteration)", 
                     "(Abjuration)");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, the result is a globe of shimmering force that encloses the subject creature if it fails to Save vs. Spell. The resilient sphere will contain its subject for the duration of the spell. The sphere is completely immune to all damage; in fact, the only method of removing the sphere is a successful Dispel Magic. Hence, the creature caught inside the globe is completely safe from all attacks, but at the same time completely unable to affect the outside world.", 
                     "When this spell is cast, it will confer full immunity to all poison effects and being poisoned to all allied creatures within a 30-ft. radius. This means that everyone affected by the spell will not able to be poisoned (say, from a spider), and will not suffer poison damage (e.g. Cloudkill, Poison Clouds spells etc. The spell lasts for 1 turn per level of the caster or until dispelled.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Protection from Poison"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Protection from Poison"); // change spell name itself
             }
            
             // Minor Globe of Invulnerability
             identifiers = new String[]{
                 "Minor Globe of Invulnerability"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 1 round/level");
             }
            
             // Ice Storm
             identifiers = new String[]{
                 "Ice Storm"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"2d8",  
                     "3d8");
             }
             
             // Fire Shield Red
             identifiers = new String[]{
                 @"Fireshield \(Red\)"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"The red Fireshield protects the user.*",  
                     "This spell conjures fire shield around the caster. This shield grants the user 75% fire resistance at level 7 + 1% every level thereafter (max 100% at level 32) and also protects the caster from attacks made within a 5' radius. Opponents that hit the caster with a weapon or spell from within this radius will suffer 4d4 points of fire damage. Multiple castings of this spell are not cumulative, but it can be used in conjunction with similar spells. Tiny and small flying creatures cannot pass through the caustic barrier. Magic resistance does not affect this spell.");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Fire Shield"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z",
                     identifier, "Fire Shield"); // change spell name itself
                 
                 EditTlkExistingEntry(@"Fire Shield \(Red\)\Z",
                     @"Fire Shield \(Red\)", "Fire Shield"); // change spell name itself
             }

             
             // Fire Shield Blue Conversion to ACID SHIELD
             identifiers = new String[]{
                 @"Fireshield \(Blue\)"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"The blue Fireshield protects the user.*",  
                     "This spell conjures an acid shield around the caster. This shield grants the user 75% acid resistance at level 7 + 1% every level thereafter (max 100% at level 32) and also protects the caster from attacks made within a 5' radius. Opponents that hit the caster with a weapon or spell from within this radius will suffer 4d4 points of acid damage. Multiple castings of this spell are not cumulative, but it can be used in conjunction with similar spells. Tiny and small flying creatures cannot pass through the caustic barrier. Magic resistance does not affect this spell.");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Acid Shield"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z",
                     identifier, "Acid Shield"); // change spell name itself
                 
                 EditTlkExistingEntry(@"Fire Shield \(Blue\)\Z",
                     @"Fire Shield \(Blue\)", "Acid Shield"); // change spell name itself
             }

             // Stoneskin
             identifiers = new String[]{
                 "Stoneskin"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"For every 2 levels of the caster, an additional skin is gained upon casting. For example, a 10th-level wizard would receive 5 skins while a 20th-level wizard would receive 10. For each skin the wizard possesses, the spell will stop one attack, so a 10th-level wizard would be protected from the first 5 attacks made against <PRO_HIMHER>, but the 6th would affect <PRO_HIMHER> normally.",  
                     "The caster receives a number of skins equalling half his/her level, up to 15 skins at level 30. For each skin the wizard possesses, one attack will be absorbed, so a 12th-level wizard would be protected from the first 6 attacks made against <PRO_HIMHER>, but the 7th would affect <PRO_HIMHER> normally.");
             }
             
             // Spirit Armor
             identifiers = new String[]{
                 "Spirit Armor"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "4 hours");
             }
            
             // Contagion
             identifiers = new String[]{
                 "Contagion"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"Strength, Dexterity, and Charisma scores are reduced by 2. The afflicted character is also Slowed. These effects persist until the character receives a Cure Disease spell.",  
                     "Strength, Dexterity, and Charisma scores are reduced by 5. The afflicted character is also Slowed. These effects persist until the character receives a Cure Disease spell. Additionally, the recipient is poisoned and is loses 1 HP every 3 seconds for 3 rounds. The poison effect increases in length every 4 levels up to 1 turn at level 35.");
             }
            
             // Emotion Hopelessness
             identifiers = new String[]{
                 "Emotion, Hopelessness"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"save vs. Spell",  
                     "save vs. Spell at a -2 penalty");
             }
             
             // Polymorph Self
             identifiers = new String[]{
                 "Polymorph Self"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"When this spell is cast, the wizard is able to assume the form of another creature.*",  
                     "When this spell is cast, the wizard is able to assume the form of another creature:\n\n - Mustard Jelly\n - Ogre Mage\n - Fire Salamander\n - Sword Spider\n - Troll\n - Winter Wolf\n\nThe caster also gains the form's physical mode of locomotion and breathing. This spell does not give the caster access to the new form’s other abilities such as special attacks or magic, nor does it run the risk of the wizard changing personality and mentality. For the duration of the spell, the caster may transform into any of the new forms at any time, as many times as he wishes. The caster gains the natural attacks of the new form in some cases and may use weapons in others. The wizard's mental attributes are not affected, but physical attributes are changed to adhere to the new form. Also, any natural protections that the new form offers are conferred to the wizard.");
             }
            
             // Polymorph Other
             identifiers = new String[]{
                 "Polymorph Other"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"The transformation is instant and permanent until a Dispel Magic is cast successfully upon the affected creature.",  
                     "The effectiveness of this spell is dependent upon the target's level, with weak creatures being relatively easy to transmute and more powerful creatures being very difficult. Creatures with less than 7 HD/levels save at a -4 penalty, those with 8 - 14 HD/levels save at a -2 penalty, and those with 15 - 22 more HD/levels save normally and those beyond 22 save with a +2 bonus. The transformation is instant and permanent until a dispel magic is cast successfully upon the affected creature.");
             }
            
             // Enchanted Weapon
             identifiers = new String[]{
                 "Enchanted Weapon"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 hour + 1 hour/7 levels");            
             }
            
             // Wizard Eye
             identifiers = new String[]{
                 "Wizard Eye"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "6 rounds + 1 round/level");            
             }
            
             // Hold Monster
             identifiers = new String[]{
                 "Hold Monster"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"Saving Throw vs. Spell is made with a -2 penalty", "Saving Throw vs. Paralyze is made with a -2 penalty");            
             }
            
             // Animate Dead Conversion to Revive Skeleton Archer
             identifiers = new String[]{
                 @"Animate Dead\n\(Necromancy\)\n\nLevel: 5"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "8 hours");
            
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30 ft.");
                 
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Level: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5");
            
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Special");
            
                 EditTlkExistingEntry(identifier, 
                     @"This spell causes a skeleton warrior.*", 
                     "This spell causes one or more skeleton archers to rise and serve the caster under any conditions. The type and number of skeleton archers that appears depends upon the level of the wizard casting the spell:\n\n  8th - 9th:      1x 4 HD skeleton archer using a long bow and fire arrows.\n  10th - 11th:    2x 4 HD skeleton archers using a long bow and fire arrows.\n  12th - 13th:    1x 6 HD skeleton archer using a long bow and arrows +1.\n  14th - 15th:    2x 6 HD skeleton archers using a long bow and arrows +1.\n  16th - 18th:    1x 8 HD skeleton archer using a +1 long bow and ice arrows +1.\n  18th - 20th:    2x 8 HD skeleton archers using a +1 long bow and ice arrows +1.\n  20st - 22nd:    1x 10 HD skeleton archer using a +2 long bow and arrows +2.\n  22nd and above: 2x 10 HD skeleton archers using a +2 long bow and arrows +2.\n\nThe skeleton archers can follow the caster, remain in an area and attack any creature entering the place, etc. They remain animated until it is destroyed in combat, 8 hours pass, or it is turned. This spell cannot be dispelled.");
            
                 EditTlkExistingEntry(identifier, 
                     "Animate Dead", 
                     "Revive Skeleton Archer"); // change spell name in spell description
                 
                 // EditTlkExistingEntry("Animate Dead" + @"\Z", 
                     // "Animate Dead", 
                     // "Revive Skeleton Archer"); // change spell name itself
             }
            
             // Oracle
             identifiers = new String[]{
                 "Oracle"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "5 rounds");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"When cast, this spell will cancel all Illusion/Phantasm spells of 5th level and lower within its area of effect.",  
                     "When cast, this spell will cancel all Illusion/Phantasm spells of 5th level and lower within its area of effect instantly and every round for the next 5 rounds.");        
             }
            
             // Summon Shadow Conversion to Waves of Fatigue
             identifiers = new String[]{
                 "Summon Shadow"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30 ft.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30-ft. radius");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Neg.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"This spell summons three 4-HD shadows.*",  
                     "Surges of negative energy render all hostile living creatures in the spell's area of effect fatigued, as if they haven't rested in a day (Save vs. Breath negates). Fatigued creatures receive all usual penalties associated with being tired; furthermore, they will move only at 75% of the their base speed, use only 75% of their usual attacks per round and THAC0 and moreover suffer a an added -1 penalty to Strength and Dexterity at caster level 9 + a further -1 penalty to Strength and Dexterity every 6 levels of the caster (up to a maximum of -5 at level 33). Multiple castings of this spell are cumulative.");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     @"\(Conjuration/Summoning, Necromancy\)",  
                     "(Necromancy)");        

                 EditTlkExistingEntry(identifier + @"( )?\n\(", 
                     identifier,  
                     "Waves of Fatigue");
                 
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier,  
                     "Waves of Fatigue"); 
             }
            
             // Confusion
             identifiers = new String[]{
                 "Confusion"
             };
             foreach (String identifier in identifiers)
             {   
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"-2 penalty",
                     "-1 penalty");
             }
            
             // Lower Resistance
             identifiers = new String[]{
                 "Lower Resistance"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", "1 turn + 1 round/3 levels");
                 EditTlkExistingEntry(identifier + @"( )?\n", @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", "10-ft. radius");
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When cast upon a target creature, this spell will lower the Magic Resistance of this creature by 10% \+ 1% per level of the caster. There is no Saving Throw, and the target's Magic Resistance, if any, does not affect this spell. For example, if a creature has 60% Magic Resistance and this spell is cast on it by a 15th-level Mage, then the target's Magic Resistance would be lowered by 25% automatically. This effect is cumulative for each casting of this spell: If Lower Resistance was cast upon the same creature again, the creature's Magic Resistance would be 60% - 25% \(initial casting\) - 25% \(current casting\), which would leave the creature with 10% Magic Resistance. This spell will last until its duration expires and cannot be dispelled.", 
                     "When cast upon a target creature, this spell will lower the Magic Resistance of this creature by 25% + 5% every 3rd level of the caster. There is no Saving Throw, and the target's Magic Resistance, if any, does not affect this spell. The effect is cumulative for each casting of this spell. This spell will last until its duration expires and cannot be dispelled.");            
             }
            
             // Chaos
             identifiers = new String[]{
                 "Chaos"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"-4 penalty",
                     "-2 penalty");
             }
            
             // Minor Spell Turning
             identifiers = new String[]{
                 "Minor Spell Turning"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 1 round/level");
             }
            
             // Spell Shield
             identifiers = new String[]{
                 "Spell Shield"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
             }
            
             // Spell Deflection
             identifiers = new String[]{
                 "Spell Deflection"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
             }
             
             // Improved Haste
             identifiers = new String[]{
                 "Improved Haste"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5 rounds + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "The affected creature functions.*",
                     "When this spell is cast, all creatures affected will move at 150% of their base speed, receive 200% of their regular attacks, gain an attack speed bonus of 2 and a casting speed bonus of 1. Thus, a creature moving at 6 and attacking twice per round would move at 9 and attack four times per round. Similarly, a spell with a casting time of 7 will be cast with a casting time of 6.\n\nThis spell is not cumulative with itself or with other similar magic. Spellcasting and spell effects are not affected. Note that this spell negates the effects of a Slow spell.");
             }
            
             // Globe of Invulnerability
             identifiers = new String[]{
                 "Globe of Invulnerability"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
             }
            
             // Flesh to Stone
             identifiers = new String[]{
                 "Flesh to Stone"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The intended subject of the spell receives a Saving Throw vs. Spell to avoid the effect.", 
                     "The intended subject of the spell receives a Saving Throw vs. Spell with a -4 penalty to avoid the effect.");            
             }
            
             // Disintegrate
             identifiers = new String[]{
                 "Disintegrate"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"the creature must make a Saving Throw vs. Spell or be transformed into dust.", 
                     "the creature must make a Saving Throw vs. Spell with a -4 penalty or be transformed into dust.");            
             }
            
             // Chain Lightning
             identifiers = new String[]{
                 "Chain Lightning"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The lightning causes 1d6 points of damage for every 2 levels of the caster. If the target of the lightning saves vs. Spell, only half damage is inflicted. Thus, a 12th-level wizard will cause 6d6 damage to a victim \(3d6 if the victim makes <PRO_HISHER> Saving Throw vs. Spell\).", 
                     "The lightning causes 5d6 points base damage at level 1; one dice is added every 4 levels of the caster, up to a maximum damage cap of 12d6 at level 29. The victim always is allowed the chance to save vs. Spell to only receive half the damage.");            
             }
            
             // Pierce Magic
             identifiers = new String[]{
                 "Pierce Magic"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "First, the creature's Magic Resistance.*", 
                     "First, the creature's Magic Resistance, if any, will be lowered by 40% at spellcaster level 9 + 5% every 4 levels of the caster; second, one spell protection of 8th level or lower affecting the creature, if any, will be canceled. For example, if this spell were cast by a 17th-level wizard, the target creature would lose 50% of its Magic Resistance from its current total (reducing it to 0 if less than that remains), and one 8th- or lower level spell protection affecting the creature would be dispelled. Spells affected by Pierce Magic are Entropy Shield, Globe of Invulnerability, Magic Resistance, Minor Globe of Invulnerability, Minor Spell Deflection, Minor Spell Turning, Shield of the Archons, Spell Deflection, Spell Immunity, Spell Shield, and Spell Turning. The target's Magic Resistance, if any, does not affect this spell, nor do any of the spell protections. Magic Resistance remains lowered for 1 round per level of the caster.\n\nNote: This spell may be used to remove magical protections even from creatures which could not normally be targetted by spells because they are invisible.");            
             }
            
             // True Sight
             identifiers = new String[]{
                 "True Sight"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Instantly and once each round for 1 turn", 
                     "Instantly and once per round for 1 turn at level 11 + 1 round/2nd level thereafter (max. 2 turns at level 31)");   
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The area of effect is roughly a 120-ft. radius around the caster. ", 
                     "");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Finally, the spell also protects the caster from magical blindness for 1 turn after it is cast.", 
                     "Finally, the spell also protects the caster from magical blindness for 1 turn at level 11 + 1 round/2nd level thereafter (max. 2 turns at level 31) after it is cast.");
             }
            
             // Protection From The Elements
             identifiers = new String[]{
                 "Protection From The Elements"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "When the spell is cast, it confers.*", 
                     "When the spell is cast, it confers near immunity (90% resistance) to all elemental attacks—such as fire, cold, acid, and electricity, whether magical or non magical—from spells, weapons, wands, breath weapons, etc.");            
             }
            
             // Sphere of Chaos
             identifiers = new String[]{
                 "Sphere of Chaos"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Saving Throw vs. Spell", 
                     "at -1");
             }
            
             // Spell Turning
             identifiers = new String[]{
                 "Spell Turning"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 1 round/level");
             }
            
             // Control Undead
             identifiers = new String[]{
                 "Control Undead"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "3 turns + 2 rounds/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "10-ft. Radius");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"If the undead have 3 Hit Dice or less, then there is no Saving Throw allowed; however, if they have 4 Hit Dice or more, a Save vs. Spell is allowed to negate the effect.", 
                     "If the undead have 5 Hit Dice or less, then there is no Saving Throw allowed; however, if they have 6 Hit Dice or more, a Save vs. Spell with a -3 penalty is allowed to negate the effect. Magic resistance may negate the effects of this spell");            
             }
            
             // Finger of Death
             identifiers = new String[]{
                 "Finger of Death"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Save vs. Spell is made with a -2 penalty. A creature that successfully saves still receives 2d8\+1 points of damage.", 
                     "Save vs. Death is made with a -3 penalty. A creature that successfully saves still receives 6d6 points of damage.");            
             }
            
             // Protection From Energy
             identifiers = new String[]{
                 "Protection From Energy"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "When the spell is cast, it confers.*", 
                     "When the spell is cast, it confers full immunity to all energy attacks—such as fire, cold, acid, magic and electricity, whether magical or non magical—from spells, weapons, wands, breath weapons, etc. Being protected from energy, the caster also receives 50% magic resistance.");
             }
            
             // Pierce Shield
             identifiers = new String[]{
                 "Pierce Shield"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, it launches a massive attack on an enemy wizard's spell defenses. The target's Magic Resistance will be lowered by 10% \+ 1% per level of the caster. Next, Pierce Shield will cancel one spell protection of any level. For example, if this spell was cast by a 15th-level wizard, the target creature would lose 25% Magic Resistance from its current total, reducing it to 0 if less than that remains, as well as canceling one spell protection if the Mage currently has one.", 
                     "When this spell is cast, it launches a massive attack on an enemy wizard's spell defenses, similarly to the level 6 spell Pierce Magic. The target's Magic Resistance, however, will be lowered by 100% and the spell will cancel one spell protection of any level.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The resistance remains lowered for 1 round per level of the caster. It cannot be dispelled.", 
                     "The resistance remains lowered for 1 turn at base level 13 and increases by 2 rounds every 4 levels of the caster. It cannot be dispelled.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 2 rounds/4 levels");
             }
            
             // Bigby's Clenched Fist
             identifiers = new String[]{
                 "Bigby's Clenched Fist"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"It initially smashes the target for 3d6 damage with no save, and the target is held. In the second round, the target can save vs. Paralysis at -2 to escape. If they fail to save, the hand does 4d6 damage. The following round, the target can save vs. Paralysis with no penalty. If they make the save, they are free to move, if they fail, the spell does 6d6 damage and holds them for 2 rounds. After the 4th round, the spell is finished.", 
                     "It initially smashes the target for 6d6 damage with no save, and the target is held. In the second round, the target can save vs. Paralysis at -6 to escape. If they fail to save, the hand does 5d6 damage. The following round, the target can save vs. Paralysis with a -4 penalty. If they make the save, they are free to move, if they fail, the spell does 4d6 damage and holds them for 2 rounds. After the 4th round, the spell is finished.");
             }
            
             // Symbol, Stun
             identifiers = new String[]{
                 "Symbol, Stun"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"causing all enemies within the area to make a Save vs. Spell at a -4 penalty or be stunned for 2 rounds \+ 1 round for every 3 levels of the caster.", 
                     "causing all enemies within the area to make a Save vs. Spell at a -6 penalty or be stunned for 6 turn + 1 round for every 4 levels of the caster.");
             }
            
             // Symbol, Death
             identifiers = new String[]{
                 "Symbol, Death"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"causing all enemies within the area to make a Save vs. Death or die. Creatures with more than 60 current Hit Points are immune to this effect.", 
                     "causing all enemies within the area to make a Save vs. Death or die. Creatures with more than 60 current Hit Points are immune to this effect, but they will be struck by 8d6 magic damage.");
             }
            
             // Symbol, Fear 
             // identifiers = new String[]{
             //     "Symbol, Fear"
             // };
             // foreach (String identifier in identifiers)
             // {
             //     Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
             // 
             //     EditExistingEntry(identifier + @"( )?\n", 
             //         @"causing all enemies within the area to make a Save vs. Spell at a -4 penalty or be affected by fear for 2 rounds + 1 round for every 3 levels of the caster.", 
             //         "causing all enemies to run in fear for 1 turn + 2 rounds for every 4 levels of the caster. There is no saving throw against this effect.");
             // }
            
             // Symbol, Fear // conversion to Symbol, Weakness 
             identifiers = new String[]{
                 "Symbol, Fear"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Symbol, Fear is a powerful enchantment.*", 
                     "Symbol, Weakness is a powerful enchantment that allows the priest to inscribe a symbol on the ground or any other surface. The symbol will remain there until an opponent comes too close, at which point it will explode causing all enemies within the area to make a Saving Throw vs. Spell with a -4 penalty or be afflicted with a terrible disease causing a permanent -4 loss in Constitution, Strength and Dexterity. The power of the disease increases gradually by 1 further ability penalty point for every 4 levels of the caster from level 15 onward, up to a maximum of a -8 Constitution, Strength and Dexterity penalty at level 31");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Symbol, Weakness"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Symbol, Weakness"); // change spell name itself
             }
            
             // Spell Trap
             identifiers = new String[]{
                 "Spell Trap"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The spell trap provides 30 levels of protection \(i.e., ten Flame Arrows or five Fingers of Death\). The spell trap can absorb any level of spell, from one to nine.", 
                     "The spell trap provides 30 levels of protection + 1 further level every 2 levels of the caster. The spell trap can absorb any level of spell, from one to nine.");
             }
            
             // Power Word, Kill
             identifiers = new String[]{
                 "Power Word, Kill"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The creature must have 60 or fewer current Hit Points, otherwise the spell has no effect. There is no Saving Throw.", 
                     "The creature must have 60 or fewer current Hit Points, otherwise 10d6 magic damage will be inflicted upon the victim. There is no Saving Throw.");
             }
            
             // Wail of the Banshee
             identifiers = new String[]{
                 "Wail of the Banshee"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Those who fail a Saving Throw vs. Death die instantly.", 
                     "Those who fail a Saving Throw vs. Death with a -5 penalty die instantly; enemies successfully saving are still wounded by the piercing scream (6d6 piercing damage).");
             }
            
             // Energy Drain
             identifiers = new String[]{
                 "Energy Drain"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"of 2 levels of experience. The target of this spell loses levels, Hit Dice, Hit Points, and abilities permanently. These levels can only be restored by a priest's Restoration spell.", 
                     "of 5 levels of experience and 2 Hitpoints per level of the caster. The target of this spell loses these levels abilities permanently. These levels can only be restored by a priest's Restoration spell.\n\nAdditionally, the the lifeforce of the target is drained by 2 Hit Points per level of the caster and added to the caster temporarily (max. 60 Hit Points at level 30)");
             }
            
             // Bigby's Crushing Hand
             identifiers = new String[]{
                 "Bigby's Crushing Hand"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"In the first round, the spell does 2d10 damage. The victim can save at -4 vs. Paralysis to avoid being pinned. If they fail, the hand does 3d10 damage the next round. The victim can again save vs. Paralysis at -2. If they fail to save, the hand does a final 4d10 damage and disappears.", 
                     "Each round the massive hand smashes the target for 2d10 crushing damage and stuns it for 1 round unless a successful save vs. paralyzation is made at a -4 penalty. After the 10th round, the spell is finished.");
             }
             
             // Shapechange
             identifiers = new String[]{
                 "Shapechange"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"With this spell, a wizard is able.*", 
                     "With this spell, a wizard is able to assume the form of a powerful creature: that of an iron golem, a mind flayer, a greater wolfwere, a tanar'ri or a giant troll. The spellcaster becomes the creature he wishes, and gains almost all of its natural abilities. The caster's mental attributes are not affected, but physical attributes are changed to adhere to the new form. All clothes and equipment he was wearing will mold into the new form and continue to function, unseen. When the wizard returns to his natural form, they will also return to their previous state. Each alteration in form requires only a second, and no system shock is incurred.");
             }
            
             // Beltyn#s Burning Blood
             identifiers = new String[]{
                 "Beltyn's Burning Blood"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The target gets to save vs. Spell every round", 
                     "The target gets to save vs. Spell at a -2 penalty every round.");
             }
            
             // Emotion Fear
             identifiers = new String[]{
                 "Emotion, Fear"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"save vs. Spell flee for 5 rounds", 
                     "save vs. Spell at a -3 penalty flee for 1 turn");
             }
            
             // Mordenkainen's Force Missiles
             identifiers = new String[]{
                 "Mordenkainen's Force Missiles"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Each missile inflicts 2d4 points of damage .*? points of magic damage.", 
                     "Each missile inflicts 3d4 points of damage to the target + 1d4 every 3 levels of the caster (up to 6d4 at level 16) and then bursts in a 5-ft. radius concussive blast that inflicts 1 point of damage per level of the caster, to a maximum of 15 points - for example, a 12th-level wizard could conjure two force missiles, each of which strikes for 4d4+12 points of magic damage.");
             }
            
             // Shout
             identifiers = new String[]{
                 "Shout"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Any creature within this area is deafened for 9 rounds and suffers 4d6 points of magic damage. A successful Save vs. Spell negates the deafness and reduces the damage by half.", 
                     "Any creature within this area suffers 4d6 points + 1d6 every 4 levels (max. 8d6 at level 23) of piercing damage, but can save vs. Spell to halve to damage. For 3 rounds, spellcasters will also be shaken by their inability to hear and not be able to cast any spells. After this, deafened spellcasters have a 50% chance to miscast spells for 1 turn.");
             }
            
             // Vitriolic Sphere
             identifiers = new String[]{
                 "Vitriolic Sphere"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The victim suffers 1d4 points of acid damage per caster level, to a maximum of 12d4 points of damage.", 
                     "The victim suffers 6d4 points of acid damage + 1d4 acid damage every 4 levels of the caster, to a maximum of 12d4 points of damage at level 27.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"If unsuccessful, the victim continues to suffer acid damage in the following rounds, sustaining two less dice of damage each round. For example, an 8th-level wizard inflicts 8d4 damage with this spell on the first round, 6d4 on the second round, 4d4 on the third round, 2d4 on the fourth round, and the spell ends on the fifth round.", 
                     "If unsuccessful, the victim continues to suffer acid damage in the following rounds: 5d6 in round 2, 4d6 in round 3, 3d6 in round 4, 2d6 in round 5, 1d6 in round 6. After round 6, the spell ends.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"hit that inflicts 1d4 points of damage per every five levels of the caster", 
                     "hit that inflicts 1d4 points of damage per every five levels of the caster (max. 6d4 at level 26)");
             }
            
             // Shroud of Flame
             identifiers = new String[]{
                 "Shroud of Flame"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Save vs. Spell", 
                     "Save vs. Spell at a -2 penalty");
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"2d6", 
                     "3d6");
             }
            
             // Otiluke's Freezing Sphere
             identifiers = new String[]{
                 "Otiluke's Freezing Sphere"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"If the target makes its Save vs. Spell, however, they have dodged the orb and avoided all damage.", 
                     ". If the target makes its Save vs. Spell with a -1 penalty, however, it can halve the damage it takes.");
             }
            
             // Soul Eater
             identifiers = new String[]{
                 "Soul Eater"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"3d8 magic damage", 
                     "7d6 magic damage");
             }
            
             // Trollish Fortitude
             identifiers = new String[]{
                 "Trollish Fortitude"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 turn/4 levels (max. 5 turns)");
             }
             
             // Antimagic Shell
             identifiers = new String[]{
                 "Antimagic Shell"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5 rounds");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "15 ft.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 creature");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell surrounds the caster with an invisible barrier that moves with <PRO_HIMHER>. This barrier makes the wizard immune to any magical attacks, but it prevents <PRO_HIMHER> from casting spells.\n\nAntimagic Shell also dispels deafness and feeblemindedness in the caster.", 
                     "This spell surrounds one creature with an invisible barrier that moves with <PRO_HIMHER>. This barrier makes the creature fully immune to any magical attacks, but the shell also prevents it from casting any spell itself.\n\nAntimagic Shell also cures/dispels deafness and feeblemindedness from the target.");
             }
            
             // Lich Touch
             identifiers = new String[]{
                 "Lich Touch"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 1 round/level");
             }
            
             // Acid Storm
             identifiers = new String[]{
                 "Acid Storm"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The victim initially suffers 10d6 points of acid damage. After the initial damage, the victim must save vs. Spell to avoid more damage. If unsuccessful, the victim continues to suffer acid damage in the following rounds, sustaining two less dice of damage each round: that is, 8d6 damage with this spell on the first round, 6d6 on the second round, 4d6 on the third round, 2d6 on the fourth round, and the spell ends on the fifth round. Moving out of the area of effect does not stop the damage.", 
                     "The victim initially suffers 10d6 points of acid damage. A save vs Spell at -3 penalty reduces this by half. After the initial damage, the victim must save vs. Death with decreasing penalties to avoid more, specifically two less dice of damage each round:\n\n- 2nd round: save vs. Death at -2 penalty or take 8d6 acid damage\n- 3rd round: save vs. Death at -1 penalty or take 6d6 acid damage\n- 4th round: save vs. Death or take 4d6 acid damage\n Moving out of the area of effect does not stop the damage.");
             }
            
             // Suffocate
             identifiers = new String[]{
                 "Suffocate"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Suffocating creatures suffer -4 to Armor Class, -4 to hit, -6 to Dexterity, one less attack per round, half movement rate, and take 4d8 points of magic damage per round. A successful Saving Throw negates all effects but 2d8 points of damage for one round. The effects begin to fade when the creature moves out of the area of effect, although it can take a round for a character to catch their second wind.", 
                     "Suffocating creatures suffer the following effects for 4 rounds: -6 to Armor Class, THAC0, Dexterity and Strength, have their attacks per round set to 1 and are slowed. Additionally, they take 4d8 points of magic damage per round. A successful Saving Throw vs. Spell at a -2 penalty negates all effects, except half of the damage (2d8)");
             }
            
             // Malavon's Rage
             identifiers = new String[]{
                 "Malavon's Rage"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"20d4", 
                     "20d5");
             }
            
             // Great Shout
             identifiers = new String[]{
                 "Great Shout"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The Great Shout is extremely taxing and dangerous to the user. The shout drains 2d4 Hit Points from the caster, and <PRO_HESHE> must make a Save vs. Spell or fall unconscious for 1 turn. Creatures 5 Hit Dice and under caught within the Great Shout instantly die. All other creatures within the area of effect must save vs. Spell. Those who fail the save are stunned for 2 rounds, deafened for 4 rounds, and suffer 4d12 points of magic damage. Those who make the save are stunned for 1 round, deafened for 2 rounds, and suffer 2d12 points of magic damage.", 
                     "Creatures 8 Hit Dice and under caught within the Great Shout instantly die. Any creature with more Hit Dice are stunned for 2 rounds and deafened for 1 turn (50% spellcasting failure) without a saving throw. They also suffer 4d12 points of magic damage (save vs. spell for half)");
             }
             
             // Iron Body
             identifiers = new String[]{
                 "Iron Body"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"While the spell is in effect, the caster is 100% resistant to electricity and poison, 50% resistant to fire, and 25% resistant to crushing damage.", 
                     "While the spell is in effect, the caster is 100% resistant to electricity, cold, poison and missiles, 75% resistant to piercing damage, 50% resistant to fire and slashing damage and 25% resistant to crushing damage.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Unfortunately, the caster's movement becomes slow and awkward, setting <PRO_HISHER> movement rate to 25% of <PRO_HISHER> normal, and <PRO_HESHE> cannot cast spells while Iron Body is in effect.", 
                     "Unfortunately, the caster's movement becomes slow and awkward, setting <PRO_HISHER> movement rate to 50% of <PRO_HISHER> normal, and <PRO_HESHE> cast spells with a -2 speed penalty while Iron Body is in effect.");
             }
            
             // Bless
             identifiers = new String[]{
                 "Bless"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 1 turn/level (max. 1 hour)");
             }
            
             // entangle
             identifiers = new String[]{
                 "Entangle"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"with a \+3 bonus ", 
                     "");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"-2 penalty", 
                     "-4 penalty");
             }
            
             // magical stone
             identifiers = new String[]{
                 "Magical Stone"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"By using this spell, the priest can create a small magical pebble, which then flies out and hits a target opponent. The stone deals 1d4 points of damage to whomever it hits.", 
                     "By using this spell, the priest concentrates on his/her god to conjure a small magical pebble, containing the elements fire, ice and lightning, which then flies out and hits a target opponent. The stone itself deals 1d4 points of damage to whoever it hits. The target will also be struck by the elemental forces contained within the stone for 1d4 fire, 1d4 cold and 1d4 lightning damage. The elemental forces increase once the priest reaches to level 6 (3*1d6 points of elemental damage) and level 12 (3*1d8 points of elemental damage). The target of this spell is allowed a saving throw vs. Spell to halve the damage taken.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1/2 of elemental damage");
             }
            
             // sprit ward
             identifiers = new String[]{
                 "Spirit Ward"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5 rounds/level");
             }
            
             // shillelagh
             identifiers = new String[]{
                 "Shillelagh"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell enables the caster to create a magical cudgel that has a \+1 bonus to its attack roll and inflicts 2d4 points of damage on opponents.", 
                     "This spell enables the caster to create a magical cudgel. The shillelagh inflicts 2d4+1 points of damage on a successful hit and causes tendrils to wrap around and hold the victim in place for one round unless a save vs. breath is made. The caster wields the shillelagh as if proficient with the weapon, at his normal THAC0. At level 1, it functions as a magical weapon with an enchantment bonus of +1. For every other four experience levels of the spellcaster, this bonus increases by one, up to a total of +3 enchantment level, +3 to attack rolls, and +3 to damage for a 9th-level caster. The shillelagh can be used only by the caster, and remains in his hand for the duration of the spell or until dispelled.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns");
             }
            
             // armor of faith
             identifiers = new String[]{
                 "Armor of Faith"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The caster of the Armor of Faith receives significant protection against melee and magical attacks. This magical armor is a force of energy that absorbs a portion of the damage intended for the caster. At 1st level, the protection is 5%, and every 5 levels of the caster improves this by another 5%: For example, a 20th-level priest would have 25% of <PRO_HISHER> damage " + @"""absorbed""" + @" if protected by this spell.", 
                     "The caster of the Armor of Faith receives significant protection against melee (crushing, slashing, piercing, missile), magical (magic damage) and elemental (fire, cold, lightning, acid) attacks. This magical armor is a force of energy that absorbs a portion of the damage intended for the caster. The absorption amount equals the level of the caster: At level 1, 1% of the damage is nullified, at level 40, 40% of the damage will be negated.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
             }
            
             // doom
             identifiers = new String[]{
                 "Doom"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1");
             }
            
             // barkskin
             identifiers = new String[]{
                 "Barkskin"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When a priest casts the Barkskin spell upon a creature, its skin becomes as tough as bark, increasing its base Armor Class to 6, plus 1 for every 4 levels of the priest: Armor Class 5 at 4th level, Armor Class 4 at 8th, and so on. In addition, Saving Throws vs. all attack forms except magic gain a \+1 bonus. This spell can be placed on the caster or on any other creature <PRO_HESHE> touches.", 
                     "When a priest casts the Barkskin spell upon a creature, its skin becomes as tough as bark, improving its Armor Class by 2, plus 1 AC for every other six levels of the caster (up to a maximum of +4 AC at 15th level). Multiple castings of this spell are not cumulative.");
             }
            
             // charm person or mammal
             identifiers = new String[]{
                 "Charm Person or Mammal"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"with a \+3 modifier", 
                     "with a +1 bonus");
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     @"Charm Person or Mammal", "Charm Mammal"); // change spell name itself (person is a mammal, so there's a redundancy in the nomenclature)
             }
            
             // find traps conversion to fire trap
             identifiers = new String[]{
                 "Find Traps"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30 ft.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Instant");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "20-ft. radius");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Breath for 1/2");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "When a priest casts a Find Traps spell.*", 
                     "This powerful trap harms those who enter, pass, or open the selected area or object. It can be used to guard a small bridge, to ward an entry, or as a trap on a chest or box. Any enemy violating the selected area will trigger the trap.\n\nWhen the spell is cast, the druid weaves a tracery of faintly glowing lines around the warding sigil. When a hostile creature comes within 15 feet of the trap, it is triggered and explodes, damaging every enemy within a 20 foot radius. The damage inflicted is equal to 1d4 fire damage + 1d4 fire damage per 2 levels of the caster (up to a maximum of 10d4). Those who a roll successful saving throw vs. breath will receive only half damage.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"\(Divination\)", "(Conjuration)");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Fire Trap"); // change spell name in the desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Fire Trap"); // change spell name itself
             }
             
             // AID
             identifiers = new String[]{
                 "Aid"
             };
             foreach (String identifier in identifiers)
             {
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 2 rounds/2 levels");
             }
            
             // goodberry conversion to divine growth
             identifiers = new String[]{
                 "Goodberry"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30 ft.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5 turns + 5 turns/4 levels");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30-ft. radius");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Casting a Goodberry spell creates.*", 
                     "This spell bestowes the priest and his/her allies with divine power. This power then flows through their veins for the next 1 turn + 1 turn/4 levels of caster and causes their body cells to grow and divide faster than normal. Light wounds will heal after only a few rounds, while more severe ones may take several minutes to mend.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Divine Growth"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Divine Growth"); // change spell name itself
             }
            
             // flame blade
             identifiers = new String[]{
                 "Flame Blade"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Personal");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Caster");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"With this spell, the caster causes a blazing ray of red-hot fire to spring forth from <PRO_HISHER> hand. This blade-like ray is wielded as if it were a sword that the caster already knows how to use, hence there are no bonuses or penalties. If the caster successfully hits with the flame blade in melee combat, the creature struck suffers 1d4 points of slashing damage, plus an additional 1d2\+4 points of fire damage. However, it is not a magical weapon in the normal sense of the term, so creatures struck only by magical weapons are not harmed by it.", 
                     "With this spell, the caster causes a blazing ray of red-hot fire to spring forth from his hand. The caster wields this blade-like ray with an additional +1 THAC0 (weapon proficiency bonuses for long swords apply as well). At level 1, the flame blade is a normal weapon without added bonuses, dealing 2d6 fire damage. From level 3 onward, it functions as a magical weapon, dealing 2d6+1 points of fire damage, with an enchantment bonus of +1. For every other three experience levels of the spellcaster, this bonus increases by one, up to a total of +3 enchantment level, +3 to attack rolls, and +3 to damage for a 9th-level caster. Since the blade is immaterial, strength modifiers do not apply to attack rolls or damage, and attacks with the flame blade are considered melee touch attacks.");
             }
            
             // chant slow removal
             identifiers = new String[]{
                 "Chant"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @" This spell requires a moderate amount.*movement is slowed by half\.", "");
             }
            
             // hold person
             identifiers = new String[]{
                 @"Hold Person( )?\n\(Enchantment/Charm\)\n\nLevel: 2"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"Those who succeed on their Saving Throws are totally", 
                     "Those who succeed on their Saving Throws vs. Paralyze are totally");
             }
            
             // resist fire and cold CONVERSION TO RESIST ELEMENTS
             identifiers = new String[]{
                 "Resist Fire and Cold"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is placed upon a creature, the creature's body is toughened to withstand heat and cold. Complete immunity to mild conditions \(standing naked in the snow or reaching into an ordinary fire to pluck out a note\) is gained. The recipient can somewhat resist intense heat or cold \(whether natural or magical in origin\), such as red-hot charcoal, a large amount of burning oil, flametongue swords, fire storms, fireballs, meteor swarms, red dragon's breath, frostbrand swords, ice storms, wands of frost, or white dragon's breath. In all of these cases, the temperature affects the creature to some extent. The recipient has all damage sustained by fire or cold reduced by 50%.", 
                     "By casting this spell, the caster confers a partial resistance to the elements fire, ice and lightning to all surrounding allied creatures. The amount of resistance gained depends on the caster's level: At level 1, the resistance is 20%. For every additional level another 2% is added, for a maximum of 50% resistance at level 16. The duration of the spell equally increases: It starts with 2 turns and is raised by 2 rounds per level of the caster, capping at 1 hour at level 16.");
                 
                 EditTlkExistingEntry(identifier + @"\Z", identifier, "Resist Elements");
             }
            
             // silence
             identifiers = new String[]{
                 "Silence, 15' Radius"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"-5 penalty", 
                     "-2 penalty");
             }
            
             // sprititual hammer
             identifiers = new String[]{
                 "Spiritual Hammer"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Special");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Caster");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"By calling upon <PRO_HISHER> deity, the caster of a Spiritual Hammer spell brings into existence a magical hammer, which <PRO_HESHE> can use for the duration of the spell. It strikes as a magical weapon with a bonus of \+1 for every 6 experience levels \(or fraction\) of the caster, up to a total of \+3 to the attack roll and \+3 to the damage roll for a 13th-level caster. The base damage inflicted when it scores a hit is exactly the same as a normal war hammer \(1d4\+1 vs. opponents of man-size or smaller and 1d4 upon larger opponents, plus the magical bonus\).", 
                     "By calling upon his/her deity, the caster of a Spiritual Hammer spell brings into existence a field of force shaped vaguely like a hammer. The caster wields the spiritual hammer as if proficient with the weapon, at his normal THAC0. As long as the caster concentrates upon the hammer, it can be used to strike at any opponents within 20 feet, but the wielder does not receive the standard penalty for holding a ranged weapon when engaged in close combat. At level 1, it functions as a magical weapon, dealing 1d8+1 points of magic damage, with an enchantment bonus of +1. For every five experience levels of the spellcaster, this bonus increases by one, up to a total of +5 enchantment level, +5 to attack rolls, and +5 to damage for a 20th-level caster. Due to its ethereal nature, strength modifiers do not apply to attack rolls or damage, and attacks with the spiritual weapon are considered melee touch attacks (+4 attack roll bonus).");
             }
            
             // call lightning
             identifiers = new String[]{
                 "Call Lightning"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "-3 penalty");
            
                 EditTlkExistingEntry(identifier + @"( )?\n\(", @"Call Lightning must be cast outside; otherwise, it will not work, and the spell is wasted\. ", "");
             }
             
             // animate dead 
             identifiers = new String[]{
                 @"Animate Dead\n\(Necromancy\)\n\nLevel: 3"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell causes a skeleton warrior to rise and serve the caster under any conditions. The type of skeleton warrior that appears depends upon the level of the priest casting the spell.*",
                     "This spell causes a skeleton warrior to rise and serve the caster under any conditions. The type of skeleton warrior that appears depends upon the level of the priest casting the spell.\n  1st - 2nd: 1x 3 HD skeleton warrior wielding a long sword.\n  3rd - 4th: 2x 3 HD skeleton warriors wielding a long sword.\n  5th - 6th: 1x 5 HD skeleton warrior wielding a long sword +1.\n  7th - 8th: 2x 5 HD skeleton warriors wielding a long sword +1.\n  9th - 10th: 1x 7 HD skeleton warrior wielding a bastard sword +1.\n  11th - 12th: 2x 7 HD skeleton warriors wielding a bastard sword +1.\n  13th - 14th: 1x 9 HD skeleton warrior wielding a two-handed sword +1.\n  abov 14th: 2x 9 HD skeleton warriors wielding a two-handed sword +1.\nThe skeleton warrior can follow the caster, remain in an area and attack any creature entering the place, etc. It remains animated until it is destroyed in combat, 8 hours pass, or it is turned. This spell cannot be dispelled.");
             }
            
             // glyph of warding
             identifiers = new String[]{
                 "Glyph of Warding"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "4");
             }
            
             // hold animal conversion to hold mammal
             identifiers = new String[]{
                 "Hold Animal"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell holds animals rigidly immobile and in place. Only normal- and giant-sized animals are affected by this spell; monsters such as wyverns, ankhegs, and carrion crawlers do not count as animals. The effect is centered on the victim selected by the caster; every enemy within 4 ft. of the target is also affected. Those who succeed on their Saving Throws are totally unaffected by the spell.", 
                     "This spell holds mammals (animals, humanoids, giant humanoids) rigidly immobile and in place. Monsters such as wyverns, ankhegs, monstrous spiders and carrion crawlers do not count as animals. The effect is centered on the victim selected by the caster; every enemy within 4 ft. of the target is also affected. Those who succeed on their Saving Throws with a penalty of -1 are totally unaffected by the spell.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Hold Mammal"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Hold Mammal"); // change spell name itself
             }
            
             // protection from fire
             identifiers = new String[]{
                 @"Protection From Fire\n\(Abjuration\)\n\nLevel: 3\nSphere: Protection, Elemental \(Fire\)"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn/level");
             }
            
             // Invisibility Purge
             identifiers = new String[]{
                 "Invisibility Purge"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5 rounds");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Any enemy invisible creatures.*", 
                     "Any enemy invisible creatures within the area of effect have their invisibility dispelled instantly and once every round for the next 5 rounds. This includes creatures under the effects of Sanctuary, Improved Invisibility, Shadow Door, Invisibility, Mislead, and so on.");
             }
            
             // Miscast Magic
             identifiers = new String[]{
                 "Miscast Magic"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"80%", 
                     "95%");
             }
            
             // Rigid Thinking
             identifiers = new String[]{
                 "Rigid Thinking"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Saving Throw vs. Spell", 
                     "Saving Throw vs. Spell with a -1 penalty");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "3");
             }
            
             // Strength of One
             identifiers = new String[]{
                 "Strength of One"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The spell lasts for 1 turn, whereupon everyone's Strength returns to normal.", 
                     "The spell lasts for 1 turn per level of the caster, whereupon everyone's Strength returns to normal.");
             }
            
             // Holy Smite
             identifiers = new String[]{
                 "Holy Smite"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The result is that any evil creatures within the spell's area of effect take 1d4 points of damage per level of the caster, or half damage upon a successful Saving Throw vs. Spell. If the victims fail their Saving Throw, they are also blinded for 1 round.", 
                     "The result is that any creatures within the spell's area of effect take 4d4 points of damage + 1d4 every 2nd level of the caster, or half damage upon a successful Saving Throw vs. Spell. If the victims fail their Saving Throw, they are also blinded for 3 rounds.");
             }
            
             // Unholy Blight
             identifiers = new String[]{
                 "Unholy Blight"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The result is that any good creatures within the spell's area of effect take 1d4 points of damage per level of the caster, or half damage upon a successful Saving Throw vs. Spell. If the victims fail their Saving Throw, they also receive a -2 penalty to all their rolls for 4 rounds.", 
                     "The result is that any creatures within the spell's area of effect take 4d4 points of damage + 1d4 every 2nd level of the caster, or half damage upon a successful Saving Throw vs. Spell. If the victims fail their Saving Throw, they are also blinded for 3 rounds.");
             }
            
             // Summon Insects
             identifiers = new String[]{
                 "Summon Insects"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5");
             }
            
             // Free Action
             identifiers = new String[]{
                 "Free Action"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour + 1 turn/4 levels");
             }
            
             // Neutralize Poison
             identifiers = new String[]{
                 "Neutralize Poison"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"10 lost", 
                     "25 lost");
             }
            
             // Defensive Harmony
             identifiers = new String[]{
                 "Defensive Harmony"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour + 5 rounds/2 levels");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"While the spell is in effect, each affected creature gains a \+2 bonus to <PRO_HISHER> Armor Class. This lasts for 6 rounds or until dispelled.", 
                     "While the spell is in effect, each affected creature gains a +2 AC bonus + 1 further AC bonus every 3 levels of the caster (max. +5 AC Bonus at level 26). This lasts for 1 hour + 5 rounds for every 2 levels of the caster (max. 2 hours at level 28) or until dispelled.");
             }
            
             // protection from lightning
             identifiers = new String[]{
                 @"Protection From Lightning( )?\n\(Abjuration\)\n\nLevel: 4"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn/level");
             }
            
             // protection from evil 10' conversion to protection from poison
             identifiers = new String[]{
                 "Protection From Evil, 10' Radius"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn/level");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Sphere: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Protection");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, all allied creatures within a \d{2}-ft. radius are affected individually by Protection From Evil. It creates a magical barrier around the recipients at a distance of one foot. The barrier moves with the recipient and has two major effects: First, all attacks made by evil or evilly enchanted creatures against the protected creature receive a penalty of -2 to each attack roll. Second, summoned demons cannot target protected creatures.", 
                     "When this spell is cast, it will confer full immunity to all poison effects and being poisoned to all allied creatures within a 30-ft. radius. This means that everyone affected by the spell will not able to be poisoned (say, from a spider), and will not suffer poison damage (e.g. Cloudkill, Poison Clouds spells etc. The spell lasts for 1 turn per level of the caster or until dispelled.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Protection from Poison"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Protection from Poison"); // change spell name itself
             }
             
             // produce fire to protection from poison
             identifiers = new String[]{
                 "Produce Fire"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn/level");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30-ft. radius");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Sphere: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Protection");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                        "When cast, flames erupt from the target point.*", 
                     "When this spell is cast, it will confer full immunity to all poison effects and being poisoned to all allied creatures within a 30-ft. radius. This means that everyone affected by the spell will not able to be poisoned (say, from a spider), and will not suffer poison damage (e.g. Cloudkill, Poison Clouds spells etc. The spell lasts for 1 turn per level of the caster or until dispelled.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, "Protection from Poison"); // change spell name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, "Protection from Poison"); // change spell name itself
             }
            
             // Poison
             identifiers = new String[]{
                 @"Poison( )?\n\(Necromancy\)"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"Saving Throw vs. Poison", 
                     "Saving Throw vs. Poison with a -1 penalty");
             }
            
             // Negative Plane Protection
             identifiers = new String[]{
                 "Negative Plane Protection"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "12 hours");
             }
            
             // Cloak of Fear
             identifiers = new String[]{
                 "Cloak of Fear"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 turn/3 levels");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Cloak of Fear empowers the caster to radiate a personal aura of fear out to a 15-ft. radius. All other characters and creatures within this aura must roll a successful Saving Throw vs. Spell or run away in panic for 4 rounds. Party members are immune to the effects, although the aura of fear may still disturb them.", 
                     "Cloak of Fear empowers the caster to radiate a personal aura of fear out to a 6-ft. radius. All enemies not immune to fear within this aura suffer -2 penalty to THAC0 and AC without a save, and each round they must roll a successful saving throw vs. spell or run away in panic for 1 round. Party members are immune to the effects of the aura. The cloak will reach its maximum duration at a a caster's level of 20, where it will last for 1 hour.");
             }
            
             // Lesser Restoration
             identifiers = new String[]{
                 "Lesser Restoration"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" The casting of this spell is very draining on the priest and <PRO_HESHE> will likely require rest immediately after the casting, as it will cause days' worth of fatigue almost instantaneously.", 
                     "");
             }
            
             // Sprit Fire
             identifiers = new String[]{
                 "Spirit Fire"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"which deliver 1d4 points of magic damage per level of the Shaman \(up to a maximum of 10d4\). There is also a 33% chance that every enemy within the area of effect will be afflicted by the Doom spell \(-2 penalty to Saving Throws and attack rolls for 1 turn\). A successful Save vs. Spell halves the damage and negates the Doom effect.", 
                     "which deliver 4d6 points of magic damage damage at 8th level + 1d6 every second level of the Shaman thereafter (up to a maximum of 13d4 at level 26. There is also a 50% chance at level 8 + 5% every level thereafter that every enemy within the area of effect will be afflicted by the Doom spell (-2 penalty to Saving Throws and attack rolls for 1 turn, max. 95% at level 26).");
             }
            
             // Iron Skins
             identifiers = new String[]{
                 "Iron Skins"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"For every 2 levels of the caster, an additional skin is gained upon casting. For example, a 10th-level Druid would receive 5 skins. For each skin the Druid possesses, the spell will stop one attack, so a 10th-level Druid would be protected from the first 5 attacks made against <PRO_HIMHER> but the 6th would affect <PRO_HIMHER> normally.", 
                     "From level 8 onwards, for every 2 levels of the caster, an additional skin is gained upon casting. For example, a 10th-level Druid would receive 3 skins. For each skin the Druid possesses, the spell will stop one attack, so a 10th-level Druid would be protected from the first 3 attacks made against <PRO_HIMHER> but the 4th would affect <PRO_HIMHER> normally.");
             }
            
             // True Seeing
             identifiers = new String[]{
                 "True Seeing"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Instantly and once each round for 1 turn", 
                     "Instantly and once per round for 1 turn at level 11 + 1 round/2nd level thereafter (max. 2 turns at level 31)");   
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The area of effect is roughly a 120-ft. radius around the caster. ", 
                     "");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Finally, the spell also protects the caster from magical blindness for 1 turn after it is cast.", 
                     "Finally, the spell also protects the caster from magical blindness for 1 turn at level 11 + 1 round/2nd level thereafter (max. 2 turns at level 31) after it is cast.");
             }
            
             // Champion's Strength
             identifiers = new String[]{
                 "Champion's Strength"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 4 rounds/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"target creature, in effect creating a champion. The target gains a bonus to <PRO_HISHER> THAC0 at a rate of 1 for every 3 levels of the caster. So a 9th level priest would confer a THAC0 bonus of 3 to the target, and so on. Also the target's Strength is set to 18/00 for the duration of the spell and receives all the bonuses to hit and damage rolls that this Strength confers. Note also that if the target's strength is above 18/00, it will actually be reduced to this value.\n\n",
                     "target creatures. The targets gain a +2 bonus to their Strength, Dexterity and THAC0 plus a +1 for every 5 levels of caster, beginning at level 10. So a 20th level priest would confer a Strength, Dexterity & THAC0 bonus of 4 to the target. The duration increases by 4 rounds every level of the caster from level 10 onwards. The spell caps at level 30 (+6 bonus, 2 hours duration)");   
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The drawback to this is that the priest must concentrate on the connection between the target and <PRO_HISHER> god for the duration of the spell, hence losing the ability to cast any spells during this time. The effect lasts for 3 rounds for every level of the caster or until dispelled.", 
                     "");
             }
            
             // Magic Resistance
             identifiers = new String[]{
                 "Magic Resistance"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, the recipient receives a resistance to all magic. The resistance conferred is 2% per level of the caster, up to a maximum of 40% at 20th level. This resistance is set so that if the target already has more Magic Resistance than the priest would confer, it will actually lower it to the set value.",
                     "When this spell is cast, all adjacent allied creatures receive a resistance to all magic. The resistance conferred is 1% per level of the caster, up to a maximum of 40% at 40th level. The resistance provided by the caster is added to any already pre-existing magic resistance of the target creatures.");   
             }
            
             // Greater Command
             identifiers = new String[]{
                 "Greater Command"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"level of the caster.",
                     "level of the caster and a Saving Throw vs. Spell has to be made with a -3 penalty in order to avoid the effect.");   
             }
            
             // Repulse Undead Conversion to Repulsion
             identifiers = new String[]{
                 "Repulse Undead"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This powerful spell creates waves of anti-negative energy that sweep outward from the caster. These waves disrupt any undead that attempt to attack the caster, pushing them away from the caster for several seconds. There is one wave per round for the duration of the spell. All undead are affected with no Saving Throw.",
                     "An invisible, mobile field surrounds the caster and prevents creatures from approaching him. Any creature within or entering the field must attempt a save vs. spell at -4 penalty every round. If it fails, it gets pushed away by 10 feet. Repelled creatures' actions are not otherwise restricted. They can fight other creatures and can cast spells and attack you with ranged weapons.");   
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Repulse Undead",
                     "Repulsion"); // name in desc
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     @"Repulse Undead",
                     "Repulsion"); // name itself
             }
            
             // Blade Barrier
             identifiers = new String[]{
                 "Blade Barrier"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The priest employs this spell to set up a wall of circling, razor-sharp blades. These whirl and flash around the caster, creating an impenetrable barrier. Any creature attempting to pass through the Blade Barrier suffers 8d8 points of damage. Creatures within the area of the barrier when it is invoked are entitled to a Saving Throw vs. Spell to negate the damage. The barrier remains for 1 turn.",
                     "The priest employs this spell to set up a wall of circling, razor-sharp blades. These whirl and flash around the caster, creating an perrillous barrier. Any creature within a 6 foot radius around the Blade Barrier suffers 1d12 points of slashing damage every 3 seconds. Note that invisibility spells will not work while the blade barrier is in effect. Cleric/Thieves are also unable to hide in the shadows for the duration of the spell.");   
            
             }
            
             // False Dawn
             identifiers = new String[]{
                 "False Dawn"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"False Dawn calls into existence a bright reddish light, as if a sunrise were occurring, within the area of effect. All undead creatures within a False Dawn suffer 6d6 points of damage. There is no Saving Throw. Affected undead also act confused on the round after the False Dawn appears.",
                     "By drawing on the power of the sun, this spell causes the caster's body to emanate a bright light that extends 15 feet in all directions. Each round, opponents withint the area must save vs. Spell at a -4 penalty or be blinded for the next round. Undead creatures suffer an aded 2d6 points of damage for each round they are exposed to the false dawn.");   
            
             }
            
             // Bolt of Glory
             identifiers = new String[]{
                 "Bolt of Glory"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Creature Type                       Damage",
                     "Creature Type - Damage");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" Prime Material Plane            6d6",
                     "Elemental - 4d4"); 
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" Elemental                             3d4",
                     "Humanoid - 6d6"); 
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" Undead                                8d6",
                     "Undead - 8d8"); 
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" Demon                                 10d6",
                     "Demonic - 10d10"); 
             }
            
             // Physical Mirror
             identifiers = new String[]{
                 "Physical Mirror"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell causes a localized folding of space. The folded space takes the form of an invisible disk that protects the caster. Any missile weapon that intersects this disk is instantaneously reversed in direction. Melee factors such as speed, range, and damage are unaffected; the direction of the object or force is simply rotated through a 180-degree arc. The sender of the missile finds <PRO_HIMHER>self the target of <PRO_HISHER> own attack. The caster of the mirror may direct missile attacks normally through the space occupied by the mirror.",
                     "This spell causes a localized folding of space. The folded space takes the form of an invisible disk that protects the caster but also distorts his appearence as if a mirrored image of the caster traveled alongside him. Any missile attack that intersects the disk is instantaneously deflected, while there is a 50% chance that a melee attacker will attack the mirrored image and a 50% chance that he will attack the caster.");
             }
            
             // Spritual Lock
             identifiers = new String[]{
                 "Spiritual Lock"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 rounds/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"The target of Spiritual Lock must Save vs. Spell with a -2 penalty or have its mind temporarily sealed away within the spirit world. During this time, the victim is unable to perform any actions that require conscious thought such as attacking, using items, or casting spells. Spirits, fey creatures, elementals, and spectral undead Save vs. Spell with a -4 penalty instead of -2. Spiritual Lock is blocked by spells and abilities that protect against feeblemind effects.",
                     "The target of Spiritual Lock must Save vs. Spell with a -4 penalty or have its mind temporarily sealed away within the spirit world. During this time, the victim is unable to perform any actions that require conscious thought such as attacking, using items, or casting spells. Spiritual Lock is blocked by spells and abilities that protect against feeblemind effects.");
             }
            
             //Sol's Searing Orb
             identifiers = new String[]{
                 "Sol's Searing Orb"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 rounds/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When the spell is completed, it creates a glowing stone. This gem must be immediately thrown at an opponent, for it quickly becomes too hot to hold. It is not possible for the priest to give the stone to another character to throw. The priest must make an attack roll with \+3 bonus and no penalty for lack of weapon proficiency. In addition, the glowing gem can be used to strike any creature, even those hit only by magical weapons, although there is no damage bonus.\n\nWhen it hits, the gem bursts with a brilliant, searing flash that causes 6d6 points of fire damage to the target and blinds <PRO_HIMHER> for 1d6 rounds. The victim is allowed a Saving Throw vs. Spell for half damage and to avoid being blinded. Undead creatures suffer 12d6 points of fire damage and are blinded for 12 rounds \(if applicable\) upon a failed Saving Throw; otherwise, they receive 9d6 points of damage and are blinded for 6 rounds.",
                     "When the spell is completed, it creates a glowing gem. This gem must be thrown at an opponent within 3 rounds, or it will become too hot to hold and is dropped by the priest. When it is thrown at a creature and hits, the gem bursts with a brilliant, searing flash that causes 12d6 points of fire damage to anyone within 30 feet. Creatures within the burst are allowed a saving throw vs. Spell at a -4 penalty. If successful, only half damage is sustained. On a failed save, the victim also suffers -2 penalty to thac0 and is blinded for 6 rounds. The victim also must save again at a -4 penalty for 6 rounds to avoid taking 1d6 points of fire damage each round. It is not possible for the priest to give the stone to another character to throw. Magic resistance does not effect this spell, nor do any of the spell protections.");
             }
            
             // Shield of the Archons
             identifiers = new String[]{
                 "Shield of the Archons"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This affects a total of spell levels equal to half the level of the caster. This includes spells cast from scrolls and innate spell-like abilities, but excludes the following: area effects that are not centered directly upon the priest, as well as area effects that are stationary, such as Cloudkill and Stinking Cloud. As long as the spell is cast directly at the priest, it will be absorbed provided that there are spell levels remaining. For example, if there is only 1 level left and a 3rd-level spell is cast at the priest, the spell will be absorbed while canceling the shield.",
                     "This affects a total of 20 spell levels + 1 spell level every 2 levels of the caster (max. 33 spell levels at caster level 40). This includes spells cast from scrolls and innate spell-like abilities, but excludes the following: area effects that are not centered directly upon the priest, as well as area effects that are stationary, such as Cloudkill and Stinking Cloud. As long as the spell is cast directly at the priest, it will be absorbed provided that there are spell levels remaining. For example, if there is only 1 level left and a 3rd-level spell is cast at the priest, the spell will be absorbed while canceling the shield.");
             }
            
             // Nature's Beauty
             identifiers = new String[]{
                 "Nature's Beauty"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, the caster appears to undergo a remarkable transformation. The caster becomes the very ideal of beauty: For a male, this is usually a nymph; for a female, it varies. As with a nymph, anyone viewing the disguised caster must make a Saving Throw vs. Spell with \+3 bonus or die of longing for the denied illusion. Even if the Saving Throw is successful, hapless viewers of the transformed Druid are all instantly smitten with permanent blindness \(until dispelled\). The transformation is instantaneous, but lasts only seconds, affecting those near the caster \(excluding fellow party members\).",
                     "When this spell is cast, the caster appears to undergo a remarkable transformation. The caster becomes the very ideal of beauty - any humanoid viewing the illusion must save vs. spell at a -5 penalty or be charmed for 1 round per level of the caster rounds. The transformation is instantaneous, but lasts only seconds, affecting those in the area but excluding fellow party members.\n\nIf the caster harms, or attempts to harm, a charmed creature by some overt action, or if a dispel magic spell is successfully cast upon a charmed creature, the charm is broken. If two or more charm effects simultaneously affect a creature, the most recent charm takes precedence.");
             }
            
             // Fire Storm
             identifiers = new String[]{
                 "Fire Storm"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When a Fire Storm spell is cast, the whole area is shot through with sheets of roaring flame and then pelted with fiery balls of lava. Creatures within the area of effect receive 2d8 points of damage plus 1 per level of the caster \(i.e. 2d8 \+ 1/level\). This assault will last for 4 rounds and will continue to do damage to the creature during that time unless <PRO_HESHE> moves out of the area of effect. There is no Saving Throw.",
                     "When a Fire Storm spell is cast, the whole area is shot through with sheets of roaring flame and then pelted with fiery balls of lava. Creatures within the area of effect receive 2d8 points of damage + 1d2 every 4 levels after level 14, with a chance to halve to damage with a Save vs. Breath at -2. This assault will last for 4 rounds and will continue to do damage to the creature during that time unless <PRO_HESHE> moves out of the area of effect. Provided the victim remains in the damage zone, the saving throw vs. Breath at a -2 penalty every round for half damage will stay in effect.");
             }
            
             // Sunray
             identifiers = new String[]{
                 "Sunray"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"When this spell is cast, it causes a ray of sunlight to beam down upon the caster and everyone within a 15-ft. radius. All creatures within the area of effect take 3d6 points of damage and must save vs. Spell or be blinded for 1 turn. Undead that are hit by the sunray take 1d6 damage per level of the caster, and must save vs. Spell or be destroyed.",
                     "When this spell is cast, it causes a ray of sunlight to beam down upon the caster and everyone within a 15-ft. radius. All creatures within the area of effect take 8d6 points of damage and must save vs. Spell at a -4 penalty or be blinded for 1 turn. Undead that are hit by the sunray must additionally save vs. Spell or suffer 14d6 damage");
             }
            
             // Confusion conversion to CONTROL UNDEAD
             identifiers = new String[]{
                 @"Confusion( )?\n\(Enchantment/Charm\)\n\nLevel: 7"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier, 
                     @"(?<=Sphere: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Undead");
            
                 EditTlkExistingEntry(identifier,
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 turns + 2 rounds/level");
            
                 EditTlkExistingEntry(identifier,
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "7");
            
                 EditTlkExistingEntry(identifier,
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "10-ft. Radius");
            
                 EditTlkExistingEntry(identifier,
                     @"This spell causes confusion in one or more enemy creatures within the area.*", 
                     "The Control Undead spell allows the caster to take control of undead creatures within the area of effect. This creates a telepathic link between the caster and the undead, allowing complete control. If the undead have 5 Hit Dice or less, then there is no Saving Throw allowed; however, if they have 6 Hit Dice or more, a Save vs. Spell with a -3 penalty is allowed to negate the effect. Magic resistance may negate the effects of this spell. The undead remain under the control of the caster for the duration of the spell or until they are affected by a Dispel Magic.");
            
                 EditTlkExistingEntry(identifier, 
                     identifier, "Control Undead\n(Necromancy)\n\nLevel: 7"); // change spell name in desc
            
                 // spell name itself is handled in the spl batcher (special case, since the spell name is already there)
             }
            
             // Holy Word
             identifiers = new String[]{
                 "Holy Word"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Hit Dice / Levels  .*?  Effects of Holy Word",
                     "Hit Dice / Levels - Effects of Holy Word");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Less than 4  .*?  Death",
                     "Less than 5 - Death");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "4 to 7  .*?  Stunned for 1 turn",
                     "Up to 10 - Stunned for 2 rounds");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "8 to 11  .*?  Slowed for 1 turn with a 75% chance of spell failure",
                     "Up to 12 - slowed for 4 rounds");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "12 and up  .*?  Deafened for 1 turn with a 50% chance of spell failure",
                     "Up to 14 - blinded for 8 rounds\nMore than 14 - deafness for 2 turns");
             }
            
             // Unholy Word
             identifiers = new String[]{
                 "Unholy Word"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Hit Dice / Levels  .*?  Effects of Unholy Word",
                     "Hit Dice / Levels - Effects of Holy Word");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "Less than 4  .*?  Death",
                     "Less than 5 - Death");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "4 to 7  .*?  Stunned for 1 turn",
                     "Up to 10 - Stunned for 2 rounds");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "8 to 11  .*?  Slowed for 1 turn with a 75% chance of spell failure",
                     "Up to 12 - slowed for 4 rounds");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "12 and up  .*?  Deafened for 1 turn with a 50% chance of spell failure",
                     "Up to 14 - confused for 8 rounds\nMore than 14 - deafness for 2 turns");
             }
            
             // Earthquake
             identifiers = new String[]{
                 "Earthquake"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" 1st: All creatures affected take 6d6 points of damage and fall to the ground for 4 rounds. A successful Saving Throw vs. Spell with a -6 penalty halves the damage and negates the fall.",
                     "1st: All creatures affected take 6d6 points of damage and fall to the ground for 4 rounds. A successful Saving Throw vs. Paralyzation with a -6 penalty halves the damage and negates the fall.\n");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" 2nd: All creatures affected take 3d6 points of damage. A successful Saving Throw vs. Spell with a -2 penalty halves the damage.",
                     "2nd: All creatures affected take 4d6 points of damage. A successful Saving Throw vs. Paralyzation with a -4 penalty halves the damage.\n");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" 3rd: All creatures affected take 2d6 points of damage. A successful Saving Throw vs. Spell halves the damage.",
                     "3rd: All creatures affected take 2d6 points of damage. A successful Saving Throw vs. Paralyzation with a -2 halves the damage.\n");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"\nThis spell will affect both enemies and friends of the caster's, so care must be taken in its use. Finally, earth elementals dislike mere mortals toying with the land and there is a small chance that casting this spell will cause an earth elemental to appear and attack the party.",
                     "4th: All creatures affected take 1d6 points of damage. A successful Saving Throw vs. Paralyzation with halves the damage.");
             }
            
             // Faerie Fire
             identifiers = new String[]{
                 "Faerie Fire"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Armor Class penalty of -2",
                     "Armor Class penalty of -4");
             }
            
             // Sunscorch
             identifiers = new String[]{
                 "Sunscorch"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"the damage is 1d6, plus 2 points per level of the caster",
                     "the damage is 2d6, plus 1 point per level of the caster (max. level 30)");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"blinded for 3 rounds",
                     "blinded for 5 rounds");
             }
            
             // Alicorn Lance
             identifiers = new String[]{
                 "Alicorn Lance"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"inflicting 3d6 points of piercing damage with a Save vs. Spell for half.",
                     "inflicting 3d6 points of piercing damage + 2 points of magic damage every 2 levels.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"-2 penalty",
                     "-3 penalty");
             }
            
             // Beast Claw
             identifiers = new String[]{
                 "Beast Claw"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30-ft. radius");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell transforms the caster's arms into the claws of a mighty beast, giving the caster 18/72 Strength and the ability to rake an opponent for 2d4 \(plus Strength bonus\) points of slashing damage. The caster can attack twice per round with the beast claws, with a \+2 bonus to hit.",
                     "This spell unleashes raw natural energy on the caster and his/her allies. Their minds will be teeming with beast-like, atavistic ferocity and their weapons will deal the maximum physical damage. Also, those affected by the spell gain a +1 bonus to strength and +2 to THAC0 for the duration of this spell");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Animalistic Instincts");
                 
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, 
                     "Animalistic Instincts");
             }
            
             // Circle of Bones
             identifiers = new String[]{
                 "Circle of Bones"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d6 crushing damage and 1d6 slashing damage per round",
                     "1d6 crushing damage and 1d6 slashing damage per round + 1d2 crushing damage and 1d2 slashing damage per round for every 5 levels of the caster (max. 2d12 crushing and 2d12 slashing damage at level 30)");
             }
            
             // Spike Growth
             identifiers = new String[]{
                 "Spike Growth"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"takes 1d4 points of piercing damage and 1d4 points of slashing damage",
                     "takes 1d2 points of piercing damage and 1d2 points of slashing damage + 1d1 points of piercing damage and 1d1 points of slashing damage every 3 levels of the caster (max. 1d12 points of piercing damage and 1d12 points of slashing damage at level 31)");
             }
            
             // Cloudburst
             identifiers = new String[]{
                 "Cloudburst"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"All cold- and fire-dwelling creatures take 2d3 points of magic damage per round. In addition, all creatures in the area have a 50% chance per round of being struck by bolts of lightning that deal 2d6 electrical damage, with a Save vs. Spell for half. Flame Blade, Shroud of Flame, and salamander auras are extinguished by Cloudburst.",
                     "All creatures in the area of effect will be struck by one bolt of lightning that deals 1d4 electrical and 1d4 magic damage (beginning at level 6) + 1d4 electrical and 1d4 magic damage for every 3 levels of the caster. The lightning damage can be saved against vs. Breath for half, the magic damage, however, is unavoidable. Flame Blade, Shroud of Flame, and salamander auras are extinguished by Cloudburst.");
             }
            
             // Mold Touch
             identifiers = new String[]{
                 "Mold Touch"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"If the infected creature fails a Save vs. Spell",
                     "If the infected creature fails a Save vs. Breath");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"\n\nEach round after the first, the nearest creature within 10 ft. of the victim must make a Save vs. Spell or be infected by the mold at full strength. This process continues until the mold fails to infect a suitable host in time. Creatures already under the effects of the mold cannot contract it again. The brown mold quickly dies once the spell expires.",
                     "");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "5 ft.");
             }
            
             // Storm Shell
             identifiers = new String[]{
                 "Storm Shell"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 4 rounds/2 levels");
             }
            
             // Favor of Ilmater
             identifiers = new String[]{
                 "Favor of Ilmater"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 turn + 1 round/2 levels");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"By invoking this spell, the caster switches <PRO_HISHER> own life force with that of the recipient, exchanging all physical injuries. The spell will only function if the caster has more Hit Points than the target before the switch is attempted. This switch is permanent until the caster uses normal methods to heal the damage. The exchange can be done from a distance so long as the spell range is not exceeded. Only the Hit Points are exchanged; the caster cannot take on other conditions from the target such as disease, poison, intoxication, and similar afflictions. ", 
                     "By invoking this spell, the caster invokes a favor of the god Ilmater, gifting to recipient 30 temporary Hit Points + 5 every 2nd level of the caster. The effect remains in effect for the duration of the spell.");
             }
            
             // Produce Fire
             identifiers = new String[]{
                 "Produce Fire"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d4", 
                     "2d12");
             }
            
             // Blood Rage
             identifiers = new String[]{
                 "Blood Rage"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "When cast, the target of this spell.*", 
                     "While under the effect of blood rage, they gain a +2 bonus to his Strength and Dexterity and become immune to charm, confusion, fear, feeblemind, hold, level drain, maze, stun, and sleep. They also gain 15 temporary Hit Points, which are taken away at the end of the berserk spree (possibly knocking them unconscious). Blood Rage cannot affect—and cannot be cast by—creatures of lawful alignment.");
             }
            
             // Cloud of Pestilence
             identifiers = new String[]{
                 "Cloud of Pestilence"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"save vs. Breath", 
                     "save vs. Breath with a -1 penalty");
             }
            
             // Unfailing Endurance Conversion to "REVIVE SKELETON ARCHER"
             identifiers = new String[]{
                 "Unfailing Endurance"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "8 hours");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "30 ft.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Special");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell restores the stamina of the creature touched, eliminating any fatigue.", 
                     "This spell causes one or more skeleton archers to rise and serve the caster under any conditions. The type and number of skeleton archers that appears depends upon the level of the wizard casting the spell:\n\n  8th - 9th:      1x 4 HD skeleton archer using a long bow and fire arrows.\n  10th - 11th:    2x 4 HD skeleton archers using a long bow and fire arrows.\n  12th - 13th:    1x 6 HD skeleton archer using a long bow and arrows +1.\n  14th - 15th:    2x 6 HD skeleton archers using a long bow and arrows +1.\n  16th - 18th:    1x 8 HD skeleton archer using a +1 long bow and ice arrows +1.\n  18th - 20th:    2x 8 HD skeleton archers using a +1 long bow and ice arrows +1.\n  20st - 22nd:    1x 10 HD skeleton archer using a +2 long bow and arrows +2.\n  22nd and above: 2x 10 HD skeleton archers using a +2 long bow and arrows +2.\n\nThe skeleton archers can follow the caster, remain in an area and attack any creature entering the place, etc. They remain animated until it is destroyed in combat, 8 hours pass, or it is turned. This spell cannot be dispelled.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Revive Skeleton Archer"); // change spell name in spell description
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, 
                     "Revive Skeleton Archer"); // change spell name itself
             }
            
             // Star Metal Cudgel CONVERSION TO  "CONE OF COLD"
             identifiers = new String[]{
                 "Star Metal Cudgel"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Instant");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "0");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "18-ft. cone with 90-deg. arc");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1/2");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell creates a meteoric iron magical club that deals 1d6\+2 points of crushing damage, confers a \+2 bonus to attack rolls, and is treated as a \+4 weapon for purposes of what it can hit. Strength, proficiency, and specialization bonuses and penalties apply normally. The club deals an additional 2d6 points of crushing damage against unnatural creatures \(undead, elementals, golems, outer-planar creatures, etc.\).", 
                     "When this spell is cast, the druid commands to force of winter by conjuring a cone-shaped area of extreme cold. It originates at the druid's hand and extends outward in a cone 18 ft. long with a 90-deg. arc. It drains heat and causes 1d4+1 points of damage per level of the caster. For example, a 10th-level druid would cast a cone of cold causing 10d4+10 points of damage.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Cone of Cold"); // change spell name in spell description
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, 
                     "Cone of Cold"); // change spell name itself
             }
            
             // Smashing Wave
             identifiers = new String[]{
                 "Smashing Wave"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"in addition, struck creatures may be either stunned \(25% chance\) or knocked unconscious \(5% chance\) for 2 rounds. If the creature struck makes a successful Save vs. Breath Weapon, the damage is reduced by half and the creature avoids being stunned or knocked unconscious.", 
                     "in addition, struck creatures may be either stunned (25% chance) or knocked unconscious (5% chance) for 2 rounds. The chance for both effects increases by 2% for every 2 levels of the caster up to a 45% chance of being stunned and 25% chance of being knocked unconscious at level 28. If the creature struck makes a successful Save vs. Breath Weapon with a -1 penalty, the damage is reduced by half and the creature avoids being stunned or knocked unconscious.");
             }
            
             // Thorn Spray
             identifiers = new String[]{
                 "Thorn Spray"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"By means of this spell, the caster can cause a spray of barbs, spikes, thorns, and spines to spring forth from <PRO_HISHER> hand. The thorn spray covers a 17-ft.-long cone, inflicting 4d10 points of piercing damage to all creatures within the area of effect.", 
                     "\nBy means of this spell, the caster can cause a spray of barbs, spikes, thorns, and spines to spring forth from <PRO_HISHER> hand. The thorn spray covers a 17-ft.-long cone, inflicting 4d10 points of piercing damage + 1 point of piercing damage per caster level to all creatures within the area of effect, up to a maximum up 4d10+30 at level 30.");
             }
            
             // Wall of Moonlight
             identifiers = new String[]{
                 "Wall of Moonlight"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Evil creatures passing through the wall take 2d10 magic damage; evil undead creatures take 5d10.", 
                     "Evil undead creatures take 6d10, non-undead evil creatures take 4d10, all other creatures take 2d10.");
             }
            
             // Righteous Wrath of the Faithful
             identifiers = new String[]{
                 "Righteous Wrath of the Faithful"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" Anyone affected by Righteous Wrath of the Faithful will suffer fatigue when the spell wears off.", 
                     "");
             }
            
             // Spike Stones
             identifiers = new String[]{
                 "Spike Stones"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Any creature entering the area takes 2d4 Hit Points of piercing damage per round and must make a Save vs. Spell or have its movement rate reduced by 30%.", 
                     "Any creature entering the area takes 2d4 Hit Points of piercing damage per round + 1 Hit Point every 2 levels of the caster and must make a Save vs. Breath with a -1 penalty or have its movement rate reduced by 50%.");
             }
            
             // Undead Ward
             identifiers = new String[]{
                 "Undead Ward"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @" If the turning fails, the undead creature is immune to further turning attempts by the spell unless it leaves and reenters the area of effect.", 
                     "");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2");
             }
            
             // Animal Rage CONVERSION TO NATURAL SELECTION
             identifiers = new String[]{
                 "Animal Rage"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Visual range of the caster");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "6");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Instant");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "15-ft. radius");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell imbues the target creature with animal ferocity. The target creature gains a Strength score of 19, \+20 Hit Points, \+20% movement rate, and a \+2 bonus to all Saving Throws. The target loses the ability to cast spells while Animal Rage is in effect; when enemies are within sight, <PRO_HESHE> immediately attacks in melee, using whatever is in hand. While this spell is in effect, there is a 5% chance per round that the target will go berserk, attacking friend and foe alike.", 
                     "When Natural Selection is cast, it snuffs out the life force of creatures within the area of effect, instantly and irrevocably, who are not fit in nature's eyes. Strong creatures with more than 8 Hit Dice are immune to this spell with the exception of summoned creatures, which are automatically slain as they are considered to be depended on their master. Only enemies are affected by this spell.");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "(Enchantment)", 
                     "(Necromancy)");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Natural Selection"); // change spell name in spell description
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, 
                     "Natural Selection"); // change spell name itself    
             }
            
             // Mass Cause Light Wounds CONVERSION TO CAUSE CROWD WOUNDS
             identifiers = new String[]{
                 "Mass Cause Light Wounds"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d8", 
                     "3d8");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Cause Crowd Wounds"); // change spell name in spell description
            
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, 
                     "Cause Crowd Wounds"); // change spell name itself    
             }
            
             // Whirlwind
             identifiers = new String[]{
                 "Whirlwind"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"it takes 2d8 crushing damage, 2d8 slashing damage, and must make a Save vs. Breath Weapon", 
                     "it takes 3d8 crushing damage, 3d8 slashing damage, and must make a Save vs. Breath Weapon at -2");
             }
            
             // Spiritual Wrath
             identifiers = new String[]{
                 "Spiritual Wrath"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"4d10 points of magic damage \(save vs. Spell for half\)", 
                     "5d6 points of magic damage + 1 points of magic damage per level of the caster (save vs. Spell at -3 for half)");
             }
            
             // Symbol, Pain
             identifiers = new String[]{
                 "Symbol, Pain"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 round/2 levels");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"must make a Save vs. Spell. Those who fail their Saving Throws are overwhelmed by pain, suffering a -4 penalty to their attack rolls, a -2 penalty to their Dexterity scores, and a -2 penalty to their Armor Class.", 
                     "must make a Save vs. Spell at -4. Those who fail their Saving Throws are overwhelmed by pain, suffering a 1 point of damage every second for the next 1 round + 1 round/2nd level of the caster. The victim will be almost driven insane by the effects of the pain, causing it to flee in panic in an effort to escape the agony.");
             }
            
             // Symbol, Hopelessness
             identifiers = new String[]{
                 "Symbol, Hopelessness"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 round/2 levels");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Spell with a -2 penalty or stand in place, overwhelmed by dejection and surrender. They will make no move to defend themselves from attack. This spell nullifies Emotion, Hope within the area of effect at the time of casting.", 
                     "Breath with a -3 penalty or stand in place, overwhelmed by dejection and surrender for the next 1 round + 1 round/2nd level of the caster. They will make no move to defend themselves from attack.");
             }
            
             // Mist of Eldath
             identifiers = new String[]{
                 "Mist of Eldath"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "Instant + 2 turns + 1 round/level");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     "This spell blankets the area of effect with a.*", 
                     "This spell blankets the area of effect with a silver-blue mist—any creature within the mist will be instantly cured of and become immune to disease, poison effects and being poisoned for 2 turns + 1 round per level of the caster. Furthermore, they are healed for 50 Hit Points and gain 50 temporary Hit Points for the duration of the spell.");
             }
             
             
            
             // *********************************
             // *********************************
             // *********************************
             // ADDITIONAL CHANGES (SUMMONS ETC.)
             // *********************************
             // *********************************
             // *********************************
             
             
             // Monster Summoning 1
             identifiers = new String[]{
                 "Monster Summoning I"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"2d3", 
                     "2d2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1st-level monsters. ", 
                     "a pack of 1st-level monsters consisting of following selection:\n\n  - Gnoll Veteran\n  - Hobgoblin Scout\n  - Half Ogre\n  - Ogrillon\n\n");
             }
             
             // Monster Summoning 2
             identifiers = new String[]{
                 "Monster Summoning II"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d6", 
                     "2d2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"2nd-level monsters. ", 
                     "a pack of 2nd-level monsters consisting of following selection:\n\n  - Hobgoblin Elite\n  - Hobgoblin Captain\n  - Hobgoblin Marksman\n  - Hobgoblin Priest\n  - Hobgoblin Wizard\n  - Gnoll Captain\n  - Gnoll Chieftain\n  - Gnoll Slasher\n\n");
             }
             
             // Monster Summoning 3
             identifiers = new String[]{
                 "Monster Summoning III"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d4", 
                     "2d2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"3rd-level monsters. ", 
                     "a pack of 3rd-level monsters consisting of following selection:\n\n  - Ogre\n  - Half-Ogre Veteran\n  - Ogre Berserker\n  - Lesser Ogre Mage\n\n");
             }
             
             // Monster Summoning 4
             identifiers = new String[]{
                 "Monster Summoning IV"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d3", 
                     "2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"4th-level monsters. ", 
                     "a pack of 4th-level monsters consisting of following selection:\n\n  - Ogre Mage\n  - Ogre Chieftain\n  - Ogre Shaman\n\n");
             }
             
             // Monster Summoning 5
             identifiers = new String[]{
                 "Monster Summoning V"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d3", 
                     "2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"5th-level monsters. ", 
                     "a pack of 5th-level monsters consisting of following selection:\n\n  - Greater Ghast\n  - Greater Ghoul\n  - Ghoul Lord\n  - Mummy\n  - Doppelganger  - Battle Horror\n  - Doom Guard\n\n");
             }
             
             // Monster Summoning 6
             identifiers = new String[]{
                 "Monster Summoning VI"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d3", 
                     "2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"6th-level monsters. ", 
                     "a pack of 6th-level monsters consisting of following selection:\n\n  - Giant Troll\n  - Snow Troll\n  - Troll Shaman\n  - Fire Troll\n\n");
             }
             
             // Monster Summoning 7
             identifiers = new String[]{
                 "Monster Summoning VII"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"1d2", 
                     "1d2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"7th- or 8th-level monsters. ", 
                     "a pack of 7th-level monsters consisting of following selection:\n\n  - Greater Doppelganger\n  - Doomsayer\n  - Revenant\n  - Greater Mummy\n\n");
             }
             
             // Animal Summoning 1
             identifiers = new String[]{
                 "Animal Summoning I"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"between 2 and 3", 
                     "2d2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"that have 4 Hit Dice or less. The animals appearing are randomly determined. ", 
                     "of the following kinds:\n\n  - Dread Wolf\n  - Black Bear\n  - Jaguar\n  - Leopard\n\n");
             }
             
             // Animal Summoning 2
             identifiers = new String[]{
                 "Animal Summoning II"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"from 1 to 3", 
                     "2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"that have 8 Hit Dice or less. The animals summoned aid the caster by whatever means they possess, staying until the spell duration expires. Only normal or giant animals can be summoned; fantastic animals or monsters cannot be summoned by this spell \(no chimerae, dragons, gorgons, manticores, etc.\).", 
                     "of the following kinds:\n\n  - Winter Wolf\n  - Old Boar\n  - Wild Tiger\n  - Brown Bear\n\nThe animals summoned aid the caster by whatever means they possess, staying until the spell duration expires.");
             }
             
             // Animal Summoning 3
             identifiers = new String[]{
                 "Animal Summoning III"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "1 hour");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"2 or 3", 
                     "1d2");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"that have 12 Hit Dice or less. Only animals within visual range of the caster at the time the spell is cast will come. The summoned animals aid the caster by whatever means they possess, staying until they are slain or the spell's duration expires. Only normal- or giant-sized animals can be summoned.", 
                     "of the following kinds:\n\n  - Polar Bear\n  - Stone Snake\n  - Cave Bear\n  - Panther\n\nThe animals summoned aid the caster by whatever means they possess, staying until the spell duration expires.");
             }
             
             // Conjure Animals
             identifiers = new String[]{
                 "Conjure Animals"
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "2 hours");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This spell allows the caster to summon forth and control 1 or 2 massive mountain bears. The bears will", 
                     "This spell allows the caster to summon forth and control a massive mountain bear, which embodies the strenth of nature. By virtue of nature, the bear will regenerate its health at an astonishing rate and");

                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"Conjure Animals", 
                     "Conjure Beast");
                 
                 EditTlkExistingEntry(identifier + @"\Z",
                     @"Conjure Animals", 
                     "Conjure Beast");
             }
             
             // Conjure Lesser Elementals
             identifiers = new String[]{
                 "Conjure Lesser Air Elemental",
                 "Conjure Lesser Fire Elemental",
                 "Conjure Lesser Earth Elemental",
                 "Conjure Lesser Water Elemental",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "4 hours");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"to summon an 8-HD elemental", 
                     "to summon 1d2 8-HD elementals");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"This elemental", 
                     "These elementals");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"the elemental is", 
                     "the elementals are");
             }
             
             // Conjure Elementals
             identifiers = new String[]{
                 "Conjure Air Elemental",
                 "Conjure Fire Elemental",
                 "Conjure Earth Elemental",
                 "Conjure Water Elemental",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)", 
                     "4 hours");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     @"There is a.*", 
                     "Initially, at level 9, there is a, equal chance for either a regular, a greater, or a elder elemental to appear. For every level above 9, this chance shifts by -3% for a regular, and +3% for an elder, until reaching 1% for a regular, 33% for a greater and 66% for an elder elemental. The conjured elemental will do the bidding of the caster until it is slain or the duration of the spell runs out. All the commands given to the elemental are done telepathically, so there is no time lost due to miscommunication and no need to know the language of the summoned creature.");
             }
             
             // Spider Spawn
             identifiers = new String[]{
                 "Spider Spawn",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1 hour");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"depends upon the level of the wizard casting the spell.*",
                     "depends upon the level of the wizard casting the spell:\n\n - Level 7 - 8:   2 giant spiders\n - Level 9 - 10: 1 giant spiders + 1x sword, wraith or phase spider\n - Level 11 - 12: 2x sword, wraith or phase spider\n - Level 13 - 14: 1x sword, wraith or phase spider + 1x vortex, gargantuan or astral phase spider\n - Level 15+:    2x vortex, gargantuan or astral phase spider\n\nThese spiders will remain under the wizard's control until they are slain, or until the spell duration expires.");
             }
             
             // Carrion Summons Conversion to Conjure Otyugh
             identifiers = new String[]{
                 "Carrion Summons",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "2 hours");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"There are two parts to this spell.*",
                     "When the wizard casts this spell, he/she conjures an Otyugh. Otyughs are foul, revolting creatures that feed primarily on offal and carrion. They are capable of both slowing and inflicting disease upon their victims. The kind of Otyughs brought forth by this spell depends on the level of the caster:\n\n - Level 11 - 14: 1 Otyugh\n - Level 15 - 18: 1 Greater Otyugh\n - Level 19+: 1 Neo-Otyugh\n\n These horrible creatures will follow every command of the caster until they are slain or the spell has expired.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Conjure Otyugh");
                 
                 EditTlkExistingEntry(identifier + @"\Z",
                     identifier, 
                     "Conjure Otyugh");
             }
             
             // Invisible Stalker Conversion to Summon Invisible Fighter
             identifiers = new String[]{
                 "Invisible Stalker",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "8 hours");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"This spell summons an invisible stalker from the Elemental Plane of Air.*",
                     "When the wizard casts this spell, an invisible creatures fight for the caster for the duration of the spell. However, the caster cannot control, which type of creatures are conjured, so that the result of using this spell determined purely by luck. The following creature types can be brought forth:\n\n - Invisible Stalker\n - Ashirukuru\n - Helmed Horror\n\nThese creatures will use their invisibility powers at their own discretion.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Summon Invisible Fighter");
                 
                 EditTlkExistingEntry(identifier + @"\Z",
                     identifier, 
                     "Summon Invisible Fighter");
             }
             
             // Summon Nishruu
             identifiers = new String[]{
                 "Summon Nishruu",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "2 hours");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"the wizard loses 1 random spell of the highest level currently memorized.",
                     
                     "the hit creature loses 1 random spell of the highest level currently memorized and the magical drain will entail a complete inability to cast spells successfully for the next round (save vs Breath at negates both effects).");
             }
             // Summon Hakeashar
             identifiers = new String[]{
                 "Summon Hakeashar",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "2 hours");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @", two things happen: First, all magical items with charges in the possession of the target will be drained by 1 charge, destroying them if only 1 charge was left; second, it causes the wizard to lose 1 random spell of the highest level currently memorized.",
                     "the hit creature loses 2 random spells of the highest level currently memorized and the magical drain will entail a complete inability to cast spells successfully for the next two rounds (save vs Breath at -2 negates both effects).");
             }

             // Wyvern Call
             identifiers = new String[]{
                 "Wyvern Call",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "3 hours");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"When this spell is cast, the wizard opens up a magical channel that will summon a wyvern to <PRO_HISHER> aid.",
                     "When this spell is cast, the wizard opens up a magical channel that will summon a wyvern to <PRO_HISHER> aid. The type of wyvern depends on the level of the caster:\n\n - Level 11 - 13: Wyvern\n - Level 14+:   Greater Wyvern\n\n");
             }
             
             // Summon Djinni Conversion to Summon Demon Knight 
             identifiers = new String[]{
                 "Summon Djinni",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1 hour");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"With this spell, the wizard can cajole.*",
                     "By means of this spell, the caster calls an outer planar creature to attack his foes and himself if not careful. The creature summoned in is a Death Knight, a powerful undead demon. The summoner can attempt to compel the demon to perform a service for him for the duration of the spell. Charismatic and powerful casters may bind the creature's will, intelligent and wise ones may negotiate with it, but dealing with these demonic creatures is always dangerous, and sometimes it may lead to disaster. Mages are warned to be careful of this spell, for a mistreated Death Knight will turn on his summoner at the first available opportunity.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Summon Demon Knight");
                 
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, 
                     "Summon Demon Knight");
             }
             
             // Stalker Conversion to Summon Demon Knight 
             identifiers = new String[]{
                 "Stalker",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1 hour");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"This spell creates two 11-HD shambling mounds.*",
                     "By means of this spell, the caster calls an outer planar creature to attack his foes and himself if not careful. The creature summoned in is a Death Knight, a powerful undead demon. The summoner can attempt to compel the demon to perform a service for him for the duration of the spell, but cannot directly order it around. Charismatic and powerful casters may bind the creature's will, intelligent and wise ones may negotiate with it, but dealing with these demonic creatures is always dangerous, and sometimes it may lead to disaster. Mages are warned to be careful of this spell, for a mistreated Death Knight will turn on his summoner at the first available opportunity.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n", 
                     identifier, 
                     "Summon Demon Knight");
                 
                 EditTlkExistingEntry(identifier + @"\Z", 
                     identifier, 
                     "Summon Demon Knight");
             }
             
             // Summon Efreeti
             identifiers = new String[]{
                 "Summon Efreeti",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "4 hours");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"Elemental Plane of Fire and enter the Prime Material.",
                     "Elemental Plane of Fire and enter the Prime Material. Coming from the Plane of Fire, the genie's primary element is fire and he will cast spells correspondent to this element. Furthermore, it is not only immune to, but is even healed by fire.");
             }
             
             // Create Boneguard
             identifiers = new String[]{
                 "Create Boneguard",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "8 hours");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"calls forth 1d2 boneguards",
                     "creates a powerful skeletal protector for himself/herself");
             }
             
             // Shadow Monsters CONVERSION TO JELLY CONJURING
             identifiers = new String[]{
                 "Shadow Monsters",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1 hour");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"This spell shapes material from the Demiplane of Shadow into illusionary monsters. Up to six shadowy creatures can be summoned at once, but their total Hit Dice will normally not exceed the spellcaster's level.",
                     "This brings to life 2 slimes or jellies and alignes their allegiance to the caster. Consequently, the creatures will follow and defend its master, attacking enemies fiercly. The exact type of slime depends on the caster level:\n\n - Level 7 - 9: 2 Ochre Jellies or Olive slimes\n - Level 10 - 12: 2 Mustard Jellies\n - Level 13+: 2 Fission Slimes\n\nThe creatures will obey their master's comands until they are slain or the spell duration has expired.");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     identifier + @"\n\(Illusion/Phantasm\)",
                     "Jelly Conjuring\n(Conjuration)"); // change spell name in desc
                  
                 EditTlkExistingEntry(identifier + @"\Z",
                        identifier,
                        "Jelly Conjuring"); // change spell name itself
             }
             
             // Demi-Shadow Monsters CONVERSION TO MIND FOG
             identifiers = new String[]{
                 "Demi-Shadow Monsters",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "4 rounds + 1 round/3 levels");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "15-ft. radius");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Saving Throw: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "Neg.");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"This spell is similar to the 4th-level wizard spell Shadow Monsters, except the summoned creatures are much more powerful.",
                     "When the wizard casts as Mind Fog spell, a bank of then mist that weakens the mental resistance of those caught within it. Creatures in the mind fog hav to save vs. Breath every round or incur a -3 drain to intelligence and wisdom for every round they remain in the area of effect. While their mental faculties are drained, they will also experience a 25% loss of their base luck value. Once they leave the fog, all effects will endure for 4 rounds after their last failed save until their mind is clear again.\n\nEvery 3 levels up to level 26, the intelligence and wisdom drain increases by one (the luck penalty, however, will not increase) - concurrently, the after effect duration of the drain is heightened by 1 round. At level 23, the spell reaches its maximum potential with a -7 drain and a drain duration of 8 rounds.\n\nThis spell is particularly devastating for unintelligent and/or unwise creatures at higher caster levels, as, once their intelligence/wisdom score reaches 0, their bodies will be unable to sustain vital life functions and they will die instantly.");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     identifier,
                     "Mind Fog");
                 
                 EditTlkExistingEntry(identifier + @"\Z",
                     identifier,
                     "Mind Fog");
             }
             
             // Shades CONVERSION TO MOMENT OF PRESCIENCE
             identifiers = new String[]{
                 "Shades",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "4 rounds");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Range: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "Personal");
                 
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Casting Time: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Area of Effect: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "The caster");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"Shades is similar to Shadow Monsters and Demi-Shadow",
                     "This spell grants an almost omniscient perception of things to come for a short duration. While this spell is in effect, the wizard's armor class is improved by 20 points, he is immune to backstabbing and any save is made by the caster with a +20 bonus. Although cast very quickly, this spell takes out a lot of the caster and can only be maintained for 4 rounds before wearing off. Hence, it is a mostly a defensive option, used to buy the wizard a few rounds in the thick of intense combat.");
                     
                 EditTlkExistingEntry(identifier + @"( )?\n",
                     identifier + @"\n\(Illusion/Phantasm\)",
                     "Moment of Prescience\n(Divination)"); // change spell name in desc
                  
                 EditTlkExistingEntry(identifier + @"\Z",
                     identifier,
                     "Moment of Prescience"); // change spell name itself
             }
             
             // Cacofiend
             identifiers = new String[]{
                 "Cacofiend",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1 hour");
             }
             
             // Summon Fiend
             identifiers = new String[]{
                 "Cacofiend",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1 hour");
             }
             
             // Gate
             identifiers = new String[]{
                 "Gate",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     @"(?<=Duration: )[\w\d,\./\\'-_ ]+?(?=\n)",
                     "1 hour");
             }
             
             // Giant Insect
             identifiers = new String[]{
                 "Giant Insect",
             };
             foreach (String identifier in identifiers)
             {
                 Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                 EditTlkExistingEntry(identifier + @"( )?\n",
                     "This spell summons.*",
                     "This spell summons 3 beetles to the caster's side. The type of beetle depends on the caster's level and may consist of the following beetles:\n\n  Boring Beetle\n  Bombardier Beetle\n  Battle Beetle\n  Stinking Beetle\n\nThe beetles will obey the caster until the spell expires or they are slain.");
             }
        }
    }
}