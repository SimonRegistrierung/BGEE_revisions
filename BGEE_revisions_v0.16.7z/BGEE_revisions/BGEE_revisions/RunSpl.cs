﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunSpl()
        {
            // ***************
            // BEGIN MODDING
            // ***************
            
            // ************ //
            // MISC CHANGES //
            // ************ //
            
            // create dismiss spell for summoned creature
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN110."))
            {
                AddTlkEntry("Dismiss Creature");
            
                // Console.WriteLine(splExtHeadersModded.Count);
                RemoveAllSplFeatureBlocks(0);
            
                splHeaderModded.castingSound = new string(new char[8]);
                splHeaderModded.flags = GetBitfieldInt(new int[] { 14, 15, 25 });
                splHeaderModded.spellBookIcon = "SPUNSUMM";
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Dismiss Creature");
                splHeaderModded.spellNameId = -1;
                splHeaderModded.spellDescriptionId = -1;
                splHeaderModded.spellDescriptionUnId = -1;

                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPUNSUMM";
                splExtHeadersModded[0] = currentSplExtendedHeader;
                
                AddSplFeatureBlockToSplExtendedHeader(68, 1, 0, 1, 0, 1, 0, 0, 100, 0, "SPGFLSH1", 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
                FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPUNSUMM.SPL");
            }
            
            // change repair golems casting time
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "a7!glr"))
            {
                foreach (SplExtendedHeader extendedHeaderModded in splExtHeadersModded)
                {
                    SplExtendedHeader currentSplExtendedHeaderModded = extendedHeaderModded;
                    currentSplExtendedHeaderModded.castingTime = 1;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // change repair golems repair time
            index = 0;
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "a7!glr1"))
            {
                foreach (SplFeatureBlock featureBlockModded in splFeatBlocksModded)
                {
                    SplFeatureBlock currentSplFeatureBlockModded =
                        (SplFeatureBlock) splFeatBlocksModded[index];
                    currentSplFeatureBlockModded.duration = 1;
                    // Console.WriteLine(currentFeatureBlockModded.duration);
                    // featureBlocksModded[featureBlockModdedIndex] = castingFeatureBlocksModded;
                    index++;
                }
        
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded,
                    splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            index = 0;
            // MAKE BOMBARDIER BEETLE ATTACK SAVABLE
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN100.SPL"))
            {
                RemoveAllSplFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(139, 1, 0, FindFirstExactTlkEntry("Releases Acidic Vapor"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 129, 4, 1, 2, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 0, 0, 0, 1, 1, 2, 0, 100, 0, new string(new char[8]), 3, 4, GetBitfieldInt(new int[] {24}), 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(74, 2, 0, 0, 0, 0, 2, 30, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 112, 0, 2, 30, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 0, FindFirstExactTlkEntry("Deafness"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(80, 2, 0, 0, 0, 0, 2, 30, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 8, 0, 2, 30, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 0, FindFirstExactTlkEntry("Blinded"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded,
                    splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // MAKE ALL LIGHTNING BOLTS NO BOUNCE
            for (int i = 0; i < splExtHeadersModded.Count; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                if (currentSplExtendedHeader.projectile == 40 || currentSplExtendedHeader.projectile == 206)
                {
                    currentSplExtendedHeader.projectile = 207;
                    FixSplOffsets();
                    FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                }
            }
        
            // MAKE BUFF SPELLS AOE
   
            identifiers = new String[]
            {
                "Aid",
                "Barkskin",
                "Bless",
                "Blood Rage",
                "Cat's Grace",
                // "Cure Disease",
                "Chaotic Commands",
                "Champion's Strength",
                // "Cure Light Wounds",
                // "Cure Medium Wounds",
                // "Cure Moderate Wounds",
                // "Cure Serious Wounds",
                // "Cure Critical Wounds",
                "Death Ward",
                "Defensive Harmony",
                "Detect Evil",
                "Emotion, Courage",
                "Emotion, Hope",
                "Enchanted Weapon",
                "Free Action",
                "Exaltation",
                "Haste",
                "Improved Haste",
                // "Improved Invisibility",
                // "Invisibility",
                "Invisibility, 10' Radius",
                "Lesser Restoration",
                "Luck",
                "Greater Restoration",
                "Mass Invisibility",
                "Negative Plane Protection",
                "Non-Detection",
                "Prayer",
                "Protection From Acid",
                "Protection From Cold",
                "Protection From Electricity",
                "Protection From Energy",
                "Protection From Evil",
                "Protection From Evil, 10' Radius",
                "Protection From Fire",
                "Protection From Lightning",
                "Protection From Magic Energy",
                "Protection From Magical Weapons",
                "Protection From Normal Missiles",
                "Protection From Normal Weapons",
                "Protection From Petrification",
                "Protection From The Elements",
                "Recitation",
                "Remove Fear",
                "Resist Fear",
                "Resist Fire and Cold",
                "Righteous Wrath of the Faithful",
                "Spirit Armor",
                "Spiritual Clarity",
                "Spirit Ward",
                "Strength",
                "Strength of One",
                "Undead Ward"
            };
            found = identifiers.Contains(currentName);
            if (found && !ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPCL104.") && !ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPCL105.")) // exclude the innate abilities for the blackguard
            {
                index = 0;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    SplExtendedHeader currentSplExtendedHeaderModded = (SplExtendedHeader)splExtHeadersModded[index];
                    currentSplExtendedHeaderModded.projectile = 162;
                    currentSplExtendedHeaderModded.target = 5;
                    splExtHeadersModded[index] = currentSplExtendedHeaderModded;
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // make healing spells ranged spells
            identifiers = new String[]{
                "Cause Light Wounds",
                "Cause Medium Wounds",
                "Cause Moderate Wounds",
                "Cause Serious Wounds",
                "Cause Critical Wounds",
                "Cure Light Wounds",
                "Cure Medium Wounds",
                "Cure Moderate Wounds",
                "Cure Serious Wounds",
                "Cure Critical Wounds",
                "Heal",
                "Improved Invisibility",
                "Invisibility",
                "Neutralize Poison",
                "Slow Poison",
                "Cause Disease",
                "Cure Disease",
                "Remove Curse",
                "Remove Paralysis",
                "Regeneration"
            };
            found = identifiers.Contains(currentName);
            if (found) // exclude the innate abilities for the blackguard
            {
                index = 0;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    SplExtendedHeader currentSplExtendedHeaderModded = (SplExtendedHeader)splExtHeadersModded[index];
                    currentSplExtendedHeaderModded.range = 30;
                    splExtHeadersModded[index] = currentSplExtendedHeaderModded;
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            
            // double innate abilities of multiclass kits (ABEL MULTICLASS MOD)
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "QD_"))
            {
                SplExtendedHeader currentExtendedHeaderModded = null;
                SplFeatureBlock currentFeatureBlockModded = null;
                ArrayList temp = new ArrayList();
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {   
                    currentExtendedHeaderModded = (SplExtendedHeader)splExtHeadersModded[i];
                    for (int j = 0; j < splFeatBlocksModded.Count; j++)
                    {
                        currentFeatureBlockModded = (SplFeatureBlock)splFeatBlocksModded[j];
                        if (currentFeatureBlockModded.opcodeNumber == 177)
                        {
                            if (
                                currentFeatureBlockModded.resource.Contains("SPCL144#") ||
                                currentFeatureBlockModded.resource.Contains("SPCL311#") ||
                                currentFeatureBlockModded.resource.Contains("SPCL321#") ||
                                currentFeatureBlockModded.resource.Contains("SPCL412#") ||
                                currentFeatureBlockModded.resource.Contains("SPCL423#") ||
                                currentFeatureBlockModded.resource.Contains("SPCL741#") ||
                                currentFeatureBlockModded.resource.Contains("SPCL742#") ||
                                currentFeatureBlockModded.resource.Contains("SPCL199#") // assassin invis
                            )
                            {
                                temp.Add(currentFeatureBlockModded);
                                // Console.WriteLine(currentFeatureBlockModded.parameter1);
                            }
                        }
                    }
                }
   
                if (temp.Count > 0 && null != currentExtendedHeaderModded && null != currentFeatureBlockModded)
                {
                    for (int k = 0; k < temp.Count; k++)
                    {
                        splFeatBlocksModded.Add(temp[k]);
                        currentExtendedHeaderModded.featureBlockCount++;
                    }
                    FixSplOffsets();
				    FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                }
            }
   
               // change spell levels for bhaalspawn abilities and golem construction
            if (
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN101.") ||
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN102.") ||
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN103.") ||
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN104.") ||
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN105.") ||
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN106.")
            )
            {
                splHeaderModded.spellLevel = 2;
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            if (
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "a7!smgl") ||
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "a7!glr.spl")
            )
            {
                splHeaderModded.spellLevel = 3;
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // UN-NERF POISON WEAPON
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "BDPWEAPN."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplCastingFeatureBlocks();
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(318, 2, 0, 0, 55, 0, 0, 0, 100, 0, "BDPWEAPN", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 2, 0, 0, 77, 0, 0, 0, 100, 0, "BDPWEAPN", 0, 0, 0, 0, 0, 0);
                // AddTlkEntry("Cannot be poisoned this round again");
                // AddFeatureBlockToExtendedHeader(206, 2, 0, FindFirstExactTlkEntry("Cannot be poisoned this round again"), 0, 0, 0, 6, 100, 0, "BDPWEAPN", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(25, 2, 0, 1, 2, 0, 0, 12, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 6, 0, 0, 12, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                // AddSplFeatureBlockToSplExtendedHeader(139, 2, 0, FindFirstExactTlkEntry("Poisoned"), 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 5;
                }
   
                index = 0;
                int foundDuration = 0;
                int duration = 12;
                int foundSavingBonus = 0;
                int savingBonus = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.savingThrowType == 4)
                    {
                        featureBlock.savingThrowBonus = savingBonus;
                        foundSavingBonus++;
                    }
                    
                    if (featureBlock.savingThrowType == 4 && featureBlock.opcodeNumber != 139)
                    {
                        featureBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 2)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                    
                    if (foundSavingBonus == 3)
                    {
                        savingBonus--;
                        foundSavingBonus = 0;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // IMPROVE KAI DURATION
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPCL144."))
            {
                AddSplFeatureBlockToSplExtendedHeader(73, 2, 1, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(54, 2, 1, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                // protection from spell
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 2, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "spcl144" + new char(), 0, 0, 0, 0, 0, 0);
   
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.projectile = 1;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                }
   
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration == 10)
                    {
                        currentSplFeatBlock.duration = 60;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // MAKE OFFENSIVE SPIN COMPATIBLE WITH HASTE SPELLS
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPL521."))
            {
                RemoveSplOpcode(206, 0);
                RemoveSplOpcode(101, 0);
                
                RemoveSplOpcode(321, "SPWI305");
                RemoveSplOpcode(321, "SPRA301");
                RemoveSplOpcode(321, "SPIN828");
                RemoveSplOpcode(321, "SPIN572");
                
                RemoveSplOpcode(126, 0);
                RemoveSplOpcode(1, 0);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration == 10)
                    {
                        currentSplFeatBlock.duration = 36;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            
            //  mod      "ARMOR"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI102."))
            {
                // String name = "Armor";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Abjuration\)");
                
                // add three new extended headers and feature blocks
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                // increase required levels and armor class for each extendedHeader
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 3;
                }
            
                // increase armor class for each featureBlock
                int ac = 6;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber == 0)
                    {
                        featureBlock.parameter1 = ac;
                        // Console.WriteLine(featureBlock.parameter1);
                        ac = ac - 1;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "INFRAVISION" CONVERSION TO TRUE STRIKE
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI111."))
            {
                // String name = "Infravision";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Abjuration\)");
                
                // add three new extended headers and feature blocks
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
            
                rgb = new byte[] {0, 86, 0, 86};
                
                AddSplFeatureBlockToSplExtendedHeader(278, 2, 1, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(301, 2, 1, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 4, 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 4, 0, 1, 3, 0, 100, 0, "EFF_M04" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 57, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 1, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPWI111" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                // increase required levels and armor class for each extendedHeader
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.target = 5;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 1;
                }
            
                // increase armor class for each featureBlock
                int foundDuration = 0;
                int duration = 60;
                int foundThaco = 0;
                int thaco = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.duration > 10)
                    {
                        featureBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (featureBlock.opcodeNumber == 278)
                    {
                        featureBlock.parameter1 = thaco;
                        foundThaco++;
                    }
            
                    if (foundDuration == 8)
                    {
                        duration += 24;
                        foundDuration = 0;
                    }
                    
                    if (foundThaco == 3)
                    {
                        thaco++;
                        foundThaco = 0;
                    }
            
                    if (featureBlock.duration > 200) // reset the last level to exactly 3 turns duration (180)
                    {
                        featureBlock.duration = 180;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SLEEP"
            // sleep change
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI116."))
            {
                // String name = "Sleep";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL0", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL1", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL2", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL3", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL4", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL0", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL1", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL2", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL3", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL4", 0, 0,0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(39, 2, 1, 0, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0,1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 14, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0,1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 1, 0, 1, 0, 1, 1, 100, 0, "SPNWCHRM", 0, 0,1, 0, 0, 0);
                // AddSplFeatureBlockToSplExtendedHeader(232, 2, 1, 0, 0, 0, 1, 60, 100, 0, "WAND80D" + new string(new char[1]), 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Unconscious"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                // Console.WriteLine(castingFeatureBlocksModded.Count);
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SHIELD"
            // friends duration change
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI114."))
            {
                // String name = "Shield";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 600;
                    }
                    index++;
                }
                // Console.WriteLine(castingFeatureBlocksModded.Count);
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "BLINDNESS"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI106."))
            {
                AddSplFeatureBlockToSplExtendedHeader(0, 2, 1, -6, 0, 0, 3, 600, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(54, 2, 1, -6, 0, 0, 3, 600, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "PROTECTION FROM PETRIFICATION"
            // make protection from petrification "true" protection from all gaze attacks
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI108."))
            {
                // String name = "Protection From Petrification";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Abjuration\)");
                
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 0, 0, 64, 0, 0, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 0, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 64, 0, 0, 300, 100, 0, "SPIN883" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 0, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 64, 0, 0, 300, 100, 0, "SPIN839" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
            
                // SplExtendedHeader x = (SplExtendedHeader) extendedHeadersModded[0];
                // Console.WriteLine(x.target);
                // int[] c = new []{ 2 };
                // Console.WriteLine(c[1]);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FRIENDS"
            // friends duration change
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI107."))
            {
                // String name = "Friends";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 300;
                    }
                    index++;
                }
                // Console.WriteLine(castingFeatureBlocksModded.Count);
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "LARLOCH'S MINOR DRAIN"
            // friends duration change
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI119.") || ContainsCaseInsensitive(currentSpellFileInfo.Name,"SPIN104."))
            {
                // String name = "Larloch's Minor Drain";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                // RemoveAllFeatureBlocks();
                // AddFeatureBlockToExtendedHeader(146, 2, 1, 1, 1, 1, 1, 0, 100, 0, "SPWI119Z", 0, 0, 0, 0, 0, 0);
                // protection from spell
                // AddFeatureBlockToExtendedHeader(206, 1, 1, FindFirstTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 300, 100, 0, "SPWI119Z", 0, 0, 0, 0, 0, 0);  
            
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.projectile = 1;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                }
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 146)
                    {
                        currentSplFeatBlock.resource = "spwi119z";
                    }
                    index++;
                }
                
                // headerModded.descriptionIcon = new string(new char[8]);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // create helper spells
                
                CreateSplObjects("SPWI119.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 4, 0, 64, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(18, 1, 1, 4, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 1, 0, 0, 4, 3, 60, 100, 0, "EFF_E04" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 0, 3, 0, 100, 0, "EFF_M07" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 1, 0, 0, 4, 3, 60, 100, 0, "EFF_E04" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 2, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                AddTlkEntry("Health Drained");
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Health Drained"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 1, 1, FindFirstExactTlkEntry("Healed"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.projectile = 1;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI119Z.SPL");
            
                //
                
            }
            
            //  mod      "PROTECTION FROM EVIL"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI113.") || ContainsCaseInsensitive(currentSpellFileInfo.Name,"SPPR107.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPCL213."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 60;
                    }
                    index++;
                }
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
   
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration += duration;
                        foundDuration++;
                    }
   
                    if (foundDuration == 12)
                    {
                        foundDuration = 0;
                        duration += 60;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CHARM PERSON"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI104."))
            {
                // String name = "Charm Person";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowBonus == 3)
                    {
                        currentSplFeatBlock.savingThrowBonus = 2;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CHILL TOUCH" CONVERSION TO DIMENSION JUMP
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI117."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(141, 1, 1, 0, 38, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(100, 1, 1, 0, 2, 0, 0, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(124, 1, 1, 0, 0, 1, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 1, 1, 1, 38, 1, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(101, 1, 1, 0, 12, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.range = 40;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                splHeaderModded.primaryTypeSchool = 8;
                splHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {6});
                splHeaderModded.castingGraphics = 10;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "BURNING HANDS"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI103."))
            {
                // String name = "Burning Hands";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
            
                index = 0;
                int damage1 = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    // Console.WriteLine(currentFeatureBlock.diceThrown + ":" + currentFeatureBlock.diceSides);
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = damage1;
                        damage1++;
                    }
                    
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CHROMATIC ORB"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI118.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPDR101"))
            {
                // String name = "Chramatic Orb";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 1, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 1, 2, 1, 1, 0, 100, 0, "spwi118a", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 3, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 3, 2, 1, 1, 0, 100, 50, "spwi118a", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 3, 2, 1, 1, 0, 49, 0, "spwi118b", 0, 0, 0, 0, 0, 1);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 5, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 5, 2, 1, 1, 0, 100, 66, "spwi118a", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 5, 2, 1, 1, 0, 65, 33, "spwi118b", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 5, 2, 1, 1, 0, 32, 0, "spwi118c", 0, 0, 0, 0, 0, 2);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 7, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 7, 2, 1, 1, 0, 100, 75, "spwi118a", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 7, 2, 1, 1, 0, 74, 50, "spwi118b", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 7, 2, 1, 1, 0, 49, 25, "spwi118c", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 7, 2, 1, 1, 0, 24, 0, "spwi118d", 0, 0, 0, 0, 0, 3);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 9, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 9, 2, 1, 1, 0, 100, 80, "spwi118a", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 9, 2, 1, 1, 0, 79, 60, "spwi118b", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 9, 2, 1, 1, 0, 59, 40, "spwi118c", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 9, 2, 1, 1, 0, 39, 20, "spwi118d", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 9, 2, 1, 1, 0, 19, 0, "spwi118e", 0, 0, 0, 0, 0, 4);
   
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 11, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 11, 2, 1, 1, 0, 100, 85, "spwi118a", 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 11, 2, 1, 1, 0, 84, 70, "spwi118b", 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 11, 2, 1, 1, 0, 69, 50, "spwi118c", 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 11, 2, 1, 1, 0, 49, 35, "spwi118d", 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 11, 2, 1, 1, 0, 34, 20, "spwi118e", 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 11, 2, 1, 1, 0, 19, 0, "spwi118f", 0, 0, 0, 0, 0, 5);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 100, 87, "spwi118a", 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 86, 73, "spwi118b", 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 72, 59, "spwi118c", 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 58, 45, "spwi118d", 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 44, 32, "spwi118e", 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 31, 19, "spwi118f", 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 13, 2, 1, 1, 0, 18, 0, "spwi118g", 0, 0, 0, 0, 0, 6);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 100, 0, "spwi118z", 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 100, 75, "spwi118a", 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 100, 75, "spwi118b", 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 74, 50, "spwi118c", 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 74, 50, "spwi118d", 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 49, 25, "spwi118e", 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 49, 25, "spwi118f", 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 15, 2, 1, 1, 0, 24, 0, "spwi118g", 0, 0, 0, 0, 0, 7);
            
                index = 0;
                level = 1;
                // short offset = 2;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    // currentSplExtendedHeader.featureBlockOffset = offset;
                    // offset += (short)(currentSplExtendedHeader.featureBlockCount);
                    level += 2;
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                    
                // create helper spells
                
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(33, 2, 1, -4, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(34, 2, 1, -4, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(35, 2, 1, -4, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(36, 2, 1, -4, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(37, 2, 1, -4, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Saving Throws Lowered"), 0, 0, 3, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 29, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 100, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 3, 3, 30, 100, 0, "EFF_E05" + new char(), 0, 0, 1, 0, 0, 0);
   
   
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118A.SPL");
            
                //
            
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(0, 2, 1, -4, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddTlkEntry("Armor Class lowered");
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Armor Class lowered"), 0, 0, 3, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 29, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 94, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 3, 3, 30, 100, 0, "EFF_E05" + new char(), 0, 0, 1, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118B.SPL");
            
                //
            
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 16, 0, 3, 0, 100, 0, new string(new char[8]), 1, 2, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 16, 3, 3, 6, 100, 0, new string(new char[8]), 1, 2, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 16, 3, 3, 12, 100, 0, new string(new char[8]), 1, 2, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 16, 3, 3, 18, 100, 0, new string(new char[8]), 1, 2, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 16, 3, 3, 24, 100, 0, new string(new char[8]), 1, 2, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 16, 3, 3, 30, 100, 0, new string(new char[8]), 1, 2, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 137, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 29, 1, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 3, 3, 30, 100, 0, "EFF_E05" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Bleeding"), 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118C.SPL");
            
                //
            
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(25, 2, 1, 3, 3, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 6, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 29, 1, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 3, 3, 30, 100, 0, "EFF_E05" + new char(), 0, 0, 1, 0, 0, 0);
                // AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Poisoned"), 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118D.SPL");
            
                //
            
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(74, 2, 1, 0, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                rgb = new byte[] {0, 127, 127, 127};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 1, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 8, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 29, 1, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 4, 3, 30, 100, 0, "EFF_E05" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Blinded"), 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 1, 0, 1, 0, 3, 3, 100, 0, "SPH1HI01", 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 1, 0, 1, 0, 3, 3, 100, 0, "SPHLHI02", 0, 0, 1, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118E.SPL");
                
                //
            
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "IBODHI3" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "MELS545" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "A7_IST5" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "FINSLOW" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "SPIN977" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "SPWISH25", 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "SPWM164" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "SPIN983" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "SPIN575" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 1, 0, 0, 1, 0, 0, 100, 0, "SPWI312" + new char(), 0, 0, 1, 0, 0, 0);
                //AddFeatureBlockToExtendedHeader(221, 2, 1, 3, 12, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                //AddFeatureBlockToExtendedHeader(221, 2, 1, 3, 15, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                //AddFeatureBlockToExtendedHeader(221, 2, 1, 3, 15, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(40, 2, 1, 0, 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 6, 1, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 41, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 0, 3, 0, 100, 0, "EFF_M29" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 3, 3, 30, 100, 0, "EFF_M28" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Slowed"), 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118F.SPL");
            
                //
                
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(109, 2, 1, 0, 2, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 13, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                rgb = new byte[] {0, 87, 54, 0};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 1, BitConverter.ToInt32(rgb, 0), 0, 0, 25, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 5, 1, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 3, 3, 30, 100, 0, "EFF_E05" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Paralyzed"), 0, 0, 3, 30, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118G.SPL");
                
                //
                
                CreateSplObjects("SPWI118.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 64, 1, 3, 0, 100, 0, new string(new char[8]), 1, 4, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 25, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 1, 0, 0, 100, 0, "EFF_M83" + new char(), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                ModifySplOpcodeSpecific(12, "diceSides", 4, 6, 1);
                
                ModifySplOpcodeSpecific(12, "diceSides", 4, 8, 2);
                
                ModifySplOpcodeSpecific(12, "diceSides", 4, 10, 3);
                
                ModifySplOpcodeSpecific(12, "diceSides", 4, 6, 4);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 2, 4);
                
                ModifySplOpcodeSpecific(12, "diceSides", 4, 8, 5);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 2, 5);
                
                ModifySplOpcodeSpecific(12, "diceSides", 4, 10, 6);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 2, 6);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 1;
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 1;
                currentSplExtendedHeader.featureBlockOffset = 0;
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI118Z.SPL");
            }
            
            //  mod      "REFLECTED IMAGE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI120."))
            {
                // String name = "Reflected Image";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                // casting visual effect
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 1, 0, 1, 0, 3, 2, 100, 0, "SPPROIMG", 0, 0, 0, 0, 0, 0);  
                // cast Extended spells repeatedly
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 1, 3, 0, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 6, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 12, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 18, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 24, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 30, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 36, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 42, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 48, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 54, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 60, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 66, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 72, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 78, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 84, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 90, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 96, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 102, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 108, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 114, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 120, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                // cast Extended spells repeatedly to accommodate for longer spell duration
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 126, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 132, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 138, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 144, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 150, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 156, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 162, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 168, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 174, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 180, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 1);
                
                // cast Extended spells repeatedly to accommodate for longer spell duration
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 126, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 132, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 138, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 144, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 150, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 156, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 162, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 168, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 174, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 180, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 186, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 192, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 198, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 204, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 210, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 216, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 222, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 228, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 234, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 240, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 2);
                
                // cast Extended spells repeatedly to accommodate for longer spell duration
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 126, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 132, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 138, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 144, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 150, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 156, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 162, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 168, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 174, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 180, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 186, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 192, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 198, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 204, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 210, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 216, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 222, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 228, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 234, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 240, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 246, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 252, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 258, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 264, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 270, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 276, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 282, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 288, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 294, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 300, 100, 0, "SPWI120D", 0, 0, 0, 0, 0, 3);
                
                // protection from spell
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 120, 100, 0, "SPWI212" + new string(new char[1]), 0, 0, 0, 0, 0, 0);  
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 180, 100, 0, "SPWI120" + new string(new char[1]), 0, 0, 0, 0, 0, 1);  
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 240, 100, 0, "SW1H26" + new string(new char[2]), 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 300, 100, 0, "SW1H26" + new string(new char[2]), 0, 0, 0, 0, 0, 3);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 5;
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // create helper spells
                
                CreateSplObjects("SPWI120.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(159, 1, 1, 1, 0, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI120D.SPL");
            
                //
            }
            
            //  mod      "KNOCK"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI207."))
            {
                // String name = "Knock";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 0, 0, 0, 0, 1, 0, 100, 0, new string(new char[8]), 2, 4, 1, -1, GetBitfieldInt(new int[] { 8 }), 0);
                AddSplFeatureBlockToSplExtendedHeader(39, 2, 2, 0, 0, 0, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Unconscious"), 0, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, -1, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 3;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int damage = 2;
                int duration = 6;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 39)
                    {
                        currentSplFeatBlock.duration = duration;
                        duration += 3;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = damage;
                        damage++;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "WEB"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI215."))
            {
                index = 0;
                int damage = 2;
                int duration = 6;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = 0;
                        currentSplFeatBlock.savingThrowType = GetBitfieldInt(new int[] {2});
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SNILLOCS SNOWBALL SWARM"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi204."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(324, 2, 0, 0, 154, 0, 0, 1, 100, 0, "SPWI225" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 2, 129, 4, 1, 1, 0, 100, 0, "DWTROLCO", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 3, 0, 2, 1, 1, 0, 100, 0, new string(new char[8]), 4, 6, GetBitfieldInt(new int[] {24}), 0, GetBitfieldInt(new int[] {8}), 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                ModifySplOpcodeSpecific(12, "parameter1", 3, 6, 1);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 9, 2);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 12, 3);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 15, 4);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 18, 5);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 21, 6);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 24, 7);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 27, 8);
                ModifySplOpcodeSpecific(12, "parameter1", 3, 30, 9);
                
                index = 0;
                level = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Detect Evil" CONVERSION TO RESIST ELEMENTS (WIZARD ONLY)
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI202"))
            {   
                CreateSplObjects("SPPR210.SPL");
            
                splHeaderModded.spellType = 1;
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Resist Fire and Cold"); // name will be changed to "resist elements" by the tlk batcher
            
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(29, 2, 2, 50, 0, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 2, 0, 27, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddTlkEntry("Resist Lightning");
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 2, FindFirstExactTlkEntry("Resist Lightning"), 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.projectile = 162;
                    currentSplExtendedHeader.target = 5;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 120;
                int foundResistance = 0;
                int resistance = 20;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 5)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 28 ||
                        currentSplFeatBlock.opcodeNumber == 29 ||
                        currentSplFeatBlock.opcodeNumber == 30 ||
                        currentSplFeatBlock.opcodeNumber == 84 ||
                        currentSplFeatBlock.opcodeNumber == 85
                        )
                    {
                        currentSplFeatBlock.parameter1 = (short)resistance;
                        foundResistance++;
                    }
            
                    if (foundDuration == 10)
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
            
                    if (foundResistance == 5)
                    {
                        resistance += 2;
                        foundResistance = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI202.SPL");
            }
            
            //  mod      "KNOW ALIGNMENT / OPPONENT"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI208."))
            {
                // String name = "Know Alignment / Opponent";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                
                RemoveSplOpcode(177, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(0, 2, 2, -2, 0,  0, 0, 60, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(86, 2, 2, -10, 0,  0, 0, 60, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(87, 2, 2, -10, 0,  0, 0, 60, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(88, 2, 2, -10, 0,  0, 0, 60, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(89, 2, 2, -10, 0,  0, 0, 60, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 2, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0,  0, 0, 60, 100, 0, "SPPR209" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 2, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0,  0, 0, 60, 100, 0, "SPWI208" + new char(), 0, 0, 1, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 3;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.target = 5;
                    currentSplExtendedHeader.projectile = 1;
                    currentSplExtendedHeader.range = 60;
                    currentSplExtendedHeader.castingTime = 2;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 7)
                    {
                        foundDuration = 0;
                        duration += 30;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "LUCK"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI209."))
            {
                // String name = "Luck";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Enchantment/Charm\)");
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 300;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "MIRROR IMAGE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI212."))
            {
                // String name = "Mirror Image";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 3;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 3;
                    index++;
                }
                
                index = 0;
                int images = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 300;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 119) // num of images
                    {
                        currentSplFeatBlock.parameter1 = images;
                        images++;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "BLUR"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI201."))
            {
                // String name = "Blur";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 300;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "DECASTAVE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI226."))
            {
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
   
                    if (foundDuration == 2)
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "VOCALIZE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI219."))
            {
                index = 0;
                int duration = 3600;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "DEAFNESS"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI223."))
            {
                // String name = "Deafness";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                AddSplFeatureBlockToSplExtendedHeader(60, 2, 2, 100, 0, 0, 3, 18, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(60, 2, 2, 100, 1, 0, 3, 18, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 2, 0, 83, 0, 3, 18, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 60 ||
                        currentSplFeatBlock.opcodeNumber == 142
                    )
                    {
                        currentSplFeatBlock.savingThrowBonus = 0;
                        currentSplFeatBlock.savingThrowType = GetBitfieldInt(new int[] {1});
                    }
                    index++;
                }
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 218;
                    currentSplExtendedHeader.target = 4;
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "UNLUCK"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI222."))
            {
                // String name = "Unluck";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 60;
                    }
            
                    if ( // increase luck/saving throws penalty
                        currentSplFeatBlock.opcodeNumber == 133 ||
                        currentSplFeatBlock.opcodeNumber == 33 ||
                        currentSplFeatBlock.opcodeNumber == 34 ||
                        currentSplFeatBlock.opcodeNumber == 35 ||
                        currentSplFeatBlock.opcodeNumber == 36 ||
                        currentSplFeatBlock.opcodeNumber == 37
                    )
                    {
                        currentSplFeatBlock.parameter1 = -3;
                    }
                    
                    if ( // increase thieving penalty
                        currentSplFeatBlock.opcodeNumber == 90 ||
                        currentSplFeatBlock.opcodeNumber == 91 ||
                        currentSplFeatBlock.opcodeNumber == 92 ||
                        currentSplFeatBlock.opcodeNumber == 275 ||
                        currentSplFeatBlock.opcodeNumber == 276 ||
                        currentSplFeatBlock.opcodeNumber == 277
                    )
                    {
                        currentSplFeatBlock.parameter1 = -50;
                    }
                    
                    index++;
                }
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 218;
                    currentSplExtendedHeader.target = 4;
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "POWER WORD SLEEP"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI220."))
            {
                // String name = "Power Word, Sleep";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL0", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL1", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL2", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL3", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL4", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL0", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL1", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL2", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL3", 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL4", 0, 0,0, 0, 0, 0);
            
                
                AddSplFeatureBlockToSplExtendedHeader(39, 2, 1, 0, 0, 0, 1, 30, 100, 0, new string(new char[8]), 0, 0,0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 0, 14, 0, 1, 30, 100, 0, new string(new char[8]), 0, 0,0, 0, 0, 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 328)
                    {
                        currentSplFeatBlock.duration = 30;
                    }
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 39 ||
                        currentSplFeatBlock.opcodeNumber == 142
                    )
                    {
                        currentSplFeatBlock.savingThrowType = 1;
                        currentSplFeatBlock.savingThrowBonus = -1;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "RAY OF ENFEEBLEMENT"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI221."))
            {
                // String name = "Ray Of Enfeeblement";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                    
                AddSplFeatureBlockToSplExtendedHeader(54, 2, 2, -5, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, -2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(73, 2, 2, -5, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, -2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(126, 2, 2, 50, 2, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, -2, 0, 0);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 60;
                    }
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 44 ||
                        currentSplFeatBlock.opcodeNumber == 54 ||
                        currentSplFeatBlock.opcodeNumber == 73 ||
                        currentSplFeatBlock.opcodeNumber == 126
                    )
                    {
                        currentSplFeatBlock.savingThrowType = 1;
                        currentSplFeatBlock.savingThrowBonus = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "DETECT INVISIBILITY"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI203."))
            {
                // String name = "Detect Invisibility";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 1, 3, 0, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 6, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 12, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 18, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 24, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 30, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 0);
            
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.castingTime = 2;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPWI203.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.range = 100;
                    currentSplExtendedHeader.castingTime = 1;
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    index++;
                }
                
                AddSplFeatureBlockToSplExtendedHeader(318, 2, 0, 0, 143, 0, 2, 0, 100, 0, "SPWI203" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(116, 2, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 0, 0, 30, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 0, FindFirstExactTlkEntry("Dispel Invisible"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                rgb = new byte[] {0, 128, 134, 137};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 2, 2, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 0, 0, 1, 0, 2, 2, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 0, 0, 0, 0, 2, 0, 100, 0, "EFF_M04" + new char(), 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI203B.SPL");
            }
            
            //  mod      "MELFS ACID ARROW"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI211."))
            {
                // String name = "Melf's Acid Arrow";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 3; // increase damage of melfs slightly
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SPELL THRUST"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI321."))
            {
                // String name = "Spell Thrust";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 218;
                    currentSplExtendedHeader.target = 4;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "LIGHTNING BOLT"
            if (
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI308.") ||
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPCL722.")
            )
            {
                // String name = "Lightning Bolt";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);

                level = 1;
                Boolean firstRun = true;
                foreach (SplExtendedHeader extHeader in splExtHeadersModded)
                {
                    extHeader.levelRequired = level;
                    if (firstRun)
                    {
                        level += 5;
                        firstRun = false;
                    }
                    else
                    {
                        level += 2;
                    }
                }

                int dice = 5; 
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber == 12)
                    {
                        featureBlock.diceThrown = dice;
                        // Console.WriteLine(featureBlock.diceThrown + ":" + dice);
                        dice++;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "LANCE OF DISRUPTION"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI327."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 6;
                        currentSplFeatBlock.diceSides = 6;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CLAIRVOYANCE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI301."))
            {
                // String name = "Clairvoyance";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 3, 0, 37, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 3, 0, 1, 0, 3, 2, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(0, 1, 3, 2, 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(36, 1, 2, 3, 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(292, 1, 3, 0, 1, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 3, 0, 57, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 3, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 300, 100, 0, "SPWI301" + new char(), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 5;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.projectile = 1;
                    currentSplExtendedHeader.target = 5;
                    level += 3;
                    index++;
                }
                
                index = 0;
                int duration = 300;
                int found = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    
                    if (
                        currentSplFeatBlock.opcodeNumber == 0 ||
                        currentSplFeatBlock.opcodeNumber == 36 ||
                        currentSplFeatBlock.opcodeNumber == 292 ||
                        currentSplFeatBlock.opcodeNumber == 142 ||
                        currentSplFeatBlock.opcodeNumber == 206
                    ) // protection features
                    {
                        currentSplFeatBlock.duration = duration;
                        found++;
                    }
            
                    if (found == 5)
                    {
                        found = 0;
                        duration += 30;
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "HOLD PERSON"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI306."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowType = GetBitfieldInt(new int[] { 2 });
                        currentSplFeatBlock.savingThrowBonus = -1;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "VAMPIRIC TOUCH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI314."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 3, 1, 2, 1, 1, 0, 100, 0, "SPWI314B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 1, FindFirstExactTlkEntry("Health Drained"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 1, 1, FindFirstExactTlkEntry("Healed"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
            
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                
                // index = 0;
                // level = 1;
                // Boolean firstRun = true;
                // foreach (ExtendedHeader extendedHeaders in extendedHeadersModded)
                // {
                //     currentExtendedHeader = (ExtendedHeader) extendedHeadersModded[index];
                //     currentExtendedHeader.levelRequired = level;
                //     if (firstRun)
                //     {
                //         level += 5;
                //         firstRun = false;
                //     }
                //     else
                //     {
                //         level += 2;
                //     }
                //     
                //     index++;
                // }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPWI314.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 1, 3, 300, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 3, 0, 2, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 1, 3, 0, 100, 0, "EFF_M07" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 3, 0, 1, 0, 3, 2, 100, 0, "SPHANDAT", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 2, 1);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 3, 2);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 4, 3);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 5, 4);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 6, 5);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 7, 6);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 8, 7);
                
                index = 0;
                level = 1;
                Boolean firstRun = true;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    if (firstRun)
                    {
                        level += 5;
                        firstRun = false;
                    }
                    else
                    {
                        level += 2;
                    }
                    
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI314A.SPL");
                
                //
                
                CreateSplObjects("SPWI314.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(18, 1, 3, 6, 0, 0, 1, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 3, 0, 1, 0, 3, 2, 100, 0, "SPHEALIN", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 3, FindFirstExactTlkEntry("A vampiric touch spell is already active"), 0, 0, 2, 300, 100, 0, "SPIN106B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 3, FindFirstExactTlkEntry("A vampiric touch spell is already active"), 0, 0, 2, 300, 100, 0, "SPWI314B", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                ModifySplOpcodeSpecific(18, "parameter1", 6, 12, 1);
                ModifySplOpcodeSpecific(18, "parameter1", 6, 18, 2);
                ModifySplOpcodeSpecific(18, "parameter1", 6, 24, 3);
                ModifySplOpcodeSpecific(18, "parameter1", 6, 30, 4);
                ModifySplOpcodeSpecific(18, "parameter1", 6, 36, 5);
                ModifySplOpcodeSpecific(18, "parameter1", 6, 42, 6);
                ModifySplOpcodeSpecific(18, "parameter1", 6, 48, 7);
                
                index = 0;
                level = 1;
                firstRun = true;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    if (firstRun)
                    {
                        level += 5;
                        firstRun = false;
                    }
                    else
                    {
                        level += 2;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI314B.SPL");
            
            }
            
            //  mod      "WRAITHFORM" CONVERSION TO ANIMATE DEAD
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI315."))
            {
                CreateSplObjects("SPWI501.SPL");
                splHeaderModded.spellLevel = 3;
            
                splHeaderModded.spellDescriptionUnId = FindFirstMatchingTlkEntry(@"Wraithform( )?\n\("); // set this id to wraithform string int, since this will be changed by the tlk batcher and is easier to find this way
                splHeaderModded.spellDescriptionId = -1; // set this id to wraithform string int, since this will be changed by the tlk batcher and is easier to find this way
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry(@"Wraithform"); // set this id to wraithform string int, since this will be changed by the tlk batcher and is easier to find this way
                splHeaderModded.spellNameId = -1; // set this id to wraithform string int, since this will be changed by the tlk batcher and is easier to find this way
                
                // first skeleton
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE01", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE01", 0, 0, 0, 0, 0, 1);
            
                // second skeleton
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks(2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE07", 0, 0, 0, 0, 0, 2);
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE07", 0, 0, 0, 0, 0, 3);
                
                // third skeleton
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                RemoveAllSplFeatureBlocks(4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE11", 0, 0, 0, 0, 0, 4);
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE11", 0, 0, 0, 0, 0, 5);
                
                // fourth skeleton
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                RemoveAllSplFeatureBlocks(6);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDL15", 0, 0, 0, 0, 0, 6);
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDL15", 0, 0, 0, 0, 0, 7);
                                    
                // fifth skeleton type
                // CopyExtendedHeaderAndFeatureBlocks(7);
                // RemoveAllFeatureBlocks(8);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SKELWARR", 0, 0, 0, 0, 0, 8);
                // CopyExtendedHeaderAndFeatureBlocks(8);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SKELWARR", 0, 0, 0, 0, 0, 9);
            
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI315.SPL");
            }
            
            //  mod      "GHOST ARMOR"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI317."))
            {
                ModifySplOpcodeSpecific(139, "parameter1", FindFirstExactTlkEntry("Ghost Armor"), 0);
   
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 1800;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SLOW"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI312."))
            {
                // RemoveExtendedHeadersAndFeatureBlocks(1);
                // RemoveAllFeatureBlocks();
                //
                // // RemoveOpcode(93, 0);
                // // RemoveOpcode(16, 0); // remove haste status
                //
                // // remove prior haste effects
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI305" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPRA301" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN828" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN572" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPCL521" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI613" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN655" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH36", 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH37", 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH40", 0, 0, 0, 0, 0, 0);
                //
                // // remove prior slow effects
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI312" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "MELS545" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "FINSLOW" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN977" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH25", 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWM164" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN983" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
                //
                // AddFeatureBlockToExtendedHeader(176, 2, 3, 50, 2, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(1, 2, 3, 50, 2, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(190, 2, 3, -2, 0, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(189, 2, 3, -5, 0, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(328, 2, 3, 1, 148, 0, 1, 36, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(0, 2, 3, -4, 0, 0, 1, 36, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(54, 2, 3, -4, 0, 0, 1, 36, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(141, 2, 3, 0, 6, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(139, 2, 3, FindFirstExactTlkEntry("Slowed"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
                // AddFeatureBlockToExtendedHeader(174, 2, 3, 0, 0, 0, 1, 0, 100, 0, "EFF_M29" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(174, 2, 3, 0, 0, 4, 1, 60, 100, 0, "EFF_M28" + new char(), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(142, 2, 3, 0, 41, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), -2, 0, 0);
   
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowBonus == -4)
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "HOLD UNDEAD"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI324."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowType = GetBitfieldInt(new int[] { 2 });
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // mod      "HASTE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI305."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                // RemoveOpcode(93, 0);
                // RemoveOpcode(16, 0); // remove haste status
   
                // remove prior haste effects
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI305" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPRA301" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN828" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN572" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPCL521" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI613" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN655" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH36", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH37", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH40", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(337, 2, 3, 0, 16, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(337, 2, 3, 0, 317, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
   
                // remove prior slow effects
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI312" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "MELS545" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "FINSLOW" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN977" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH25", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWM164" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN983" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(337, 2, 3, 0, 40, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
   
                AddSplFeatureBlockToSplExtendedHeader(176, 2, 3, 150, 2, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(1, 2, 3, 150, 2, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(190, 2, 3, 2, 0, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(189, 2, 3, 1, 0, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 3, FindFirstExactTlkEntry("Hasted"), 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 0, 3, 0, 100, 0, "EFF_M28" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 4, 3, 36, 100, 0, "EFF_M29" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 3, 0, 4, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 3, 0, 38, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(240, 2, 3, 0, 41, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
    
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 30;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)    
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                    index++;
                }
   
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Minor Spell Deflection
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI318."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 5;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 11)    
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Otiluke's Resilient Sphere" conversion to Protection from Poison
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI413."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                rgb = new byte[] {0, 50, 255, 255};
            
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poison"), 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poisoned"), 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 137, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 6, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(101, 2, 0, 0, 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(173, 2, 0, 100, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 30, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 0, 0, 2, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 30, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(164, 2, 0, 0, 0, 1, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 0, 0, 0, 1, 3, 1, 100, 0, "EFF_P06" + new char(), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                splHeaderModded.primaryTypeSchool = 1;
                splHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {13});
                splHeaderModded.castingGraphics = 12;
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.castingTime = 7;
                    currentSplExtendedHeader.target = 5;
                    currentSplExtendedHeader.projectile = 162;
                    currentSplExtendedHeader.range = 1;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 480;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 60;
                        foundDuration = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "ICE STORM"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI404."))
            {
                // String name = "Spell Thrust";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 4; // increase damage of ice storm
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FARSIGHT" CONVERSION TO RAY OF FROST
            if (
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI424.")
            )
            {
                CreateSplObjects("SPWI217.SPL");

                // String name = "Ray of Frost";
                // String desc = "Ray of Frost\n(Evocation)\n\nLevel: 2\nRange: 15 ft.\nDuration: 1 round\nCasting Time: 3\nArea of Effect: 2-ft. by 15-ft. jet\nSaving Throw: None\n\nUpon casting this spell, a jet of ice appears at the caster's fingertips and bursts out toward one target of the caster's choice. That target will be hit by this frost ray for 6d6 points of damage. The ice jet strikes a second time halfway through its duration, and the caster may move while the spell is in effect. There is no Saving Throw against this spell, though anti-cold capabilities such as Cold Resistance will apply and may reduce or eliminate the damage.";
                // AddTlkEntry(name);
                // AddTlkEntry(desc);

                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Farsight"); // reset this to farsight (will be overridden by RunTlkSpl)
                splHeaderModded.spellDescriptionUnId = FindFirstMatchingTlkEntry(@"Farsight\n\("); // reset this to farsight (will be overridden by RunTlkSpl)
                
                splHeaderModded.spellLevel = 4;
                // splHeaderModded.spellType = 1;
                splHeaderModded.spellBookIcon = "SPWI424C";

                foreach (SplExtendedHeader extHeader in splExtHeadersModded)
                {
                    extHeader.projectile = 191;
                    extHeader.memorizedIcon = "SPWI424B"; 
                }

                foreach (SplFeatureBlock splFeatureBlock in splFeatBlocksModded)
                {
                    if (splFeatureBlock.opcodeNumber == 177)
                    {
                        splFeatureBlock.resource = "DWTROLCO";
                    }

                    if (splFeatureBlock.opcodeNumber == 12)
                    {
                        splFeatureBlock.parameter22 = 8;
                        splFeatureBlock.diceThrown = 6;
                        splFeatureBlock.diceSides = 6;
                    }
                }

                FixSplOffsets();
                FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI424.SPL");
            }
            
            //  mod      "FIRE SHIELD RED"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI418."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                ModifySplOpcodeSpecific(232, "SPWI418D", 0);
                
                index = 0;
                level = 9;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                int foundAttribute = 0;
                int attribute = 50;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 8)
                    {
                        foundDuration = 0;
                        duration += 12;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 27 || currentSplFeatBlock.opcodeNumber == 84)
                    {
                        currentSplFeatBlock.parameter1 = attribute;
                        foundAttribute++;
                    }
            
                    if (foundAttribute == 2)
                    {
                        foundAttribute = 0;
                        attribute += 5;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            
                // CREATE HELPER SPELLS
            
                CreateSplObjects("SPWI418.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 8, 1, 0, 0, 100, 0, new string(new char[8]), 4, 4, GetBitfieldInt(new int[] {24}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 4, 0, 129, 4, 1, 0, 0, 100, 0, "DWTROLFI", 4, 4, 0, 0, 0, 0);
            
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI418D.SPL");
            }
            
            //  mod      "FIRE SHIELD BLUE" CONVERSION TO ACID SHIELD
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI403."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(328, 1, 4, 1, 5, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1, 0);
                AddSplFeatureBlockToSplExtendedHeader(233, 1, 4, 2, 125, 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(328, 1, 4, 1, 65, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1, 0);
                AddSplFeatureBlockToSplExtendedHeader(328, 1, 4, 1, 68, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 4, 0, 69, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(27, 1, 4, 50, 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(206, 1, 5, -1, 0, 0, 3, 120, 100, 0, "DW#W418B", 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(272, 1, 5, 1, 3, 0, 3, 120, 100, 0, "DW#W418A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 4, 0, 69, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 4, 0, 0, 4, 3, 120, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 3, 120, 100, 0, "MESTSH" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(221, 1, 4, 10, 18, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(221, 1, 4, 10, 19, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(221, 1, 4, 10, 20, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("Invulnerable to swarm attacks"), 0, 0, 3, 120, 100, 0, "SPPR319" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("Invulnerable to swarm attacks"), 0, 0, 3, 120, 100, 0, "SPPR517" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("Invulnerable to swarm attacks"), 0, 0, 3, 120, 100, 0, "SPPR717" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(232, 1, 4, 1, 0, 0, 3, 120, 100, 0, "SPWI403A", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                splHeaderModded.primaryTypeSchool = 6;
                splHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {8});
                splHeaderModded.castingGraphics = 14;
            
                index = 0;
                level = 9;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                int foundAttribute = 0;
                int attribute = 75;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 8)
                    {
                        foundDuration = 0;
                        duration += 12;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 27)
                    {
                        currentSplFeatBlock.parameter1 = attribute;
                        foundAttribute++;
                    }
            
                    if (foundAttribute == 1)
                    {
                        foundAttribute = 0;
                        attribute += 1;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            
                // CREATE HELPER SPELLS
            
                CreateSplObjects("SPWI403.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 1, 1, 0, 0, 100, 0, new string(new char[8]), 4, 4, GetBitfieldInt(new int[] {24}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 4, 0, 129, 4, 1, 0, 0, 100, 0, "DWTROLAC", 4, 4, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI403A.SPL");
            }
            
            //  mod      "MINOR GLOBE OF INVULNERABILITY"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI406."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 25)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SPIRIT ARMOR"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI414."))
            {
                ModifySplOpcodeSpecific(139, "parameter1", FindFirstExactTlkEntry("Spirit Armor"), 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 1200;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "STONE SKIN"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI408."))
            {
                // String name = "Stone Skin";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 6;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int skins = 3;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    
                    if (currentSplFeatBlock.opcodeNumber == 218) // num of skins
                    {
                        currentSplFeatBlock.parameter1 = skins;
                        skins++;
                    }
                    
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CONTAGION"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI409."))
            {
                // String name = "Spell Thrust";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                // AddSplFeatureBlockToSplExtendedHeader(139, 2, 0, FindFirstExactTlkEntry("Poisoned"), 6, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(25, 2, 0, 3, 3, 0 ,0, 18, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 6, 0 ,0, 18, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 78) // change disease strength
                    {
                        currentSplFeatBlock.savingThrowType = 4; // poison / death
                        currentSplFeatBlock.savingThrowBonus = -2;
                        if (currentSplFeatBlock.parameter1 > 0) // change disease amount from 2 to 5
                        {
                            currentSplFeatBlock.parameter1 = 5; 
                        }
                    }
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 25 ||
                        currentSplFeatBlock.opcodeNumber == 142
                    ) // change saving throws of new poison effect
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                        currentSplFeatBlock.savingThrowType = 4; // poison / death
                    }
            
                    index++;
                }
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                int length = 18;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (
                        currentSplFeatBlock.opcodeNumber == 25 ||
                        (currentSplFeatBlock.opcodeNumber == 25 && currentSplFeatBlock.parameter2 == 6)
                    ) // change poison length & display respective icon per level 
                    {
                        currentSplFeatBlock.duration = length;
                        length += 6;
                    }
                    index++;
                }
                
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Emotion Hopelessness"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI411."))
            {
                // String name = "Spell Thrust";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (
                        currentSplFeatBlock.duration > 10
                    ) // change disease strength
                    {
                        currentSplFeatBlock.duration = 60;
                        if (currentSplFeatBlock.parameter1 > 0) // change disease amount from 2 to 5
                        {
                            currentSplFeatBlock.parameter1 = 5; 
                        }
                    }
            
                    if (
                        currentSplFeatBlock.savingThrowType == 1 
                    )
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
                    
                    if (
                        currentSplFeatBlock.opcodeNumber == 321 
                    )
                    {
                        currentSplFeatBlock.resource = "SPWI427" + new char();
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "POLYMORPH OTHER"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI415."))
            {
                // String name = "Polymorph Other";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "SPPOLYMP", 7, 0, 16, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "POLYBACK", 7, 0, 16, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(111, 2, 5, 0, 0, 1, 1, 0, 100, 0, "DVSQUIR" + new char(), 7, 0, 16, -4, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "SPPOLYMP", 14, 8, 16, -2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "POLYBACK", 14, 8, 16, -2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(111, 2, 5, 0, 0, 1, 1, 0, 100, 0, "DVSQUIR" + new char(), 14, 8, 16, -2, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "SPPOLYMP", 22, 15, 16, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "POLYBACK", 22, 15, 16, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(111, 2, 5, 0, 0, 1, 1, 0, 100, 0, "DVSQUIR" + new char(), 22, 15, 16, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "SPPOLYMP", 0, 23, 16, 2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "POLYBACK", 0, 23, 16, 2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(111, 2, 5, 0, 0, 1, 1, 0, 100, 0, "DVSQUIR" + new char(), 0, 23, 16, 2, 0, 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.diceThrown == 15)
                    {
                        currentSplFeatBlock.savingThrowBonus = 0;
                    }
                    else if (currentSplFeatBlock.diceThrown == 10)
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
                    else if (currentSplFeatBlock.diceThrown == 5)
                    {
                        currentSplFeatBlock.savingThrowBonus = -4;
                    }
                    else if (currentSplFeatBlock.diceThrown == 0)
                    {
                        currentSplFeatBlock.savingThrowBonus = 2;
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "POLYMORPH SELF"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI416."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI467" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 10, 1, 4, 0, 300, 100, 0, "SPWI467" + new char(), 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 4, 0, 300, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 4, 0, 300, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 4, 0, 300, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 4, 0, 300, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 4, 0, 300, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 4, 0, 300, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 4, 0, 300, 100, 0, "SPWI467" + new char(), 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 4, 0, 54, 0, 2, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI416" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI603" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI819" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI916" + new char(), 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPWI416.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 4, 0, 0, 0, 2, 360000, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "PLYJELLY";
                splHeaderModded.spellBookIcon = "PLYJELLY";
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Mustard Jelly");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI461.SPL");
                
                //
                
                CreateSplObjects("SPWI416.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 4, 0, 0, 0, 2, 360000, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "PLYOGRE" + new char();
                splHeaderModded.spellBookIcon = "PLYOGRE" + new char();
                AddTlkEntry("Shapeshift: Ogre Mage");
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Ogre Mage");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI462.SPL");
                
                //
                
                CreateSplObjects("SPWI416.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 4, 0, 0, 0, 2, 360000, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPIN833" + new char();
                splHeaderModded.spellBookIcon = "SPIN833" + new char();
                AddTlkEntry("Shapeshift: Fire Salamander");
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Fire Salamander");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI463.SPL");
                
                //
                
                CreateSplObjects("SPWI416.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 4, 0, 0, 0, 2, 360000, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "PLYSPIDR";
                splHeaderModded.spellBookIcon = "PLYSPIDR";
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Spider");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI464.SPL");
                
                //
                
                CreateSplObjects("SPWI416.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 4, 0, 0, 0, 2, 360000, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPIN154"+ new char();
                splHeaderModded.spellBookIcon = "SPIN154" + new char();
                AddTlkEntry("Shapeshift: Troll");
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Troll");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI465.SPL");
                
                //
                
                CreateSplObjects("SPWI416.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 4, 0, 0, 0, 2, 360000, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "PLYWOLF" + new char();
                splHeaderModded.spellBookIcon = "PLYWOLF" + new char();
                AddTlkEntry("Shapeshift: Winter Wolf");
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Winter Wolf");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI466.SPL");
                
                //
                
                CreateSplObjects("SPWI416.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(135, 1, 4, 0, 0, 0, 2, 360000, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI467" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 4, 0, 0, 0, 2, 360000, 100, 0, "SPWI467" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(279, 1, 4, 0, 7, 1, 2, 360000, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI467" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPWI977" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPPR731" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 4, 0, 0, 1, 2, 0, 100, 0, "SPPR732" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "PLYMAN" + new string(new char[2]);
                splHeaderModded.spellBookIcon = "PLYMAN" + new string(new char[2]);
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Natural Form");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI467.SPL");
                
                //
            }
            
            //  mod      "ENCHANTED WEAPON"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI417."))
            {
                // String name = "Enchanted Weapon";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 7;
                    index++;
                }
                
                index = 0;
                int found = 0;
                int duration = 300;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        found += 1;
                    }
                    if (found == 4)
                    {
                        found = 0;
                        duration += 300;
                    }
            
                    
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "WIZARD EYE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI425."))
            {
                // String name = "Wizard Eye";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 1;
                    index++;
                }
                
                index = 0;
                int found = 0;
                int duration = 30;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        found += 1;
                    }
                    if (found == 3)
                    {
                        found = 0;
                        duration += 6;
                    }
            
                    
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CONFUSION"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI401."))
            {
                // String name = "Confusion";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                index = 0;
                int duration = 60;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                    }
            
                    if (currentSplFeatBlock.savingThrowBonus == -2)
                    {
                        currentSplFeatBlock.savingThrowBonus = -1;
                    }
                    
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "HOLD MONSTER"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI507."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowType = GetBitfieldInt(new int[] { 2 });
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "ANIMATE DEAD" CONVERSION TO REVIVE SKELETON ARCHER
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI501."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR04", 0, 0, 0, 0, 0, 0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR04", 0, 0, 0, 0, 0, 1);
                // CopyExtendedHeaderAndFeatureBlocks(1);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR04", 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifySplOpcodeSpecific(177, "SKELAR06", 2);
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR06", 0, 0, 0, 0, 0, 3);
                // CopyExtendedHeaderAndFeatureBlocks(4);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR06", 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifySplOpcodeSpecific(177, "SKELAR08", 4);
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR08", 0, 0, 0, 0, 0, 5);
                // CopyExtendedHeaderAndFeatureBlocks(7);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR08", 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifySplOpcodeSpecific(177, "SKELAR10", 6);
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR10", 0, 0, 0, 0, 0, 7);
                // CopyExtendedHeaderAndFeatureBlocks(10);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR10", 0, 0, 0, 0, 0, 11);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.target = 4;
                    currentSplExtendedHeader.range = 30;
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                }
                
                String newName = "Revive Skeleton Archer";
                AddTlkEntry(newName);
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry(newName);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "ORACLE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI515."))
            {
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 1, 3, 0, 100, 0, "SPWI515A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 6, 100, 0, "SPWI515A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 12, 100, 0, "SPWI515A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 18, 100, 0, "SPWI515A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 24, 100, 0, "SPWI515A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 30, 100, 0, "SPWI515A", 0, 0, 0, 0, 0, 0);
            
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.castingTime = 1;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // create helper spells
                
                CreateSplObjects("SPWI515.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 5, 134, 6, 1, 2, 0, 100, 0, "FLQPPALN", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 5, 134, 6, 1, 2, 0, 100, 0, "D0QPPLKM", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 5, 7, 7, 1, 2, 0, 100, 0, "DESTSELF", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(220, 2, 5, 5, 5, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 0, 0, 30, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 0, 0, 0, 1, 2, 0, 100, 0, "EFF_M04" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 0, 0, 1, 0, 2, 2, 100, 0, "SPTRESEE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(221, 2, 5, 5, 3, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(116, 2, 5, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI515A.SPL");
            
                //
            }
            
            //  mod      "CHAOS"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI508."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowBonus == -4)
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
            
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SHADES" CONVERSION TO MOMENT OF PRESCIENCE
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi632."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(292, 1, 3, 0, 1, 0, 3, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(0, 1, 5, 10, 0, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(0, 1, 5, 20, GetBitfieldInt(new int[] {0}), 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(0, 1, 5, 20, GetBitfieldInt(new int[] {1}), 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(0, 1, 5, 20, GetBitfieldInt(new int[] {2}), 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(0, 1, 5, 20, GetBitfieldInt(new int[] {3}), 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(33, 1, 5, 20, 0, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(34, 1, 5, 20, 0, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(35, 1, 5, 20, 0, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(36, 1, 5, 20, 0, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(37, 1, 5, 20, 0, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 5, 0, 57, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(233, 1, 5, 2, 128, 0, 0, 0, 24, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 5, 0, 0, 0, 0, 3, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 5, 0, 0, 4, 0, 24, 100, 0, "EFF_E04" + new char(), 0, 0, 0, 0, 0, 0);
                rgb = new byte[] {0, 133, 89, 116};
                AddSplFeatureBlockToSplExtendedHeader(50, 1, 5, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 1, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SUMMON SHADOW" CONVERSION TO WAVES OF FATIGUE
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi525."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                rgb = new byte[] {0, 96, 76, 13};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 5, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 1, 1, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 5, 0, 9, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 5, 0, 39, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 5, FindFirstExactTlkEntry("Fatigued"), 0, 1, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(93, 2, 5, 7, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(44, 2, 5, 0, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(15, 2, 5, 0, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(126, 2, 5, 75, 5, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(1, 2, 5, 75, 5, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(278, 2, 5, 75, 5, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                splHeaderModded.primaryTypeSchool = 8;
                splHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {13});
                splHeaderModded.castingGraphics = 10;
            
                index = 0;
                level = 9;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.target = 4;
                    currentSplExtendedHeader.projectile = 170;
                    currentSplExtendedHeader.range = 30;
                    currentSplExtendedHeader.castingTime = 5;
                    level += 3;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                int foundAttribute = 0;
                int attribute = -1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 8)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 15 || currentSplFeatBlock.opcodeNumber == 44)
                    {
                        currentSplFeatBlock.parameter1 = attribute;
                        foundAttribute++;
                    }
            
                    if (foundAttribute == 4)
                    {
                        foundAttribute = 0;
                        attribute--;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "LOWER RESISTANCE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI514."))
            {
                // String name = "Lower Resistance";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 9;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 218;
                    currentSplExtendedHeader.target = 4;
                    currentSplExtendedHeader.levelRequired = level;
                    level += 3;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int resist = -20;
                int foundDuration = 0;
                Boolean foundResist = true;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 166)
                    {
                        currentSplFeatBlock.parameter1 = resist;
                        foundResist = true;
                    }
            
                    if (foundResist)
                    {
                        foundResist = false;
                        resist -= 5;
                    }
                    
                    if (foundDuration == 3)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
                    
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Minor Spell Turning
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI522."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 9;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 5)    
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Spell Shield
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI519."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 9;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 7)    
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Improved Haste
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI613."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                // RemoveOpcode(93, 0);
                // RemoveOpcode(16, 0); // remove haste status
                
                // remove prior haste effects
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI305" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPRA301" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN828" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN572" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPCL521" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI613" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN655" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH36", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH37", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH40", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(337, 2, 3, 0, 16, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(337, 2, 3, 0, 317, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
   
                // remove prior slow effects
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWI312" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "MELS545" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "FINSLOW" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN977" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWISH25", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPWM164" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN983" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(321, 2, 3, 0, 0, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(337, 2, 3, 0, 40, 0, 1, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0, 0);
   
                AddSplFeatureBlockToSplExtendedHeader(176, 2, 3, 150, 2, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(1, 2, 3, 200, 2, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(190, 2, 3, 2, 0, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(189, 2, 3, 1, 0, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 3, FindFirstExactTlkEntry("Hasted"), 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 0, 3, 0, 100, 0, "EFF_M28" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 4, 3, 36, 100, 0, "EFF_M29" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 3, 0, 4, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 3, 0, 38, 0, 3, 36, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(240, 2, 3, 0, 41, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
   
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 30;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)    
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                    index++;
                }
   
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Spell Deflection
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI618."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 11;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 13)    
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "GLOBE OF INVULNERABILITY"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI602."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 11;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 27)
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FLESH TO STONE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI604."))
            {
                // String name = "Flesh to Stone";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
            
                index = 0;
                int duration = 60;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    currentSplFeatBlock.savingThrowType = 16;
                    currentSplFeatBlock.savingThrowBonus = -4;
                    
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Disintegrate"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI616."))
            {
                // String name = "Disintegrate";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
            
                index = 0;
                int duration = 60;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    currentSplFeatBlock.savingThrowType = 1;
                    currentSplFeatBlock.savingThrowBonus = -4;
                    
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Chain Lightning"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI615.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPDR601"))
            {
                // String name = "Disintegrate";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int dmg = 4;
                Boolean foundDmg = true;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = dmg;
                        foundDmg = true;
                    }
            
                    if (foundDmg)
                    {
                        foundDmg = false;
                        dmg++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Pierce Magic"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI608."))
            {
                // String name = "Pierce Magic";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                int resist = 40;
                Boolean foundResist = false;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration == 72)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 166)
                    {
                        currentSplFeatBlock.parameter1 = resist;
                        foundResist = true;
                    }
            
                    if (foundDuration == 3)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    if (foundResist)
                    {
                        foundResist = false;
                        resist += 5;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "True Sight"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI609."))
            {
                RemoveSplOpcode(146, 0);
                RemoveSplOpcode(177, 0);
                RemoveSplOpcode(220, 0);
                RemoveSplOpcode(221, 0);
                RemoveSplOpcode(328, 0);
                RemoveSplOpcode(116, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 1, 3, 0, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 6, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 12, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 24, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 30, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 36, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 42, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 48, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 54, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 60, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifyAllSplDurations(10, 66, new int[] { 146 }, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 66, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                ModifyAllSplDurations(10, 72, new int[] { 146 }, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 72, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                ModifyAllSplDurations(10, 78, new int[] { 146 }, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 78, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 3);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                ModifyAllSplDurations(10, 84, new int[] { 146 }, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 84, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 4);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                ModifyAllSplDurations(10, 90, new int[] { 146 }, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 90, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                ModifyAllSplDurations(10, 96, new int[] { 146 }, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 96, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 6);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                ModifyAllSplDurations(10, 102, new int[] { 146 }, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 102, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 7);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(7);
                ModifyAllSplDurations(10, 108, new int[] { 146 }, 8);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 108, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(8);
                ModifyAllSplDurations(10, 114, new int[] { 146 }, 9);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 114, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 9);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(9);
                ModifyAllSplDurations(10, 120, new int[] { 146 }, 10);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 120, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 10);
            
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 8)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "PROTECTION FROM THE ELEMENTS"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI702."))
            {
                // String name = "Protection From The Elements";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                AddSplFeatureBlockToSplExtendedHeader(27, 2, 7, 75, 0, 0, 3, 84, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 75, 24, 0, 3, 84, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 5;
                    index++;
                }
                
                index = 0;
                int durationFound = 0;
                int duration = 300;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration == 84)
                    {
                        currentSplFeatBlock.duration = duration;
                        durationFound++;
                    }
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 28 ||
                        currentSplFeatBlock.opcodeNumber == 29 ||
                        currentSplFeatBlock.opcodeNumber == 27 ||
                        currentSplFeatBlock.opcodeNumber == 30 ||
                        currentSplFeatBlock.opcodeNumber == 84 ||
                        currentSplFeatBlock.opcodeNumber == 85
                    )
                    {
                        currentSplFeatBlock.parameter1 = 90;
                    }
            
                    if (durationFound == 13)
                    {
                        durationFound = 0;
                        duration += 300;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Sphere of Chaos
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI711."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = -1;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Spell Turning
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI701."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 13;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 10)    
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // Control Undead
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI720."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                ModifySplOpcode(241, "diceSize", 4, 6);
                ModifySplOpcode(241, "diceThrown", 3, 5);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                    }
            
                    if (currentSplFeatBlock.diceSides == 4)
                    {
                        currentSplFeatBlock.diceSides = 6;
                    }
            
                    if (currentSplFeatBlock.diceThrown == 3)
                    {
                        currentSplFeatBlock.diceThrown = 5;
                    }
            
                    index++;
                }
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 13;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.projectile = 218;
                    currentSplExtendedHeader.target = 4;
                    level += 2;
                }
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = 1;
   
                index = 0;
                int duration = 180;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)    
                    {
                        duration += 18;
                        foundDuration = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FINGER OF DEATH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI713."))
            {
                // String name = "Finger of Death";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 328)
                    {
                        currentSplFeatBlock.duration = 60;
                    }
                    
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 6;
                        currentSplFeatBlock.diceThrown = 6;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 55)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                        currentSplFeatBlock.savingThrowType = 4; // poison / death
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "PROTECTION FROM ENERGY"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI803."))
            {
                // String name = "Protection From Energy";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                AddSplFeatureBlockToSplExtendedHeader(166, 2, 8, 50, 0, 0, 3, 96, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 8, 0, 28, 0, 3, 96, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 15;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 5;
                    index++;
                }
                
                index = 0;
                int durationFound = 0;
                int duration = 60;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration == 96)
                    {
                        currentSplFeatBlock.duration = duration;
                        durationFound++;
                    }
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 28 ||
                        currentSplFeatBlock.opcodeNumber == 29 ||
                        currentSplFeatBlock.opcodeNumber == 27 ||
                        currentSplFeatBlock.opcodeNumber == 30 ||
                        currentSplFeatBlock.opcodeNumber == 31 ||
                        currentSplFeatBlock.opcodeNumber == 84 ||
                        currentSplFeatBlock.opcodeNumber == 85
                    )
                    {
                        currentSplFeatBlock.parameter1 = 100;
                    }
            
                    if (durationFound == 15)
                    {
                        durationFound = 0;
                        duration += 60;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            //  mod      "Pierce Shield"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI805."))
            {
                // String name = "Pierce Shield";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 15;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration == 96)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 166)
                    {
                        currentSplFeatBlock.parameter1 = 100;
                    }
            
                    if (foundDuration == 4)
                    {
                        foundDuration = 0;
                        duration += 12;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Bigby's Clenched Fist"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI818."))
            {
                // String name = "Bigby's Clenched Fist";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    // first damage 
                    if (currentSplFeatBlock.opcodeNumber == 12 && currentSplFeatBlock.duration == 0)
                    {
                        currentSplFeatBlock.diceThrown = 6;
                        currentSplFeatBlock.diceSides = 6;
                    }
                    // second damage 
                    if (currentSplFeatBlock.opcodeNumber == 12 && currentSplFeatBlock.duration == 6)
                    {
                        currentSplFeatBlock.diceThrown = 5;
                        currentSplFeatBlock.diceSides = 6;
                        currentSplFeatBlock.savingThrowBonus = -6;
                        currentSplFeatBlock.savingThrowType = 4;
                    }
                    // third damage 
                    if (currentSplFeatBlock.opcodeNumber == 12 && currentSplFeatBlock.duration == 12)
                    {
                        currentSplFeatBlock.diceThrown = 4;
                        currentSplFeatBlock.diceSides = 6;
                        currentSplFeatBlock.savingThrowBonus = -4;
                        currentSplFeatBlock.savingThrowType = 4;
                    }
            
                    // second hold
                    if (currentSplFeatBlock.opcodeNumber == 175 && currentSplFeatBlock.duration == 6)
                    {
                        currentSplFeatBlock.savingThrowBonus = -6;
                        currentSplFeatBlock.savingThrowType = 4;
                    }
                    // third hold 
                    if (currentSplFeatBlock.opcodeNumber == 175 && currentSplFeatBlock.duration == 12)
                    {
                        currentSplFeatBlock.savingThrowBonus = -4;
                        currentSplFeatBlock.savingThrowType = 4;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 166)
                    {
                        currentSplFeatBlock.parameter1 = 100;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SYMBOL, STUN"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI816."))
            {
                // String name = "Symbol, Stun";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 15;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 166)
                    {
                        currentSplFeatBlock.parameter1 = 100;
                    }
            
                    if (foundDuration == 4)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    if (currentSplFeatBlock.savingThrowBonus == -4)
                    {
                        currentSplFeatBlock.savingThrowBonus = -6;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SYMBOL, DEATH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI817."))
            {
                // String name = "Symbol, Death";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 1, 7, 1, 0, 64, 1, 1, 0, 100, new string(new char[8]), 8, 6, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // //  mod      "SYMBOL, FEAR"
            // if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI811."))
            // {
            //     // String name = "Symbol, Fear";
            //     // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
            //     
            //     RemoveExtendedHeadersAndFeatureBlocks(1);
            //     
            //     CopyExtendedHeaderAndFeatureBlocks(0);
            //     CopyExtendedHeaderAndFeatureBlocks(0);
            //     CopyExtendedHeaderAndFeatureBlocks(0);
            //     CopyExtendedHeaderAndFeatureBlocks(0);
            //     CopyExtendedHeaderAndFeatureBlocks(0);
            //     
            //     index = 0;
            //     level = 15;
            //     foreach (ExtendedHeader extendedHeaders in extendedHeadersModded)
            //     {
            //         currentExtendedHeader = (ExtendedHeader) extendedHeadersModded[index];
            //         currentExtendedHeader.levelRequired = level;
            //         level += 4;
            //         index++;
            //     }
            //     
            //     index = 0;
            //     int duration = 60;
            //     int foundDuration = 0;
            //     foreach (FeatureBlock featureBlock in featureBlocksModded)
            //     {
            //         currentFeatureBlock = (FeatureBlock)featureBlocksModded[index];
            //
            //         if (currentFeatureBlock.duration > 10)
            //         {
            //             currentFeatureBlock.duration = duration;
            //             foundDuration++;
            //         }
            //
            //         if (currentFeatureBlock.opcodeNumber == 24)
            //         {
            //             currentFeatureBlock.savingThrowBonus = 0;
            //             currentFeatureBlock.savingThrowType = 0;
            //         }
            //
            //         if (foundDuration == 4)
            //         {
            //             foundDuration = 0;
            //             duration += 12;
            //         }
            //
            //         if (currentFeatureBlock.savingThrowBonus == -4)
            //         {
            //             currentFeatureBlock.savingThrowBonus = -6;
            //         }
            //
            //         index++;
            //     }
            //     
            //     FixFeatureBlockOffsets();
			//     FileOperations.WriteFile(headerModded, extendedHeadersModded, castingFeatureBlocksModded, featureBlocksModded, outputBasePath + "/" + currentSpell);
            // }
            
            //  mod      "SYMBOL, FEAR" CONVERSION TO SYMBOL WEAKNESS
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI811."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(78, 2, 8, 4, 4, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(78, 2, 8, 4, 5, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(78, 2, 8, 4, 6, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 8, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 8, 0, 7, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 8, 0, 0, 1, 1, 0, 100, 0, "EFF_P03" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 15;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int disease = 4;
                int diseaseFound = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 78)
                    {
                        currentSplFeatBlock.parameter1 = disease;
                        diseaseFound++;
                    }
                    
                    if (diseaseFound == 3)
                    {
                        diseaseFound = 0;
                        disease++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SPELL TRAP"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI902."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 17;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 102;
                int foundDuration = 0;
                int spells = 30;
                int foundSpells = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 259)
                    {
                        currentSplFeatBlock.parameter1 = spells;
                        foundSpells++;
                    }
            
                    if (foundSpells == 18)
                    {
                        spells++;
                        foundSpells = 0;
                    }
                    
                    if (foundDuration == 11)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "POWER WORD KILL"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI912."))
            {
                // String name = "Power Word, Kill";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 1, 7, 1, 0, 64, 1, 1, 0, 100, new string(new char[8]), 10, 6, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "WAIL OF THE BANSHEE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI913."))
            {
                // String name = "Wail of the Banshee";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 1, 7, 1, 0, 16, 1, 1, 0, 100, new string(new char[8]), 8, 6, 0, 0, 0, 0);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber > 55)
                    {
                        currentSplFeatBlock.savingThrowBonus = -5;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "ENERGY DRAIN"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI914.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR714."))
            {
                // String name = "Energy Drain";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 0, 1, 1, 3, 0, 100, 0, "SPWI914A", 0, 0, 0, 0, 0, 0);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber > 216)
                    {
                        currentSplFeatBlock.parameter1 = 5;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPWI914.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 9, 0, 2, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 9, 2, 0, 64, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(17, 1, 9, 2, 0, 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                rgb = new byte[] {0, 99, 189, 255};
                AddSplFeatureBlockToSplExtendedHeader(50, 1, 9, BitConverter.ToInt32(rgb, 0), 0, 0, 30, 0, 0, 0, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 0, 2, 100, 0, "SPHEALIN", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 1, 9, FindFirstExactTlkEntry("Healed"), 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 9, FindFirstExactTlkEntry("Health drained"), 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                ModifySplOpcodeSpecific(12, "parameter1", 2, 4, 1);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 4, 1);
                
                ModifySplOpcodeSpecific(12, "parameter1", 2, 6, 2);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 6, 2);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 8, 3);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 8, 3);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 10, 4);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 10, 4);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 12, 5);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 12, 5);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 14, 6);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 14, 6);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 16, 7);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 16, 7);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 18, 8);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 18, 8);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 20, 9);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 20, 9);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 22, 10);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 22, 10);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 24, 11);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 24, 11);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 26, 12);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 26, 12);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 28, 13);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 28, 13);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 30, 14);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 30, 14);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 32, 15);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 32, 15);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 34, 16);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 34, 16);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 36, 17);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 36, 17);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 38, 18);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 38, 18);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 40, 19);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 40, 19);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 42, 20);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 42, 20);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 44, 21);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 44, 21);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 46, 22);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 46, 22);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 48, 23);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 48, 23);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 50, 24);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 50, 24);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 52, 25);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 52, 25);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 54, 26);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 54, 26);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 56, 27);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 56, 27);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 58, 28);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 58, 28);
            
                ModifySplOpcodeSpecific(12, "parameter1", 2, 60, 29);
                ModifySplOpcodeSpecific(17, "parameter1", 2, 60, 29);
            
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    level++;
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI914A.spl");
            
                //
            }
            
            //  mod      "BIGBY'S CRUSHING HAND"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI918."))
            {
                // String name = "Bigby's Crushing Hand";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 1, 1, 0, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 6, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 12, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 18, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 24, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 30, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 36, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 48, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 54, 100, 0, "SPWI918D", 0, 0, 0, 0, 0, 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber > 216)
                    {
                        currentSplFeatBlock.parameter1 = 10;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPWI918.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 9, 0, 1, 0, 2, 2, 100, 0, "SPBGBFST", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 9, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 1, 10, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 9, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 1, 10, GetBitfieldInt(new int[] {2}), -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(45, 2, 9, 0, 0, 0, 2, 6, 100, 0, "SPBGBFST", 0, 0, GetBitfieldInt(new int[] {2}), -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 9, FindFirstExactTlkEntry("Stunned"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 9, 0, 55, 0, 2, 6, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 9, 0, 0, 4, 2, 6, 100, 0, "EFF_E08" + new char(), 0, 0, GetBitfieldInt(new int[] {2}), -4, 0, 0);
            
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    level++;
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI918D.spl");
            
                //
            }
            
            //  mod      "SHAPECHANGE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI916."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI977" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 9, 10, 1, 9, 0, 300, 100, 0, "SPWI977" + new char(), 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 9, 0, 0, 4, 0, 300, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 9, 0, 0, 4, 0, 300, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 9, 0, 0, 4, 0, 300, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 9, 0, 0, 4, 0, 300, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 9, 0, 0, 4, 0, 300, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 9, 0, 0, 4, 0, 300, 100, 0, "SPWI977" + new char(), 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 9, 0, 54, 0, 2, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 9, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI416" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 9, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI603" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 9, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI819" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 9, FindFirstExactTlkEntry("You have already cast a polymorph-type spell on yourself."), 0, 0, 2, 300, 100, 0, "SPWI916" + new char(), 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPWI916.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);    
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 9, 0, 0, 0, 2, 360000, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPIN153" + new char();
                splHeaderModded.spellBookIcon = "SPIN153" + new char();
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapechange: Iron Golem");
                splHeaderModded.spellType = 9;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI971.SPL");
                
                //
                
                CreateSplObjects("SPWI916.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 9, 0, 0, 0, 2, 360000, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPIN152" + new char();
                splHeaderModded.spellBookIcon = "SPIN152" + new char();
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapechange: Mind Flayer");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI972.SPL");
                
                //
                
                CreateSplObjects("SPWI916.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 9, 0, 0, 0, 2, 360000, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPIN156" + new char();
                splHeaderModded.spellBookIcon = "SPIN156" + new char();
                AddTlkEntry("Shapeshift: Tanar'ri");
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Tanar'ri");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI973.SPL");
                
                //
                
                CreateSplObjects("SPWI916.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 9, 0, 0, 0, 2, 360000, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPIN154"  + new char();
                splHeaderModded.spellBookIcon = "SPIN154" + new char();
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapechange: Giant Troll");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI974.SPL");
                
                //
                
                CreateSplObjects("SPWI916.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 9, 0, 0, 0, 2, 360000, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPIN155"+ new char();
                splHeaderModded.spellBookIcon = "SPIN155" + new char();
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapechange: Greater Wolfwere");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI975.SPL");
                
                //
                
                CreateSplObjects("SPWI916.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(135, 1, 9, 0, 0, 0, 2, 360000, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI977" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(171, 1, 9, 0, 0, 0, 2, 360000, 100, 0, "SPWI977" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(279, 1, 9, 0, 7, 1, 2, 360000, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "SPPOLYMP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 9, 0, 1, 0, 2, 3, 100, 0, "POLYBACK", 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI461" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI462" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI463" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI464" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI465" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI466" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI467" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI971" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI972" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI973" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI974" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI975" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPWI977" + new char(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPPR731" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(112, 1, 9, 0, 0, 1, 2, 0, 100, 0, "SPPR732" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "PLYMAN" + new string(new char[2]);
                splHeaderModded.spellBookIcon = "PLYMAN" + new string(new char[2]);
                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Shapeshift: Natural Form");
                splHeaderModded.spellType = 4;
                splHeaderModded.flags = GetBitfieldInt(new int[] {14});
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.castingGraphics = 0;
                splHeaderModded.primaryTypeSchool = 0;
                splHeaderModded.secondaryTypeSchool = 0;
                splHeaderModded.spellLevel = 1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPWI977.SPL");
                
                //
            }
            
            //  mod      "Beltyn's Burning Blood"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi422."))
            {
                // String name = "Beltyn's Burning Blood";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    // Console.WriteLine(index);
                    if (currentSplFeatBlock.savingThrowType != 0)
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Emotion, Fear"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi428."))
            {
                // String name = "Emotion, Fear";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    // Console.WriteLine(index);
                    if (currentSplFeatBlock.duration == 30)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                        currentSplFeatBlock.duration = 60;
                    }
                    
                    if (
                        currentSplFeatBlock.opcodeNumber == 321 
                    )
                    {
                        currentSplFeatBlock.resource = "SPWI426" + new char();
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Mordenkainen's Force Missiles"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi429."))
            {
                // String name = "Mordenkainen's Force Missiles";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                index = 0;
                int dmg1 = 3;
                int foundDmg1 = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = dmg1;
                        foundDmg1++;
                    }
                    
                    if (foundDmg1 == 3)
                    {
                        foundDmg1 = 0;
                        dmg1++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Shout"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi430."))
            {
                // String name = "Shout";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
                
                AddSplFeatureBlockToSplExtendedHeader(60, 2, 2, 100, 0, 0, 3, 18, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(60, 2, 2, 100, 1, 0, 3, 18, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 2, 0, 83, 0, 3, 18, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int dmg = 4;
                int foundDmg = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.parameter21 = 0; // normal
                        currentSplFeatBlock.parameter22 = 16; // piercing damage
                        currentSplFeatBlock.diceThrown = dmg;
                        foundDmg++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 80) // no saving throw allowed against deafness
                    {
                        currentSplFeatBlock.savingThrowBonus = 0;
                        currentSplFeatBlock.savingThrowType = 0;
                    }
            
                    if (foundDmg == 1)
                    {
                        foundDmg = 0;
                        dmg++;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Vitriolic Sphere"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi431."))
            {
                // String name = "Vitriolic Sphere";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
                
                RemoveSplOpcode(146, 0);
                RemoveSplOpcode(318, 0);
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 6, 100, 0, "spwi431a", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 12, 100, 0, "spwi431b", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 18, 100, 0, "spwi431c", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 24, 100, 0, "spwi431d", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 9, 0, 1, 4, 1, 30, 100, 0, "spwi431e", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int dmg = 7;
                int foundDmg = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = dmg;
                        foundDmg++;
                    }
            
                    if (foundDmg == 1)
                    {
                        foundDmg = 0;
                        dmg++;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("spwi431.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 4, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 4, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 4, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 5, 4, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;        
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi431a.spl");
                
                //
                
                CreateSplObjects("spwi431.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 4, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 4, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 4, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 4, 4, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi431b.spl");
                
                //
                
                CreateSplObjects("spwi431.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 4, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 4, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 4, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 3, 4, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi431c.spl");
                
                //
                
                CreateSplObjects("spwi431.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 4, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 4, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 4, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 2, 4, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi431d.spl");
                
                //
                
                CreateSplObjects("spwi431.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 4, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 4, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 4, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi431e.spl");
                
                //
                // CreateSplObjects("spwi431.spl");
                // RemoveAllFeatureBlocks();
                // RemoveAllCastingFeatureBlocks();
                // RemoveExtendedHeadersAndFeatureBlocks(1);
                //
                // AddFeatureBlockToExtendedHeader(177, 2, 4, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(12, 2, 4, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, GetBitfieldInt(new int[] {4, 24}), 0, 0, 0);
                //
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                //
                // ModifyOpcodeSpecific(12, "diceThrown", 1, 2, 1);
                // ModifyOpcodeSpecific(12, "diceThrown", 1, 3, 2);
                // ModifyOpcodeSpecific(12, "diceThrown", 1, 4, 3);
                // ModifyOpcodeSpecific(12, "diceThrown", 1, 5, 4);
                // ModifyOpcodeSpecific(12, "diceThrown", 1, 6, 5);
                //
                // FixFeatureBlockOffsets();
				// FileOperations.WriteFile(headerModded, extendedHeadersModded, castingFeatureBlocksModded, featureBlocksModded, outputBasePath + "/spwi431y.spl");
            }
            
            //  mod      "Shroud of Flame"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi524."))
            {
                // String name = "Shroud of Flame";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.savingThrowType != 0)
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 3;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Otiluke's Freezing Sphere"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi626."))
            {
                // String name = "Otiluke's Freezing Sphere";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.savingThrowType != 0)
                    {
                        currentSplFeatBlock.savingThrowBonus = -1;
            
                        // activate save vs half in bitfield
                        // BitArray bitArray1 = new BitArray(8, false);
                        // BitArray bitArray2 = new BitArray(8, false);
                        // BitArray bitArray3 = new BitArray(8, false);
                        // BitArray bitArray4 = new BitArray(8, false);
                        //
                        // bitArray2[0] = true;
                        //
                        // byte[] newByte = new byte[4];
                        //
                        // bitArray1.CopyTo(newByte, 0);
                        // bitArray2.CopyTo(newByte, 1);
                        // bitArray3.CopyTo(newByte, 2);
                        // bitArray4.CopyTo(newByte, 3);
                        //
                        // int newInt = BitConverter.ToInt32(newByte, 0);
                        
                        currentSplFeatBlock.stackingId = GetBitfieldInt(new int[] { 8 });
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Soul Eater"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi628."))
            {
                // String name = "Soul Eater";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 7;
                        currentSplFeatBlock.diceSides = 6;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Trollish Fortitude"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi629."))
            {
                // String name = "Trollish Fortitude";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration == 120)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 3)
                    {
                        foundDuration = 0;
                        duration += 60;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Antimagic Shell"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi630."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.target = 1;
                    currentSplExtendedHeader.projectile = 1;
                    currentSplExtendedHeader.range = 15;
                    index++;
                }
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 30;
                    }
            
                    if (currentSplFeatBlock.targetType == 1)
                    {
                        currentSplFeatBlock.targetType = 2;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Lich Touch"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi631."))
            {
                // String name = "Trollish Fortitude";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 1;
                    index++;
                }
                
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration != 0)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 3)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Acid Storm"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi706."))
            {
                // String name = "Acid Storm";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
                
                RemoveSplOpcode(146, 0);
                RemoveSplOpcode(324, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 7, 0, 1, 4, 1, 6, 100, 0, "spwi706A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 7, 0, 1, 4, 1, 12, 100, 0, "spwi706B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 7, 0, 1, 4, 1, 18, 100, 0, "spwi706C", 0, 0, 0, 0, 0, 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                        currentSplFeatBlock.savingThrowType = 1;
                    }
                    
                    index++;
                }
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("spwi706.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 1, -2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, -2, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 8, 6, 1, -2, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi706a.spl");
                
                //
                
                CreateSplObjects("spwi706.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 1, -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 6, 6, 1, -1, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi706b.spl");
                
                //
                
                CreateSplObjects("spwi706.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 2, 0, 1, 3, 100, 0, "ACIDH" + new string(new char[3]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 129, 4, 1, 1, 0, 100, 0, "DWTROLAC", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 102, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 1, 1, 1, 0, 100, 0, new string(new char[8]), 4, 6, 1, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/spwi706c.spl");
            }
            
            //  mod      "Suffocate"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi709."))
            {
                // String name = "Suffocate";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                AddSplFeatureBlockToSplExtendedHeader(44, 2, 7, -6, 0, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 64, 4, 1, 6, 100, 0, new string(new char[8]), 4, 8, GetBitfieldInt(new int[] {0, 24}), 0, GetBitfieldInt(new int[] { 8 }), 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 64, 4, 1, 12, 100, 0, new string(new char[8]), 4, 8, GetBitfieldInt(new int[] {0, 24}), 0, GetBitfieldInt(new int[] { 8 }), 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 64, 4, 1, 18, 100, 0, new string(new char[8]), 4, 8, GetBitfieldInt(new int[] {0, 24}), 0, GetBitfieldInt(new int[] { 8 }), 0);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 1)
                    {
                        currentSplFeatBlock.parameter1 = 1; // number of attacks
                        currentSplFeatBlock.parameter2 = 1; // number of attacks
                    }
            
                    if (currentSplFeatBlock.savingThrowType == 1) // add saving penalty
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
            
                    if (currentSplFeatBlock.parameter1 < 0)
                    {
                        currentSplFeatBlock.parameter1 = -6;
                    }
            
                    if (currentSplFeatBlock.duration == 6)
                    {
                        currentSplFeatBlock.duration = 18;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Malavon's Revenge"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi726."))
            {
                // String name = "Malavon's Revenge";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)"),
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceSides = 5; // dmg mod
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Great Shout"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi814."))
            {
                
                RemoveSplOpcode(45, "duration", 12); // only delete if the prop has the specified value;
                RemoveSplOpcode(142, "duration", 12); // only delete if the prop has the specified value;
                RemoveSplOpcode(80, "duration", 12); // only delete if the prop has the specified value;
                RemoveSplOpcode(12, "targetType", 1); // only delete if the prop has the specified value;
                RemoveSplOpcode(39, "targetType", 1); // only delete if the prop has the specified value;
                RemoveSplOpcode(139, "targetType", 1); // only delete if the prop has the specified value;
                RemoveSplOpcode(139, "savingThrowType", 1); // only delete if the prop has the specified value;
                
                
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration == 6)
                    {
                        currentSplFeatBlock.duration = 12;
                    }
            
                    if (currentSplFeatBlock.duration == 24)
                    {
                        currentSplFeatBlock.duration = 60;
                    }
                    
                    if (currentSplFeatBlock.diceThrown == 5)
                    {
                        currentSplFeatBlock.diceThrown = 8;
                        currentSplFeatBlock.diceSides = 5;
                    }
                    
                    if (currentSplFeatBlock.diceThrown == 3)
                    {
                        currentSplFeatBlock.diceThrown = 4;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Iron Body"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi819."))
            {
                
                RemoveSplOpcode(145, "targetType", 1); // only delete if the prop has the specified val
                ModifySplOpcode(126, "property1", 25, 50);
                // add cold res
                AddSplFeatureBlockToSplExtendedHeader(28, 1, 8, 100, 1, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // add casting speed malus
                AddSplFeatureBlockToSplExtendedHeader(189, 1, 8, -2, 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // add slashing res
                AddSplFeatureBlockToSplExtendedHeader(86, 1, 8, 50, 1, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // add piercing res
                AddSplFeatureBlockToSplExtendedHeader(88, 1, 8, 75, 1, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // add missile res
                AddSplFeatureBlockToSplExtendedHeader(89, 1, 8, 100, 1, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // add immunity to cold spells
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 8, 0, 0, 0, 3, 120, 100, 0, "SPPR411" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 8, 0, 0, 0, 3, 120, 100, 0, "SPWI327" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 8, 0, 0, 0, 3, 120, 100, 0, "SPWI404" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 8, 0, 0, 0, 3, 120, 100, 0, "SPWI503" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 8, 0, 0, 0, 3, 120, 100, 0, "SPPR424" + new char(), 0, 0, 0, 0, 0, 0); // now cone of cold
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Bless"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR101."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 5;
                    index++;
                }
                
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 6;
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Entangle"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR105."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 0)
                    {
                        currentSplFeatBlock.parameter1 = -4;
                    }
            
                    if (currentSplFeatBlock.savingThrowBonus == 3)
                    {
                        currentSplFeatBlock.savingThrowBonus = 0;
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "MAGICAL STONE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR106."))
            {
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 1, 0, 0, 1, 1, 0, 100, 0, "SPPR106A", 0, 0, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPPR106.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplCastingFeatureBlocks();
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 1, 129, 4, 1, 1, 0, 100, 0, "DWTROLCO", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 1, 129, 4, 1, 1, 0, 100, 0, "DWTROLFI", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, 1, 0, GetBitfieldInt(new int[] {8}), 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, 1, 0, GetBitfieldInt(new int[] {8}), 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 1, 0, 0, 2, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, 1, 0, GetBitfieldInt(new int[] {8}), 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 28, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 29, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 1, 0, 30, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 0, 1, 0, 100, 0, "EFF_P13" + new char(), 0, 0, 1, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                ModifySplOpcodeSpecific(12, "diceSides", 4, 6, 1);
                ModifySplOpcodeSpecific(12, "diceSides", 4, 8, 2);
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    if (index == 1)
                    {
                        currentSplExtendedHeader.levelRequired = 6;
                    }
                    else if (index ==2)
                    {
                        currentSplExtendedHeader.levelRequired = 12;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR106A.SPL");
                
            }
            
            //  mod      "SHILLELAGH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR110."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (index == 0)
                    {
                        currentSplFeatBlock.duration = 120;
                    }
                    else if (index == 2)
                    {
                        currentSplFeatBlock.resource = "SHILLE2" + new char();
                        currentSplFeatBlock.duration = 120;
                    }
                    else if (index == 4)
                    {
                        currentSplFeatBlock.resource = "SHILLE3" + new char();
                        currentSplFeatBlock.duration = 120;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "ARMOR OF FAITH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR111."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 1;
                    index++;
                }
                
                index = 0;
                int absorption = 1;
                int foundAbsorption = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 27 ||
                        currentSplFeatBlock.opcodeNumber == 28 ||
                        currentSplFeatBlock.opcodeNumber == 29 ||
                        currentSplFeatBlock.opcodeNumber == 30 ||
                        currentSplFeatBlock.opcodeNumber == 31 ||
                        currentSplFeatBlock.opcodeNumber == 86 ||
                        currentSplFeatBlock.opcodeNumber == 87 ||
                        currentSplFeatBlock.opcodeNumber == 88 ||
                        currentSplFeatBlock.opcodeNumber == 89
                        )
                    {
                        currentSplFeatBlock.parameter1 = absorption;
                        foundAbsorption++;
                    }
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 300;
                    }
            
                    if (foundAbsorption == 9)
                    {
                        foundAbsorption = 0;
                        absorption++;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "DOOM"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR113."))
            {
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.castingTime = 1;
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
           
            // mod       "CURSE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR112."))
            {
               index = 0;
               foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
               {
                   currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                   currentSplExtendedHeader.castingTime = 2;
                   index++;
               }
            
               FixSplOffsets();
               FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SPIRIT WARD"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR150."))
            {
                index = 0;
                int duration = 30;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 13)
                    {
                        foundDuration = 0;
                        duration += 30;
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "AID"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR201."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 8)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 10)
                    {
                        foundDuration = 0;
                        duration += 12;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "BARKSKIN"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR202."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(0, 2, 2, 2, 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(7, 2, 2, 23, 3, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 2, 0, 4, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 2, 0, 20, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 2, 0, 0, 4, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 2, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 300, 100, 0, "SPPR202" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 6;
                    index++;
                }
                
                index = 0;
                int acBonus = 2;
                int foundAcBonus = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 0)
                    {
                        currentSplFeatBlock.parameter1 = acBonus;
                        foundAcBonus++;
                    }
            
                    if (foundAcBonus == 1)
                    {
                        foundAcBonus = 0;
                        acBonus ++;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CHARM PERSON OR MAMMAL"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR204."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.savingThrowBonus == 3)
                    {
                        currentSplFeatBlock.savingThrowBonus = 1;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FIND TRAPS" (CONVERT TO "FIRE TRAP")
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR205."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 0, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, GetBitfieldInt(new int[] { 1 }), 0, GetBitfieldInt(new int[] { 8 }), 0);
            
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 100; // TRAPGLYP
                currentSplExtendedHeader.castingTime = 5;
                currentSplExtendedHeader.range = 30;
                currentSplExtendedHeader.target = 4;
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
            
                index = 0;
                int damage1 = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    // Console.WriteLine(currentFeatureBlock.diceThrown + ":" + currentFeatureBlock.diceSides);
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = damage1;
                        damage1++;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "GOODBERRY" (CONVERT TO "DIVINE GROWTH")
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR207."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.projectile = 162;
                currentSplExtendedHeader.castingTime = 9;
                currentSplExtendedHeader.range = 1;
                currentSplExtendedHeader.target = 5;
            
                rgb = new byte[] {0, 56, 86, 0};
            
                AddSplFeatureBlockToSplExtendedHeader(98, 2, 1, 1, 3, 0, 0, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 1, 2, 56, 0, 0, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 1, 0, 0, 4, 0, 60, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 1, BitConverter.ToInt32(rgb, 0), 0, 0, 25, 0, 3, 0, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 1, 0, 1, 0, 0, 3, 100, 0, "ICWRATI" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 0, 60, 100, 0, "SPPR207" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 0, 60, 100, 0, "SPPR711" + new char(), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 4;
                }
                
                index = 0;
                int durationFound = 0;
                int duration = 30;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    // Console.WriteLine(currentFeatureBlock.diceThrown + ":" + currentFeatureBlock.diceSides);
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        durationFound++;
                    }
            
                    if (durationFound == 7)
                    {
                        durationFound = 0;
                        duration += 30;
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // remove slow effect of chant spell
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR203."))
            {
                RemoveSplOpcode(176, 0);
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FLAME BLADE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR206."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 2, 0, 0, 0, 3, 120, 100, 0, "FBLADE" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 2, 0, 0, 0, 3, 3, 100, 0, "SPFLMBLD", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(278, 1, 1, 1, 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
            
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    if (i == 1)
                    {
                        currentSplExtendedHeader.levelRequired = 3;
                    }
                    else if (i == 2)
                    {
                        currentSplExtendedHeader.levelRequired = 6;
                    }
                    else if (i == 3)
                    {
                        currentSplExtendedHeader.levelRequired = 9;
                    }
                }
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    // Console.WriteLine(currentFeatureBlock.diceThrown + ":" + currentFeatureBlock.diceSides);
                    if (index == 3)
                    {
                        currentSplFeatBlock.resource = "FBLADE1" + new char();
                    }
                    else if (index == 6)
                    {
                        currentSplFeatBlock.resource = "FBLADE2" + new char();
                    }
                    else if (index == 9)
                    {
                        currentSplFeatBlock.resource = "FBLADE3" + new char();
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "HOLD PERSON"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR208."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowType = GetBitfieldInt(new int[] { 2 });
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Resist Fire and Cold" CONVERSION TO RESIST ELEMENTS
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR210."))
            {   
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(29, 2, 2, 50, 0, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 2, 0, 27, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 2, FindFirstExactTlkEntry("Resist Lightning"), 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 120;
                int foundResistance = 0;
                int resistance = 20;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 5)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (
                        currentSplFeatBlock.opcodeNumber == 28 ||
                        currentSplFeatBlock.opcodeNumber == 29 ||
                        currentSplFeatBlock.opcodeNumber == 30 ||
                        currentSplFeatBlock.opcodeNumber == 84 ||
                        currentSplFeatBlock.opcodeNumber == 85
                        )
                    {
                        currentSplFeatBlock.parameter1 = (short)resistance;
                        foundResistance++;
                    }
            
                    if (foundDuration == 10)
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
            
                    if (foundResistance == 5)
                    {
                        resistance += 2;
                        foundResistance = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Silence"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR211."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowBonus == -5 )
                    {
                        currentSplFeatBlock.savingThrowBonus = -2;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Spiritual Hammer"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR213."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(111, 1, 2, 0, 0, 0, 3, 120, 100, 0, "shammr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 2, 0, 0, 0, 3, 3, 100, 0, "SPCRTWPN", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(278, 1, 1, 1, 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    if (i == 1)
                    {
                        currentSplExtendedHeader.levelRequired = 5;
                    }
                    else if (i == 2)
                    {
                        currentSplExtendedHeader.levelRequired = 10;
                    }
                    else if (i == 3)
                    {
                        currentSplExtendedHeader.levelRequired = 15;
                    }
                    else if (i == 4)
                    {
                        currentSplExtendedHeader.levelRequired = 20;
                    }
                }
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    // Console.WriteLine(currentFeatureBlock.diceThrown + ":" + currentFeatureBlock.diceSides);
                    if (index == 3)
                    {
                        currentSplFeatBlock.resource = "shammr2" + new char();
                    }
                    else if (index == 6)
                    {
                        currentSplFeatBlock.resource = "shammr3" + new char();
                    }
                    else if (index == 9)
                    {
                        currentSplFeatBlock.resource = "shammr4" + new char();
                    }
                    else if (index == 12)
                    {
                        currentSplFeatBlock.resource = "shammr5" + new char();
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Writhing Fog"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR250."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber > 40)
                    {
                        currentSplFeatBlock.probability1 = 100;
                    }
                    
                    if (currentSplFeatBlock.opcodeNumber > 12)
                    {
                        currentSplFeatBlock.diceThrown = 6;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Call Lightning"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR302."))
            {
                splHeaderModded.flags = GetBitfieldInt(new int[] {9}); // castable indoors since sunscorch is also castable indoors
                
                index = 0;
                int dmg = 5;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = dmg;
                        dmg++;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Animate Dead"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR301."))
            {
                // first skeleton
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE01", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE01", 0, 0, 0, 0, 0, 1);
            
                // second skeleton
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks(2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE07", 0, 0, 0, 0, 0, 2);
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE07", 0, 0, 0, 0, 0, 3);
                
                // third skeleton
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                RemoveAllSplFeatureBlocks(4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE11", 0, 0, 0, 0, 0, 4);
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDE11", 0, 0, 0, 0, 0, 5);
                
                // fourth skeleton
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                RemoveAllSplFeatureBlocks(6);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDL15", 0, 0, 0, 0, 0, 6);
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SPANDL15", 0, 0, 0, 0, 0, 7);
                                    
                // fifth skeleton type
                // CopyExtendedHeaderAndFeatureBlocks(7);
                // RemoveAllFeatureBlocks(8);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SKELWARR", 0, 0, 0, 0, 0, 8);
                // CopyExtendedHeaderAndFeatureBlocks(8);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "SKELWARR", 0, 0, 0, 0, 0, 9);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                splHeaderModded.spellDescriptionId = -1;
                splHeaderModded.spellNameId = -1;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Glyph of Warding"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR304."))
            {
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    currentSplExtendedHeader.castingTime = 4;
                }
                
                index = 0;
                int dmg = 5;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = dmg;
                        currentSplFeatBlock.diceSides = 4;
                        dmg++;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Hold Animal" CONVERSION TO "HOLD MAMMAL"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR305."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 5, FindFirstExactTlkEntry("Held"), 1, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 5, 0, 13, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(175, 2, 5, 2, 3, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(175, 2, 5, 1, 3, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(175, 2, 5, 5, 3, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(328, 2, 5, 0, 152, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -1, 1, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 5, 0, 0, 4, 1, 60, 100, 0, "EFF_E08" + new char(), 0, 0, GetBitfieldInt(new int[] {2}), -1, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 5, 0, 1, 0, 1, 60, 100, 0, "SPMINDAT", 0, 0, GetBitfieldInt(new int[] {2}), -1, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Protection from Fire"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR306."))
            {
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 60;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 5)
                    {
                        duration += 60;
                        foundDuration = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Invisibility Purge"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR309."))
            {
                // String name = "Invisibility Purge";
            
                RemoveAllSplFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 1, 3, 0, 100, 0, "SPPR309A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 6, 100, 0, "SPPR309A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 12, 100, 0, "SPPR309A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 18, 100, 0, "SPPR309A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 24, 100, 0, "SPPR309A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 1, 1, 1, 4, 3, 30, 100, 0, "SPPR309A", 0, 0, 0, 0, 0, 0);
            
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.castingTime = 2;
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPPR309.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    currentSplExtendedHeader.range = 100;
                    currentSplExtendedHeader.castingTime = 1;
                    index++;
                }
                
                AddSplFeatureBlockToSplExtendedHeader(318, 2, 0, 0, 143, 0, 2, 0, 100, 0, "SPPR309" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(116, 2, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 0, 0, 30, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 0, FindFirstExactTlkEntry("Dispel Invisible"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                rgb = new byte[] {0, 128, 134, 137};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 2, 2, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 0, 0, 1, 0, 2, 2, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 0, 0, 0, 0, 2, 0, 100, 0, "EFF_M04" + new char(), 0, 0, 0, 0, 0, 0);
            
                
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR309A.SPL");
            
            }
            
            //  mod      "Miscast Magic"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR310."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 60)
                    {
                        currentSplFeatBlock.parameter1 = 95;
                    }
            
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Rigid Thinking"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR311."))
            {
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.castingTime = 3;
                }
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = -1;
                    }
            
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Strength of One"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR312."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 60;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 6)
                    {
                        duration += 60;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Holy Smite"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR313."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 3, 0, 26, 0, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(74, 2, 3, 0, 0, 0, 1, 18, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 3, FindFirstExactTlkEntry("Blinded"), 0, 0, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 0, 1, 18, 100, 0, "EFF_M85" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 2, 4, 1, 0, GetBitfieldInt(new int[] {8}), 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
                
                index = 0;
                int damage = 4;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = damage;
                        damage++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Unholy Blight"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR314."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 3, 0, 26, 0, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(74, 2, 3, 0, 0, 0, 1, 18, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 3, FindFirstExactTlkEntry("Blinded"), 0, 0, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 0, 1, 18, 100, 0, "EFF_M85" + new char(), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 2, 4, 1, 0, GetBitfieldInt(new int[] {8}), 0);
   
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
                
                index = 0;
                int damage = 4;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = damage;
                        damage++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Summon Insects"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR319."))
            {
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.castingTime = 5;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FARSIGHT" CONVERSION TO RAY OF FROST
            if (
                ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR415.")
            )
            {
                CreateSplObjects("SPWI217.SPL");

                // String name = "Ray of Frost";
                // String desc = "Ray of Frost\n(Evocation)\n\nLevel: 2\nRange: 15 ft.\nDuration: 1 round\nCasting Time: 3\nArea of Effect: 2-ft. by 15-ft. jet\nSaving Throw: None\n\nUpon casting this spell, a jet of ice appears at the caster's fingertips and bursts out toward one target of the caster's choice. That target will be hit by this frost ray for 6d6 points of damage. The ice jet strikes a second time halfway through its duration, and the caster may move while the spell is in effect. There is no Saving Throw against this spell, though anti-cold capabilities such as Cold Resistance will apply and may reduce or eliminate the damage.";
                // AddTlkEntry(name);
                // AddTlkEntry(desc);

                splHeaderModded.spellNameUnId = FindFirstExactTlkEntry("Farsight"); // reset this to farsight (will be overridden by RunTlkSpl)
                splHeaderModded.spellDescriptionUnId = FindFirstMatchingTlkEntry(@"Farsight\n\("); // reset this to farsight (will be overridden by RunTlkSpl)

                splHeaderModded.spellLevel = 4;
                splHeaderModded.spellType = 2;
                splHeaderModded.spellBookIcon = "SPPR415C";

                foreach (SplExtendedHeader extHeader in splExtHeadersModded)
                {
                    extHeader.projectile = 191;
                    extHeader.memorizedIcon = "SPPR415B"; 
                }

                foreach (SplFeatureBlock splFeatureBlock in splFeatBlocksModded)
                {
                    if (splFeatureBlock.opcodeNumber == 177)
                    {
                        splFeatureBlock.resource = "DWTROLCO";
                    }

                    if (splFeatureBlock.opcodeNumber == 12)
                    {
                        splFeatureBlock.parameter22 = 8;
                        splFeatureBlock.diceThrown = 6;
                        splFeatureBlock.diceSides = 6;
                    }
                }

                FixSplOffsets();
                FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR415.SPL");
            }
            
            //  mod      "Free Action" (make free action last longer and compatible with haste spells)
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR403."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                RemoveSplOpcode(206, "spwi305");
                RemoveSplOpcode(206, "spwi613");
                RemoveSplOpcode(206, "spra301");
                RemoveSplOpcode(206, "spin828");
                RemoveSplOpcode(206, "spin572");
                RemoveSplOpcode(267, "parameter1", FindFirstExactTlkEntry("Hasted"));
                RemoveSplOpcode(240, "parameter2", 195);
                RemoveSplOpcode(240, "parameter2", 38);
                RemoveSplOpcode(126, 0);
                RemoveSplOpcode(101, "parameter2", 126);
                RemoveSplOpcode(101, "parameter2", 16);
                RemoveSplOpcode(169, "parameter2", 195);
                RemoveSplOpcode(169, "parameter2", 38);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 4;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 300;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 46)
                    {
                        duration += 60;
                        foundDuration = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Neutralize Poison"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR404."))
            {
                
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.opcodeNumber == 17)
                    {
                        currentSplFeatBlock.parameter1 = 25;    
                    }
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Defensive Harmony"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR406."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 300;
                int foundAc = 0;
                int ac = 2;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 0)
                    {
                        currentSplFeatBlock.parameter1 = ac;
                        foundAc++;
                    }
            
                    if (foundDuration == 5)
                    {
                        duration += 30;
                        foundDuration = 0;
                    }
            
                    if (foundAc == 3)
                    {
                        ac++;
                        foundAc = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Protection from Lightning"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR407."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 480;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 60;
                        foundDuration = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Protection from Evil 10 foot" conversion to Protection from Poison
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR408."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                rgb = new byte[] {0, 50, 255, 255};
            
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poison"), 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poisoned"), 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 137, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 6, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(101, 2, 0, 0, 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(173, 2, 0, 100, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 30, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 0, 0, 2, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 30, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(164, 2, 0, 0, 0, 1, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 0, 0, 0, 1, 3, 1, 100, 0, "EFF_P06" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 480;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 60;
                        foundDuration = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }

            //  mod      "Poison"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR411."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == GetBitfieldInt(new int[] {2}))
                    {
                        currentSplFeatBlock.savingThrowBonus = -1;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Negative Plane Protection"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR413."))
            {
                index = 0;
                int duration = 480;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 3600;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Cloak of Fear"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR416."))
            {
                RemoveAllSplFeatureBlocks();
            
                rgb = new byte[] {0, 0, 99, 109};
            
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 4, 0, 1, 0, 3, 2, 100, 0, "ICCLKFR" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 4, 0, 61, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 4, 0, 0, 4, 3, 60, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(50, 1, 4, BitConverter.ToInt32(rgb, 0), 0, 0, 25, 0, 3, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 0, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 6, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 12, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 18, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 24, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 30, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 36, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 42, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 48, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 60, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifyAllSplDurations(10, 120, new int[] { 146 }, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 66, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 72, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 78, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 84, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 90, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 96, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 102, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 108, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 114, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 120, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 1);
            
                
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                ModifyAllSplDurations(10, 180, new int[] { 146 }, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 126, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 132, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 138, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 144, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 150, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 156, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 162, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 168, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 174, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 180, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 2);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                ModifyAllSplDurations(10, 240, new int[] { 146 }, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 186, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 192, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 198, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 204, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 210, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 216, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 222, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 228, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 234, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 240, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 3);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                ModifyAllSplDurations(10, 300, new int[] { 146 }, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 246, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 252, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 258, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 264, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 270, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 276, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 282, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 288, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 294, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 4, 4, 1, 4, 3, 300, 100, 0, "SPPR416D", 0, 0, 0, 0, 0, 4);
                
                // protection from spell
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 4, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "EFF_E03" + new char(), 0, 0, 0, 0, 0, 4);
            
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 3;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("sppr416.spl");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplCastingFeatureBlocks();
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 4, 3, 1, 0, 0, 100, 0, "SPPR417I", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(54, 2, 4, -2, 0, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(0, 2, 4, -2, 0, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(24, 2, 4, 0, 0, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 4, 0, 36, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 4, FindFirstExactTlkEntry("Panic"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 4, 0, 0, 4, 1, 6, 100, 0, "EFF_E05" + new char(), 0, 0, 1, 0, 0, 0);
                
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.projectile = 292;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr416d.spl");
            
            }
            
            //  mod      "Spirit Fire"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR450."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
                
                index = 0;
                int dmg = 4;
                byte prob = 50;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = dmg;
                        currentSplFeatBlock.diceSides = 6;
                        dmg += 1;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 146)
                    {
                        currentSplFeatBlock.probability1 = prob;
                        prob += 5;
                    }
            
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = -1;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "IRON SKIN"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR506."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 6; // begin two levels below to give druid a little bit of an edge and more iron skins at lower levels
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int skins = 3;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    
                    if (currentSplFeatBlock.opcodeNumber == 218) // num of skins
                    {
                        currentSplFeatBlock.parameter1 = skins;
                        skins++;
                    }
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "True Seeing"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR505."))
            {
                RemoveSplOpcode(146, 0);
                RemoveSplOpcode(177, 0);
                RemoveSplOpcode(220, 0);
                RemoveSplOpcode(221, 0);
                RemoveSplOpcode(328, 0);
                RemoveSplOpcode(116, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 1, 3, 0, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 6, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 12, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 24, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 30, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 36, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 42, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 48, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 54, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 60, 100, 0, "SPPR505D", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifyAllSplDurations(10, 66, new int[] { 146 }, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 66, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                ModifyAllSplDurations(10, 72, new int[] { 146 }, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 72, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                ModifyAllSplDurations(10, 78, new int[] { 146 }, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 78, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 3);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                ModifyAllSplDurations(10, 84, new int[] { 146 }, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 84, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 4);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                ModifyAllSplDurations(10, 90, new int[] { 146 }, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 90, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                ModifyAllSplDurations(10, 96, new int[] { 146 }, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 96, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 6);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                ModifyAllSplDurations(10, 102, new int[] { 146 }, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 102, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 7);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(7);
                ModifyAllSplDurations(10, 108, new int[] { 146 }, 8);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 108, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(8);
                ModifyAllSplDurations(10, 114, new int[] { 146 }, 9);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 114, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 9);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(9);
                ModifyAllSplDurations(10, 120, new int[] { 146 }, 10);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 12, 1, 4, 3, 120, 100, 0, "SPPR950" + new char(), 0, 0, 0, 0, 0, 10);
            
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 8)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Champions Strength"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR507."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveSplOpcode(44, 0);
                RemoveSplOpcode(145, 0);
                RemoveSplOpcode(97, 0);
                RemoveSplOpcode(54, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(44, 2, 5, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(15, 2, 5, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(54, 2, 5, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                
                index = 0;
                level = 9;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 120;
                int thaco = 2;
                int str = 2;
                int dex = 2;
                int foundThaco = 0;
                int foundStr = 0;
                int foundDex = 0;
                int foundDuration = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 15)
                    {
                        currentSplFeatBlock.parameter1 = dex;
                        foundDex++;
                    }
                    if (currentSplFeatBlock.opcodeNumber == 44)
                    {
                        currentSplFeatBlock.parameter1 = str;
                        foundStr++;
                    }
                    if (currentSplFeatBlock.opcodeNumber == 54)
                    {
                        currentSplFeatBlock.parameter1 = thaco;
                        foundThaco++;
                    }
            
                    if (foundDex == 5)
                    {
                        dex++;
                        foundDex = 0;
                    }
                    if (foundStr == 5)
                    {
                        str++;
                        foundStr = 0;
                    }
                    if (foundThaco == 5)
                    {
                        thaco++;
                        foundThaco = 0;
                    }
                    if (foundDuration == 8)
                    {
                        duration += 24;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Magic Resistance"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR509."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int resist = 1;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = 300;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 166)
                    {
                        currentSplFeatBlock.parameter1 = resist;
                        resist++;
                        currentSplFeatBlock.parameter2 = 0;
                    }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Greater Command"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR512."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                    }
                    
                    if (foundDuration == 4)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Repulse Undead" Conversion to Repulsion
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR515."))
            {
                RemoveAllSplFeatureBlocks();
            
                rgb = new byte[] {0, 142, 182, 205};
                
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 5, 0, 66, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 5, BitConverter.ToInt32(rgb, 0), 1, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 1, 5, 0, 14, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 5, 0, 0, 1, 3, 0, 100, 0, "EFF_M06" + new byte(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 5, 0, 0, 4, 3, 60, 100, 0, "EFF_M03" + new byte(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 0, 3, 0, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 6, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 12, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 18, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 24, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 30, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 36, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 42, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 48, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 54, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 60, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifyAllSplDurations(10, 66, new int[] { 146 }, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 66, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                ModifyAllSplDurations(10, 72, new int[] { 146 }, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 72, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                ModifyAllSplDurations(10, 78, new int[] { 146 }, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 78, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 3);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                ModifyAllSplDurations(10, 84, new int[] { 146 }, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 84, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 4);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                ModifyAllSplDurations(10, 90, new int[] { 146 }, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 90, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                ModifyAllSplDurations(10, 96, new int[] { 146 }, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 96, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 6);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                ModifyAllSplDurations(10, 102, new int[] { 146 }, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 102, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 7);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(7);
                ModifyAllSplDurations(10, 108, new int[] { 146 }, 8);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 108, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(8);
                ModifyAllSplDurations(10, 114, new int[] { 146 }, 9);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 114, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 9);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(9);
                ModifyAllSplDurations(10, 120, new int[] { 146 }, 10);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 120, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 10);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(10);
                ModifyAllSplDurations(10, 126, new int[] { 146 }, 11);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 126, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 11);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(11);
                ModifyAllSplDurations(10, 132, new int[] { 146 }, 12);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 132, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 12);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(12);
                ModifyAllSplDurations(10, 138, new int[] { 146 }, 13);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 138, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 13);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(13);
                ModifyAllSplDurations(10, 144, new int[] { 146 }, 14);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 144, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 14);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(14);
                ModifyAllSplDurations(10, 150, new int[] { 146 }, 15);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 150, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 15);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(15);
                ModifyAllSplDurations(10, 156, new int[] { 146 }, 16);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 156, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 16);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(16);
                ModifyAllSplDurations(10, 162, new int[] { 146 }, 17);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 162, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 17);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(17);
                ModifyAllSplDurations(10, 168, new int[] { 146 }, 18);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 168, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 18);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(18);
                ModifyAllSplDurations(10, 174, new int[] { 146 }, 19);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 174, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 19);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(19);
                ModifyAllSplDurations(10, 180, new int[] { 146 }, 20);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 180, 100, 0, "SPPR515D", 0, 0, 0, 0, 0, 20);
                
                // protection from spell
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 8);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 9);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 10);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 11);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 12);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 13);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 14);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 15);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 16);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 17);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 18);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 19);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 5, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR515" + new byte(), 0, 0, 0, 0, 0, 20);
            
            
                index = 0;
                level = 9;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPPR515.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 5, 0, 0, 0, 3, 3, 100, 0, "FIRECOLD", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(235, 2, 5, 10, 2, 0, 1, 1, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.projectile = 296;
                    currentSplExtendedHeader.range = 10;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR515D.SPL");
                                
            }
            
            //  mod      "Blade Barrier"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR603."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(142, 1, 6, 0, 98, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(144, 1, 6, 0, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 6, 0, 1, 0, 3, 60, 100, 0, "SPBLDTOP", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 6, 0, 1, 0, 3, 60, 100, 0, "SPBLDBTM", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 6, 0, 0, 4, 3, 60, 100, 0, "EFF_M02" + new byte(), 0, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 0, 3, 0, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 6, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 12, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 18, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 24, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 30, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 36, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 42, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 48, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 54, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 4, 3, 60, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifyAllSplDurations(10, 66, new int[] { 146 }, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 66, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                ModifyAllSplDurations(10, 72, new int[] { 146 }, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 72, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                ModifyAllSplDurations(10, 78, new int[] { 146 }, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 78, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 3);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                ModifyAllSplDurations(10, 84, new int[] { 146 }, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 84, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 4);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                ModifyAllSplDurations(10, 90, new int[] { 146 }, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 90, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                ModifyAllSplDurations(10, 96, new int[] { 146 }, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 96, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 6);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                ModifyAllSplDurations(10, 102, new int[] { 146 }, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 102, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 7);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(7);
                ModifyAllSplDurations(10, 108, new int[] { 146 }, 8);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 108, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(8);
                ModifyAllSplDurations(10, 114, new int[] { 146 }, 9);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 114, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 9);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(9);
                ModifyAllSplDurations(10, 120, new int[] { 146 }, 10);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 120, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 10);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(10);
                ModifyAllSplDurations(10, 126, new int[] { 146 }, 11);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 126, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 11);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(11);
                ModifyAllSplDurations(10, 132, new int[] { 146 }, 12);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 132, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 12);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(12);
                ModifyAllSplDurations(10, 138, new int[] { 146 }, 13);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 138, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 13);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(13);
                ModifyAllSplDurations(10, 144, new int[] { 146 }, 14);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 144, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 14);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(14);
                ModifyAllSplDurations(10, 150, new int[] { 146 }, 15);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 150, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 15);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(15);
                ModifyAllSplDurations(10, 156, new int[] { 146 }, 16);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 156, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 16);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(16);
                ModifyAllSplDurations(10, 162, new int[] { 146 }, 17);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 162, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 17);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(17);
                ModifyAllSplDurations(10, 168, new int[] { 146 }, 18);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 168, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 18);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(18);
                ModifyAllSplDurations(10, 174, new int[] { 146 }, 19);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 174, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 19);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(19);
                ModifyAllSplDurations(10, 180, new int[] { 146 }, 20);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 180, 100, 0, "SPPR603D", 0, 0, 0, 0, 0, 20);
            
                // protection from spell
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 1);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 2);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 3);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 4);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 5);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 5);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 6);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 6);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 7);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 7);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 8);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 8);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 9);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 9);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 10);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 10);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 11);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 11);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 12);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 12);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 13);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 13);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 14);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 14);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 15);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 15);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 16);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 16);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 17);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 17);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 18);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 18);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 19);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 19);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR603" + new byte(), 0, 0, 0, 0, 0, 20);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 6, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "SPPR725" + new byte(), 0, 0, 0, 0, 0, 20);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 7)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPPR603.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 6, 1, 4, 3, 3, 100, 0, "SPPR603E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 6, 1, 4, 3, 6, 100, 0, "SPPR603E", 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR603D.SPL");
                
                // 
                
                CreateSplObjects("SPPR603.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(47, 1, 6, 0, 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(160, 1, 6, 0, 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 6, 0, 0, 256, 1, 0, 0, 100, 0, new string(new char[8]), 1, 12, 0, 0, 0, 0);
                
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                    currentSplExtendedHeader.projectile = 218;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR603E.SPL");
            }
            
            // //  mod      "Fire Seeds"
            // if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR606."))
            // {
            //     // CREATE HELPER SPELLS
            //     
            //     CreateSplObjects("SPPR606.SPL");
            //     RemoveAllFeatureBlocks();
            //     RemoveAllCastingFeatureBlocks();
            //     RemoveExtendedHeadersAndFeatureBlocks(1);
            //     
            //     AddFeatureBlockToExtendedHeader(146, 1, 6, 6, 1, 4, 3, 3, 100, 0, "SPPR606D", 0, 0, 0, 0, 0, 0);
            //     AddFeatureBlockToExtendedHeader(146, 1, 6, 6, 1, 4, 3, 6, 100, 0, "SPPR606D", 0, 0, 0, 0, 0, 0);
            //     
            //     index = 0;
            //     foreach (ExtendedHeader extendedHeaders in extendedHeadersModded)
            //     {
            //         currentExtendedHeader = (ExtendedHeader) extendedHeadersModded[index];
            //         currentExtendedHeader.projectile = 226;
            //         index++;
            //     }
            //     
            //     FixFeatureBlockOffsets();
				// FileOperations.WriteFile(headerModded, extendedHeadersModded, castingFeatureBlocksModded, featureBlocksModded, outputBasePath + "/SPPR606D.SPL");
            //     
            //     // 
            // }
            
            //  mod      "False Dawn"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR609."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 0, 0, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 0, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 6, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 12, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 18, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 24, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 30, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 36, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 42, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 48, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 54, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 60, 100, 0, "SPPR609E", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifyAllSplDurations(10, 66, new int[] { 146 }, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 66, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                ModifyAllSplDurations(10, 72, new int[] { 146 }, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 72, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                ModifyAllSplDurations(10, 78, new int[] { 146 }, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 78, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 3);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                ModifyAllSplDurations(10, 84, new int[] { 146 }, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 84, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 4);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                ModifyAllSplDurations(10, 90, new int[] { 146 }, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 90, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                ModifyAllSplDurations(10, 96, new int[] { 146 }, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 96, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 6);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                ModifyAllSplDurations(10, 102, new int[] { 146 }, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 102, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 7);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(7);
                ModifyAllSplDurations(10, 108, new int[] { 146 }, 8);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 108, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(8);
                ModifyAllSplDurations(10, 114, new int[] { 146 }, 9);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 114, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 9);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(9);
                ModifyAllSplDurations(10, 120, new int[] { 146 }, 10);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 120, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 10);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(10);
                ModifyAllSplDurations(10, 126, new int[] { 146 }, 11);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 126, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 11);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(11);
                ModifyAllSplDurations(10, 132, new int[] { 146 }, 12);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 132, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 12);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(12);
                ModifyAllSplDurations(10, 138, new int[] { 146 }, 13);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 138, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 13);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(13);
                ModifyAllSplDurations(10, 144, new int[] { 146 }, 14);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 144, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 14);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(14);
                ModifyAllSplDurations(10, 150, new int[] { 146 }, 15);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 150, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 15);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(15);
                ModifyAllSplDurations(10, 156, new int[] { 146 }, 16);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 156, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 16);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(16);
                ModifyAllSplDurations(10, 162, new int[] { 146 }, 17);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 162, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 17);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(17);
                ModifyAllSplDurations(10, 168, new int[] { 146 }, 18);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 168, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 18);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(18);
                ModifyAllSplDurations(10, 174, new int[] { 146 }, 19);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 174, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 19);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(19);
                ModifyAllSplDurations(10, 180, new int[] { 146 }, 20);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 180, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 20);
            
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 7)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPPR609.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 6, 4, 3, 1, 3, 0, 100, 0, "SPPR609" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(74, 2, 6, 0, 0, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 6, 0, 8, 0, 1, 6, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 6, FindFirstExactTlkEntry("Blinded"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 0, 0, 1, 0, 3, 3, 100, 0, "DVSUN1" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 0, 0, 1, 0, 3, 3, 100, 0, "DVSUN2" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                rgb = new byte[] {0, 127, 127, 127};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 6, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 1, 1, 100, 0, new string(new char[8]), 0, 0, 1, -5, 0, 0);
            
                rgb = new byte[] {0, 150, 150, 150};
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 1, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 2, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 3, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 4, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 5, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 6, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 16, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 21, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 32, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 34, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 37, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 48, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 49, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 50, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 52, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(8, 1, 0, BitConverter.ToInt32(rgb, 0), 53, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 1, 0, 0, 0);
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 223;
                    currentSplExtendedHeader.range = 60;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR609E.SPL");
                
                //
                
                CreateSplObjects("SPPR609.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 0, 0, 0, 0, 0, 6, 100, 0, "SPFDAWN" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 0, 0, 0, 64, 1, 0, 0, 100, 0, new string(new char[8]), 2, 6, 0, 0, 0, 0);
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 302;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR609F.SPL");
                    
            }
            
            //  mod      "Bolt of Glory"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR612."))
            {
                RemoveSplOpcode(215, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 6, 0, 0, 0, 3, 3, 100, 0, "SPBOLTGL", 0, 0, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Physical Mirror"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR613.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR525."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 1, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0,
                    0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 3, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0,
                    0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 4, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0,
                    0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 101, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 102, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 6, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0,
                    0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 9, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0,
                    0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 10, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 11, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 14, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 15, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 16, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 19, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 26, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 29, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 31, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 34, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 55, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 58, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 257, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(83, 1, 6, 0, 8, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0,
                    0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 6, 0, 0, 1, 3, 0, 100, 0, "EFF_P08" + new char(), 0, 0, 0,
                    0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 1, 6, 0, 0, 4, 3, 120, 100, 0, "EFF_M11B", 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 6, 0, 132, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0,
                    0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(233, 2, 6, 0, 122, 0, 0, 3, 120, 100, 0, new string(new char[8]), 0,
                    0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 0, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 6, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 12, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 18, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 24, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 30, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 36, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 42, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 48, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 54, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 60, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 66, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 72, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 78, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 84, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 90, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 96, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 102, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 108, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 114, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 6, 0, 1, 1, 3, 120, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifyAllSplDurations(10, 126, new int[] {146}, 1);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 126, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 1);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                ModifyAllSplDurations(10, 132, new int[] {146}, 2);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 132, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                ModifyAllSplDurations(10, 138, new int[] {146}, 3);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 138, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 3);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                ModifyAllSplDurations(10, 144, new int[] {146}, 4);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 144, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 4);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                ModifyAllSplDurations(10, 150, new int[] {146}, 5);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 150, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                ModifyAllSplDurations(10, 156, new int[] {146}, 6);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 156, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 6);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                ModifyAllSplDurations(10, 162, new int[] {146}, 7);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 162, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 7);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(7);
                ModifyAllSplDurations(10, 168, new int[] {146}, 8);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 168, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(8);
                ModifyAllSplDurations(10, 174, new int[] {146}, 9);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 174, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 9);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(9);
                ModifyAllSplDurations(10, 180, new int[] {146}, 10);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 180, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 10);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(10);
                ModifyAllSplDurations(10, 186, new int[] {146}, 11);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 186, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 11);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(11);
                ModifyAllSplDurations(10, 192, new int[] {146}, 12);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 192, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 12);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(12);
                ModifyAllSplDurations(10, 198, new int[] {146}, 13);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 198, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 13);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(13);
                ModifyAllSplDurations(10, 204, new int[] {146}, 14);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 204, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 14);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(14);
                ModifyAllSplDurations(10, 210, new int[] {146}, 15);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 210, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 15);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(15);
                ModifyAllSplDurations(10, 216, new int[] {146}, 16);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 216, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 16);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(16);
                ModifyAllSplDurations(10, 222, new int[] {146}, 17);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 222, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 17);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(17);
                ModifyAllSplDurations(10, 228, new int[] {146}, 18);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 228, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 18);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(18);
                ModifyAllSplDurations(10, 234, new int[] {146}, 19);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 234, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 19);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(19);
                ModifyAllSplDurations(10, 240, new int[] {146}, 20);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 240, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 20);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(20);
                ModifyAllSplDurations(10, 246, new int[] {146}, 21);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 246, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 21);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(21);
                ModifyAllSplDurations(10, 252, new int[] {146}, 22);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 252, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 22);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(22);
                ModifyAllSplDurations(10, 258, new int[] {146}, 23);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 258, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 23);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(23);
                ModifyAllSplDurations(10, 264, new int[] {146}, 24);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 264, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 24);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(24);
                ModifyAllSplDurations(10, 270, new int[] {146}, 25);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 270, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 25);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(25);
                ModifyAllSplDurations(10, 276, new int[] {146}, 26);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 276, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 26);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(26);
                ModifyAllSplDurations(10, 282, new int[] {146}, 27);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 282, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 27);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(27);
                ModifyAllSplDurations(10, 282, new int[] {146}, 28);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 282, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 28);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(28);
                ModifyAllSplDurations(10, 294, new int[] {146}, 29);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 294, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 29);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(29);
                ModifyAllSplDurations(10, 300, new int[] {146}, 30);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 5, 0, 1, 4, 3, 300, 100, 0, "SPPR613D", 0, 0, 0, 0, 0, 30);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded,
                    splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPPR613.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(159, 1, 1, 1, 0, 0, 3, 6, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                currentSplExtendedHeader.featureBlockOffset = 0;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR613D.SPL");
            }
            
            //  mod      "Spiritual Lock"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR650."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                RemoveSplOpcode(177, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 144;
                int foundDuration = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.savingThrowBonus == -2)
                    {
                        currentSplFeatBlock.savingThrowBonus = -4;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Shield of the Archons"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR701."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                ModifySplOpcode(201, "parameter1", 7, 14);
                ModifySplOpcode(201, "parameter1", 9, 14);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 84;
                int foundDuration = 0;
                int spells = 20;
                int foundSpells = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 201)
                    {
                        currentSplFeatBlock.parameter1 = spells;
                        foundSpells++;
                    }
            
                    if (foundSpells == 18)
                    {
                        spells++;
                        foundSpells = 0;
                    }
                    
                    if (foundDuration == 11)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Nature's Beauty"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR704."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 7, 0, 1, 0, 3, 2, 100, 0, "ICCLKFR2", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(5, 2, 7, 1, 1, 0, 3, 90, 100, 0, new string(new char[8]), 0, 0, 1, -5, 0, 0);
                rgb = new byte[] {0, 255, 144, 147};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 7, BitConverter.ToInt32(rgb, 0), 0, 0, 30, 0, 0, 1, 1, 100, 0, new string(new char[8]), 0, 0, 1, -5, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 0, 0, 1, 90, 100, 0, new string(new char[8]), 0, 0, 1, -5, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 1, 0, 1, 3, 100, 0, "SPNWCHRM", 0, 0, 1, -5, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 7, 0, 0, 4, 1, 90, 100, 0, "SPNWCHRM", 0, 0, 1, -5, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                    index++;
                }
                
                index = 0;
                int duration = 84;
                int foundDuration = 0;
                
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10 && currentSplFeatBlock.opcodeNumber != 146)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Fire Storm"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR705."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 187, 5, 1, 0, 0, 100, 0, "DVFIREST", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 7, 0, 1, 1, 0, 0, 100, 0, "SPPR705D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 2, 8, GetBitfieldInt(new int[] {1}), -2, GetBitfieldInt(new int[] {8}), 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 2, GetBitfieldInt(new int[] {1}), -2, GetBitfieldInt(new int[] {8}), 1);
                CopySplExtendedHeaderAndSplFeatureBlocks(1);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 2, GetBitfieldInt(new int[] {1}), -2, GetBitfieldInt(new int[] {8}), 2);
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 2, GetBitfieldInt(new int[] {1}), -2, GetBitfieldInt(new int[] {8}), 3);
                CopySplExtendedHeaderAndSplFeatureBlocks(3);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 2, GetBitfieldInt(new int[] {1}), -2, GetBitfieldInt(new int[] {8}), 4);
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 2, GetBitfieldInt(new int[] {1}), -2, GetBitfieldInt(new int[] {8}), 5);
                CopySplExtendedHeaderAndSplFeatureBlocks(5);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 1, 2, GetBitfieldInt(new int[] {1}), -2, GetBitfieldInt(new int[] {8}), 6);
            
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.projectile = 229;
                    currentSplExtendedHeader.range = 30;
                    currentSplExtendedHeader.target = 4;
                    level += 4;
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("SPPR705.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 0, 1, 1, 0, 0, 100, 0, "SPPR705E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 0, 1, 4, 0, 6, 100, 0, "SPPR705E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 0, 1, 4, 0, 12, 100, 0, "SPPR705E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 0, 1, 4, 0, 18, 100, 0, "SPPR705E", 0, 0, 0, 0, 0, 0);
                
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.projectile = 1;
                    currentSplExtendedHeader.target = 5;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR705D.SPL");
            
                //
                
                CreateSplObjects("SPPR705.SPL");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 0, 0, 0, 0, 0, 6, 100, 0, "SPPR705" + new char(), 0, 0, 0, 0, 0, 0);
                index = 0;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.target = 5;
                    currentSplExtendedHeader.projectile = 205;
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR705E.SPL");
            
            }
            
            //  mod      "SYMBOL, FEAR" CONVERSION TO SYMBOL WEAKNESS
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR706."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(78, 2, 7, 4, 4, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(78, 2, 7, 4, 5, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(78, 2, 7, 4, 6, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 7, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 7, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 7, 0, 0, 1, 1, 0, 100, 0, "EFF_P03" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int disease = 4;
                int diseaseFound = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 78)
                    {
                        currentSplFeatBlock.parameter1 = disease;
                        diseaseFound++;
                    }
                    
                    if (diseaseFound == 3)
                    {
                        diseaseFound = 0;
                        disease++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SUNRAY"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR707."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 7, 7, 0, 1, 1, 0, 100, 0, "SPPR609D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 8, 6, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(74, 2, 7, 0, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 8, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 7, FindFirstExactTlkEntry("Blinded"), 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 170, 5, 1, 1, 0, 100, 0, "UNDDEATH", 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 171, 5, 1, 1, 0, 100, 0, "UNDDEATH", 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 163, 5, 1, 1, 0, 100, 0, "UNDDEATH", 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 7, 172, 5, 1, 1, 0, 100, 0, "UNDDEATH", 0, 0, 1, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 0, 0, 1, 3, 100, 0, "SPFDAWN" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 7, 0, 0, 1, 1, 0, 100, 0, "EFF_P56" + new char(), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int disease = 4;
                int diseaseFound = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 78)
                    {
                        currentSplFeatBlock.parameter1 = disease;
                        diseaseFound++;
                    }
                    
                    if (diseaseFound == 3)
                    {
                        diseaseFound = 0;
                        disease++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FINGER OF DEATH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR708."))
            {
                // String name = "Finger of Death";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 328)
                    {
                        currentSplFeatBlock.duration = 60;
                    }
                    
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 6;
                        currentSplFeatBlock.diceThrown = 6;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 55)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                        currentSplFeatBlock.savingThrowType = 4; // poison / death
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            
            //  mod      "CONFUSION" FOR PRIESTS CONVERSION TO CONTROL UNDEAD
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR709."))
            {
                CreateSplObjects("SPWI720.SPL");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            
                ModifySplOpcode(241, "diceSize", 4, 6);
                ModifySplOpcode(241, "diceThrown", 3, 5);
            
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[index];
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                    }
            
                    if (currentSplFeatBlock.diceSides == 4)
                    {
                        currentSplFeatBlock.diceSides = 6;
                    }
            
                    if (currentSplFeatBlock.diceThrown == 3)
                    {
                        currentSplFeatBlock.diceThrown = 5;
                    }
            
                    index++;
                }
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                splHeaderModded.spellType = 2;
                splHeaderModded.exclusionFlags = 0;
                splHeaderModded.spellDescriptionUnId = FindFirstExactTlkEntry(@"Confusion\n\(Enchantment/Charm\)\n\nLevel: 7\nSphere: Chaos"); // reset the desc to confusion (this is handled by the tlk batcher) 
            
                level = 13;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.projectile = 218;
                    currentSplExtendedHeader.target = 4;
                    level += 2;
                }
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = 1;
            
                index = 0;
                int duration = 180;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 18;
                        foundDuration = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "HOLY WORD"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR710."))
            {
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 7, 0, 1, 0, 2, 3, 100, 0, "SPHOLY" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 0, 0, 1, 3, 0, 0, "SPPOWWRD", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(80, 2, 7, 0, 0, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 112, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(74, 2, 7, 0, 0, 0, 1, 48, 100, 0, new string(new char[8]), 14, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 8, 0, 1, 48, 100, 0, new string(new char[8]), 14, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(40, 2, 7, 0, 0, 0, 1, 24, 100, 0, new string(new char[8]), 12, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 41, 0, 1, 24, 100, 0, new string(new char[8]), 12, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(45, 2, 7, 0, 0, 0, 1, 12, 100, 0, new string(new char[8]), 10, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 55, 0, 1, 12, 100, 0, new string(new char[8]), 10, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(55, 2, 7, 0, 2, 1, 1, 0, 100, 0, new string(new char[8]), 5, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 64, 1, 1, 0, 10, 0, new string(new char[8]), 1, 8, 0, 0, 0 ,0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 6;
                    index++;
                }
                
                index = 0;
                int damage = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = damage;
                        damage++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "UNHOLY WORD"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR715."))
            {
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 1, 7, 0, 1, 0, 2, 3, 100, 0, "SPHOLY" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 0, 0, 1, 3, 0, 0, "SPPOWWRD", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(80, 2, 7, 0, 0, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 112, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(128, 2, 7, 0, 0, 0, 1, 48, 100, 0, new string(new char[8]), 14, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 3, 0, 1, 48, 100, 0, new string(new char[8]), 14, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(40, 2, 7, 0, 0, 0, 1, 24, 100, 0, new string(new char[8]), 12, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 41, 0, 1, 24, 100, 0, new string(new char[8]), 12, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(45, 2, 7, 0, 0, 0, 1, 12, 100, 0, new string(new char[8]), 10, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 55, 0, 1, 12, 100, 0, new string(new char[8]), 10, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(55, 2, 7, 0, 2, 1, 1, 0, 100, 0, new string(new char[8]), 5, 0, 0, 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 8, 0, 0, 0 ,0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                index = 0;
                level = 13;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 6;
                    index++;
                }
                
                index = 0;
                int damage = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = damage;
                        damage++;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SYMBOL, STUN"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR716."))
            {
                // String name = "Symbol, Stun";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 15;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 4;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 166)
                    {
                        currentSplFeatBlock.parameter1 = 100;
                    }
            
                    if (foundDuration == 4)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    if (currentSplFeatBlock.savingThrowBonus == -4)
                    {
                        currentSplFeatBlock.savingThrowBonus = -6;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SYMBOL, DEATH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR717."))
            {
                // String name = "Symbol, Death";
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 1, 7, 1, 0, 64, 1, 1, 0, 100, new string(new char[8]), 8, 6, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "EARTHQUAKE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR720."))
            {
                // headerModded = ChangeTlkName(headerModded, name, name + @"\n\(Illusion/Phantasm\)");
                
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(269, 1, 7, 30, 1, 0, 0, 2, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 123, 4, 1, 0, 0, 100, 0, "DVQUAKE" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 146, 4, 1, 0, 0, 100, 0, "DVQUAKE" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 145, 4, 1, 0, 0, 100, 0, "DVQUAKE" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 2, 0, 118, 4, 1, 0, 0, 100, 0, "DVQUAKE" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(39, 2, 7, 0, 0, 0, 0, 18, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), -6, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 7, 0, 0, 1, 0, 0, 100, 0, "EFF_P92" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 0, 0, 0, 0, 100, 0, new string(new char[8]), 6, 6, GetBitfieldInt(new int[] {2}), -6, GetBitfieldInt(new int[] {8}), 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 7, 1, 1, 4, 0, 6, 100, 0, "SPPR720D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 7, 1, 1, 4, 0, 12, 100, 0, "SPPR720E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 7, 1, 1, 4, 0, 18, 100, 0, "SPPR720F", 0, 0, 0, 0, 0, 0);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("sppr720.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(269, 1, 7, 20, 1, 0, 0, 2, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 0, 0, 0, 3, 100, 0, "SPIMPPT"+ new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 2, 7, 0, 0, 1, 0, 0, 100, 0, "EFF_P92"+ new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 0, 1, 0, 0, 100, 0, new string(new char[8]), 4, 6, GetBitfieldInt(new int[] {2}), -4, GetBitfieldInt(new int[] {8}), 0);
                
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                    currentSplExtendedHeader.projectile = 0;
                    currentSplExtendedHeader.range = 1;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr720d.spl");
            
                // 
                
                CreateSplObjects("sppr720.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(269, 1, 7, 20, 1, 0, 0, 2, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 0, 0, 0, 3, 100, 0, "SPIMPPT"+ new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 2, 7, 0, 0, 1, 0, 0, 100, 0, "EFF_P92"+ new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 0, 1, 0, 0, 100, 0, new string(new char[8]), 2, 6, GetBitfieldInt(new int[] {2}), -2, GetBitfieldInt(new int[] {8}), 0);
                
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                    currentSplExtendedHeader.projectile = 0;
                    currentSplExtendedHeader.range = 1;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr720e.spl");
                
                // 
                
                CreateSplObjects("sppr720.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(269, 1, 7, 20, 1, 0, 0, 2, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 0, 0, 0, 3, 100, 0, "SPIMPPT"+ new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(172, 2, 7, 0, 0, 1, 0, 0, 100, 0, "EFF_P92"+ new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 7, 0, 0, 0, 1, 0, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {2}), 0, GetBitfieldInt(new int[] {8}), 0);
                
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
                    currentSplExtendedHeader.projectile = 0;
                    currentSplExtendedHeader.range = 1;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr720f.spl");
            
            }
            
            //  mod      "FAERIE FIRE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR100."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 0)
                    {
                        currentSplFeatBlock.parameter1 = -4;
                    }
            
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SUNSCORCH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr116."))
            {
                index = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.diceThrown = 2;
                        currentSplFeatBlock.diceSides = 6;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 142 || currentSplFeatBlock.opcodeNumber == 74)
                    {
                        currentSplFeatBlock.duration = 30;
                    }
            
                    index++;
                }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "ALICORN LANCE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr216."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 4, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,1);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 6, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,2);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 8, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,3);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 10, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,4);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 12, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,5);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 14, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,6);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 16, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,7);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 18, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,8);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 20, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,9);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 22, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,10);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 24, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,11);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 26, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,12);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 28, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,13);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 30, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0 ,14);
            
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 2, 2, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                index = 0;
                level = 1;
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[index];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                    index++;
                }
                
                index = 0;
                int duration = 60;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
            
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
                    
                    if (currentSplFeatBlock.opcodeNumber == 12)
                    {
                        currentSplFeatBlock.savingThrowType = 0;
                        currentSplFeatBlock.savingThrowBonus = 0;
                        currentSplFeatBlock.stackingId = 0;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 0)
                    {
                        currentSplFeatBlock.parameter1 = -3;
                    }
            
                    if (foundDuration == 8)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "BEAST CLAW" CONVERSION TO "ANIMALISTIC INSTINCTS"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr217."))
            {
                // Console.WriteLine("got here");
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
            
                rgb = new byte[] {0, 86, 0, 86};
                
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 2, FindFirstExactTlkEntry("Combat Bonuses"), 0, 0, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(73, 2, 2, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(250, 2, 2, 20, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(301, 2, 2, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(44, 2, 2, 1, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(278, 2, 2, 2, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 2, 0, 148, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 2, BitConverter.ToInt32(rgb, 0), 0, 0, 20, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                // protection from spell
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 2, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 3, 60, 100, 0, "sppr217" + new char(), 0, 0, 0, 0, 0, 0);
                
                // increase required levels and armor class for each extendedHeader
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.projectile = 162;
                    currentSplExtendedHeader.target = 5;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
            
                // increase armor class for each featureBlock
                int foundDuration = 0;
                int duration = 60;
                int foundAttackDmgBonus = 0;
                int attackDmgBonus = 1;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.duration > 10)
                    {
                        featureBlock.duration = duration;
                        foundDuration++;
                    }
            
                    // if (featureBlock.opcodeNumber == 73)
                    // {
                    //     featureBlock.parameter1 = attackDmgBonus;
                    //     foundAttackDmgBonus++;
                    // }
            
                    if (foundDuration == 4)
                    {
                        duration += 12;
                        foundDuration = 0;
                    }
                    
                    // if (foundAttackDmgBonus == 4)
                    // {
                    //     attackDmgBonus++;
                    //     foundAttackDmgBonus = 0;
                    // }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "SPIKE GROWTH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr325."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                // increase required levels and armor class for each extendedHeader
                level = 1;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 3;
                }
            
                // increase armor class for each featureBlock
                int foundDmg = 0;
                int dmg = 2;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
            
                    if (featureBlock.opcodeNumber == 12)
                    {
                        featureBlock.diceSides = dmg;
                        foundDmg++;
                    }
                    
                    if (foundDmg == 2)
                    {
                        dmg++;
                        foundDmg = 0;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CIRCLE OF BONES"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr324."))
            {
                // CREATE HELPER SPELLS
                
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 0, 1, 0, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {24}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 256, 1, 0, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {24}), 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                ModifySplOpcodeSpecific(12, "diceSides", 6, 8, 1);
                ModifySplOpcodeSpecific(12, "diceSides", 6, 10, 2);
                ModifySplOpcodeSpecific(12, "diceSides", 6, 12, 3);
                ModifySplOpcodeSpecific(12, "diceThrown", 1, 2, 4);
                ModifySplOpcodeSpecific(12, "diceSides", 6, 8, 4);
                ModifySplOpcodeSpecific(12, "diceSides", 6, 10, 5);
                ModifySplOpcodeSpecific(12, "diceSides", 6, 12, 6);
                
                level = 0;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.target = 1;
                    currentSplExtendedHeader.projectile = 449;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 5;
                    if (currentSplExtendedHeader.levelRequired == 0)
                    {
                        currentSplExtendedHeader.levelRequired = 1;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr324d.spl");
            
            }
            
            //  mod      "CLOUDBURST"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr326."))
            {
                RemoveSplOpcode(12, "parameter22", 64); // remove magic damage
                RemoveSplOpcode(12, "parameter22", 4);
                RemoveSplOpcode(318, "targetType", 2);
                
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 4, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 0);
                
                // CopyExtendedHeaderAndFeatureBlocks(0);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 1);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 1);
                //
                // CopyExtendedHeaderAndFeatureBlocks(1);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 2);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 2);
                //
                // CopyExtendedHeaderAndFeatureBlocks(2);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 3);
                //
                // CopyExtendedHeaderAndFeatureBlocks(3);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 4);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 4);
                //
                // CopyExtendedHeaderAndFeatureBlocks(4);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 5);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 5);
                //
                // CopyExtendedHeaderAndFeatureBlocks(5);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 6);
                //
                // CopyExtendedHeaderAndFeatureBlocks(6);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 7);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 7);
                //
                // CopyExtendedHeaderAndFeatureBlocks(7);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 8);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 8);
                //
                // CopyExtendedHeaderAndFeatureBlocks(8);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 9);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 9);
                //
                // CopyExtendedHeaderAndFeatureBlocks(9);
                //
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 64, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 10);
                // AddFeatureBlockToExtendedHeader(12, 2, 3, 0, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 1, 6, GetBitfieldInt(new int[] {1}), 0, GetBitfieldInt(new int[] {8}), 10);
                    
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                // increase required levels and armor class for each extendedHeader
                level = 5;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 3;
                }
            
                // increase armor class for each featureBlock
                int foundDamage = 0;
                int damage = 2;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber == 12 || featureBlock.opcodeNumber == 215)
                    {
                        featureBlock.probability1 = (byte)100;
                    }
            
                    if (featureBlock.opcodeNumber == 12)
                    {
                        featureBlock.diceThrown = damage;
                        foundDamage++;
                    }
                    
                    if (foundDamage == 2)
                    {
                        damage++;
                        foundDamage = 0;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "MOLD TOUCH"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr327."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 3, 0, 0, 0, 1, 3, 100, 0, "MTOUCHH" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 3, 0, 0, 1, 1, 0, 100, 0, "#FF_P107", 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 3, 0, 1, 1, 3, 0, 100, 0, "SPPR327D", 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 3, 0, 0, 0, 1, 20, 100, 0, "SPPR327E", 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(318, 2, 3, 0, 0, 0, 1, 20, 100, 0, "SPPR327E", 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 3, 0, 1, 1, 3, 0, 100, 0, "SPPR327E", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 3, 0, 0, 0, 1, 20, 100, 0, "SPPR327D", 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(318, 2, 3, 0, 0, 0, 1, 20, 100, 0, "SPPR327D", 0, 0, 0, 0, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 3, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 1, 20, 100, 0, "SPPR327" + new char(), 0, 0, 0, 0, 0, 0);
                
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.range = 5;
                currentSplExtendedHeader.projectile = 190;
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // CREATE HELPER SPELLS
                
                CreateSplObjects("sppr327.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 3, FindFirstExactTlkEntry("Diseased"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 3, 0, 7, 0, 2, 20, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 1, 2, 0, 100, 0, new string(new char[8]), 4, 6, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 4, 2, 6, 100, 0, new string(new char[8]), 4, 6, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 4, 2, 12, 100, 0, new string(new char[8]), 4, 6, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 4, 2, 18, 100, 0, new string(new char[8]), 4, 6, 0, 0, 0, 0);
                
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    SplExtendedHeader currentSplExtendedHeader1 = (SplExtendedHeader) splExtHeadersModded[0];
                    currentSplExtendedHeader1.projectile = 1;
                    currentSplExtendedHeader.featureBlockOffset = 0;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr327d.spl");
                
                //
                
                CreateSplObjects("sppr327.spl");
                RemoveAllSplFeatureBlocks();
                RemoveAllSplCastingFeatureBlocks();
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 3, FindFirstExactTlkEntry("Diseased"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 3, 0, 7, 0, 2, 20, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 1, 2, 0, 100, 0, new string(new char[8]), 2, 6, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 4, 2, 6, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 3, 0, 0, 64, 4, 2, 12, 100, 0, new string(new char[8]), 1, 6, 0, 0, 0, 0);
                
                foreach (SplExtendedHeader extendedHeaders in splExtHeadersModded)
                {
                    SplExtendedHeader currentSplExtendedHeader2 = (SplExtendedHeader) splExtHeadersModded[0];
                    currentSplExtendedHeader2.projectile = 1;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr327e.spl");
            
            }
            
            //  mod      "STORM SHELL"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr328."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                // increase required levels and armor class for each extendedHeader
                level = 5;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
            
                // increase armor class for each featureBlock
                int foundDuration = 0;
                int duration = 60;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.duration > 10)
                    {
                        featureBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 7)
                    {
                        duration += 24;
                        foundDuration = 0;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "FAVOR OF ILMATER"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr330."))
            {
                RemoveSplOpcode(343, 0);
                AddSplFeatureBlockToSplExtendedHeader(18, 2, 3, 20, 0, 0, 3, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 3, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 0, 1, 60, 100, 0, "SPPR330" + new char(), 0, 0, 0, 0, 0, 0);
            
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                // increase required levels and armor class for each extendedHeader
                level = 5;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level += 2;
                }
            
                // increase armor class for each featureBlock
                int foundDuration = 0;
                int duration = 60;
                int hp = 30;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.duration > 10)
                    {
                        featureBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (featureBlock.opcodeNumber == 18)
                    {
                        featureBlock.parameter1 = hp;
                        hp += 5;
                    }
            
                    if (foundDuration == 2)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  //  mod      "PRODUCE FIRE"
            // if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr418."))
            //  {
            //      RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
            //      RemoveSplOpcode(12, 0);
            //  
            //      int oldVal = 1;
            //      int newVal = 2;
            //      
            //      AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 0, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 2, 12, GetBitfieldInt(new int[] { 24 }), 0, 0, 0);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(0);
            //      AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 1, 0, 8, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] { 24 }), 0, 0, 1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //      CopySplExtendedHeaderAndSplFeatureBlocks(1);
            //  
            //      // increase required levels and armor class for each extendedHeader
            //      level = 0;
            //      for (int i = 0; i < splExtHeadersModded.Count; i++)
            //      {
            //          currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
            //          currentSplExtendedHeader.levelRequired = level;
            //          splExtHeadersModded[i] = currentSplExtendedHeader;
            //          level += 1;
            //      }
            //      
            //      // increase armor class for each featureBlock
            //      int foundDmg = 0;
            //      int dmg = 1;
            //      foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
            //      {
            //          if (featureBlock.opcodeNumber == 12 && featureBlock.parameter1 > 0)
            //          {
            //              featureBlock.parameter1 = dmg;
            //              foundDmg++;
            //          }
            //          if (foundDmg == 1)
            //          {
            //              dmg++;
            //              foundDmg = 0;
            //          }
            //      }
            //  
            //      FixFeatureBlockOffsets();
            //	   FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            //  }
           
            //  mod      "PRODUCE FIRE" conversion to Protection from Poison
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr418."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                
                rgb = new byte[] {0, 50, 255, 255};
            
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poison"), 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poisoned"), 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 137, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 6, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(101, 2, 0, 0, 25, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(173, 2, 0, 100, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 30, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 0, 0, 2, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 30, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(164, 2, 0, 0, 0, 1, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 0, 0, 0, 1, 3, 1, 100, 0, "EFF_P06" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    splExtHeadersModded[i] = currentSplExtendedHeader;
                    level++;
                }
                
                index = 0;
                int foundDuration = 0;
                int duration = 480;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 4)
                    {
                        duration += 60;
                        foundDuration = 0;
                    }
            
                    index++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // BLOOD RAGE AUXILLIARY SPELL
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPIN117."))
            {
                RemoveSplOpcode(3, 0);
                
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 3, 0, 0, 0, 1, 20, 100, 0, "SPPR421D", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 3, 0, 0, 0, 1, 20, 100, 0, "SPPR421" + new char(), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                splHeaderModded.spellDescriptionUnId = -1;
                splHeaderModded.spellNameUnId = -1;
                splHeaderModded.flags = 0;
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.target = 1;
                    currentSplExtendedHeader.location = 2;
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
            
                index = 0;
                foreach (SplFeatureBlock featureBlockModded in splFeatBlocksModded)
                {
                    SplFeatureBlock currentSplFeatureBlockModded = (SplFeatureBlock)splFeatBlocksModded[index];
                    currentSplFeatureBlockModded.targetType = 2;
                    index++;
                }
                int foundDuration = 0;
                int duration = 30;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber > 10)
                    {
                        featureBlock.duration = duration;
                        foundDuration++;
                    }
                    if (foundDuration == 74)
                    {
                        duration += 6;
                        foundDuration = 0;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/SPPR421D.SPL");
            }
            //  mod      "BLOOD RAGE" MAIN SPELL
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr421."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 3, 0, 1, 1, 3, 0, 100, 0, "SPPR421D", 0, 0, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "CLOUD OF PESTILENCE" 
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr422."))
            {
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.savingThrowType == GetBitfieldInt(new int[] {1}))
                    {
                        featureBlock.savingThrowBonus = -1;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "UNFAILING ENDURANCE" CONVERSION TO REVIVE SKELETON ARCHER
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr423."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR04", 0, 0, 0, 0, 0, 0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR04", 0, 0, 0, 0, 0, 1);
                // CopyExtendedHeaderAndFeatureBlocks(1);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR04", 0, 0, 0, 0, 0, 2);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifySplOpcodeSpecific(177, "SKELAR06", 2);
                CopySplExtendedHeaderAndSplFeatureBlocks(2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR06", 0, 0, 0, 0, 0, 3);
                // CopyExtendedHeaderAndFeatureBlocks(4);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR06", 0, 0, 0, 0, 0, 5);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifySplOpcodeSpecific(177, "SKELAR08", 4);
             
                
                CopySplExtendedHeaderAndSplFeatureBlocks(4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR08", 0, 0, 0, 0, 0, 5);
                // CopyExtendedHeaderAndFeatureBlocks(7);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR08", 0, 0, 0, 0, 0, 8);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifySplOpcodeSpecific(177, "SKELAR10", 6);
                CopySplExtendedHeaderAndSplFeatureBlocks(6);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR10", 0, 0, 0, 0, 0, 7);
                // CopyExtendedHeaderAndFeatureBlocks(10);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 2, 2400, 100, 0, "SKELAR10", 0, 0, 0, 0, 0, 11);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.target = 4;
                    currentSplExtendedHeader.range = 30;
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "STAR METAL CUDGEL" CONVERSION TO Cone of Cold
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr424."))
            {
                CreateSplObjects("SPWI503.SPL");
                
                splHeaderModded.spellType = 2;
                splHeaderModded.flags = 9;
                splHeaderModded.exclusionFlags = 15;
                splHeaderModded.primaryTypeSchool = 6;
                splHeaderModded.spellLevel = 4;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr424.spl");
            }
            
            //  mod      "SMASHING WAVE"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr425."))
            {
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 4, 0, 14, 0, 1, 12, 5, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, 0);
                
                RemoveSplOpcode(139, "duration", 12);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                }
                int foundProbSleep = 0;
                int probSleep = 5;
                int probStun1 = 30;
                int probStun2 = 6;
                int foundProbStun1 = 0;
                int foundProbStun2 = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.probability1 == 5)
                    {
                        featureBlock.probability1 = (byte)probSleep;
                        // Console.WriteLine(probSleep);
                        foundProbSleep++;
                    }
                    if (featureBlock.probability1 == 30)
                    {
                        featureBlock.probability1 = (byte)probStun1;
                        // Console.WriteLine(probStun1);
                        foundProbStun1++;
                    }
                    if (featureBlock.probability2 == 6)
                    {
                        featureBlock.probability2 = (byte)probStun2;
                        // Console.WriteLine(probStun2);
                        foundProbStun2++;
                    }
                    
                    
                    if (foundProbStun1 == 3)
                    {
                        // Console.WriteLine(probStun1);
                        foundProbStun1 = 0;
                        probStun1 += 4;
                    }
                    if (foundProbStun2 == 3)
                    {
                        // Console.WriteLine(probStun2);
                        foundProbStun2 = 0;
                        probStun2 += 2;
                    }
                    if (foundProbSleep == 3)
                    {
                        // Console.WriteLine(probSleep);
                        foundProbSleep = 0;
                        probSleep += 2;
                    }
            
                    if (featureBlock.savingThrowType == GetBitfieldInt(new int[] {1}))
                    {
                        featureBlock.savingThrowBonus = -1;
                    }
            
                    if (featureBlock.duration > 5)
                    {
                        featureBlock.duration = 12;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "THORN SPRAY"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr426."))
            {
                AddSplFeatureBlockToSplExtendedHeader(12, 2, 4, 8, 0, 16, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 7;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
            
                int damage = 8;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.parameter1 == 8)
                    {
                        featureBlock.parameter1 = damage;
                        damage++;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "WALL OF MOONLIGHT"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr427."))
            {
                RemoveSplOpcode(206, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 2, 4, 0, 1, 1, 2, 0, 100, 0, "SPPR427A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 2, 4, 0, 0, 0, 2, 60, 100, 0, "SPPR427" + new char(), 0, 0, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "RIGHTEOUS WRATH OF THE FAITHFUL" (remove fatigue only)
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr518a.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr518b."))
            {
                RemoveSplOpcode(93, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Spike Stones"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr519."))
            {
                ModifySplOpcode(126, "parameter1", 70, 50);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 9;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level += 2;
                }
            
                int damage = 10;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber == 12)
                    {
                        featureBlock.parameter1 = damage;
                        damage++;
                    }
            
                    if (featureBlock.savingThrowType == 1)
                    {
                        featureBlock.savingThrowType = GetBitfieldInt(new int[] {1});
                        featureBlock.savingThrowBonus = -1;
                    }
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Undead Ward"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr521."))
            {
                RemoveSplOpcode(318, 0);
                
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.castingTime = 2;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Animal Rage" Conversion to NATURAL SELECTION
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr522."))
            {
                CreateSplObjects("SPWI605.SPL");
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/sppr522.spl");
            }
            
            //  mod      "Mass Cause Light Wouds" CONVERSION TO CAUSE CROWD WOUNDS
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr523."))
            {
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber == 12)
                    {
                        featureBlock.diceThrown = 3;
                        featureBlock.diceSides = 8;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Whirlwind"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr616."))
            {
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber == 12)
                    {
                        featureBlock.diceThrown = 3;
                        featureBlock.diceSides = 8;
                    }
            
                    if (featureBlock.savingThrowType == GetBitfieldInt(new int[] {1}))
                    {
                        featureBlock.savingThrowBonus = -2;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Spiritual Wrath"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr617."))
            {
                RemoveSplOpcode(324, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 9;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                
                int damage = 10;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (featureBlock.opcodeNumber == 12)
                    {
                        featureBlock.diceThrown = 5;
                        featureBlock.diceSides = 6;
                        featureBlock.parameter1 = damage;
                        damage++;
                    }
            
                    if (featureBlock.savingThrowType == GetBitfieldInt(new int[] {1}))
                    {
                        featureBlock.savingThrowBonus = -3;
                    }
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Symbol, Pain"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr733."))
            {
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(24, 2, 7, 0, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(328, 2, 7, 0, 140, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 1, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 2, 0, 3, 3, 100, 0, "SPFEAREF", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 7, FindFirstExactTlkEntry("Panic"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 36, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 1, 0, 1, 60, 100, 0, "CDHORROR", 0, 0, 0, 1, -4, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 7, 0, 0, 4, 1, 60, 100, 0, "EFF_E05" + new char(), 0, 0, 1, -4, 0, 0);
            
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 7, 0, 0, 1, 1, 0, 100, 0, "EFF_P02" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(328, 2, 7, 0, 2, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 7, FindFirstExactTlkEntry("Wracking Pains"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(215, 2, 7, 0, 0, 0, 1, 3, 100, 0, "CONJUH" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(78, 2, 7, 1, 2, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 169, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0, 1, -4, 0, 0);
                
                // PROTECTION FROM SPELL
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 1, 0, 0, 0, 3, 60, 100, 0, "SPPR733" + new string(new char[1]), 0, 0, 1, -4, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                level = 11;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                
                index = 0;
                int duration = 36;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 18)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
                    
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Symbol, Hopelessness"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr734."))
            {
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                level = 11;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    currentSplExtendedHeader.castingTime = 2;
                    level++;
                }
                
                index = 0;
                int duration = 36;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 6)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Mist of Eldath"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr738."))
            {
                // add health bonus
                AddSplFeatureBlockToSplExtendedHeader(18, 2, 7, 50, 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 7, 0, 22, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                ModifySplOpcode(17, "parameter1", 25, 50);
                
                // add protection from disease
                AddSplFeatureBlockToSplExtendedHeader(101, 2, 7, 0, 78, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 7, 0, 7, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 7, FindFirstExactTlkEntry("Stricken by a foul disease"), 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 7, FindFirstExactTlkEntry("Diseased"), 0, 0, 3, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
            
                // add protection from poison
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poison"), 25, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(267, 2, 0, FindFirstExactTlkEntry("Poisoned"), 25, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 137, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(169, 2, 0, 0, 6, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(101, 2, 0, 0, 25, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(173, 2, 0, 100, 0, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 0, 0, 30, 0, 1, 120, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(141, 2, 0, 0, 2, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                rgb = new byte[] {0, 50, 255, 255};
                AddSplFeatureBlockToSplExtendedHeader(50, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 30, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(164, 2, 0, 0, 0, 1, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(174, 2, 0, 0, 0, 1, 3, 1, 100, 0, "EFF_P06" + new char(), 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
            
                level = 11;
                for (int i = 0; i < splExtHeadersModded.Count; i++)
                {
                    currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                    currentSplExtendedHeader.levelRequired = level;
                    level++;
                }
                
                index = 0;
                int duration = 120;
                int foundDuration = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (foundDuration == 13)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    if (currentSplFeatBlock.savingThrowType == 1)
                    {
                        currentSplFeatBlock.savingThrowBonus = -3;
                        currentSplFeatBlock.savingThrowType = GetBitfieldInt(new int[] {1});
                    }
            
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // *********************************
            // *********************************
            // *********************************
            // ADDITIONAL CHANGES (SUMMONS ETC.)
            // *********************************
            // *********************************
            // *********************************
    
            //  mod      "Monster Summoning 1"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI309."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("MSUMMO1"), 0, 3, 300, 100, 0, "MSUMMO1" + new char(), 2, 2, 0, 0, 0, 0);
               
                index = 0;
                level = 5;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Monster Summoning 2"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI407."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("MSUMMO2"), 0, 3, 300, 100, 0, "MSUMMO2" + new char(), 2, 2, 0, 0, 0, 0);
               
                index = 0;
                level = 7;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Monster Summoning 3"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI504."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("MSUMMO3"), 0, 3, 300, 100, 0, "MSUMMO3" + new char(), 2, 2, 0, 0, 0, 0);
               
                index = 0;
                level = 9;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Monster Summoning 4"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi610."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("MSUMMO4"), 0, 3, 300, 100, 0, "MSUMMO4" + new char(), 2, 1, 0, 0, 0, 0);
               
                index = 0;
                level = 11;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Monster Summoning 5"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi724."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("MSUMMO5"), 0, 3, 300, 100, 0, "MSUMMO5" + new char(), 2, 1, 0, 0, 0, 0);
               
                index = 0;
                level = 13;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Monster Summoning 6"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi820."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("MSUMMO6"), 0, 3, 300, 100, 0, "MSUMMO6" + new char(), 2, 1, 0, 0, 0, 0);
               
                index = 0;
                level = 15;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Monster Summoning 7"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi904."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("MSUMMO7"), 0, 3, 300, 100, 0, "MSUMMO7" + new char(), 1, 2, 0, 0, 0, 0);
               
                index = 0;
                level = 17;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Animal Summoning 1"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR402."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("ASUMMO1"), 0, 3, 300, 100, 0, "ASUMMO1" + new char(), 2, 2, 0, 0, 0, 0);
               
                index = 0;
                level = 5;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Animal Summoning 2"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR501."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("ASUMMO2"), 0, 3, 300, 100, 0, "ASUMMO2" + new char(), 2, 1, 0, 0, 0, 0);
               
                index = 0;
                level = 7;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Animal Summoning 3"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR602."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(331, 1, 3, 0, FindInSmTables("ASUMMO3"), 0, 3, 300, 100, 0, "ASUMMO3" + new char(), 1, 2, 0, 0, 0, 0);
               
                index = 0;
                level = 9;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Conjure Animals"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR604."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 600, 100, 0, "CONJANIM", 0, 0, 0, 0, 0, 0);
               
                index = 0;
                level = 9;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Conjure Lesser Elementals"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI516."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 0, "LESSERFE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 50, 0, "LESSERFE", 0, 0, 0, 0, 0, 0);
               
                index = 0;
                level = 9;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI520."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 0, "LESSERAE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 50, 0, "LESSERAE", 0, 0, 0, 0, 0, 0);
               
                index = 0;
                level = 9;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI521."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 0, "LESSEREE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 50, 0, "LESSEREE", 0, 0, 0, 0, 0, 0);
               
                index = 0;
                level = 9;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi526."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 0, "LESSERWE", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 50, 0, "LESSERWE", 0, 0, 0, 0, 0, 0);
               
                index = 0;
                level = 9;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Conjure Elementals"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI620.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR605."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 31, 0, "FELEM2" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 66, 32, "FELEM1" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 67, "FELEM3" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level++;
                }
                
                int rep = 0;
                int multiplier = 1;
                int counter = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (counter > 2)
                    {
                        if (featureBlock.resource.Contains("FELEM1"))
                        {
                            featureBlock.probability1 -= (byte) (3 * multiplier);
                        }
                        // else if (featureBlock.resource.Contains("FELEM2"))
                        // {
                        //     featureBlock.probability1 -= (byte) (1 * multiplier);
                        // }
                        else if (featureBlock.resource.Contains("FELEM3"))
                        {
                            featureBlock.probability2 -= (byte) (3 * multiplier);
                        }
                    }
                
                    rep++;
                
                    if (rep >= 3 && counter > 4)
                    {
                        rep = 0;
                        multiplier++;
                    }
                
                    counter++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI621."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 31, 0, "AELEM2" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 66, 32, "AELEM1" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 67, "AELEM3" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level++;
                }
                
                int rep = 0;
                int multiplier = 1;
                int counter = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (counter > 2)
                    {
                        if (featureBlock.resource.Contains("AELEM1"))
                        {
                            featureBlock.probability1 -= (byte) (3 * multiplier);
                        }
                        // else if (featureBlock.resource.Contains("AELEM2"))
                        // {
                        //     featureBlock.probability1 -= (byte) (1 * multiplier);
                        // }
                        else if (featureBlock.resource.Contains("AELEM3"))
                        {
                            featureBlock.probability2 -= (byte) (3 * multiplier);
                        }
                    }
                
                    rep++;
                
                    if (rep >= 3 && counter > 4)
                    {
                        rep = 0;
                        multiplier++;
                    }
                
                    counter++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI622.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR702."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 31, 0, "EELEM2" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 66, 32, "EELEM1" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 67, "EELEM3" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level++;
                }
                
                int rep = 0;
                int multiplier = 1;
                int counter = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (counter > 2)
                    {
                        if (featureBlock.resource.Contains("EELEM1"))
                        {
                            featureBlock.probability1 -= (byte) (3 * multiplier);
                        }
                        // else if (featureBlock.resource.Contains("EELEM2"))
                        // {
                        //     featureBlock.probability1 -= (byte) (1 * multiplier);
                        // }
                        else if (featureBlock.resource.Contains("EELEM3"))
                        {
                            featureBlock.probability2 -= (byte) (3 * multiplier);
                        }
                    }
                
                    rep++;
                
                    if (rep >= 3 && counter > 4)
                    {
                        rep = 0;
                        multiplier++;
                    }
                
                    counter++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi633."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 31, 0, "WELEM2" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 66, 32, "WELEM1" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 67, "WELEM3" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                // CopyExtendedHeaderAndFeatureBlocks(0);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level++;
                }
                
                int rep = 0;
                int multiplier = 1;
                int counter = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    if (counter > 2)
                    {
                        if (featureBlock.resource.Contains("WELEM1"))
                        {
                            featureBlock.probability1 -= (byte) (3 * multiplier);
                        }
                        // else if (featureBlock.resource.Contains("WELEM2"))
                        // {
                        //     featureBlock.probability1 -= (byte) (1 * multiplier);
                        // }
                        else if (featureBlock.resource.Contains("WELEM3"))
                        {
                            featureBlock.probability2 -= (byte) (3 * multiplier);
                        }
                    }
                
                    rep++;
                
                    if (rep >= 3 && counter > 4)
                    {
                        rep = 0;
                        multiplier++;
                    }
                
                    counter++;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // SPIDER SPAWN
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI423."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SPIDER1A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SPIDER1A", 0, 0, 0, 0, 0, 0);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SPIDER1A", 0, 0, 0, 0, 0, 0);
            
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SPIDER1A", 0, 0, 0, 0, 0, 1);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SPIDER1A", 0, 0, 0, 0, 0, 1);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 2);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SPIDER1A", 0, 0, 0, 0, 0, 2);
            
                // CopyExtendedHeaderOnly(0);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 3);
            
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER3A", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER3B", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER3C", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 3);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 3);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 4);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 4);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 4);
            
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER3A", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER3B", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER3C", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER3A", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER3B", 0, 0, 0, 0, 0, 4);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER3C", 0, 0, 0, 0, 0, 4);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER2A", 0, 0, 0, 0, 0, 5);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER2B", 0, 0, 0, 0, 0, 5);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER2C", 0, 0, 0, 0, 0, 5);
                //
                // CopyExtendedHeaderOnly(0);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER3A", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER3B", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER3C", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER3A", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER3B", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER3C", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 33, 0, "SPIDER3A", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 66, 34, "SPIDER3B", 0, 0, 0, 0, 0, 6);
                // AddFeatureBlockToExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 67, "SPIDER3C", 0, 0, 0, 0, 0, 6);
                
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level += 2;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // CARRION CRAWLERS CONVERSION TO CONJURE OTYUGH
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI623."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 600, 100, 0, "OTYUGH01", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderOnly(0);
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 600, 100, 0, "OTYUGH02", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderOnly(0);
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 600, 100, 0, "OTYUGH03", 0, 0, 0, 0, 0, 0);
            
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level += 3;
                }
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // INVISIBLE STALKER CONVERSION TO SUMMON INVISIBLE FIGHTER
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI601."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 33, 0, "ISTALKER", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 66, 34, "ASHIRUKU", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 67, "HELMHORR", 0, 0, 0, 0, 0, 0);
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // SUMMON NISHRUU MOD
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI624."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 600, 100, 0, "NISHRUU" + new char(), 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // // ITEM MOD
                // String itmFileName = "NISHRUU.ITM";
                // byte[] itm = FileOperations.ReadFile(itmInputPath + "/" + itmFileName);
                // String addStr = "Magic drained";
                // AddTlkEntry(addStr);
                // Buffer.BlockCopy(BitConverter.GetBytes(FindFirstExactTlkEntry(addStr)), 0, itm, 510, 4);
                // FixFeatureBlockOffsets();
				// FileOperations.WriteFile(itmOutputPath + "/" + itmFileName, itm);
            }
            
            // WYVERN CALL
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI619."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 900, 100, 0, "WYVERNLE", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                ModifySplOpcodeSpecific(177, "WYVERNGR", 1);
                
                index = 0;
                level = 11;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level += 3;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // SUMMON HAKEASHAR MOD
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI719."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 600, 100, 0, "HAKESHAR", 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
                
                // // ITEM MOD
                // String itmFileName = "HAKESHAR.ITM";
                // byte[] itm = FileOperations.ReadFile(itmInputPath + "/" + itmFileName);
                // String addStr = "Magic drained";
                // AddTlkEntry(addStr);
                // Buffer.BlockCopy(BitConverter.GetBytes(FindFirstExactTlkEntry(addStr)), 0, itm, 510, 4);
                // FixFeatureBlockOffsets();
				// FileOperations.WriteFile(itmOutputPath + "/" + itmFileName, itm);
            }
            
            // SUMMON DJINNI CONVERSION TO SUMMON DEMON KNIGHT
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI716."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "DEMONKNI", 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // STALKER CONVERSION TO SUMMON DEMON KNIGHT
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr739."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "DEMONKNI", 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // SUMMON EFREETI MOD
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI717."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 1200, 100, 0, "EFREETI" + new char(), 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // CREATE BONEGUARD MOD
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi935."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "BONEGUAR", 0, 0, 0, 0, 0, 0);
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // SHADOW MONSTERS CONVERSION TO JELLY CONJURING
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi432."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 49, 0, "SLIME2A" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 50, "SLIME2B" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 49, 0, "SLIME2A" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 50, "SLIME2B" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderOnly(0);
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SLIME3" + new string(new char[2]), 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SLIME3" + new string(new char[2]), 0, 0, 0, 0, 0, 1);
                
                CopySplExtendedHeaderOnly(1);
                                      
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SLIME4" + new string(new char[2]), 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "SLIME4" + new string(new char[2]), 0, 0, 0, 0, 0, 2);
                
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level += 3;
                }
                
                splHeaderModded.castingGraphics = 14;
                splHeaderModded.primaryTypeSchool = 6;
                splHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {8});
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            // DEMI-SHADOW MONSTERS CONVERSION TO MIND FOG
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "spwi527."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 5, 0, 86, 0, 1, 24, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(19, 2, 5, 3, 0, 0, 1, 24, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(49, 2, 5, 3, 0, 0, 1, 24, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(21, 2, 5, 25, 2, 0, 1, 24, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(22, 2, 5, 75, 2, 0, 1, 24, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(262, 2, 5, 4, 1, 0, 1, 24, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(142, 2, 5, 8, 0, 0, 1, 24, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
            
                String intDrained = "Intelligence drained";
                String wisDrained = "Wisdom drained";
                EditExistingTlkEntry("Intelligence drained by Mind Flayer", "Intelligence drained by Mind Flayer", intDrained, true, false);
                EditExistingTlkEntry("Intelligence drained by mind flayer", "Intelligence drained by mind flayer", intDrained, true, false);
                AddTlkEntry(wisDrained);
                
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 5, FindFirstExactTlkEntry(intDrained), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(139, 2, 5, FindFirstExactTlkEntry(wisDrained), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {0}), 0, 0, 0);
            
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                CopySplExtendedHeaderAndSplFeatureBlocks(0);
                
                index = 0;
                level = 9;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    extendedHeader.projectile = 332;
                    extendedHeader.range = 30;
                    extendedHeader.target = 4;
                    level += 4;
                }
                
                splHeaderModded.castingGraphics = 13;
                splHeaderModded.primaryTypeSchool = 5;
                splHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {12});
                
                int duration = 24;
                int foundDuration = 0;
                int intWis = -3;
                int foundIntWis = 0;
                // int luck = 75;
                // int foundLuck = 0;
                // int lore = 25;
                // int foundLore = 0;
                foreach (SplFeatureBlock featureBlock in splFeatBlocksModded)
                {
                    currentSplFeatBlock = (SplFeatureBlock)splFeatBlocksModded[index];
                    if (currentSplFeatBlock.duration > 10)
                    {
                        currentSplFeatBlock.duration = duration;
                        foundDuration++;
                    }
            
                    if (currentSplFeatBlock.opcodeNumber == 19 || currentSplFeatBlock.opcodeNumber == 49)
                    {
                        currentSplFeatBlock.parameter1 = intWis;
                        foundIntWis++;
                    }
                    
                    // if (currentSplFeatureBlock.opcodeNumber == 22)
                    // {
                    //     currentSplFeatureBlock.parameter1 = luck;
                    //     foundLuck++;
                    // }
            
                    // if (currentFeatureBlock.opcodeNumber == 21)
                    // {
                    //     currentFeatureBlock.parameter1 = lore;
                    //     foundLore++;
                    // }
            
                    if (foundDuration == 7)
                    {
                        foundDuration = 0;
                        duration += 6;
                    }
            
                    if (foundIntWis == 2)
                    {
                        foundIntWis = 0;
                        intWis--;
                    }
            
                    // if (foundLuck == 1)
                    // {
                    //     foundLuck = 0;
                    //     luck--;
                    // }
            
                    // if (foundLore == 1)
                    // {
                    //     foundLore = 0;
                    //     lore -= 5;
                    // }
                    index++;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Cacofiend"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI707."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "TANARRI" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 0, 201, 111, 0, 0, 0, 100, 0, "SPWI707" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(326, 1, 0, 0, 38, 0, 0, 0, 10, 0, "DW#EVIL" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 0, 0, 38, 0, 0, 0, 100, 0, "SPWI707" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 0, 1, 0, 0, 0, 10, 0, "DW#DAMN" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 0, -1, 0, 4, 0, 6, 10, 0, "DW#DAMN" + new char(), 0, 0, 0, 0, 0, 0);
            
                index = 0;
                level = 13;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Summon Fiend"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI807."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "GLABREZU", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 0, 201, 111, 0, 0, 0, 100, 0, "SPWI807" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(326, 1, 0, 0, 38, 0, 0, 0, 10, 0, "DW#EVIL" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 0, 0, 38, 0, 0, 0, 100, 0, "SPWI807" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 0, 1, 0, 0, 0, 10, 0, "DW#DAMN" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 0, -1, 0, 4, 0, 6, 10, 0, "DW#DAMN" + new char(), 0, 0, 0, 0, 0, 0);
            
                index = 0;
                level = 15;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Gate"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPWI905.") || ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR703."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
               
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 300, 100, 0, "PITFIEND", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 0, 202, 111, 0, 0, 0, 100, 0, "SPWI905" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(326, 1, 0, 0, 38, 0, 0, 0, 25, 0, "DW#EVIL" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(318, 1, 0, 0, 38, 0, 0, 0, 100, 0, "SPWI905" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(146, 1, 0, 0, 1, 0, 0, 0, 25, 0, "DW#DAMN" + new char(), 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(206, 1, 0, -1, 0, 4, 0, 6, 25, 0, "DW#DAMN" + new char(), 0, 0, 0, 0, 0, 0);
            
                index = 0;
                //level = 17;
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.levelRequired = level;
            
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Giant Insect"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "sppr429."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
            
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "BEETLE1A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "BEETLE1B", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 50, 0, "BEETLE1A", 0, 0, 0, 0, 0, 0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 51, "BEETLE1B", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderOnly(0);
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "BEETLE1A", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "BEETLE1B", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 50, 0, "BEETLE2A", 0, 0, 0, 0, 0, 1);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 51, "BEETLE2B", 0, 0, 0, 0, 0, 1);
                                
                CopySplExtendedHeaderOnly(0);
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "BEETLE2A", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "BEETLE2B", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 50, 0, "BEETLE2A", 0, 0, 0, 0, 0, 2);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 51, "BEETLE2B", 0, 0, 0, 0, 0, 2);
                
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level += 2;
                }
                
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
            
            //  mod      "Call Woodland Beings"
            if (ContainsCaseInsensitive(currentSpellFileInfo.Name, "SPPR410."))
            {
                RemoveSplExtendedHeadersAndSplFeatureBlocks(1);
                RemoveAllSplFeatureBlocks();
                
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "WOODLAN1", 0, 0, 0, 0, 0, 0);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "WOODLAN2", 0, 0, 0, 0, 0, 1);
                
                CopySplExtendedHeaderOnly(0);
                AddSplFeatureBlockToSplExtendedHeader(177, 1, 0, 0, 2, 0, 3, 2400, 100, 0, "WOODLAN3", 0, 0, 0, 0, 0, 2);
            
                index = 0;
                level = 7;
                foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
                {
                    extendedHeader.levelRequired = level;
                    level += 4;
                }
            
                FixSplOffsets();
                FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + currentSpellFileInfo);
            }
        }

        internal static void FixEffectDurations()
        {
            DirectoryInfo splDir = new DirectoryInfo(splOutputPath);
            FileInfo[] splFiles = splDir.GetFiles("*.spl");
            foreach (FileInfo splFile in splFiles)
            {
                CreateSplObjects(splOutputPath,  splFile.Name);
                foreach (SplFeatureBlock featBlock in splFeatBlocksModded)
                {
                    if (IsOpcodeMatch(featBlock) == 1)
                    {
                        FixDuration(featBlock, 6);
                    }
                }
                // if (splExtHeadersModded.Count != 0)
                // {
                //     SplExtendedHeader x = (SplExtendedHeader) splExtHeadersModded[0];
                //     // Console.WriteLine(splFile + " " + splHeaderModded.extendedHeaderCount + " " + x.projectile);
                //     Console.WriteLine(splFile + " " + splHeaderModded.spellBookIcon);
                // }
                FixSplOffsets();
				FileOperations.WriteFile(splHeaderModded, splExtHeadersModded, splCastFeatBlocksModded, splFeatBlocksModded, splOutputPath + "/" + splFile.Name);
            }
        }
        internal static int IsOpcodeMatch(SplFeatureBlock featBlock)
        {
            if (
                featBlock.opcodeNumber == 9 || 
                featBlock.opcodeNumber == 7 || 
                featBlock.opcodeNumber == 50 || 
                featBlock.opcodeNumber == 51 || 
                featBlock.opcodeNumber == 52 || 
                featBlock.opcodeNumber == 8
            )
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        internal static void FixDuration(SplFeatureBlock featBlock, int dur)
        {
            featBlock.duration = dur;
        }
        
        internal static void FixSplOffsets()
        {
            splHeaderModded.extendedHeaderCount = (short)splExtHeadersModded.Count;
            splHeaderModded.extendedHeaderOffset = SplHeader.size;
            splHeaderModded.castingFeatureBlockCount = (short)splCastFeatBlocksModded.Count;
            splHeaderModded.castingFeatureBlockOffset = (short) (SplHeader.size + SplExtendedHeader.size * splExtHeadersModded.Count);
            
            int featBlockOffset = splCastFeatBlocksModded.Count;
            for (int i = 0; i < splExtHeadersModded.Count; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                currentSplExtendedHeader.featureBlockOffset = (short)featBlockOffset;
                featBlockOffset += currentSplExtendedHeader.featureBlockCount;
                splExtHeadersModded[i] = currentSplExtendedHeader;
            }
        }
        
        internal static void CopySplExtendedHeaderAndSplFeatureBlocks(int extHeaderIndex)
        {
            SplExtendedHeader firstSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
            splExtHeadersModded[0] = firstSplExtendedHeader;
            //
            SplExtendedHeader oldSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extHeaderIndex];
            // we need to create a fresh extended header (NOT A COPY!!!) since arraylists only contain references, not complete copies of objects
            SplExtendedHeader newSplExtendedHeader = new SplExtendedHeader( 
                    oldSplExtendedHeader.spellForm, 
                    oldSplExtendedHeader.friendlyAbility, 
                    oldSplExtendedHeader.location, 
                    oldSplExtendedHeader.memorizedIcon, 
                    oldSplExtendedHeader.target, 
                    oldSplExtendedHeader.targetNumber, 
                    oldSplExtendedHeader.range, 
                    oldSplExtendedHeader.levelRequired, 
                    oldSplExtendedHeader.castingTime, 
                    oldSplExtendedHeader.timesPerDay, 
                    oldSplExtendedHeader.diceSides, 
                    oldSplExtendedHeader.diceThrown, 
                    oldSplExtendedHeader.enchanted, 
                    oldSplExtendedHeader.damageType, 
                    oldSplExtendedHeader.featureBlockCount, 
                    oldSplExtendedHeader.featureBlockOffset, 
                    oldSplExtendedHeader.charges, 
                    oldSplExtendedHeader.chargeDepletionBehaviour, 
                    oldSplExtendedHeader.projectile
                );
            
            // get feature block offset for the old extended header
            int oldExtendedHeaderFeatureBlockOffset = 0;
            for (int i = 0; i < extHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                oldExtendedHeaderFeatureBlockOffset += currentSplExtendedHeader.featureBlockCount;
            }

            // copy all featureblocks of the old extendedheader as a new instance to to feature blocks modded array list
            for (int i = 0; i < oldSplExtendedHeader.featureBlockCount; i++)
            {
                // we need to create a fresh feature block (NOT A COPY!!!) since arraylists only contain references, not complete copies of objects
                SplFeatureBlock oldSplFeatureBlock = (SplFeatureBlock)splFeatBlocksModded[i + oldExtendedHeaderFeatureBlockOffset];
                SplFeatureBlock newSplFeatureBlock = null;
                if (oldSplFeatureBlock.opcodeNumber == 12 || oldSplFeatureBlock.opcodeNumber == 233)
                {
                    newSplFeatureBlock = new SplFeatureBlock(
                        oldSplFeatureBlock.opcodeNumber,
                        oldSplFeatureBlock.targetType,
                        oldSplFeatureBlock.power,
                        oldSplFeatureBlock.parameter1,
                        oldSplFeatureBlock.parameter21,
                        oldSplFeatureBlock.parameter22,
                        oldSplFeatureBlock.timingMode,
                        oldSplFeatureBlock.resistance,
                        oldSplFeatureBlock.duration,
                        oldSplFeatureBlock.probability1,
                        oldSplFeatureBlock.probability2,
                        oldSplFeatureBlock.resource,
                        oldSplFeatureBlock.diceThrown,
                        oldSplFeatureBlock.diceSides,
                        oldSplFeatureBlock.savingThrowType,
                        oldSplFeatureBlock.savingThrowBonus,
                        oldSplFeatureBlock.stackingId
                    );
                }
                else if (oldSplFeatureBlock.opcodeNumber == 50)
                {
                    newSplFeatureBlock = new SplFeatureBlock(
                        oldSplFeatureBlock.opcodeNumber,
                        oldSplFeatureBlock.targetType,
                        oldSplFeatureBlock.power,
                        oldSplFeatureBlock.parameter1,
                        oldSplFeatureBlock.parameter23,
                        oldSplFeatureBlock.parameter24,
                        oldSplFeatureBlock.parameter25,
                        oldSplFeatureBlock.parameter26,
                        oldSplFeatureBlock.timingMode,
                        oldSplFeatureBlock.resistance,
                        oldSplFeatureBlock.duration,
                        oldSplFeatureBlock.probability1,
                        oldSplFeatureBlock.probability2,
                        oldSplFeatureBlock.resource,
                        oldSplFeatureBlock.diceThrown,
                        oldSplFeatureBlock.diceSides,
                        oldSplFeatureBlock.savingThrowType,
                        oldSplFeatureBlock.savingThrowBonus,
                        oldSplFeatureBlock.stackingId
                    );
                    
                }
                else
                {
                    newSplFeatureBlock = new SplFeatureBlock(
                        oldSplFeatureBlock.opcodeNumber,
                        oldSplFeatureBlock.targetType,
                        oldSplFeatureBlock.power,
                        oldSplFeatureBlock.parameter1,
                        oldSplFeatureBlock.parameter2,
                        oldSplFeatureBlock.timingMode,
                        oldSplFeatureBlock.resistance,
                        oldSplFeatureBlock.duration,
                        oldSplFeatureBlock.probability1,
                        oldSplFeatureBlock.probability2,
                        oldSplFeatureBlock.resource,
                        oldSplFeatureBlock.diceThrown,
                        oldSplFeatureBlock.diceSides,
                        oldSplFeatureBlock.savingThrowType,
                        oldSplFeatureBlock.savingThrowBonus,
                        oldSplFeatureBlock.stackingId
                    );
                }

                splFeatBlocksModded.Add(newSplFeatureBlock);
            }
            
            splExtHeadersModded.Add(newSplExtendedHeader);
            // Console.WriteLine(headerModded.featureBlockTableOffset);
            splHeaderModded.featureBlockTableOffset += SplExtendedHeader.size; // increase effects offset by byte size of newly added extended header 
            splHeaderModded.extendedHeaderCount += 1;
        }
        
        internal static void CopySplExtendedHeaderOnly(int extHeaderIndex)
        {
            SplExtendedHeader oldSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extHeaderIndex];
            // we need to create a fresh extended header (NOT A COPY!!!) since arraylists only contain references, not complete copies of objects
            SplExtendedHeader newSplExtendedHeader = new SplExtendedHeader( 
                    oldSplExtendedHeader.spellForm, 
                    oldSplExtendedHeader.friendlyAbility, 
                    oldSplExtendedHeader.location, 
                    oldSplExtendedHeader.memorizedIcon, 
                    oldSplExtendedHeader.target, 
                    oldSplExtendedHeader.targetNumber, 
                    oldSplExtendedHeader.range, 
                    oldSplExtendedHeader.levelRequired, 
                    oldSplExtendedHeader.castingTime, 
                    oldSplExtendedHeader.timesPerDay, 
                    oldSplExtendedHeader.diceSides, 
                    oldSplExtendedHeader.diceThrown, 
                    oldSplExtendedHeader.enchanted, 
                    oldSplExtendedHeader.damageType, 
                    0, // Copy extended header only, no feature blocks yet!!
                    oldSplExtendedHeader.featureBlockOffset, 
                    oldSplExtendedHeader.charges, 
                    oldSplExtendedHeader.chargeDepletionBehaviour, 
                    oldSplExtendedHeader.projectile
                );
            splExtHeadersModded.Add(newSplExtendedHeader);
            // Console.WriteLine(headerModded.featureBlockTableOffset);
            splHeaderModded.featureBlockTableOffset += SplExtendedHeader.size; // increase effects offset by byte size of newly added extended header 
            splHeaderModded.extendedHeaderCount += 1;
        }

        internal static void AddSplFeatureBlockToSplExtendedHeader(
            short opcodeNumber, 
            byte targetType, 
            byte power, 
            int parameter1, 
            int parameter2, 
            byte timingMode, 
            byte resistance, 
            int duration, 
            byte probability1, 
            byte probability2, 
            String resource, 
            int diceThrown, 
            int diceSides, 
            int savingThrowType, 
            int savingThrowBonus, 
            int stackingId,
            int extendedHeaderIndex
            )
        {
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount += 1; // increase featureBlock count for the modded extended heaeder 

            // get offset to insert the new featureblocks at the correct position in the featureblock array
            int fbOffset = 0;
            for (int i = 0; i < extendedHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += currentSplExtendedHeader.featureBlockCount;
            }
            
            // add the offset of the last extended header we want to add the featureblock to, if the new effect shall be added AFTER the already existing effects
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            fbOffset += currentSplExtendedHeader.featureBlockCount - 1;

            // headerModded.featureBlockTableOffset = extendedHeadersModded.Count * 40; // set the offset to the correct amount
            SplFeatureBlock newSplFeatureBlock = new SplFeatureBlock(opcodeNumber, targetType, power, parameter1, parameter2, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSides, savingThrowType, savingThrowBonus, stackingId);
            // splFeatBlocksModded.Add(newSplFeatureBlock);
            splFeatBlocksModded.Insert(fbOffset, newSplFeatureBlock);
        }
        
        internal static void AddSplFeatureBlockToSplExtendedHeader(
            short opcodeNumber, 
            byte targetType, 
            byte power, 
            int parameter1, 
            short parameter21, 
            short parameter22, 
            byte timingMode, 
            byte resistance, 
            int duration, 
            byte probability1, 
            byte probability2, 
            String resource, 
            int diceThrown, 
            int diceSides, 
            int savingThrowType, 
            int savingThrowBonus, 
            int stackingId,
            int extendedHeaderIndex
        )
        {
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount += 1; // increase featureBlock count for the modded extended heaeder 

            // get offset to insert the new featureblocks at the correct position in the featureblock array
            int fbOffset = 0;
            for (int i = 0; i < extendedHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += currentSplExtendedHeader.featureBlockCount;
            }
            
            // add the offset of the last extended header we want to add the featureblock to, if the new effect shall be added AFTER the already existing effects
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            fbOffset += currentSplExtendedHeader.featureBlockCount - 1;

            // headerModded.featureBlockTableOffset = extendedHeadersModded.Count * 40; // set the offset to the correct amount
            SplFeatureBlock newSplFeatureBlock = new SplFeatureBlock(opcodeNumber, targetType, power, parameter1, parameter21, parameter22, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSides, savingThrowType, savingThrowBonus, stackingId);
            // featureBlocksModded.Add(newFeatureBlock);
            splFeatBlocksModded.Insert(fbOffset, newSplFeatureBlock);
        }
        
        internal static void AddSplFeatureBlockToSplExtendedHeader(
            short opcodeNumber, 
            byte targetType, 
            byte power, 
            int parameter1, 
            byte parameter23, 
            byte parameter24, 
            byte parameter25, 
            byte parameter26, 
            byte timingMode, 
            byte resistance, 
            int duration, 
            byte probability1, 
            byte probability2, 
            String resource, 
            int diceThrown, 
            int diceSides, 
            int savingThrowType, 
            int savingThrowBonus, 
            int stackingId,
            int extendedHeaderIndex
        )
        {
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount += 1; // increase featureBlock count for the modded extended heaeder 

            // get offset to insert the new featureblocks at the correct position in the featureblock array
            int fbOffset = 0;
            for (int i = 0; i < extendedHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += currentSplExtendedHeader.featureBlockCount;
            }
            
            // add the offset of the last extended header we want to add the featureblock to, if the new effect shall be added AFTER the already existing effects
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            fbOffset += currentSplExtendedHeader.featureBlockCount - 1;

            // headerModded.featureBlockTableOffset = extendedHeadersModded.Count * 40; // set the offset to the correct amount
            SplFeatureBlock newSplFeatureBlock = new SplFeatureBlock(opcodeNumber, targetType, power, parameter1, parameter23, parameter24, parameter25, parameter26, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSides, savingThrowType, savingThrowBonus, stackingId);
            // featureBlocksModded.Add(newFeatureBlock);
            splFeatBlocksModded.Insert(fbOffset, newSplFeatureBlock);
        }

        internal static void ModifyAllSplDurations(int thresholdDuration, int newDuration, int[]excludeOpcodes, int extHeaderStart)
        {
            int featureBlockStart = 0;
            for (int i = 0; i < extHeaderStart; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                featureBlockStart += currentSplExtendedHeader.featureBlockCount;
            }

            // Console.WriteLine(extHeaderStart);
            // Console.WriteLine(featureBlockStart + " : " + featureBlocksModded.Count);
            
            for (int j = featureBlockStart; j <= splFeatBlocksModded.Count-1; j++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[j];
                if (currentSplFeatBlock.duration >= thresholdDuration && Array.IndexOf(excludeOpcodes, currentSplFeatBlock.opcodeNumber) == -1)
                {
                    currentSplFeatBlock.duration = newDuration;
                }
            }
        }
        
        internal static void ModifySplOpcode(int opcodeNum, String propName, int oldVal, int newVal)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
                    {
                        if (currentSplFeatBlock.targetType == oldVal)
                        {
                            currentSplFeatBlock.targetType = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[1]))
                    {
                        if (currentSplFeatBlock.power == oldVal)
                        {
                            currentSplFeatBlock.power = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[2]))
                    {
                        if (currentSplFeatBlock.parameter1 == oldVal)
                        {
                            currentSplFeatBlock.parameter1 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[3]))
                    {
                        if (currentSplFeatBlock.parameter2 == oldVal)
                        {
                            currentSplFeatBlock.parameter2 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[4]))
                    {
                        if (currentSplFeatBlock.parameter21 == oldVal)
                        {
                            currentSplFeatBlock.parameter21 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[5]))
                    {
                        if (currentSplFeatBlock.parameter22 == oldVal)
                        {
                            currentSplFeatBlock.parameter22 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[6]))
                    {
                        if (currentSplFeatBlock.timingMode == oldVal)
                        {
                            currentSplFeatBlock.timingMode = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[7]))
                    {
                        if (currentSplFeatBlock.resistance == oldVal)
                        {
                            currentSplFeatBlock.resistance = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[8]))
                    {
                        if (currentSplFeatBlock.duration == oldVal)
                        {
                            currentSplFeatBlock.duration = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[9]))
                    {
                        if (currentSplFeatBlock.probability1 == oldVal)
                        {
                            currentSplFeatBlock.probability1 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[10]))
                    {
                        if (currentSplFeatBlock.probability2 == oldVal)
                        {
                            currentSplFeatBlock.probability2 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[11]))
                    {
                        if (currentSplFeatBlock.diceThrown == oldVal)
                        {
                            currentSplFeatBlock.diceThrown = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[12]))
                    {
                        if (currentSplFeatBlock.diceSides == oldVal)
                        {
                            currentSplFeatBlock.diceSides = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[13]))
                    {
                        if (currentSplFeatBlock.savingThrowType == oldVal)
                        {
                            currentSplFeatBlock.savingThrowType = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[14]))
                    {
                        if (currentSplFeatBlock.savingThrowBonus == oldVal)
                        {
                            currentSplFeatBlock.savingThrowBonus = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[15]))
                    {
                        if (currentSplFeatBlock.stackingId == oldVal)
                        {
                            currentSplFeatBlock.stackingId = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[16]))
                    {
                        if (currentSplFeatBlock.parameter23 == oldVal)
                        {
                            currentSplFeatBlock.parameter23 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[17]))
                    {
                        if (currentSplFeatBlock.parameter24 == oldVal)
                        {
                            currentSplFeatBlock.parameter24 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[18]))
                    {
                        if (currentSplFeatBlock.parameter25 == oldVal)
                        {
                            currentSplFeatBlock.parameter25 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[19]))
                    {
                        if (currentSplFeatBlock.parameter26 == oldVal)
                        {
                            currentSplFeatBlock.parameter26 = (byte)newVal;
                        }
                    }
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String propName, int oldVal, int newVal, int extHeaderIndex)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
                    {
                        if (currentSplFeatBlock.targetType == oldVal)
                        {
                            currentSplFeatBlock.targetType = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[1]))
                    {
                        if (currentSplFeatBlock.power == oldVal)
                        {
                            currentSplFeatBlock.power = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[2]))
                    {
                        if (currentSplFeatBlock.parameter1 == oldVal)
                        {
                            currentSplFeatBlock.parameter1 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[3]))
                    {
                        if (currentSplFeatBlock.parameter2 == oldVal)
                        {
                            currentSplFeatBlock.parameter2 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[4]))
                    {
                        if (currentSplFeatBlock.parameter21 == oldVal)
                        {
                            currentSplFeatBlock.parameter21 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[5]))
                    {
                        if (currentSplFeatBlock.parameter22 == oldVal)
                        {
                            currentSplFeatBlock.parameter22 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[6]))
                    {
                        if (currentSplFeatBlock.timingMode == oldVal)
                        {
                            currentSplFeatBlock.timingMode = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[7]))
                    {
                        if (currentSplFeatBlock.resistance == oldVal)
                        {
                            currentSplFeatBlock.resistance = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[8]))
                    {
                        if (currentSplFeatBlock.duration == oldVal)
                        {
                            currentSplFeatBlock.duration = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[9]))
                    {
                        if (currentSplFeatBlock.probability1 == oldVal)
                        {
                            currentSplFeatBlock.probability1 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[10]))
                    {
                        if (currentSplFeatBlock.probability2 == oldVal)
                        {
                            currentSplFeatBlock.probability2 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[11]))
                    {
                        if (currentSplFeatBlock.diceThrown == oldVal)
                        {
                            currentSplFeatBlock.diceThrown = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[12]))
                    {
                        if (currentSplFeatBlock.diceSides == oldVal)
                        {
                            currentSplFeatBlock.diceSides = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[13]))
                    {
                        if (currentSplFeatBlock.savingThrowType == oldVal)
                        {
                            currentSplFeatBlock.savingThrowType = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[14]))
                    {
                        if (currentSplFeatBlock.savingThrowBonus == oldVal)
                        {
                            currentSplFeatBlock.savingThrowBonus = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[15]))
                    {
                        if (currentSplFeatBlock.stackingId == oldVal)
                        {
                            currentSplFeatBlock.stackingId = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[16]))
                    {
                        if (currentSplFeatBlock.parameter23 == oldVal)
                        {
                            currentSplFeatBlock.parameter23 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[17]))
                    {
                        if (currentSplFeatBlock.parameter24 == oldVal)
                        {
                            currentSplFeatBlock.parameter24 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[18]))
                    {
                        if (currentSplFeatBlock.parameter25 == oldVal)
                        {
                            currentSplFeatBlock.parameter25 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[19]))
                    {
                        if (currentSplFeatBlock.parameter26 == oldVal)
                        {
                            currentSplFeatBlock.parameter26 = (byte)newVal;
                        }
                    }
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String propName, int newVal, int extHeaderIndex)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
					{
						currentSplFeatBlock.targetType = (byte)newVal;
					}
					if (propName.Equals(propNameList[1]))
					{
						currentSplFeatBlock.power = (byte)newVal;
					}
					if (propName.Equals(propNameList[2]))
					{
						currentSplFeatBlock.parameter1 = newVal;
					}
					if (propName.Equals(propNameList[3]))
					{
						currentSplFeatBlock.parameter2 = newVal;
					}
					if (propName.Equals(propNameList[4]))
					{
						currentSplFeatBlock.parameter21 = (short)newVal;
					}
					if (propName.Equals(propNameList[5]))
					{
						currentSplFeatBlock.parameter22 = (short)newVal;
					}
					if (propName.Equals(propNameList[6]))
					{
						currentSplFeatBlock.timingMode = (byte)newVal;
					}
					if (propName.Equals(propNameList[7]))
					{
						currentSplFeatBlock.resistance = (byte)newVal;
					}
					if (propName.Equals(propNameList[8]))
					{
						currentSplFeatBlock.duration = (short)newVal;
					}
					if (propName.Equals(propNameList[9]))
					{
						currentSplFeatBlock.probability1 = (byte)newVal;
					}
					if (propName.Equals(propNameList[10]))
					{
						currentSplFeatBlock.probability2 = (byte)newVal;
					}
					if (propName.Equals(propNameList[11]))
					{
						currentSplFeatBlock.diceThrown = newVal;
					}
					if (propName.Equals(propNameList[12]))
					{
						currentSplFeatBlock.diceSides = newVal;
					}
					if (propName.Equals(propNameList[13]))
					{
						currentSplFeatBlock.savingThrowType = newVal;
					}
					if (propName.Equals(propNameList[14]))
					{
						currentSplFeatBlock.savingThrowBonus = newVal;
					}
					if (propName.Equals(propNameList[15]))
					{
						currentSplFeatBlock.stackingId = newVal;
					}
					if (propName.Equals(propNameList[16]))
					{
						currentSplFeatBlock.parameter23 = (byte)newVal;
					}
					if (propName.Equals(propNameList[17]))
					{
						currentSplFeatBlock.parameter24 = (byte)newVal;
					}
					if (propName.Equals(propNameList[18]))
					{
						currentSplFeatBlock.parameter25 = (byte)newVal;
					}
					if (propName.Equals(propNameList[19]))
					{
						currentSplFeatBlock.parameter26 = (byte)newVal;
					}
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String newVal, int extHeaderIndex)
        {
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }

            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    currentSplFeatBlock.resource = newVal;
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String oldVal, String newVal, int extHeaderIndex)
        {
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }

            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (currentSplFeatBlock.resource.Equals(oldVal))
                    {
                        currentSplFeatBlock.resource = newVal;
                    }
                }
            }
        }

        internal static void RemoveSplOpcode(int opcodeNum, int keepNum)
        {
            ArrayList savedOpcodeInstances = new ArrayList();
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    // Console.WriteLine(index);
                    savedOpcodeInstances.Add(i);
                }
            }

            for (int j = savedOpcodeInstances.Count - 1 - keepNum; j >= 0; j--) // keep the specified number of instances
            {
                int indexToDel = (int)savedOpcodeInstances[j];
                // Console.WriteLine(indexToDel + " " + featureBlocksModded.Count);
                splFeatBlocksModded.RemoveAt(indexToDel); // remove the value stored in the savedOpcodeInstances
            }
            
            foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
            {
                int newCount = extendedHeader.featureBlockCount - ((savedOpcodeInstances.Count - keepNum) / splExtHeadersModded.Count);
                extendedHeader.featureBlockCount = Convert.ToInt16(newCount);
            }
        }
        
        internal static void RemoveSplOpcode(int opcodeNum, String propName, int val)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
                    {
                        if (currentSplFeatBlock.targetType == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[1]))
                    {
                        if (currentSplFeatBlock.power == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[2]))
                    {
                        if (currentSplFeatBlock.parameter1 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[3]))
                    {
                        if (currentSplFeatBlock.parameter2 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[4]))
                    {
                        if (currentSplFeatBlock.parameter21 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[5]))
                    {
                        if (currentSplFeatBlock.parameter22 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[6]))
                    {
                        if (currentSplFeatBlock.timingMode == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[7]))
                    {
                        if (currentSplFeatBlock.resistance == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[8]))
                    {
                        if (currentSplFeatBlock.duration == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[9]))
                    {
                        if (currentSplFeatBlock.probability1 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[10]))
                    {
                        if (currentSplFeatBlock.probability2 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[11]))
                    {
                        if (currentSplFeatBlock.diceThrown == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[12]))
                    {
                        if (currentSplFeatBlock.diceSides == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[13]))
                    {
                        if (currentSplFeatBlock.savingThrowType == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[14]))
                    {
                        if (currentSplFeatBlock.savingThrowBonus == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[15]))
                    {
                        if (currentSplFeatBlock.stackingId == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[16]))
                    {
                        if (currentSplFeatBlock.parameter23 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[17]))
                    {
                        if (currentSplFeatBlock.parameter24 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[18]))
                    {
                        if (currentSplFeatBlock.parameter25 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[19]))
                    {
                        if (currentSplFeatBlock.parameter26 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                }
            }

            for (int j = savedOpcodeInstances.Count - 1; j >= 0; j--) // keep the specified number of instances
            {
                int indexToDel = (int)savedOpcodeInstances[j];
                // Console.WriteLine(indexToDel + " " + featureBlocksModded.Count);
                splFeatBlocksModded.RemoveAt(indexToDel); // remove the value stored in the savedOpcodeInstances
            }
            
            foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
            {
                int newCount = extendedHeader.featureBlockCount - ((savedOpcodeInstances.Count) / splExtHeadersModded.Count);
                extendedHeader.featureBlockCount = Convert.ToInt16(newCount);
            }
        }
        
        internal static void RemoveSplOpcode(int opcodeNum, String val)
        {
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (currentSplFeatBlock.resource.Contains(val))
                    {
                        savedOpcodeInstances.Add(i);
                    }
                }
            }

            for (int j = savedOpcodeInstances.Count - 1; j >= 0; j--) // keep the specified number of instances
            {
                int indexToDel = (int)savedOpcodeInstances[j];
                // Console.WriteLine(indexToDel + " " + featureBlocksModded.Count);
                splFeatBlocksModded.RemoveAt(indexToDel); // remove the value stored in the savedOpcodeInstances
            }
            
            foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
            {
                int newCount = extendedHeader.featureBlockCount - ((savedOpcodeInstances.Count) / splExtHeadersModded.Count);
                extendedHeader.featureBlockCount = Convert.ToInt16(newCount);
            }
        }
        
        internal static void RemoveSplExtendedHeadersAndSplFeatureBlocks(int keepNum)
        {
            // Console.WriteLine(headerModded.extendedHeaderCount);
            
            int extendedHeadersCount = splExtHeadersModded.Count;
            for (int i = extendedHeadersCount; i > keepNum; i--)
            {
                splExtHeadersModded.RemoveAt(i - 1);
                splHeaderModded.extendedHeaderCount -= 1;
            }

            // determine, how many dependent featureblocks to remove after the extended headers have been removed
            int featureBlocksCount = splFeatBlocksModded.Count;
            int numFeatureBlocksToSpare = 0;
            if (splExtHeadersModded.Count != 0) // only do this, if, after the extendedHeaders are deleted, there is still one remaining, otherwise the number of feature blocks to spare can be set to 0
            {
                SplExtendedHeader firstSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0]; // only check this, if, after the extendedHeaders are deleted, there is still one remaining
                numFeatureBlocksToSpare = keepNum * firstSplExtendedHeader.featureBlockCount;
            }
            
            for (int j = featureBlocksCount; j > numFeatureBlocksToSpare; j--)
            {
                splFeatBlocksModded.RemoveAt(j - 1);
            }
            
            extendedHeadersCount = splExtHeadersModded.Count;
            splHeaderModded.featureBlockTableOffset = SplHeader.size + SplExtendedHeader.size * extendedHeadersCount; // we have to adapt the offset to the featureblock data, since we have modified the number of extended header by deletion. the structure of the file is header - all extendedheaders - all featureblocks. hence we can calculate the offset to the first featureblock by header size + extendedheader size * extendedheader count

            // Console.WriteLine(featureBlocksModded.Count);
            // Console.WriteLine(headerModded.extendedHeaderCount);
        }
        
        internal static void RemoveAllSplFeatureBlocks()
        {
            // determine, how many featureblocks to remove
            int featureBlocksCount = splFeatBlocksModded.Count;
            // Console.WriteLine(featureBlocksModded.Count);

            for (int j = featureBlocksCount; j > 0; j--)
            {
                splFeatBlocksModded.RemoveAt(j - 1);
            }

            for (int i = 0; i < splExtHeadersModded.Count; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                currentSplExtendedHeader.featureBlockCount = 0;
            }
        }
        
        internal static void RemoveAllSplFeatureBlocks(int extendedHeaderIndex)
        {
            int fbBegin = 0;
            int fbEnd = 0;
            for (int i = 0; i <= extendedHeaderIndex - 1; i++)
            {
                SplExtendedHeader currentSplExtendedHeader1 = (SplExtendedHeader) splExtHeadersModded[i];
                fbBegin += currentSplExtendedHeader1.featureBlockCount;
            }
            
            SplExtendedHeader currentSplExtendedHeader2 = (SplExtendedHeader) splExtHeadersModded[extendedHeaderIndex];
            fbEnd += currentSplExtendedHeader2.featureBlockCount - 1;
            
            for (int j = fbBegin + fbEnd; j >= fbBegin; j--)
            {
                // Console.WriteLine(j);
                // Console.WriteLine(splFeatBlocksModded.Count);
                splFeatBlocksModded.RemoveAt(j);
            }
            
            currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount = 0;
        }
        
        internal static void RemoveAllSplCastingFeatureBlocks()
        {
            // determine, how many featureblocks to remove
            int castingFeatureBlocksCount = splCastFeatBlocksModded.Count;
            // Console.WriteLine(featureBlocksModded.Count);

            for (int j = castingFeatureBlocksCount; j > 0; j--)
            {
                splCastFeatBlocksModded.RemoveAt(j - 1);
            }

            splHeaderModded.castingFeatureBlockCount = 0;
        }
    }
}