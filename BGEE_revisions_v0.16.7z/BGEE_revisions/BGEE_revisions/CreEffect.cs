﻿using System;
using System.Text;

namespace BGEE_revisions
{
    internal class CreEffect
    {
        internal static int size = 264; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal int arrayOffset;
        internal StringBuilder stringBuilder;

        internal String signature;
        internal String version;
        internal int opcode;
        internal int target;
        internal int power;
        internal int parameter1;
        internal int parameter2;
        internal int timingMode;
        internal int duration;
        internal short probability1;
        internal short probability2;
        internal String resource;
        internal int diceThrown;
        internal int diceSize;
        internal int saveType;
        internal int saveBonus;
        internal int special;
        internal int primaryType;
        internal int usedInternally;
        internal int minLevel;
        internal int maxLevel;
        internal int resistance;
        internal int parameter3;
        internal int parameter4;
        internal int parameter5;
        internal int timeApplied;
        internal String resource2;
        internal String resource3;
        internal int casterLocationX;
        internal int casterLocationY;
        internal int targetLocationX;
        internal int targetLocationY;
        internal int resourceType;
        internal String parentResource;
        internal int resourceFlags;
        internal int impactProjectile;
        internal int sourceItemSlot;
        internal String varName;
        internal int casterLevel;
        internal int internalFlags;
        internal int secondaryType;
        internal byte[] unknown;

        internal CreEffect(byte[] byteArray, int baseOffset)
        {
            this.baseOffset = baseOffset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            signature = ConvertToStringData(4);
            version = ConvertToStringData(4);
            opcode = ConvertToIntData();
            target = ConvertToIntData();
            power = ConvertToIntData();
            parameter1 = ConvertToIntData();
            parameter2 = ConvertToIntData();
            timingMode = ConvertToIntData();
            duration = ConvertToIntData();
            probability1 = ConvertToShortData();
            probability2 = ConvertToShortData();
            resource = ConvertToStringData(8);
            diceThrown = ConvertToIntData();
            diceSize = ConvertToIntData();
            saveType = ConvertToIntData();
            saveBonus = ConvertToIntData();
            special = ConvertToIntData();
            primaryType = ConvertToIntData();
            usedInternally = ConvertToIntData();
            minLevel = ConvertToIntData();
            maxLevel = ConvertToIntData();
            resistance = ConvertToIntData();
            parameter3 = ConvertToIntData();
            parameter4 = ConvertToIntData();
            parameter5 = ConvertToIntData();
            timeApplied = ConvertToIntData();
            resource2 = ConvertToStringData(8);
            resource3 = ConvertToStringData(8);
            casterLocationX = ConvertToIntData();
            casterLocationY = ConvertToIntData();
            targetLocationX = ConvertToIntData();
            targetLocationY = ConvertToIntData();
            resourceType = ConvertToIntData();
            parentResource = ConvertToStringData(8);
            resourceFlags = ConvertToIntData();
            impactProjectile = ConvertToIntData();
            sourceItemSlot = ConvertToIntData();
            varName = ConvertToStringData(32);
            casterLevel = ConvertToIntData();
            internalFlags = ConvertToIntData();
            secondaryType = ConvertToIntData();
            unknown = ConvertToUnknownData(60);
            
            this.byteArray = null; // clear the byteList;
        }
        
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal long ConvertToLongData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 8; // increase baseOffset 8 bytes
            return BitConverter.ToInt64(byteArray, currentOffset);
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }
        
        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(signature);
            CopyBytesToArray(version);
            CopyBytesToArray(opcode);
            CopyBytesToArray(target);
            CopyBytesToArray(power);
            CopyBytesToArray(parameter1);
            CopyBytesToArray(parameter2);
            CopyBytesToArray(timingMode);
            CopyBytesToArray(duration);
            CopyBytesToArray(probability1);
            CopyBytesToArray(probability2);
            CopyBytesToArray(resource);
            CopyBytesToArray(diceThrown);
            CopyBytesToArray(diceSize);
            CopyBytesToArray(saveType);
            CopyBytesToArray(saveBonus);
            CopyBytesToArray(special);
            CopyBytesToArray(primaryType);
            CopyBytesToArray(usedInternally);
            CopyBytesToArray(minLevel);
            CopyBytesToArray(maxLevel);
            CopyBytesToArray(resistance);
            CopyBytesToArray(parameter3);
            CopyBytesToArray(parameter4);
            CopyBytesToArray(parameter5);
            CopyBytesToArray(timeApplied);
            CopyBytesToArray(resource2);
            CopyBytesToArray(resource3);
            CopyBytesToArray(casterLocationX);
            CopyBytesToArray(casterLocationY);
            CopyBytesToArray(targetLocationX);
            CopyBytesToArray(targetLocationY);
            CopyBytesToArray(resourceType);
            CopyBytesToArray(parentResource);
            CopyBytesToArray(resourceFlags);
            CopyBytesToArray(impactProjectile);
            CopyBytesToArray(sourceItemSlot);
            CopyBytesToArray(varName);
            CopyBytesToArray(casterLevel);
            CopyBytesToArray(internalFlags);
            CopyBytesToArray(secondaryType);
            CopyBytesToArray(unknown);
            
            return byteArray;
        }
        
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(long variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += 1;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
        
        internal void PrintValues()
        {
            Console.WriteLine(signature);
            Console.WriteLine(version);
            Console.WriteLine(opcode);
            Console.WriteLine(target);
            Console.WriteLine(power);
            Console.WriteLine(parameter1);
            Console.WriteLine(parameter2);
            Console.WriteLine(timingMode);
            Console.WriteLine(duration);
            Console.WriteLine(probability1);
            Console.WriteLine(probability2);
            Console.WriteLine(resource);
            Console.WriteLine(diceThrown);
            Console.WriteLine(diceSize);
            Console.WriteLine(saveType);
            Console.WriteLine(saveBonus);
            Console.WriteLine(special);
            Console.WriteLine(primaryType);
            Console.WriteLine(usedInternally);
            Console.WriteLine(minLevel);
            Console.WriteLine(maxLevel);
            Console.WriteLine(resistance);
            Console.WriteLine(parameter3);
            Console.WriteLine(parameter4);
            Console.WriteLine(parameter5);
            Console.WriteLine(timeApplied);
            Console.WriteLine(resource2);
            Console.WriteLine(resource3);
            Console.WriteLine(casterLocationX);
            Console.WriteLine(casterLocationY);
            Console.WriteLine(targetLocationX);
            Console.WriteLine(targetLocationY);
            Console.WriteLine(resourceType);
            Console.WriteLine(parentResource);
            Console.WriteLine(resourceFlags);
            Console.WriteLine(impactProjectile);
            Console.WriteLine(sourceItemSlot);
            Console.WriteLine(varName);
            Console.WriteLine(casterLevel);
            Console.WriteLine(internalFlags);
            Console.WriteLine(secondaryType);
            Console.WriteLine(unknown);
        }
    }
}