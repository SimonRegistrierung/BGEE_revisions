﻿using System;
using System.Text;

namespace BGEE_revisions
{
    internal class StoItem
    {
        internal static int size = 28; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String itmFileName;
        internal short itemExpirationTime;
        internal short quantity1;
        internal short quantity2;
        internal short quantity3;
        internal int flags;
        internal int amountInStock;
        internal int infiniteSupplyFlag;
        
        internal StoItem(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            itmFileName = ConvertToStringData(8);
            itemExpirationTime = ConvertToShortData();
            quantity1 = ConvertToShortData();
            quantity2 = ConvertToShortData();
            quantity3 = ConvertToShortData();
            flags = ConvertToIntData();
            amountInStock = ConvertToIntData();
            infiniteSupplyFlag = ConvertToIntData();

            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }
        
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal long ConvertToLongData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 8; // increase baseOffset 8 bytes
            return BitConverter.ToInt64(byteArray, currentOffset);
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(itmFileName);
            CopyBytesToArray(itemExpirationTime);
            CopyBytesToArray(quantity1);
            CopyBytesToArray(quantity2);
            CopyBytesToArray(quantity3);
            CopyBytesToArray(flags);
            CopyBytesToArray(amountInStock);
            CopyBytesToArray(infiniteSupplyFlag);

            return byteArray;
        }

        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(long variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine(itmFileName);
            Console.WriteLine(itemExpirationTime);
            Console.WriteLine(quantity1);
            Console.WriteLine(quantity2);
            Console.WriteLine(quantity3);
            Console.WriteLine(flags);
            Console.WriteLine(amountInStock);
            Console.WriteLine(infiniteSupplyFlag);
        }
    }
}