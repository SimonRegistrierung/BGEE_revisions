﻿using System;
using System.Text;

namespace BGEE_revisions
{
    internal class StoHeader
    {
        internal static int size = 156; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String signature;
        internal String version;
        internal int type;
        internal int name;
        internal int flags;
        internal int sellPriceMarkup;
        internal int buyPriceMarkup;
        internal int depreciationRate;
        internal short chanceStealFailure;
        internal short capacity;
        internal byte[] unknown1;
        internal int itemsPurchasedOffset;
        internal int itemsPurchasedCount;
        internal int itemsForSaleOffset;
        internal int itemsForSaleCount;
        internal int lore;
        internal int identifyPrice;
        internal String rumoursTavern;
        internal int drinksForSaleOffset;
        internal int drinksForSaleCount;
        internal String rumoursTemple;
        internal int roomFlags;
        internal int pricePeasantRoom;
        internal int priceMerchantRoom;
        internal int priceNobleRoom;
        internal int priceRoyalRoom;
        internal int curesForSaleOffset;
        internal int curesForSaleCount;
        internal byte[] unknown2;

        internal StoHeader(byte[] byteArray)
        {
            baseOffset = 0; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            signature = ConvertToStringData(4);
            version = ConvertToStringData(4);
            type = ConvertToIntData();
            name = ConvertToIntData();
            flags = ConvertToIntData();
            sellPriceMarkup = ConvertToIntData();
            buyPriceMarkup = ConvertToIntData();
            depreciationRate = ConvertToIntData();
            chanceStealFailure = ConvertToShortData();
            capacity = ConvertToShortData();
            unknown1 = ConvertToUnknownData(8);
            itemsPurchasedOffset = ConvertToIntData();
            itemsPurchasedCount = ConvertToIntData();
            itemsForSaleOffset = ConvertToIntData();
            itemsForSaleCount = ConvertToIntData();
            lore = ConvertToIntData();
            identifyPrice = ConvertToIntData();
            rumoursTavern = ConvertToStringData(8);
            drinksForSaleOffset = ConvertToIntData();
            drinksForSaleCount = ConvertToIntData();
            rumoursTemple = ConvertToStringData(8);
            roomFlags = ConvertToIntData();
            pricePeasantRoom = ConvertToIntData();
            priceMerchantRoom = ConvertToIntData();
            priceNobleRoom = ConvertToIntData();
            priceRoyalRoom = ConvertToIntData();
            curesForSaleOffset = ConvertToIntData();
            curesForSaleCount = ConvertToIntData();
            unknown2 = ConvertToUnknownData(36);

            size = baseOffset;

            this.byteArray = null; // clear the byteList;
        }
        
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal long ConvertToLongData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 8; // increase baseOffset 8 bytes
            return BitConverter.ToInt64(byteArray, currentOffset);
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(signature);
            CopyBytesToArray(version);
            CopyBytesToArray(type);
            CopyBytesToArray(name);
            CopyBytesToArray(flags);
            CopyBytesToArray(sellPriceMarkup);
            CopyBytesToArray(buyPriceMarkup);
            CopyBytesToArray(depreciationRate);
            CopyBytesToArray(chanceStealFailure);
            CopyBytesToArray(capacity);
            CopyBytesToArray(unknown1);
            CopyBytesToArray(itemsPurchasedOffset);
            CopyBytesToArray(itemsPurchasedCount);
            CopyBytesToArray(itemsForSaleOffset);
            CopyBytesToArray(itemsForSaleCount);
            CopyBytesToArray(lore);
            CopyBytesToArray(identifyPrice);
            CopyBytesToArray(rumoursTavern);
            CopyBytesToArray(drinksForSaleOffset);
            CopyBytesToArray(drinksForSaleCount);
            CopyBytesToArray(rumoursTemple);
            CopyBytesToArray(roomFlags);
            CopyBytesToArray(pricePeasantRoom);
            CopyBytesToArray(priceMerchantRoom);
            CopyBytesToArray(priceNobleRoom);
            CopyBytesToArray(priceRoyalRoom);
            CopyBytesToArray(curesForSaleOffset);
            CopyBytesToArray(curesForSaleCount);
            CopyBytesToArray(unknown2);

            return byteArray;
        }

        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(long variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine(signature);
            Console.WriteLine(version);
            Console.WriteLine(type);
            Console.WriteLine(name);
            Console.WriteLine(flags);
            Console.WriteLine(sellPriceMarkup);
            Console.WriteLine(buyPriceMarkup);
            Console.WriteLine(depreciationRate);
            Console.WriteLine(chanceStealFailure);
            Console.WriteLine(capacity);
            Console.WriteLine(unknown1);
            Console.WriteLine(itemsPurchasedOffset);
            Console.WriteLine(itemsPurchasedCount);
            Console.WriteLine(itemsForSaleOffset);
            Console.WriteLine(itemsForSaleCount);
            Console.WriteLine(lore);
            Console.WriteLine(identifyPrice);
            Console.WriteLine(rumoursTavern);
            Console.WriteLine(drinksForSaleOffset);
            Console.WriteLine(drinksForSaleCount);
            Console.WriteLine(rumoursTemple);
            Console.WriteLine(roomFlags);
            Console.WriteLine(pricePeasantRoom);
            Console.WriteLine(priceMerchantRoom);
            Console.WriteLine(priceNobleRoom);
            Console.WriteLine(priceRoyalRoom);
            Console.WriteLine(curesForSaleOffset);
            Console.WriteLine(curesForSaleCount);
            Console.WriteLine(unknown2);
        }
    }
}