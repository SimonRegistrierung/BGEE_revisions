﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Management.Instrumentation;
using System.Security.AccessControl;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        // tlk objects
        internal static TlkHeader tlkHeader;
        internal static ArrayList tlkEntries;
        internal static ArrayList tlkIndexes = new ArrayList();
        internal static ArrayList tlkNewOffsets = new ArrayList();

        // paths
        internal static String splInputPath = ConfigurationManager.AppSettings["splinput"];
        internal static String splOutputPath = ConfigurationManager.AppSettings["sploutput"];
        internal static String tlkInputPath = ConfigurationManager.AppSettings["tlkinput"];
        internal static String tlkOutputPath = ConfigurationManager.AppSettings["tlkoutput"];
        internal static String creInputPath = ConfigurationManager.AppSettings["creinput"];
        internal static String creOutputPath = ConfigurationManager.AppSettings["creoutput"];
        internal static String itmInputPath = ConfigurationManager.AppSettings["itminput"];
        internal static String itmOutputPath = ConfigurationManager.AppSettings["itmoutput"];
        internal static String dlgInputPath = ConfigurationManager.AppSettings["dlginput"];
        internal static String dlgOutputPath = ConfigurationManager.AppSettings["dlgoutput"];
        internal static String twodaInputPath = ConfigurationManager.AppSettings["2dainput"];
        internal static String twodaOutputPath = ConfigurationManager.AppSettings["2daoutput"];
        internal static String bcsInputPath = ConfigurationManager.AppSettings["bcsinput"];
        internal static String bcsOutputPath = ConfigurationManager.AppSettings["bcsoutput"];
        internal static String wmpInputPath = ConfigurationManager.AppSettings["wmpinput"];
        internal static String wmpOutputPath = ConfigurationManager.AppSettings["wmpoutput"];
        internal static String stoInputPath = ConfigurationManager.AppSettings["stoinput"];
        internal static String stoOutputPath = ConfigurationManager.AppSettings["stooutput"];
        internal static String idsInputPath = ConfigurationManager.AppSettings["idsinput"];
        internal static String idsOutputPath = ConfigurationManager.AppSettings["idsoutput"];
        internal static String areInputPath = ConfigurationManager.AppSettings["areinput"];
        internal static String areOutputPath = ConfigurationManager.AppSettings["areoutput"];
        //
        internal static String effOutputPath = ConfigurationManager.AppSettings["effoutput"];
        internal static String bamOutputPath = ConfigurationManager.AppSettings["bamoutput"];
        internal static String miscOutputPath = ConfigurationManager.AppSettings["miscoutput"];
        //
        internal static String overridePath = ConfigurationManager.AppSettings["override"];
        //

        //
        internal static String miscModPath = ConfigurationManager.AppSettings["miscmod"];
        internal static String effModPath = ConfigurationManager.AppSettings["effmod"];
        internal static String twodaModPath = ConfigurationManager.AppSettings["2damod"];
        internal static String itmModPath = ConfigurationManager.AppSettings["itmmod"];
        internal static String creModPath = ConfigurationManager.AppSettings["cremod"];
        internal static String bamModPath = ConfigurationManager.AppSettings["bammod"];

        //

        // raw byte arrays
        internal static byte[] tlkByteArray;
        internal static byte[] splByteArray;
        internal static byte[] creByteArray;
        internal static byte[] itmByteArray;
        internal static byte[] dlgByteArray;
        internal static byte[] effByteArray;
        internal static byte[] wmpByteArray;
        internal static byte[] stoByteArray;
        internal static byte[] areByteArray;

        // file type paths
        internal static DirectoryInfo splInputDirectory = new DirectoryInfo(splInputPath);
        internal static DirectoryInfo creInputDirectory = new DirectoryInfo(creInputPath);
        internal static DirectoryInfo twodaInputDirectory = new DirectoryInfo(twodaInputPath);
        internal static DirectoryInfo itmInputDirectory = new DirectoryInfo(itmInputPath);
        internal static DirectoryInfo dlgInputDirectory = new DirectoryInfo(dlgInputPath);
        internal static DirectoryInfo bcsInputDirectory = new DirectoryInfo(bcsInputPath);
        internal static DirectoryInfo wmpInputDirectory = new DirectoryInfo(wmpInputPath);
        internal static DirectoryInfo stoInputDirectory = new DirectoryInfo(stoInputPath);
        internal static DirectoryInfo idsInputDirectory = new DirectoryInfo(idsInputPath);
        internal static DirectoryInfo areInputDirectory = new DirectoryInfo(areInputPath);

        //
        internal static DirectoryInfo miscModDirectory = new DirectoryInfo(miscModPath);
        internal static DirectoryInfo bamModDirectory = new DirectoryInfo(bamModPath);
        internal static DirectoryInfo effModDirectory = new DirectoryInfo(effModPath);
        internal static DirectoryInfo twodaModDirectory = new DirectoryInfo(twodaModPath);
        internal static DirectoryInfo itmModDirectory = new DirectoryInfo(itmModPath);
        internal static DirectoryInfo creModDirectory = new DirectoryInfo(creModPath);
        //

        internal static FileInfo[] splsRaw = splInputDirectory.GetFiles();
        internal static FileInfo[] cresRaw = creInputDirectory.GetFiles("*.cre");
        internal static FileInfo[] twodasRaw = twodaInputDirectory.GetFiles("*.2da");
        internal static FileInfo[] itmsRaw = itmInputDirectory.GetFiles("*.itm");
        internal static FileInfo[] dlgsRaw = dlgInputDirectory.GetFiles("*.dlg");
        internal static FileInfo[] bcssRaw = bcsInputDirectory.GetFiles("*.bcs");
        internal static FileInfo[] wmpsRaw = wmpInputDirectory.GetFiles("*.wmp");
        internal static FileInfo[] stosRaw = stoInputDirectory.GetFiles("*.sto");
        internal static FileInfo[] idsRaw = idsInputDirectory.GetFiles("*.ids");
        internal static FileInfo[] aresRaw = areInputDirectory.GetFiles("*.are");

        //
        internal static FileInfo[] miscsModRaw = miscModDirectory.GetFiles("*.*");
        internal static FileInfo[] bamsModRaw = bamModDirectory.GetFiles("*.bam");
        internal static FileInfo[] effsModRaw = effModDirectory.GetFiles("*.eff");
        internal static FileInfo[] twodasModRaw = twodaModDirectory.GetFiles("*.2da");
        internal static FileInfo[] itmsModRaw = itmModDirectory.GetFiles("*.itm");
        internal static FileInfo[] cresModRaw = creModDirectory.GetFiles("*.cre");
        //

        // ids objects
        internal static IdsFile idsFile;
        //
        internal static FileInfo currentIdsFileInfo;
        // created ids
        internal static short proFrostRayId = 0;

        // spl objects
        internal static SplHeader splHeader;
        internal static ArrayList splExtHeaders;
        internal static ArrayList splCastFeatBlocks;
        internal static ArrayList splFeatBlocks;

        //
        internal static SplHeader splHeaderModded;
        internal static ArrayList splExtHeadersModded;
        internal static ArrayList splCastFeatBlocksModded;
        internal static ArrayList splFeatBlocksModded;

        //
        internal static SplExtendedHeader currentSplExtendedHeader;
        internal static SplFeatureBlock currentSplCastFeatBlock;
        internal static SplFeatureBlock currentSplFeatBlock;
        //
        internal static ArrayList spells = new ArrayList();
        internal static FileInfo currentSpellFileInfo = null;
        
        // itm objects
        internal static ItmHeader itmHeader;
        internal static ArrayList itmExtHeaders;
        internal static ArrayList itmEffFeatBlocks;
        internal static ArrayList itmAbilFeatBlocks;
        //
        internal static ItmHeader itmHeaderModded;
        internal static ArrayList itmExtHeadersModded;
        internal static ArrayList itmEffFeatBlocksModded;
        internal static ArrayList itmAbilFeatBlocksModded;
        //
        internal static ItmExtHeader currentItmExtHeader;
        internal static ItmFeatBlock currentItmFeatBlock;
        //
        internal static ArrayList items = new ArrayList();
        internal static FileInfo currentItemFileInfo = null;
        
        // cre objects
        internal static CreHeader creHeader;
        internal static ArrayList creKnownSpells;
        internal static ArrayList creMemorizedSpellsInfos;
        internal static ArrayList creMemorizedSpells;
        internal static ArrayList creEffects;
        internal static ArrayList creItems;
        internal static CreItemSlots creItemSlots;
        //
        internal static CreHeader creHeaderModded;
        internal static ArrayList creKnownSpellsModded;
        internal static ArrayList creMemorizedSpellsInfosModded;
        internal static ArrayList creMemorizedSpellsModded;
        internal static ArrayList creEffectsModded;
        internal static ArrayList creItemsModded;
        internal static CreItemSlots creItemSlotsModded;
        //
        internal static CreKnownSpell currentCreKnownSpell;
        internal static CreMemorizedSpellsInfo currentCreMemorizedSpellsInfo;
        internal static CreMemorizedSpell currentCreMemorizedSpell;
        internal static CreEffect currentCreEffect;
        internal static CreItem currentCreItem;
        //
        internal static ArrayList cres = new ArrayList();
        internal static FileInfo currentCreFileInfo = null;
        
        // dlg objects
        internal static DlgHeader dlgHeader;
        internal static ArrayList dlgStateTables;
        internal static ArrayList dlgTransitionTables;
        internal static ArrayList dlgStateTriggers;
        internal static ArrayList dlgTransitionTriggers;
        internal static ArrayList dlgActionTables;
        internal static byte[] dlgStringSection;
        //
        internal static DlgHeader dlgHeaderModded;
        internal static ArrayList dlgStateTablesModded;
        internal static ArrayList dlgTransitionTablesModded;
        internal static ArrayList dlgStateTriggersModded;
        internal static ArrayList dlgTransitionTriggersModded;
        internal static ArrayList dlgActionTablesModded;
        internal static byte[] dlgStringSectionModded;
        //
        internal static DlgStateTable currentDlgStateTable;
        internal static DlgTransitionTable currentDlgTransitionTable;
        internal static DlgStateTrigger currentDlgStateTrigger;
        internal static DlgTransitionTrigger currentDlgTransitionTrigger;
        internal static DlgActionTable currentDlgActionTable;
        //
        internal static ArrayList dlgs = new ArrayList();
        internal static FileInfo currentDlgFileInfo = null;
        
        // ids
        internal static ArrayList idss = new ArrayList();

        // 2da objects
        internal static TwodaFile twodaFile;
        //
        internal static ArrayList twodas = new ArrayList();
        internal static FileInfo currentTwodaFileInfo = null;
        
        // bcs
        internal static ArrayList bcss = new ArrayList();
        internal static FileInfo currentBcsFileInfo = null;
        
        // wmp objects
        internal static WmpHeader wmpHeader;
        internal static ArrayList wmpWorldMapEntries;
        internal static ArrayList wmpAreaEntries;
        internal static ArrayList wmpAreaLinkEntries;
        //
        internal static WmpHeader wmpHeaderModded;
        internal static ArrayList wmpWorldMapEntriesModded;
        internal static ArrayList wmpAreaEntriesModded;
        internal static ArrayList wmpAreaLinkEntriesModded;
        //
        internal static WmpWorldMapEntry currentWmpWorldMapEntry;
        internal static WmpAreaEntry currentWmpAreaEntry;
        internal static WmpAreaLinkEntry currentWmpAreaLinkEntry;
        //
        internal static ArrayList wmps = new ArrayList();
        internal static FileInfo currentWmpFileInfo = null;
        
        // sto objects
        internal static StoHeader stoHeader;
        internal static ArrayList stoItemsPurchased;
        internal static ArrayList stoItemsForSale;
        internal static ArrayList stoDrinks;
        internal static ArrayList stoCures;
        //
        internal static StoHeader stoHeaderModded;
        internal static ArrayList stoItemsPurchasedModded;
        internal static ArrayList stoItemsForSaleModded;
        internal static ArrayList stoDrinksModded;
        internal static ArrayList stoCuresModded;
        //
        internal static int currentStoItemPurchased;
        internal static StoItem currentStoItemForSale;
        internal static StoDrink currentStoDrink;
        internal static StoCure currentStoCure;
        //
        internal static ArrayList stos = new ArrayList();
        internal static FileInfo currentStoFileInfo = null;
        
        // are objects
        internal static AreHeader areHeader;
        internal static ArrayList areActors;
        internal static ArrayList areTriggers;
        internal static ArrayList areSpawnPoints;
        internal static ArrayList areEntrances;
        internal static ArrayList areContainers;
        internal static ArrayList areItems;
        internal static ArrayList areVertices;
        internal static ArrayList areAmbients;
        internal static ArrayList areVariables;
        internal static byte[] areExploredBitmasks;
        internal static ArrayList areDoors;
        internal static ArrayList areAnimations;
        internal static ArrayList areTiledObjects;
        internal static AreSong areSong;
        internal static AreRestEncounter areRestEncounter;
        internal static ArrayList areAutomapNotes;
        internal static ArrayList areProjectileTraps;

        //
        internal static AreHeader areHeaderModded;
        internal static ArrayList areActorsModded;
        internal static ArrayList areTriggersModded;
        internal static ArrayList areSpawnPointsModded;
        internal static ArrayList areEntrancesModded;
        internal static ArrayList areContainersModded;
        internal static ArrayList areItemsModded;
        internal static ArrayList areVerticesModded;
        internal static ArrayList areAmbientsModded;
        internal static ArrayList areVariablesModded;
        internal static byte[] areExploredBitmasksModded;
        internal static ArrayList areDoorsModded;
        internal static ArrayList areAnimationsModded;
        internal static ArrayList areTiledObjectsModded;
        internal static AreSong areSongModded;
        internal static AreRestEncounter areRestEncounterModded;
        internal static ArrayList areAutomapNotesModded;
        internal static ArrayList areProjectileTrapsModded;
        //
        internal static AreActor currentAreActor;
        internal static AreTrigger currentAreTrigger;
        internal static AreSpawnPoint currentAreSpawnPoint;
        internal static AreEntrance currentAreEntrance;
        internal static AreContainer currentAreContainer;
        internal static AreItem currentAreItem;
        internal static AreVertex currentAreVertex;
        internal static AreAmbient currentAreAmbient;
        internal static AreVariable currentAreVariable;
        internal static AreDoor currentAreDoor;
        internal static AreAnimation currentAreAnimation;
        internal static AreTiledObject currentAreTiledObject;
        internal static AreAutomapNote currentAreAutomapNote;
        internal static AreProjectileTrap currentAreProjectileTrap;
        
        //
        internal static ArrayList ares = new ArrayList();
        internal static FileInfo currentAreFileInfo = null;
        
        // MISC VARS
        internal static String[] identifiers;
        internal static byte[] rgb;

        internal static short level;
        internal static int index;

        internal static String currentName;
        internal static Boolean found = false;
        
        internal static void Main(string[] args)
        {
            // Pre-filter files in case it's necessary
            FilterFiles();
            
            // TLK entry generation
            CreateTlkObjects();

            // beginning of main operation
            Console.WriteLine("STARTING IDS PATCHING...");
            foreach (FileInfo ids in idss)
            {
                currentIdsFileInfo = ids;
                CreateIdsObject();
                RunIds();
            }
            Console.WriteLine("DONE!\n==========");
            
            // beginning of main operation
            Console.WriteLine("STARTING SPL PATCHING...");
            foreach (FileInfo spell in spells)
            {
                currentSpellFileInfo = spell;
                // Console.WriteLine(currentSpellFileInfo.Name);
            
                // SPl Object generation
                CreateSplObjects();
                RunSpl();
            }
            // Fix effect duration
            FixEffectDurations();
            Console.WriteLine("DONE!\n==========");
            
            Console.WriteLine("STARTING ITM PATCHING...");
            foreach (FileInfo item in items)
            {
                currentItemFileInfo = item;
                CheckForPreModdedFile();
            
                // ITM Object generation
                CreateItmObjects();
                RunItm();
                    
            }
            Console.WriteLine("DONE!\n==========");
            
            Console.WriteLine("STARTING CRE PATCHING...");
            foreach (FileInfo cre in cres)
            {
                currentCreFileInfo = cre;
                CheckForPreModdedFile();
            
                // CRE Object generation
                CreateCreObjects();
                RunCre();
            }
            Console.WriteLine("DONE!\n==========");
            Console.WriteLine("STARTING DLG PATCHING...");
            foreach (FileInfo dlg in dlgs)
            {
                currentDlgFileInfo = dlg;
            
                // DLG Object generation
                CreateDlgObjects();
                RunDlg();
            }
            Console.WriteLine("DONE!\n==========");
            Console.WriteLine("STARTING 2DA PATCHING...");
            foreach (FileInfo twoda in twodas)
            {
                currentTwodaFileInfo = twoda;
                CreateTwodaObject();
            
                RunTwoda();
            }
            Console.WriteLine("DONE!\n==========");
            Console.WriteLine("STARTING BCS PATCHING...");
            BcsParser bcsParser = new BcsParser(idss);
            foreach (FileInfo bcs in bcss)
            {
                currentBcsFileInfo = bcs;
            
                // BCS Object generation
                RunBcs(bcsParser);
            }
            Console.WriteLine("DONE!\n==========");
            Console.WriteLine("STARTING WMP PATCHING...");
            foreach (FileInfo wmp in wmps)
            {
                currentWmpFileInfo = wmp;
            
                // WMP Object generation
                CreateWmpObjects();
                RunWmp();
            }
            Console.WriteLine("DONE!\n==========");
            Console.WriteLine("STARTING STO PATCHING...");
            foreach (FileInfo sto in stos)
            {
                currentStoFileInfo = sto;
            
                // STO Object generation
                CreateStoObjects();
                RunSto();
            }
            Console.WriteLine("DONE!\n==========");
            Console.WriteLine("STARTING ARE PATCHING...");
            foreach (FileInfo are in ares)
            {
                currentAreFileInfo = are;
            
                // ARE Object generation
                // Console.WriteLine(are.Name);
                CreateAreObjects();
                RunAre();
            }
            Console.WriteLine("DONE!\n==========");
            
            // run tlk changes only once (not in a loop)
            Console.WriteLine("PATCHING TLK...");
            RunTlk();
            Console.WriteLine("DONE!\n==========");

            // add final touches only once (not in a loop)
            PatchAndCopyCres();
            CopyTwoDAs();
            PatchAndCopyEffs();
            CopyAndPatchItms();
            CopyBams();
            CopyMiscs();

            // Copy Files
            Console.WriteLine("COPYING FILES...");
            CopyAllFiles(idsOutputPath, overridePath);
            CopyAllFiles(splOutputPath, overridePath);
            CopyAllFiles(itmOutputPath, overridePath);
            CopyAllFiles(creOutputPath, overridePath);
            CopyAllFiles(stoOutputPath, overridePath);
            CopyAllFiles(dlgOutputPath, overridePath);
            CopyAllFiles(wmpOutputPath, overridePath);
            CopyAllFiles(bcsOutputPath, overridePath);
            CopyAllFiles(twodaOutputPath, overridePath);
            Console.WriteLine("DONE!\n==========");
        }
    }
}