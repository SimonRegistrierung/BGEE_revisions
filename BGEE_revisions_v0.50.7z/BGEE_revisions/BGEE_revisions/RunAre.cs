﻿using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunAre()
        {
            for (int i = areItemsModded.Count - 1; i >= 0; i--)
            // foreach (AreItem areItem in areItemsModded)
            {
                currentAreItem = (AreItem) areItemsModded[i];
                // CORRECT NON-EXISTING ITEMS
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(currentAreItem))) // if the item file doe not exist in the source path, we can assume this item does not exist
                {
                    Console.WriteLine("Found non-existing item \"" + currentAreItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");
                    
                    if (ContainsCaseInsensitive(currentAreItem.resource, "null"))
                    {
                        currentAreItem.resource = "RNDTRE03";
                        currentAreItem.quantity1 = 1;
                        currentAreItem.quantity2 = 0;
                        currentAreItem.quantity3 = 0;
                    }
                    else // else, we replace this with a random item
                    {
                        currentAreItem.resource = "RNDTRE04";
                        currentAreItem.quantity1 = 1;
                        currentAreItem.quantity2 = 0;
                        currentAreItem.quantity3 = 0;
                    }

                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");

                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // REMOVE ALL WANDS
                if (ContainsCaseInsensitive(currentAreItem.resource, "WAND"))
                {
                    Console.WriteLine("Found WAND item \"" + currentAreItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");

                    currentAreItem.resource = "RNDTRE04";
                    currentAreItem.quantity1 = 1;
                    currentAreItem.quantity2 = 0;
                    currentAreItem.quantity3 = 0;
                    
                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");

                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // convert all buggy random items to functioning
                if (currentAreItem.resource.Contains("RNDTRE08") || currentAreItem.resource.Contains("RNDTRE09"))
                {
                    currentAreItem.resource = "RNDTRE07";
                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // // EQUALIZE WAND CHARGES 
                // String fileName = GetItemFileName(currentAreItem);
                // // Console.WriteLine("-----");
                // // Console.WriteLine(fileName);
                // // Console.WriteLine("-----");
                // CreateItmObjects(fileName);
                // if (itmHeaderModded.itemType == 35) // if it's a wand
                // {
                //     if (currentAreItem.quantity1 > 0)
                //     {
                //         currentAreItem.quantity1 = 15;
                //     }
                //
                //     if (currentAreItem.quantity2 > 0)
                //     {
                //         currentAreItem.quantity2 = 15;
                //     }
                //
                //     if (currentAreItem.quantity3 > 0)
                //     {
                //         currentAreItem.quantity3 = 15;
                //     }
                //
                //     // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                //     if (fileName.Contains("WAND06."))
                //     {
                //         currentAreItem.quantity1 = 15;
                //         currentAreItem.quantity2 = 15;
                //     }
                //
                //     FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                // }
                
                // CLOAK OF NYMPH CHARGES
                if (currentAreItem.resource.Contains("CLCK07")) // cloak of the nymph
                {
                    currentAreItem.quantity1 = 1;
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // change erroneously placed undroppable plate mail in the undercity
                if (currentAreItem.resource.Contains("PLAT07"))
                {
                    currentAreItem.resource = "PLAT01" + new string(new char[2]);
                    currentAreItem.quantity3 = 0;
                    currentAreItem.flags = GetBitfieldInt(new int[] {0});
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // INCREASE ITEM QUANTITY FOR GOLEM BUILDING
                if (
                    ContainsCaseInsensitive(currentAreItem.resource, "A7!") && !ContainsCaseInsensitive(currentAreItem.resource, "TOM") // GOLEM CONSTRUCTION ITEMS
                )
                {
                    currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 2);
                    // Console.WriteLine(currentAreItem.resource);
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                //
                // REPLACE CURSED SCROLLS WITH RANDOM LOOT
                if (
                    currentAreItem.resource.Contains("SCRL10") ||
                    currentAreItem.resource.Contains("SCRL11") ||
                    currentAreItem.resource.Contains("SCRL12") ||
                    currentAreItem.resource.Contains("SCRL13") ||
                    currentAreItem.resource.Contains("SCRL14") ||
                    currentAreItem.resource.Contains("SCRL15") ||
                    currentAreItem.resource.Contains("SCRL16") ||
                    currentAreItem.resource.Contains("SCRL17") ||
                    currentAreItem.resource.Contains("SCRL18")
                )
                {
                    // Console.WriteLine("got here");
                    currentAreItem.resource = "RNDTRE03";
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                ////
                ///
                /// 
                // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF SLEEP
                // if (currentAreFileInfo.Name.Contains("BG1900"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND08" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("BG2611"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND08" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF CURSING
                // if (currentAreFileInfo.Name.Contains("BG1200"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND19" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF GLITTERDUST
                // if (currentAreFileInfo.Name.Contains("AR0405"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF POLYMORPHING
                // if (currentAreFileInfo.Name.Contains("BD7400"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND09" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("AR0907"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND09" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF MONSTER SUMMONING
                // if (currentAreFileInfo.Name.Contains("BG1803"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND10" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF THE HEAVENS
                // if (currentAreFileInfo.Name.Contains("BG4010"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND11" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF CLOUDKILL
                // if (currentAreFileInfo.Name.Contains("BG2614"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND13" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF WAND OF SPELLSTRIKING
                // if (currentAreFileInfo.Name.Contains("AR0527"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF WAND OF CURSING
                // if (currentAreFileInfo.Name.Contains("AR2210"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF LIGHTNING TO WAND OF GLITTERDUST
                // if (currentAreFileInfo.Name.Contains("BG0504"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("AR1401"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("BG0109"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FROST TO WAND OF SPELL STRIKING
                // if (currentAreFileInfo.Name.Contains("AR1303"))
                // {
                //     if (currentAreItem.resource.Contains("WAND06"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
            }

            // make all creatures spawn/be available at all day and night times
            // foreach (AreActor areActor in areActorsModded)
            // {
            //     if (areActor.appearanceSchedule != -1)
            //     {
            //         // Console.WriteLine(currentAreFileInfo.Name + " : " + currentAreActor.name);
            //         areActor.appearanceSchedule = -1;
            //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            //     }
            // }
            
            ////////////
            // INCREASE FOUND GOLD IN SOME AREAS TO COMPENSATE FOR ADDITIONS OF NEW SHOPS AND REQUIRED CASH
            ///////////
            ///
            /// LION'S WAY
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG2700"))
            {
                int containerIndex = FindAreContainerOfItem("MISC42");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 15000, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // ALARICS CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG3601"))
            {
                foreach (AreItem areItem in areItemsModded)
                {
                    if (ContainsCaseInsensitive(areItem.resource, "MISC07"))
                    {
                        areItem.quantity1 = 2000;
                    }
                }
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // ANCIENT RUINS
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG4101"))
            {
                int containerIndex = FindAreContainerOfItem("MISC48");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 3000, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // ULCASTER RUINS
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG3901"))
            {
                int containerIndex = FindAreContainerOfItem("ULBOOK54");
                AddAreItem("MISC07" + new string(new char[2]), 0, 5000, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // DRYAD FALLS
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG5200"))
            {
                int containerIndex = FindAreContainerOfItem("MISC62");
                AddAreItem("MISC07" + new string(new char[2]), 0, 4000, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                AddAreItem("MISC43" + new string(new char[2]), 0, 3, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // DRYAD FALLS CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG5202"))
            {
                foreach (AreItem areItem in areItemsModded)
                {
                    if (ContainsCaseInsensitive(areItem.resource, "MISC07"))
                    {
                        areItem.quantity1 = 2000;
                    }
                }
                int containerIndex = FindAreContainerOfItem("MISC07");
                AddAreItem("MISC41" + new string(new char[2]), 0, 3, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // MULAHEYS CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG5405"))
            {
                // Console.WriteLine("GOT HERE");
                int containerIndex = FindAreContainerOfItem("SW1H08");
                AddAreItem("MISC42" + new string(new char[2]), 0, 3, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 3000, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
        }

        internal static void RemoveAreItem(int index)
        {
            areItemsModded.RemoveAt(index);
        }

        internal static void AddAreItem(String resource, short itemExpirationTime, short quantity1, short quantity2, short quantity3, int flags, int containerIndex)
        {
            currentAreContainer = (AreContainer) areContainersModded[containerIndex];
            currentAreContainer.itemCount++;
            areItemsModded.Add(new AreItem(resource, itemExpirationTime, quantity1, quantity2, quantity3, flags));
            areHeaderModded.numberOfItems++;
        }

        internal static int FindAreContainerOfItem(String itmResource)
        {
            Boolean found1 = false;
            int itmIndex = 0;
            foreach (AreItem areItem in areItemsModded)
            {
                Console.WriteLine(areItem.resource + ":" + itmResource);
                if (ContainsCaseInsensitive(areItem.resource, itmResource))
                {
                    found1 = true;
                    break;
                }
                itmIndex++;
            }

            Boolean found2 = false;
            int containerIndex = 0;
            int itmOffset = 0;
            foreach (AreContainer areContainer in areContainersModded)
            {
                itmOffset += areContainer.itemCount;
                if (itmOffset >= itmIndex)
                {
                    found2 = true;
                    break;
                }
                containerIndex++;
            }

            if (found1 && found2)
            {
                
                return containerIndex;
            }
            else
            {
                throw new Exception("COULD NOT FIND ITEM IN CONTAINER!\nFOUND1:" + found1 + "\n - FOUND2: " + found2 + "\nitmIndex:" + itmIndex + "\n - containerIndex: " + containerIndex);
            }
        }
    }
}