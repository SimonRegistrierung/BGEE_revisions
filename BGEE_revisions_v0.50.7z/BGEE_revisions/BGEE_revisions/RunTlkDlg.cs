﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlkDlg()
        {
            // CHANGE THALANTYR DIALOG (WANDS REQUIRED FOR BOW CONSTRUCTION)
            identifiers = new String[]{
                "I will also need a Wand of Magic Missiles, a Wand of Frost, and a Wand of Lightning"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "I will also need a Potion of Cold Resistance, a Potion of Insulation, and a Potion of Perception", false, false);
            }
            
            // CHANGE DENAKS REPONSE TO ALWAYS ATTACK EVEN WITH EDWIN IN THE PARTY WITHOUT DYNAHEIR
            identifiers = new String[]{
                "Good day, travelers. Mmm, Edwin, I did not expect to see you so soon."
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "It is so sad to have met you this fine day. Normally, we would be quite ecstatic to have visitors,", false, false);
            }
        }
    }
}