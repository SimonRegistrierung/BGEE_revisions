﻿using System;
using System.Collections;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunSto()
        {
            // adjust container sizes
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Ammo Belt"))
            {
                stoHeaderModded.capacity = 1000;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Gem Bag"))
            {
                stoHeaderModded.capacity = 100;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Scroll Case"))
            {
                stoHeaderModded.capacity = 250;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Potion Case"))
            {
                stoHeaderModded.capacity = 250;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Holding"))
            {
                stoHeaderModded.capacity = 500;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // correct wrong string in keyring stores
            if (ContainsCaseInsensitive(currentStoFileInfo.Name, "KEYR"))
            {
                // Console.WriteLine(currentStoFileInfo.Name);
                stoHeaderModded.capacity = 50;
                stoHeaderModded.name = FindExactTlkEntry("Key ring");
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wand Case") ||
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wandcase")
            )
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // remove all items from all containers
            if (stoHeaderModded.type == 5) // if it's a container
            {
                stoHeaderModded.itemsForSaleCount = 0;
                stoHeaderModded.itemsForSaleOffset = 156;
                stoHeaderModded.drinksForSaleCount = 0;
                stoHeaderModded.drinksForSaleOffset = 156;
                stoHeaderModded.curesForSaleCount = 0;
                stoHeaderModded.curesForSaleOffset = 156;
                stoItemsForSaleModded = new ArrayList();
                stoDrinksModded = new ArrayList();
                stoCuresModded = new ArrayList();
                
                // change the offset for the items purchased by the store
                stoHeaderModded.itemsPurchasedOffset = 156;

                // Console.WriteLine(StoHeader.size);
                // Console.WriteLine(stoItemsForSaleModded.Count * StoItem.size);
                // Console.WriteLine(stoDrinksModded.Count * StoDrink.size);
                // Console.WriteLine(stoCuresModded.Count * StoCure.size);
                // Console.WriteLine(stoItemsPurchased.Count * 4);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }

            // equalize prizes of all stores (prevent stealing exploit)
            if (
                stoHeaderModded.type == 0 ||
                stoHeaderModded.type == 1 ||
                stoHeaderModded.type == 2 ||
                stoHeaderModded.type == 3
            ) // if it's a store
            {
                stoHeaderModded.sellPriceMarkup = 150;
                stoHeaderModded.buyPriceMarkup = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                stoHeaderModded.type == 0 ||
                stoHeaderModded.type == 1 ||
                stoHeaderModded.type == 2 ||
                stoHeaderModded.type == 3
            ) // if it's a store
            {
                stoHeaderModded.flags = ModExistingBitfield(stoHeaderModded.flags, new int[] {3}, false);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                    stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // TLK STRING CHANGES
            //                          all containers should have the same name, even though they have different optical appearances
            /////////////////////////////////////////
            if (stoHeaderModded.type == 5) // if it's a container
            {
                if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeader.name), "Bag of Holding"))
                {
                    stoHeaderModded.name = FindExactTlkEntry("Bag of Holding");
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
                if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeader.name), "Gem Bag"))
                {
                    stoHeaderModded.name = FindExactTlkEntry("Gem Bag");
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
                if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeader.name), "Potion Case"))
                {
                    stoHeaderModded.name = FindExactTlkEntry("Potion Case");
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
                if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeader.name), "Scroll Case"))
                {
                    stoHeaderModded.name = FindExactTlkEntry("Scroll Case");
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
                if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeader.name), "Ammo Belt"))
                {
                    stoHeaderModded.name = FindExactTlkEntry("Ammo Belt");
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            }



            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // STORE ITEM CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            ///
            // correct empty items in containers (NULL.itm, RNDTRS.ITM... etc...)
            for (int i = stoItemsForSaleModded.Count - 1; i >= 0; i--)
            {
                currentStoItemForSale = (StoItem) stoItemsForSaleModded[i];
                // CORRECT NON-EXISTING ITEMS
                if (
                        !FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(currentStoItemForSale))
                    ) 
                    // if the item file does not exist in the source path, we can assume this item does not exist
                {
                    // String newItem = "POTN52"; // POTION OF EXTRA HEALING
                    // Console.WriteLine("Found non-existing item \"" + currentStoItemForSale.itmFileName + "\" in \"" + currentStoFileInfo.Name + "\"");
                    //
                    // currentStoItemForSale.itmFileName = newItem;
                    // currentStoItemForSale.quantity1 = 3;
                    // currentStoItemForSale.quantity2 = 0;
                    // currentStoItemForSale.quantity3 = 0;
                    // currentStoItemForSale.flags = GetBitfieldInt(new int[] {0});
                    //
                    // Console.WriteLine("replacing with \"" + newItem + "\"");
                    
                    RemoveStoItem(i);

                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                    continue;
                }
                
                // OTHER ITEM CHARGE CHANGES
                if (currentStoItemForSale.itmFileName.Contains("CLCK07")) // cloak of the nymph
                {
                    currentStoItemForSale.quantity1 = 1;
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
                
                // STANDARDSIZE CHARGES FOR SANDTHIEF'S RING
                if (currentStoItemForSale.itmFileName.Contains("RING05")) // cloak of the nymph
                {
                    currentStoItemForSale.quantity1 = 3;
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
                // equalize wand charges for all stores (see item mod for wands)
                // String fileName = GetItemFileName(currentStoItemForSale);
                //
                // CreateItmObjects(fileName);
                // if (itmHeaderModded.itemType == 35) // if it's a wand
                // {
                //     if (currentStoItemForSale.quantity1 > 0)
                //     {
                //         currentStoItemForSale.quantity1 = 15;
                //     }
                //
                //     if (currentStoItemForSale.quantity2 > 0)
                //     {
                //         currentStoItemForSale.quantity2 = 15;
                //     }
                //
                //     if (currentStoItemForSale.quantity3 > 0)
                //     {
                //         currentStoItemForSale.quantity3 = 15;
                //     }
                //
                //     // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                //     if (fileName.Contains("WAND06."))
                //     {
                //         currentStoItemForSale.quantity1 = 15;
                //         currentStoItemForSale.quantity2 = 15;
                //     }
                //     
                //     FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                // }
                
                //
                // REMOVE AND OR REDUCE SOME STORE ITEMS
                //
                if (stoHeaderModded.type == 0 || // if it's a store
                    stoHeaderModded.type == 1 ||
                    stoHeaderModded.type == 2 ||
                    stoHeaderModded.type == 3
                   )
                {
                    if (
                        ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "WAND") &&
                        !ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "K#WAND") &&
                        !ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "RGWAND")
                    )
                    {
                        RemoveStoItem(i);
                        FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded,
                            stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                    }
                }

                //
                // DECREASE NON-AMMO & AMMO (NO INFINITY SUPPLY)
                //
                if (stoHeaderModded.type == 0 || // if it's a store
                    stoHeaderModded.type == 1 ||
                    stoHeaderModded.type == 2 ||
                    stoHeaderModded.type == 3
                   )
                {
                    if (currentStoItemForSale.infiniteSupplyFlag == 0)
                    {
                        // DECREASE ITEMS (NON-AMMO)
                        if (
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 5) &&
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 14) &&
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 24) &&
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 31)
                        )
                        {
                            Console.WriteLine("NON-AMMO FOUND: " + currentStoItemForSale.itmFileName + " in " +
                                              currentStoFileInfo.Name);
                            if (currentStoItemForSale.amountInStock >= 5)
                            {
                                currentStoItemForSale.amountInStock = 4;
                                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded,
                                    stoCuresModded, stoItemsPurchasedModded,
                                    stoOutputPath + "/" + currentStoFileInfo.Name);
                            }
                            else if (currentStoItemForSale.amountInStock < 5 && currentStoItemForSale.amountInStock > 1)
                            {
                                currentStoItemForSale.amountInStock = 2;
                                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded,
                                    stoCuresModded, stoItemsPurchasedModded,
                                    stoOutputPath + "/" + currentStoFileInfo.Name);
                            }
                        }

                        // DECREASE ITEMS (AMMO)
                        else
                        {
                            int totalNum = currentStoItemForSale.quantity1 * currentStoItemForSale.amountInStock;
                            Console.WriteLine("AMMO FOUND: " + currentStoItemForSale.itmFileName + " in " +
                                              currentStoFileInfo.Name + " with a total amount of " + totalNum +
                                              " (quantity1 " + currentStoItemForSale.quantity1 + " + instock " +
                                              currentStoItemForSale.amountInStock + ")");
                            if (totalNum <= 2)
                            {
                                currentStoItemForSale.quantity1 = 10;
                                currentStoItemForSale.amountInStock = 1;
                            }
                            else if (totalNum <= 50)
                            {
                                currentStoItemForSale.quantity1 = 10;
                                currentStoItemForSale.amountInStock = 5;
                            }
                            else if (totalNum <= 100)
                            {
                                currentStoItemForSale.quantity1 = 10;
                                currentStoItemForSale.amountInStock = 10;
                            }
                            else if (totalNum <= 200)
                            {
                                currentStoItemForSale.quantity1 = 10;
                                currentStoItemForSale.amountInStock = 20;
                            }
                            else if (totalNum <= 300)
                            {
                                currentStoItemForSale.quantity1 = 10;
                                currentStoItemForSale.amountInStock = 30;
                            }
                            else if (totalNum <= 400)
                            {
                                currentStoItemForSale.quantity1 = 10;
                                currentStoItemForSale.amountInStock = 40;
                            }
                            else
                            {
                                currentStoItemForSale.quantity1 = 10;
                                currentStoItemForSale.amountInStock = 50;
                            }

                            FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded,
                                stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                        }
                    }
                    //
                    // CHANGE INFINITE SUPPLY
                    //
                    else
                    {
                        // DECREASE ITEMS (NON-AMMO)
                        if (
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 5) &&
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 14) &&
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 24) &&
                            !FindStoItemType(GetItemFileName(currentStoItemForSale), 31)
                        )
                        {
                            Console.WriteLine("INFINITE NON-AMMO FOUND: " + currentStoItemForSale.itmFileName + " in " +
                                              currentStoFileInfo.Name);
                            currentStoItemForSale.amountInStock = 5;
                            currentStoItemForSale.infiniteSupplyFlag = 0;
                            FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded,
                                stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                        }
                        // DECREASE ITEMS (AMMO)
                        else
                        {
                            Console.WriteLine("INFINITE AMMO FOUND: " + currentStoItemForSale.itmFileName + " in " +
                                              currentStoFileInfo.Name);
                            currentStoItemForSale.quantity1 = 10;
                            currentStoItemForSale.amountInStock = 50;
                            currentStoItemForSale.infiniteSupplyFlag = 0;
                            FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded,
                                stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                        }
                    }
                }

                // SET HORN OF EVIL COUNT TO 1
                if (
                    ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "MH#MISC5") // HORN OF GOODNESS/EVIL
                )
                {
                    currentStoItemForSale.amountInStock = 1;
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
                
                // GIVE CRYSTAL BALL DETECT ILLUSION ABILITY
                if (
                    ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "MH#MISC3") // CRYSTAL BALL
                )
                {
                    currentStoItemForSale.quantity1 = 10;
                    currentStoItemForSale.quantity2 = 10;
                }
                
                // INCREASE ITEM QUANTITY FOR GOLEM BUILDING
                if (
                    ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "A7!") && !ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "TOM") // GOLEM CONSTRUCTION ITEMS
                )
                {
                    currentStoItemForSale.amountInStock = currentStoItemForSale.amountInStock * 2;
                    // Console.WriteLine(currentStoItemForSale.itmFileName);
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }

                index++;
            }

            ////
            /// THESE FUNCTIONS NEED TO BE SEQUENTIALLY AFTER THE PREVIOUS METHODS, BECAUSE THEY ADD ITEMS,
            /// THAT ARE NOT CONTAINED IN THE ITM SOURCE DIR AND WOULD NORMALLY BE DELETED BY THE METHODS
            /// FOR FINDING AND DELETING EMPTY CONTAINER ITEMS ABOVE
            ///
            /// THESE NEXT FUNCTIONS ADD THE NEW AMMO BELT AND THE NEW WANDS
            ///
            
            // Delete Ammo duplicate ammo belt in Quartermaster's Store and Add custom one (SOD)
            if (ContainsCaseInsensitive(currentStoFileInfo.Name, "BDBELEG4."))
            {
                for (int i = 0; i < stoItemsForSaleModded.Count; i++)
                {
                    currentStoItemForSale = (StoItem) stoItemsForSaleModded[i];
                    if (ContainsCaseInsensitive(currentStoItemForSale.itmFileName, "BAG05"))
                    {
                        // Console.WriteLine("got here");
                        RemoveStoItem(i);
                        // AddStoItem("BAG", 0, 0, 0, 1);
                        // stoItem.itmFileName = "BAG00";
                        // FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                
                    }
                }
                AddStoItem("ammobelt", 1, 0, 0, 1);
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // create bag27 with starting items
            if (ContainsCaseInsensitive(currentStoFileInfo.Name, "BAG27."))
            {
                AddStoItem("MH#RING1", 0, 0, 0, 1);
                AddStoItem("MH#IOUN7", 0, 0, 0, 1);
                AddStoItem("MH#IOUN5", 0, 0, 0, 1);
                
                // AddStoItem("MH#PLAT1", 0, 0, 0, 1);
                // AddStoItem("MH#SPER1", 0, 0, 0, 1);
                
                // AddStoItem("X#XZRING", 0, 0, 0, 1);
                // AddStoItem("X#TOME", 0, 0, 0, 1);
                // AddStoItem("X#WINAMU", 0, 0, 0, 1);
                // AddStoItem("X#RINGRO", 0, 0, 0, 1);
                // AddStoItem("X#KISPR", 0, 0, 0, 1);
                // AddStoItem("X#JACLUB", 0, 0, 0, 1);
                // AddStoItem("X#IAMUL", 0, 0, 0, 1);
                // AddStoItem("X#GARCH2", 0, 0, 0, 1);
                // AddStoItem("X#FASH01", 0, 0, 0, 1);
                // AddStoItem("X#COAMUL", 0, 0, 0, 1);
                    
                AddStoItem("OHDPOTN1", 1, 0, 0, 5);
                
                AddStoItem("SCRL87", 3, 0, 0, 1);
                AddStoItem("SCRL1H", 3, 0, 0, 1);
                AddStoItem("SCRL1O", 3, 0, 0, 1);
                AddStoItem("SCRL1L", 3, 0, 0, 1);
                AddStoItem("SCRL2B", 3, 0, 0, 1);
                AddStoItem("SCRL1R", 3, 0, 0, 1);
                AddStoItem("SCRL1Y", 3, 0, 0, 1);
                AddStoItem("SCRL5G", 3, 0, 0, 1);
                AddStoItem("SCRL6D", 3, 0, 0, 1);
                AddStoItem("SCRL6J", 3, 0, 0, 1);
                AddStoItem("SCRL6H", 3, 0, 0, 1);
                AddStoItem("SCRL6I", 3, 0, 0, 1);
                AddStoItem("SCRL6O", 3, 0, 0, 1);
                AddStoItem("SCRL6P", 3, 0, 0, 1);
                AddStoItem("SCRL81", 3, 0, 0, 1);
                AddStoItem("SCRL85", 3, 0, 0, 1);
                AddStoItem("SCRL86", 3, 0, 0, 1);
                AddStoItem("SCRL90", 3, 0, 0, 1);
                AddStoItem("SCRL96", 3, 0, 0, 1);
                AddStoItem("SCRL97", 3, 0, 0, 1);
                AddStoItem("SCRL99", 3, 0, 0, 1);
                AddStoItem("SCRLA3", 3, 0, 0, 1);
                AddStoItem("SCRLA5", 3, 0, 0, 1);
                AddStoItem("SCRLA7", 3, 0, 0, 1);
                
                AddStoItem("MISC82", 0, 0, 0, 1);
                
                AddStoItem("THRING01", 0, 0, 0, 1);
                AddStoItem("THRING02", 0, 0, 0, 1);
                AddStoItem("THDAGG02", 0, 0, 0, 2);
                AddStoItem("THCLCK01", 0, 0, 0, 1);
                AddStoItem("THCLCK02", 0, 0, 0, 1);
                AddStoItem("THBELT01", 0, 0, 0, 1);
                AddStoItem("THAMUL01", 0, 0, 0, 1);
                AddStoItem("THBOOT01", 0, 0, 0, 1);

                AddStoItem("SW1H47", 0, 0, 0, 1);
                AddStoItem("SW1H49", 0, 0, 0, 1);
                AddStoItem("PLAT04", 0, 0, 0, 1);
                AddStoItem("SHLD17A", 0, 0, 0, 1);
                AddStoItem("SHLD06A", 0, 0, 0, 1);
                
                AddStoItem("MH#WAND1", 20, 20, 0, 1);
                AddStoItem("MH#WAND2", 20, 0, 0, 1);
                AddStoItem("BDWAND01", 20, 0, 0, 1);
                AddStoItem("OHDWAND1", 20, 0, 0, 1);
                AddStoItem("OHNWAND1", 20, 0, 0, 1);
                AddStoItem("WAND02", 20, 0, 0, 1);
                AddStoItem("WAND03", 20, 0, 0, 1);
                AddStoItem("WAND04", 20, 0, 0, 1);
                AddStoItem("WAND05", 20, 20, 0, 1);
                AddStoItem("WAND06", 20, 20, 0, 1);
                AddStoItem("WAND07", 20, 0, 0, 1);
                AddStoItem("WAND08", 20, 0, 0, 1);
                AddStoItem("WAND09", 20, 0, 0, 1);
                AddStoItem("WAND10", 20, 0, 0, 1);
                AddStoItem("WAND11", 20, 0, 0, 1);
                AddStoItem("WAND12", 20, 0, 0, 1);
                AddStoItem("WAND13", 20, 0, 0, 1);
                // AddStoItem("WAND15", 20, 0, 0, 1); WAND OF APPRENTI (WILL BE GIVEN LATER IN BG2)
                AddStoItem("WAND18", 20, 0, 0, 1);
                AddStoItem("WAND19", 20, 0, 0, 1);
                AddStoItem("WANDSKEL", 20, 0, 0, 1);
                AddStoItem("WANDSKUL", 20, 0, 0, 1);
                AddStoItem("WANDSHAD", 20, 0, 0, 1);
                AddStoItem("WANDCHAO", 20, 0, 0, 1);

                // AddStoItem("MISC07", 10000, 0, 0, 1);
                
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                //
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                // AddStoItem("MISC07", 32000, 0, 0, 1);
                
                // AddStoItem("A7!TOM01", 0, 0, 0, 1);
                
                // AddStoItem("OHDWAND1", 25, 0, 0, 1);
                
                AddStoItem("POTN36", 1, 0, 0, 12);
                
                AddStoItem("AROW06", 120, 0, 0, 1);
                AddStoItem("AROW07", 120, 0, 0, 1);
                AddStoItem("AROW02", 360, 0, 0, 1);
                AddStoItem("AROW11", 120, 0, 0, 1);
                AddStoItem("BOLT05", 120, 0, 0, 1);
                AddStoItem("BOLT02", 360, 0, 0, 1);
                AddStoItem("BOLT06", 120, 0, 0, 1);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }

            
            ////////////
            // TESTING
            ////////////
            // if (currentStoFileInfo.Name.Contains("INN2616"))
            // {
            //     foreach (StoDrink item in stoDrinks)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.drinkName);
            //     }
            //     
            //     foreach (StoCure item in stoCures)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.splResource);
            //     }
            //     
            //     foreach (StoItem item in stoItemsForSale)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.itmFileName);
            //     }
            //     
            //     foreach (int item in stoItemsPurchasedModded)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item);
            //     }
            // }

            // foreach (StoItem stoItem in stoItemsForSale)
            // {
            //     if (stoItem.amountInStock > 5)
            //     {
            //         curren
            //     }
            // }

            // foreach (StoItem stoItem in stoItemsForSaleModded)
            // {
            //     if (ContainsCaseInsensitive(stoItem.itmFileName, "WAND"))
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + stoItem.itmFileName + " : " + stoItem.amountInStock);
            //     }
            // }
        }

        internal static void AddStoItem(String resource, short quantity1, short quantity2, short quantity3, int amount)
        {
            int maxSize = 8;
            int delta = maxSize - resource.Length;
            if (delta < 0)
            {
                throw new Exception("ERROR: NAME LENGTH TOO LARGE");
            }

            stoItemsForSaleModded.Add(new StoItem(resource + new string(new char[delta]), 0, quantity1, quantity2, quantity3, GetBitfieldInt(new int[] {0}), amount, 0));
        }

        internal static void RemoveStoItem(int index)
        {
            stoItemsForSaleModded.RemoveAt(index);
        }

        internal static Boolean FindStoItemType(String fileName, int itemType)
        {
            String filePath = itmInputDirectory + @"\" + fileName;
            // Console.WriteLine(filePath);
            if (FileOperations.CheckFilePath(filePath))
            {
                CreateItmObjects(fileName);
                if (itmHeaderModded.itemType == itemType)
                {
                    // Console.WriteLine("true");
                    return true;
                }
                else
                {
                    // Console.WriteLine("false");
                    return false;
                }
            }
            else
            {
                throw new Exception("COULD NOT FIND ITM FILE!");
            }
        }
    }
}