﻿using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void CheckIfItemsAvailableInGame()
        {
            // FilterFiles();
            CreateTlkObjects();
            String findStr;
            ArrayList strList = new ArrayList();
            foreach (FileInfo sto in stos)
            {
                currentStoFileInfo = sto;
                CreateStoObjects();
                foreach (StoItem stoItem in stoItemsForSaleModded)
                {
                    findStr = stoItem.itmFileName.Replace("\u0000", "");
                    if (!strList.Contains(findStr))
                    {
                        strList.Add(findStr);
                    }
                }
            }
            foreach (FileInfo are in ares)
            {
                currentAreFileInfo = are;
                CreateAreObjects();
                foreach (AreItem areItem in areItemsModded)
                {
                    findStr = areItem.resource.Replace("\u0000", "");
                    if (!strList.Contains(findStr))
                    {
                        strList.Add(findStr);
                    }
                }
            }
            foreach (FileInfo cre in cres)
            {
                currentCreFileInfo = cre;
                CreateCreObjects();
                foreach (CreItem creItem in creItemsModded)
                {
                    findStr = creItem.resource.Replace("\u0000", "");
                    if (!strList.Contains(findStr))
                    {
                        strList.Add(findStr);
                    }
                }
            }

            String[] strings = strList.Cast<string>().ToArray();
            FileOperations.WriteFileAsString(String.Join("\n", strings), @"D:\text.txt");
            
            foreach (FileInfo item in items)
            {
                String searchName = item.Name.Replace(".itm", "").Replace(".ITM", "");
                // Console.WriteLine(searchName);
                Boolean found = false;
                
                currentItemFileInfo = item;
                CreateItmObjects();
            
                if (!ContainsCaseInsensitive(String.Join("      ", strings), searchName) && IsDroppable())
                {
                    Console.WriteLine("Could not find item:     \"" + searchName + "\"");
                }
            }
        }

        internal static void DisplayAllNonDroppableItems()
        {
            foreach (FileInfo item in items)
            {
                currentItemFileInfo = item;
                CreateItmObjects();
            
                if (!IsDroppable() && itmHeaderModded.itemType <= 10)
                {
                    foreach (ItmFeatBlock itmFeatBlock in itmEffFeatBlocksModded)
                    {
                        if (itmFeatBlock.opcodeNumber == 126 || itmFeatBlock.opcodeNumber == 176)
                        {
                            Console.WriteLine(item.Name);
                        }
                    }
                }
            }
        }

        internal static void SaveAllCreatureXps()
        {
            StringBuilder sb = new StringBuilder();
            foreach (FileInfo cre in cres)
            {
                currentCreFileInfo = cre;
                CreateCreObjects();
                sb.Append(cre.Name + "\t" + creHeaderModded.xpKill + "\n");
            }
            FileOperations.WriteFileAsString(sb.ToString(), @"D:\exp.txt");
        }

        internal static void DisplayAllCreatureXpsNotEndingWithZero()
        {
            foreach (FileInfo cre in cres)
            {
                currentCreFileInfo = cre;
                CreateCreObjects();
                if (creHeaderModded.xpKill % 10 != 0 && creHeaderModded.xpKill.ToString().Length > 1)
                {
                    int newVal = Int32.Parse(creHeaderModded.xpKill.ToString().Remove(creHeaderModded.xpKill.ToString().Length - 1, 1).Insert(creHeaderModded.xpKill.ToString().Length - 1, "0"));
                    Console.WriteLine(cre.Name + "\t" + creHeaderModded.xpKill);
                    Console.WriteLine(cre.Name + "\t" + newVal);
                }
            }
        }

        internal static void GetCreaturesWithGreaterOrEqualExp(int expVal)
        {
            
            DirectoryInfo dir = new DirectoryInfo(@"D:\Games\BG1EE\override");
            FileInfo[] cresRaw = dir.GetFiles("*.cre");
            foreach (FileInfo cre in cresRaw)
            {
                currentCreFileInfo = cre;
                CreateCreObjects();

                if (creHeaderModded.xpKill >= expVal)
                {
                    Console.WriteLine(currentCreFileInfo.Name);
                }
            }
        }

        internal static void FindAllAddXPObjects()
        {
            foreach (FileInfo dlg in dlgs)
            {
                currentDlgFileInfo = dlg;
                CreateDlgObjects();
                // Console.WriteLine(currentDlgFileInfo.Name);
                foreach (DlgActionTable dlgActionTable in dlgActionTables)
                {
                    Regex regex = new Regex(".*AddXPObject.*");
                    MatchCollection matches = regex.Matches(dlgActionTable.str);
                    if (matches.Count > 0)
                    {
                        Console.WriteLine("FOUND in " + currentDlgFileInfo.Name);
                        foreach (Match match in matches)
                        {
                            Console.WriteLine(match.Value);
                        }
                    }
                }
                
                // else
                // {
                //     Console.WriteLine("NOT FOUND in " + currentDlgFileInfo.Name);
                // }
            }
        }
    }
}