﻿using System;
using System.Text;

namespace BGEE_revisions
{
    // Spell form 1 - Standard 2 - Projectile
    // bit 2: ‘Friendly’ ability
    // Location
    // Memorised icon (BAM). The engine replaces the last character of this filename with a B.
    // Target:  0 = Invalid (target cannot be selected) 1 = Creature / Living actor 2 = Crash 3 = Dead actor To be precise, it can target living and dead actors. It really just ignores any range requirement, including being in the same area. 4 = Area 5 = Self 6 = Crash 7 = None (Self, ignores game pause)
    // Target Number
    // Range (in ft.)
    // Level Required
    // Casting Time
    // Times per day
    // Dice Sides (unused)
    // Dice Thrown (unused)
    // Enchanted (unused)
    // Damage Type (unused)
    // Count of feature blocks
    // Offset to feature blocks
    // Charges (unused)
    // Charge depletion behaviour (unused)
    // Projectile (BG2: projectl.ids. Note: in BG2, this value is off-by-one from projectl.ids value. I.e. binary value of 2 corresponds to 0x1 - ARROW)
    
    internal class SplExtendedHeader
    {
        internal static int size = 40; // extended header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal byte spellForm;
        internal byte friendlyAbility;
        internal short location;
        internal String memorizedIcon;
        internal byte target;
        internal byte targetNumber;
        internal short range;
        internal short levelRequired;
        internal short castingTime;
        internal short timesPerDay;
        internal short diceSides;
        internal short diceThrown;
        internal short enchanted;
        internal short damageType;
        internal short featureBlockCount;
        internal short featureBlockIndex;
        internal short charges;
        internal short chargeDepletionBehaviour;
        internal short projectile;

        internal SplExtendedHeader(byte spellForm, byte friendlyAbility, short location, String memorizedIcon, byte target, byte targetNumber , short range, short levelRequired, short castingTime, short timesPerDay, short diceSides, short diceThrown, short enchanted, short damageType, short featureBlockCount, short featureBlockIndex, short charges, short chargeDepletionBehaviour, short projectile)
        {
            this.spellForm = spellForm;
            this.friendlyAbility = friendlyAbility;
            this.location = location;
            this.memorizedIcon = memorizedIcon;
            this.target = target;
            this.targetNumber = targetNumber;
            this.range = range;
            this.levelRequired = levelRequired;
            this.castingTime = castingTime;
            this.timesPerDay = timesPerDay;
            this.diceSides = diceSides;
            this.diceThrown = diceThrown;
            this.enchanted = enchanted;
            this.damageType = damageType;
            this.featureBlockCount = featureBlockCount;
            this.featureBlockIndex = featureBlockIndex;
            this.charges = charges;
            this.chargeDepletionBehaviour = chargeDepletionBehaviour;
            this.projectile = projectile;
        }
        internal SplExtendedHeader(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            spellForm = ConvertToByteData();
            friendlyAbility = ConvertToByteData();
            location = ConvertToShortData();
            memorizedIcon = ConvertToStringData(8);
            target = ConvertToByteData();
            targetNumber = ConvertToByteData();
            range = ConvertToShortData();
            levelRequired = ConvertToShortData();
            castingTime = ConvertToShortData();
            timesPerDay = ConvertToShortData();
            diceSides = ConvertToShortData();
            diceThrown = ConvertToShortData();
            enchanted = ConvertToShortData();
            damageType = ConvertToShortData();
            featureBlockCount = ConvertToShortData();
            featureBlockIndex = ConvertToShortData();
            charges = ConvertToShortData();
            chargeDepletionBehaviour = ConvertToShortData();
            projectile = ConvertToShortData();

            size = baseOffset - offset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }
        
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal char ConvertToCharData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return BitConverter.ToChar(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }
        
        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(spellForm);
            CopyBytesToArray(friendlyAbility);
            CopyBytesToArray(location);
            CopyBytesToArray(memorizedIcon);
            CopyBytesToArray(target);
            CopyBytesToArray(targetNumber);
            CopyBytesToArray(range);
            CopyBytesToArray(levelRequired);
            CopyBytesToArray(castingTime);
            CopyBytesToArray(timesPerDay);
            CopyBytesToArray(diceSides);
            CopyBytesToArray(diceThrown);
            CopyBytesToArray(enchanted);
            CopyBytesToArray(damageType);
            CopyBytesToArray(featureBlockCount);
            CopyBytesToArray(featureBlockIndex);
            CopyBytesToArray(charges);
            CopyBytesToArray(chargeDepletionBehaviour);
            CopyBytesToArray(projectile);
            
            return byteArray;
        }
        
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(char variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
        
        internal void PrintValues()
        {
            Console.WriteLine("spellForm:\t" + spellForm);
            Console.WriteLine("friendlyAbility:\t" + friendlyAbility);
            Console.WriteLine("location:\t" + location);
            Console.WriteLine("memorizedIcon:\t" + memorizedIcon);
            Console.WriteLine("target:\t" + target);
            Console.WriteLine("targetNumber:\t" + targetNumber);
            Console.WriteLine("range:\t" + range);
            Console.WriteLine("levelRequired:\t" + levelRequired);
            Console.WriteLine("castingTime:\t" + castingTime);
            Console.WriteLine("timesPerDay:\t" + timesPerDay);
            Console.WriteLine("diceSides:\t" + diceSides);
            Console.WriteLine("diceThrown:\t" + diceThrown);
            Console.WriteLine("enchanted:\t" + enchanted);
            Console.WriteLine("damageType:\t" + damageType);
            Console.WriteLine("featureBlockCount:\t" + featureBlockCount);
            Console.WriteLine("featureBlockOffset:\t" + featureBlockIndex);
            Console.WriteLine("charges:\t" + charges);
            Console.WriteLine("chargeDepletionBehaviour:\t" + chargeDepletionBehaviour);
            Console.WriteLine("projectile:\t" + projectile);
        }
    }
}