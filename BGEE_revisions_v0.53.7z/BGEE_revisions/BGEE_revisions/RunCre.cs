﻿using System;
using System.Collections;
using System.Linq;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunCre()
        {
            // rename skeletons according to HPs
            if (EqualsCaseInsensitive(GetTlkStringFromStrRef(creHeader.name), "Skeleton") ||
                EqualsCaseInsensitive(GetTlkStringFromStrRef(creHeader.name), "Skeleton Warrior")
            )
            {
                if (creHeader.maxHp >= 1 && creHeader.maxHp < 9)
                {
                    creHeader.name = AddExactTlkEntryIfNotFound("Lesser Skeleton");
                    creHeader.tooltip = AddExactTlkEntryIfNotFound("Lesser Skeleton");
                }
                else if (creHeader.maxHp >= 9 && creHeader.maxHp < 40)
                {
                    creHeader.name = AddExactTlkEntryIfNotFound("Skeleton");
                    creHeader.tooltip = AddExactTlkEntryIfNotFound("Skeleton");
                }
                else if (creHeader.maxHp >= 40 && creHeader.maxHp < 80)
                {
                    creHeader.name = AddExactTlkEntryIfNotFound("Greater Skeleton");
                    creHeader.tooltip = AddExactTlkEntryIfNotFound("Greater Skeleton");
                }
                // else if (creHeader.maxHp >= 60 && creHeader.maxHp < 80)
                // {
                //     creHeader.name = AddExactTlkEntryIfNotFound("Skeleton Monster");
                //     creHeader.tooltip = AddExactTlkEntryIfNotFound("Skeleton Monster");
                // }
                else if (creHeader.maxHp >= 80)
                {
                    creHeader.name = AddExactTlkEntryIfNotFound("Skeleton Warrior");
                    creHeader.tooltip = AddExactTlkEntryIfNotFound("Skeleton Warrior");
                }
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod loup garou (remove silber weapon requirement)
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "LOUPGAR"))
            {
                for (int i = 0; i < creHeaderModded.itemsCount; i++)
                {
                    currentCreItem = (CreItem) creItemsModded[i];
                    if (currentCreItem.resource.Equals("RINGLOUP"))
                    {
                        currentCreItem.resource = "IMMUNE1";
                        FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                            creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                            creOutputPath + "/" + currentCreFileInfo.Name);
                        break;
                    }
                }
            }

            // // mod cultists in Demon Chamber
            // if (ContainsCaseInsensitive(currentCreFileInfo.Name, @"CULTD\d"))
            // {
            //     creHeaderModded.currentHp = 39;
            //     creHeaderModded.maxHp = 39;
            //
            //     foreach (CreItem creItem in creItemsModded)
            //     {
            //         if (ContainsCaseInsensitive(creItem.resource, "POTN09"))
            //         {
            //             creItem.resource = "POTN02" + new string(new char[2]);
            //         }
            //     }
            //
            //     FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
            //         creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
            //         creOutputPath + "/" + currentCreFileInfo.Name);
            // }
            
            // mod shandalar
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "SHANDAL2."))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resMagic = 0;
                creHeaderModded.resMagicCold = 0;
                creHeaderModded.resMagicFire = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                creHeaderModded.currentHp = 72;
                creHeaderModded.maxHp = 72;

                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // REMOVE BG1 MAGE HIGH LEVEL SPELLS [it's dumb]
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "KAHRK") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "CULT") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "CHSAM") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "GALDOR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "HALBAZ") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "KRYSTI") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SHANDA") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DAITEL") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SHALDR")
            )
            {
                // Console.WriteLine(currentCreFileInfo.Name);
                for (int i = creKnownSpellsModded.Count - 1; i >= 0; i--)
                {
                    // Console.WriteLine(i);
                    currentCreKnownSpell = (CreKnownSpell) creKnownSpellsModded[i];
                    if (
                        currentCreKnownSpell.resource.Contains("SPWI6") || 
                        currentCreKnownSpell.resource.Contains("SPWI7") || 
                        currentCreKnownSpell.resource.Contains("SPWI8") || 
                        currentCreKnownSpell.resource.Contains("SPWI9")
                    )
                    {
                        Console.WriteLine("Removed " + currentCreKnownSpell.resource + " in " + currentCreFileInfo.Name);
                        creKnownSpellsModded.RemoveAt(i);
                    }
                }

                for (int i = creMemorizedSpells.Count - 1; i >= 0; i--)
                {
                    // Console.WriteLine(i);
                    currentCreMemorizedSpell = (CreMemorizedSpell) creMemorizedSpellsModded[i];
                    if (
                        currentCreMemorizedSpell.resource.Contains("SPWI6") || 
                        currentCreMemorizedSpell.resource.Contains("SPWI7") || 
                        currentCreMemorizedSpell.resource.Contains("SPWI8") || 
                        currentCreMemorizedSpell.resource.Contains("SPWI9")
                    )
                    {
                        creMemorizedSpellsModded.RemoveAt(i);
                    }
                }
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // REMOVE BG1 PRIEST HIGH LEVEL SPELLS [it's dumb]
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "MADARC") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "BASSIL") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "AMARAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "x#andart") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "CORSON") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "TAMOKO") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OSMADI") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "KAISH") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "WUDEI") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "JALANT") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DIYAB")
            )
            {
                // Console.WriteLine(currentCreFileInfo.Name);
                for (int i = creKnownSpellsModded.Count - 1; i >= 0; i--)
                {
                    // Console.WriteLine(i);
                    currentCreKnownSpell = (CreKnownSpell) creKnownSpellsModded[i];
                    if (
                        currentCreKnownSpell.resource.Contains("SPPR5") || 
                        currentCreKnownSpell.resource.Contains("SPPR6") || 
                        currentCreKnownSpell.resource.Contains("SPPR7")
                    )
                    {
                        Console.WriteLine("Removed " + currentCreKnownSpell.resource + " in " + currentCreFileInfo.Name);
                        creKnownSpellsModded.RemoveAt(i);
                    }
                }

                for (int i = creMemorizedSpells.Count - 1; i >= 0; i--)
                {
                    // Console.WriteLine(i);
                    currentCreMemorizedSpell = (CreMemorizedSpell) creMemorizedSpellsModded[i];
                    if (
                        currentCreMemorizedSpell.resource.Contains("SPPR5") || 
                        currentCreMemorizedSpell.resource.Contains("SPPR6") || 
                        currentCreMemorizedSpell.resource.Contains("SPPR7")
                    )
                    {
                        creMemorizedSpellsModded.RemoveAt(i);
                    }
                }
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod wolf of ulcaster (ridiculous hp)
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "dw#ulcwo."))
            {
                creHeaderModded.currentHp = 75;
                creHeaderModded.maxHp = 75;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod daerragh (ring of fire resistance)
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "daerragh."))
            {
                foreach (CreItem creItem in creItemsModded)
                {
                    if (ContainsCaseInsensitive(creItem.resource, "RINGITF"))
                    {
                        creItem.resource = "RING02" + new string(new char[2]);
                        FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                            creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                            creOutputPath + "/" + currentCreFileInfo.Name);
                    }
                }
            }

            // mod borda
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "BORDA."))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resMagic = 0;
                creHeaderModded.resMagicCold = 0;
                creHeaderModded.resMagicFire = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod DRELIK
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "DRELIK."))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resMagic = 0;
                creHeaderModded.resMagicCold = 0;
                creHeaderModded.resMagicFire = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod drizzt
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "DRIZZ"))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // MAKE QUAYLE AND JAN REGULAR MAGES
            if (
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Jan") &&
                GetTlkStringFromStrRef(creHeaderModded.tooltip).Equals("Jan") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Quayle") &&
                GetTlkStringFromStrRef(creHeaderModded.tooltip).Equals("Quayle")
            )
            {
                creHeaderModded.kitInfo = 0;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod MARL
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "MARL."))
            {
                creHeaderModded.xpKill = 900;
                
                // creItemSlotsModded.PrintValues();
                // Console.WriteLine("==============");
                // creItemSlots.PrintValues();

                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }

            // patch super low saving throws of creatures
            if (
                creHeaderModded.sound4 < 1 || creHeaderModded.sound4 > 500000 &&
                creHeaderModded.sound5 < 1 || creHeaderModded.sound5 > 500000 &&
                creHeaderModded.sound6 < 1 || creHeaderModded.sound6 > 500000
            )
            {
                if (creHeaderModded.saveSpell < 5)
                {
                    creHeaderModded.saveSpell = 5;
                }
                if (creHeaderModded.saveBreath < 5)
                {
                    creHeaderModded.saveBreath = 5;
                }
                if (creHeaderModded.saveDeath < 5)
                {
                    creHeaderModded.saveDeath = 5;
                }
                if (creHeaderModded.savePoly < 5)
                {
                    creHeaderModded.savePoly = 5;
                }
                if (creHeaderModded.saveWands < 5)
                {
                    creHeaderModded.saveWands = 5;
                }
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            // else
            // {
            //     Console.WriteLine(currentCreFileInfo.Name);
            // }
            
            // remove see through invisibility for enemies
            for (int i = creEffectsModded.Count - 1; i >= 0; i--)
            {
                CreEffect currentCreEffect = (CreEffect)creEffectsModded[i];
                if (currentCreEffect.opcode == 193)
                {
                    RemoveCreEffect(i);
                    
                    
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
            }
            
            // patch flaming fists to regular fighters (it's silly that you lose reputation for killing them, when they are hostile against you in Baldur's Gate after the killings of Rieltar & co (simple because you can't avoid killing them and have to bend over backwards just to prevent this from happening if you don't play evil.
            if (creHeaderModded.classId == 156 || creHeaderModded.classId == 212)
            {
                creHeaderModded.classId = 2;
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }

            // prevent all non-innocent npc from affecting your rep when killed
            if (creHeaderModded.repLossKilled != 0)
            {
                creHeaderModded.repLossKilled = 0;
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // prevent amnian and flaming fist soldiers from being innocent byte name
            String[] names = new[]
            {
                "Amnian", 
                "Amnish", 
                "Thayan", 
                "Bodyguard", 
                "Flaming Fist Enforcer", 
                "Flaming Fist Scout", 
                "Flaming Fist Mercenary", 
                "Flaming Fist Officer", 
                "Flaming Fist Veteran", 
                "Flaming Fist Watcher", 
                "Flaming Fist Sergeant", 
            };
            if (names.Contains(GetTlkStringFromStrRef(creHeaderModded.name)))
            {
                creHeaderModded.classId = 2;
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make misc people CLERICS since they use cleric spells
            names = new[]
            {
                "Flaming Fist Healer",  
            };
            if (
                    names.Contains(GetTlkStringFromStrRef(creHeaderModded.name)) ||
                    ContainsCaseInsensitive(currentCreFileInfo.Name, "UNSHEY.")
                )
            {
                creHeaderModded.classId = 3;
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make misc people DRUIDS since they use classes 
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "LASKAL"))
            {
                creHeaderModded.classId = 11;
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make misc people THIEVES since they use classes 
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "BREVLI.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "BHEREN.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "CORDYR.")
            )
            {
                creHeaderModded.classId = 205;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // Increase golems health points
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "a7!gl"))
            {
                creHeaderModded.currentHp = Convert.ToInt16(creHeaderModded.currentHp * 1.5);
                creHeaderModded.maxHp = Convert.ToInt16(creHeaderModded.maxHp * 1.5);
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // remove backstab modifier for enemies
            for (int i = creEffectsModded.Count - 1; i >= 0; i--)
            {
                CreEffect currentCreEffect = (CreEffect)creEffectsModded[i];
                if (currentCreEffect.opcode == 263)
                {
                    RemoveCreEffect(i);                    
                    
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
            }

            // adjust Valygar
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "Valyg")
            )
            {
                creHeaderModded.con = 18;
                
                RemoveAllCreEffects(233);
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }

            // make dorn somewhat tankier 
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DORN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHB2DORN")
            )
            {
                creHeaderModded.con = 17;
                creHeaderModded.dex = 14;
                creHeaderModded.wis = 13;
                creHeaderModded.cha = 11;
                // creHeaderModded.currentHp = 14;
                // creHeaderModded.maxHp = 14;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                                        creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make minsc more competitive with the other fighters, better stats, better profs, give him more berserk charges
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "MINSC") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "E32.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHB1MNSC.")
                )
            {
                creHeaderModded.con = 18;
                creHeaderModded.strBonus = 95;

                for (int i = creEffectsModded.Count - 1; i >= 0; i--)
                {
                    currentCreEffect = (CreEffect)creEffectsModded[i];
                    if (currentCreEffect.parameter2 == 101)
                    {
                        RemoveCreEffect(i);
                    }
                }

                foreach (CreEffect creEffect in creEffectsModded)
                {
                    if (creEffect.opcode == 233 && creEffect.parameter2 == 104) // LONGBOW
                    {
                        creEffect.parameter1 = 2;
                    }
                    else if (creEffect.opcode == 233 && creEffect.parameter2 == 93) // TWO-HANDED SWORD
                    {
                        creEffect.parameter2 = 90; // LONG SWORD
                    }
                }

                foreach (CreItem creItem in creItems)
                {
                    if (creItem.resource.Contains("SW2H01"))
                    {
                        creItem.resource = "SW1H04Q"; // quality long sword
                    }
                }

                AddCreSpell(16, "SPIN117" + new char(), 0, 2, GetBitfieldShort(new int[] {}));
                AddCreSpell(16, "SPIN117" + new char(), 0, 2, GetBitfieldShort(new int[] {}));
                AddCreSpell(16, "SPIN117" + new char(), 0, 2, GetBitfieldShort(new int[] {}));
                AddCreSpell(16, "SPIN117" + new char(), 0, 2, GetBitfieldShort(new int[] {}));
                AddCreSpell(16, "SPIN117" + new char(), 0, 2, GetBitfieldShort(new int[] {}));

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make Rasaad more skilled
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "RASAAD") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHB1RASD")
            )
            {
                creHeaderModded.con = 16;
                creHeaderModded.dex = 18;
                creHeaderModded.wis = 18;
                creHeaderModded.str = 17;
                // creHeaderModded.currentHp = 10;
                // creHeaderModded.maxHp = 10;
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make corwins stats more sensible
            if (ContainsCaseInsensitive(currentName, "CORWIN"))
            {
                creHeaderModded.dex = 18;
                creHeaderModded.str = 16;
                creHeaderModded.strBonus = 0;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // give Dynaheir 18 int
            if (ContainsCaseInsensitive(currentName, "DYNA"))
            {
                creHeaderModded.intelligence = 18;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            //
            
            // remove edwin's amulet
            // if (ContainsCaseInsensitive(currentCreFileInfo.Name, "EDWIN"))
            // {
            //     foreach (CreItem creItem in creItemsModded)
            //     {
            //         if (ContainsCaseInsensitive(creItem.resource, "MISC89"))
            //         {
            //             creItem.resource = "AMUL11" + new string(new char[2]);
            //     
            //             FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
            //                 creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
            //                 creOutputPath + "/" + currentCreFileInfo.Name);
            //         }
            //     }
            // }
            
            // make baeloth level 1 NPC
            if (EqualsCaseInsensitive("BAELOTH.CRE", currentCreFileInfo.Name))
            {
                creHeaderModded.levelClass1 = 1;
            
                creHeaderModded.currentHp = 4;
                creHeaderModded.maxHp = 4;
            
                currentCreMemorizedSpellsInfo = (CreMemorizedSpellsInfo) creMemorizedSpellsInfosModded[9];
                currentCreMemorizedSpellsInfo.spellsMemorizable = 0;
                currentCreMemorizedSpellsInfo.spellsCurrMemorizable = 0;
                currentCreMemorizedSpellsInfo.spellCount = 0;
                
                currentCreMemorizedSpellsInfo = (CreMemorizedSpellsInfo) creMemorizedSpellsInfosModded[8];
                currentCreMemorizedSpellsInfo.spellsMemorizable = 0;
                currentCreMemorizedSpellsInfo.spellsCurrMemorizable = 0;
                currentCreMemorizedSpellsInfo.spellCount = 0;
                
                currentCreMemorizedSpellsInfo = (CreMemorizedSpellsInfo) creMemorizedSpellsInfosModded[7];
                currentCreMemorizedSpellsInfo.spellsMemorizable = 8;
                currentCreMemorizedSpellsInfo.spellsCurrMemorizable = 8;
                currentCreMemorizedSpellsInfo.spellCount = 8;
                
                creMemorizedSpells.Clear();

                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI114" + new char(), 0));
                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI114" + new char(), 0));
                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI112" + new char(), 0));
                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI112" + new char(), 0));
                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI112" + new char(), 0));
                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI112" + new char(), 0));
                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI112" + new char(), 0));
                creMemorizedSpells.Add(new CreMemorizedSpell("SPWI112" + new char(), 0));
                
                creEffectsModded.RemoveAt(creEffectsModded.Count-2);
            
                creHeaderModded.xpPower = 500;
                creHeaderModded.thaco = 20;
                creHeaderModded.saveDeath = 14;
                creHeaderModded.saveWands = 11;
                creHeaderModded.savePoly = 13;
                creHeaderModded.saveBreath = 15;
                creHeaderModded.saveSpell = 12;
                creHeaderModded.lore = 3;
                
                creKnownSpellsModded.RemoveRange(3, creKnownSpellsModded.Count - 3); // keep the first five (level 1) spells, remove everything else 
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }

            // patch planetar & devas to be more nice-looking
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DQ#GRSOL") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FANGEL01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOL01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOL04") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLA2") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLA2") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLA3") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLAR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SOLAR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SOLAR01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDPPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDSOLAR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDSPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANET01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANGOOD") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDSPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVAGOOD") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVAST01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVMON01")
            )
            {
                creHeaderModded.animId = 32589;
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            else if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANEVIL") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANWISH") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHBCEL02") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHBCEL03") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHBDVA01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVAEVIL")
            )
            {
                creHeaderModded.animId = 32585;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make BG1 Flesh Golems not look like ogrillions
            if (
                EqualsCaseInsensitive("FGOLEM.CRE", currentCreFileInfo.Name) ||
                EqualsCaseInsensitive("GOLEMF.CRE", currentCreFileInfo.Name) ||
                EqualsCaseInsensitive("GOLEMF2.CRE", currentCreFileInfo.Name)
            )
            {
                creHeaderModded.animId = 57345;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // Give Spectacles of Spectacle more initial Charges
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "BDZAVIAK."))
            {
                for (int i = 0; i < creItemsModded.Count; i++)
                {
                    // Console.WriteLine("got here");
                    currentCreItem = (CreItem)creItemsModded[i];
                    if (currentCreItem.resource.Equals("BDMISC01"))
                    {
                        currentCreItem.charges1 = 10;
                        currentCreItem.charges2 = 10;
                    }
                }
                
                
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // CUSTOM SPELL REVISION CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 
            ///
            ///
            ///
            
            // correct empty items in containers (NULL.itm, RNDTRS.ITM... etc...)
            foreach (CreItem creItem in creItemsModded)
            {
                // CORRECT NON-EXISTING ITEMS
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(creItem))) // if the item file doe not exist in the source path, we can assume this item does not exist
                {
                    String newItem = GetRandomItem();
                    Console.WriteLine("Found non-existing item \"" + creItem.resource + "\" in \"" + currentCreFileInfo.Name + "\"");
                    
                    if (ContainsCaseInsensitive(creItem.resource, "null"))
                    {
                        creItem.resource = "RNDTRE03";
                        creItem.charges1 = 1;
                        creItem.charges2 = 0;
                        creItem.charges3 = 0;
                    }
                    else // else, we replace this with a random item
                    {
                        creItem.resource = "RNDTRE04";
                        creItem.charges1 = 1;
                        creItem.charges2 = 0;
                        creItem.charges3 = 0;
                    }
                    
                    creItem.flags = GetBitfieldInt(new int[] {0});
                    
                    Console.WriteLine("replacing with \"" + creItem.charges1 + "x " + creItem.resource + "\"");

                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
                
                // REMOVE ALL WANDS
                if (ContainsCaseInsensitive(creItem.resource, "wand"))
                {
                    Console.WriteLine("Found WAND item \"" + creItem.resource + "\" in \"" + currentCreFileInfo.Name + "\"");

                    creItem.resource = "RNDTRE04";
                    creItem.charges1 = 1;
                    creItem.charges2 = 0;
                    creItem.charges3 = 0;
                    
                    Console.WriteLine("replacing with \"" + creItem.charges1 + "x " + creItem.resource + "\"");

                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }

                // convert all buggy random items to functioning
                if (ContainsCaseInsensitive(creItem.resource, "RNDTRE08") || ContainsCaseInsensitive(creItem.resource, "RNDTRE09"))
                {
                    creItem.charges1 = 1;
                    creItem.resource = "RNDTRE04";
                    Console.WriteLine("replacing with \"" + creItem.charges1 + "x " + creItem.resource + "\"");
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }

                // OTHER ITEM CHARGE CHANGES
                if (ContainsCaseInsensitive(creItem.resource, "CLCK07")) // cloak of the nymph
                {
                    // Console.WriteLine("got here");
                    creItem.charges1 = 1;
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
                
                // INCREASE MONEY STASHES GLOBALLY
                if (ContainsCaseInsensitive(creItem.resource, "MISC07"))
                {
                    if (creItem.charges1 < 5000)
                    {
                        creItem.charges1 = (short)(creItem.charges1 * 5);
                        Console.WriteLine("FOUND MONEY IN CHAR '" + currentCreFileInfo + "', changed quantity to "+ creItem.charges1);
                    }
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
                
                // /// WAND CHARGE CHANGES
                // // equalize wand charges for all creatures (see item mod for wands)
                // String fileName = GetItemFileName(creItem);
                // // Console.WriteLine(fileName);
                // CreateItmObjects(fileName);
                // if (itmHeaderModded.itemType == 35) // if it's a wand
                // {
                //     if (creItem.charges1 > 0)
                //     {
                //         creItem.charges1 = 15;
                //     }
                //
                //     if (creItem.charges2 > 0)
                //     {
                //         creItem.charges2 = 15;
                //     }
                //
                //     if (creItem.charges3 > 0)
                //     {
                //         creItem.charges3 = 15;
                //     }
                //
                //     // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                //     if (fileName.Contains("WAND06."))
                //     {
                //         creItem.charges1 = 15;
                //         creItem.charges2 = 15;
                //     }
                //     
                //     FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                //         creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                //         creOutputPath + "/" + currentCreFileInfo.Name);
                // }
                
                // REPLACE CURSED SCROLLS WITH RANDOM LOOT
                if (!currentCreFileInfo.Name.Contains("ETTERC1"))
                {
                    if (
                        creItem.resource.Contains("SCRL10") ||
                        creItem.resource.Contains("SCRL11") ||
                        creItem.resource.Contains("SCRL12") ||
                        creItem.resource.Contains("SCRL13") ||
                        creItem.resource.Contains("SCRL14") ||
                        creItem.resource.Contains("SCRL15") ||
                        creItem.resource.Contains("SCRL16") ||
                        creItem.resource.Contains("SCRL17") ||
                        creItem.resource.Contains("SCRL18")
                    )
                    {
                        // Console.WriteLine("got here");
                        creItem.resource = "RNDTRE03";
                        FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                            creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                            creOutputPath + "/" + currentCreFileInfo.Name);
                    }
                }
            }
            
            // REMOVE SOME OF THE POTIONS OF NPCS
            // Random random = new Random();
            // int del = random.Next(0, 1);
            // Console.WriteLine(del);
            // if (del == 1)
            // {
            //     for (int i1 = creItemsModded.Count - 1; i1 >= 0; i1--)
            //     {
            //         currentCreItem = (CreItem) creItemsModded[i1];
            //         if (
            //             currentCreItem.resource.Contains("POTN") ||
            //             currentCreItem.resource.Contains("PTN")
            //         )
            //         {
            //             Console.WriteLine("Changing CRE Potion of " + currentCreFileInfo.Name + " from " + currentCreItem.resource + " to RNDTRE03");
            //             currentCreItem.resource = "RNDTRE03";
            //             FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
            //                 creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
            //                 creOutputPath + "/" + currentCreFileInfo.Name);
            //         }
            //     }
            // }
            
            //      CHANGE SPEED EFFECTS    ///
            // Change Creature effects associated with haste and movement speed to modify this according to the haste spell changes
            for (int i = 0; i < creEffects.Count; i++)
            {
                currentCreEffect = (CreEffect) creEffects[i];
                if (currentCreEffect.opcode == 126 ||
                    currentCreEffect.opcode == 176 ||
                    currentCreEffect.opcode == 16 ||
                    currentCreEffect.opcode == 317)
                {
                    ModifyCreEffectOpcode(176);
                    ModifyCreEffectParam1(150);
                    ModifyCreEffectParam2(2);
                    
                    
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
            }
            
            // CREATURE XP CHANGES
            // 2000 EXP
            if (
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Greater Basilisk") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Greater Doppelganger") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Ughh") || 
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Argh") || 
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Ungh") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Halbazzer Drin") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Skeleton Warrior") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Skeleton Monster") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Greater Skeleton") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Astral Phase Spider") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Karoug") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Doomsayer") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Davaeorn") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Wolf of Ulcaster") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Schlumpsha the Sewer King") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Andris") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Tellan") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Sirine Queen") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Kirinhale") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Doppelganger Mage") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Doppelganger Shaman") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Doppelganger Assassin") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "WOLFWEGR.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DAITEL.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DOPDUR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DOPFUE") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DOPISL") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DOPKIE") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "WYVERNBI.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "MEIALA.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "GRAEL.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "TAMOKO.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "WUDEI.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "HASEO.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "GORF_.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "RAHVIN.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SHALDR.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "CARSTO.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "AIRASPEC.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "BELT.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "BPAL_ATA.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "CADDER.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DRADEE") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DELTAN") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Slythe") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Krystin") ||   
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Mendas") ||   
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Firebead Elvenhair") ||   
                ContainsCaseInsensitive(currentCreFileInfo.Name, "QUEEN.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "ENTILL.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "ENTAR .") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "THALAN.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "TETHTO") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "RESAR.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "ULRAUN.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "JELLSPA.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "CHESS.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "KAHRK.")
            )
            {
                creHeaderModded.xpKill = 2000;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            // 1000 EXP
            if (
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Battle Horror") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Doom Guard") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Shoal the Nereid") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Shandalar") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Revenant") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Invisible Stalker") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Helmed Horror") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Vampiric Wolf") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Phase Spider") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Sword Spider") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Wraith Spider") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Sword Spider") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Mad Arcand") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Jalantha Mistmyr") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Lothander") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Marek") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Daese") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Gamaz") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Zhalimar Cloudwolfe") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Aasim") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Alai") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Diyab") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Gardush") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Naaman") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Jardak") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Ramazith") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Phandalyn") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "KOVERA.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PRIDEM.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "LIIA.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "ORDULI.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "LOVEM.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "AVARICEM.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FEARM.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "HACK.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "MOORLOCK.") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Tarnor") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Imanel Silversword") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Islanne") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Durlag") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Durlag Trollkiller") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Kiel") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Fuernebol") ||
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Mirror Fiend") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "KALDRAN.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "UBTUTH.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "TUTH.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "UBSVLREV.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "HURGAN.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SENIYA.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "ALVANH.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "UBSNOGOL")
            )
            {
                creHeaderModded.xpKill = 1000;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            // 4000 EXP
            if (
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Demon Knight") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "retard.") ||  // Angelo
                ContainsCaseInsensitive(currentCreFileInfo.Name, "galdor.") ||  // Angelo
                ContainsCaseInsensitive(currentCreFileInfo.Name, "diarmi.") ||  // Diarmid
                ContainsCaseInsensitive(currentCreFileInfo.Name, "semaj.") ||  // Semaj
                ContainsCaseInsensitive(currentCreFileInfo.Name, "tazok.") // Tazok
            )
            {
                creHeaderModded.xpKill = 4000;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            // 6000 EXP
            if (
                GetTlkStringFromStrRef(creHeaderModded.name).Equals("Aec'Letec") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SAREVO.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SAREVO2.")
            )
            {
                creHeaderModded.xpKill = 6000;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // MISC SMALL CREATURE XP CHANGES
            Boolean changed = false;
            if (creHeaderModded.xpKill > 1 && creHeaderModded.xpKill < 25)
            {
                creHeaderModded.xpKill = 5;
                changed = true;
            }
            else if (creHeaderModded.xpKill > 25 && creHeaderModded.xpKill < 100)
            {
                creHeaderModded.xpKill = 25;
                changed = true;
            }
            else if (creHeaderModded.xpKill > 100 && creHeaderModded.xpKill < 250)
            {
                creHeaderModded.xpKill = 100;
                changed = true;
            }
            else if (creHeaderModded.xpKill > 250 && creHeaderModded.xpKill < 420)
            {
                creHeaderModded.xpKill = 250;
                changed = true;
            }
            else if (creHeaderModded.xpKill > 420 && creHeaderModded.xpKill < 650)
            {
                creHeaderModded.xpKill = 420;
                changed = true;
            }
            else if (creHeaderModded.xpKill > 650 && creHeaderModded.xpKill < 1000)
            {
                creHeaderModded.xpKill = 650;
                changed = true;
            }
            else if (creHeaderModded.xpKill > 1000 && creHeaderModded.xpKill < 2000)
            {
                creHeaderModded.xpKill = 975;
                changed = true;
            }
            else if (creHeaderModded.xpKill > 2000 && creHeaderModded.xpKill < 3000)
            {
                creHeaderModded.xpKill = 2000;
                changed = true;
            }
            else // if xp is uneven (does not end with a "0"), we change that
            {
                if (creHeaderModded.xpKill % 10 != 0 && creHeaderModded.xpKill.ToString().Length > 1)
                {
                    int newVal = Int32.Parse(creHeaderModded.xpKill.ToString().Remove(creHeaderModded.xpKill.ToString().Length - 1, 1).Insert(creHeaderModded.xpKill.ToString().Length - 1, "0"));
                    creHeaderModded.xpKill = newVal;
                    changed = true;
                }
            }

            if (changed)
            {
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
        }

        internal static void RemoveCreItem(int index)
        {
            creItemsModded.RemoveAt(index);
        }
        
        internal static Boolean IsPermanentCorpse()
        {
            BitArray bitArray = new BitArray(new int[] {creHeaderModded.creatureFlags});
            Console.WriteLine(currentCreFileInfo.Name + " : " + bitArray[2]);
            return bitArray[2];
        }
        
        internal static void RemoveCreEffect(int index)
        {
            creEffectsModded.RemoveAt(index);
            creHeaderModded.effectsCount--;
            creHeaderModded.itemsOffset -= CreEffect.size;
            creHeaderModded.itemSlotsOffset -= CreEffect.size;
        }
        internal static void RemoveAllCreEffects(int opcode)
        {
            for (int i = creEffectsModded.Count - 1; i >= 0; i--)
            {
                currentCreEffect = (CreEffect) creEffectsModded[i];
                if (currentCreEffect.opcode == opcode)
                {
                    creEffectsModded.RemoveAt(i);
                }
            }
        }
        internal static void RemoveAllCreEffects()
        {
            for (int i = creEffectsModded.Count; i >= 0; i--)
            {
                currentCreEffect = (CreEffect) creEffectsModded[i];
                creEffectsModded.RemoveAt(i);
            }
        }

        internal static void AddCreEffect(String signature, String version, int opcode, int target, int power, int parameter1, int parameter2, int timingMode, int duration, short probability1, short probability2, String resource, int diceThrown, int diceSize, int saveType, int saveBonus, int special, int primaryType, int usedInternally, int minLevel, int maxLevel, int resistance, int parameter3, int parameter4, int parameter5, int timeApplied, String resource2, String resource3, int casterLocationX, int casterLocationY, int targetLocationX, int targetLocationY, int resourceType, String parentResource, int resourceFlags, int impactProjectile, int sourceItemSlot, String varName, int casterLevel, int internalFlags, int secondaryType)
        {
            creEffectsModded.Add(new CreEffect(signature, version, opcode, target, power, parameter1, parameter2,
                timingMode, duration, probability1, probability2, resource, diceThrown, diceSize, saveType, saveBonus,
                special, primaryType, usedInternally, minLevel, maxLevel, resistance, parameter3, parameter4,
                parameter5, timeApplied, resource2, resource3, casterLocationX, casterLocationY, targetLocationX,
                targetLocationY, resourceType, parentResource, resourceFlags, impactProjectile, sourceItemSlot, varName,
                casterLevel, internalFlags, secondaryType));
        }
        
        internal static void ModifyCreEffectOpcode(short newOpcode)
        {
            currentCreEffect.opcode = newOpcode;
        }
        
        internal static void ModifyCreEffectParam1(byte param1)
        {
            currentCreEffect.parameter1 = param1;
        }
        internal static void ModifyCreEffectParam2(byte param2)
        {
            currentCreEffect.parameter2 = param2;
        }

        internal static void AddCreSpell(int memorizedSpellsInfoIndex, String spellName, short spellLevel, short spellType, short memorized)
        {
            currentCreMemorizedSpellsInfo = (CreMemorizedSpellsInfo)creMemorizedSpellsInfosModded[memorizedSpellsInfoIndex];
            currentCreMemorizedSpellsInfo.spellCount++;
            currentCreMemorizedSpellsInfo.spellsMemorizable++;
            currentCreMemorizedSpellsInfo.spellsCurrMemorizable++;
            creMemorizedSpellsInfosModded[memorizedSpellsInfoIndex] = currentCreMemorizedSpellsInfo;

            int insertIndex = 0;
            for (int i = 0; i < memorizedSpellsInfoIndex; i++)
            {
                currentCreMemorizedSpellsInfo = (CreMemorizedSpellsInfo)creMemorizedSpellsInfosModded[i];
                insertIndex += currentCreMemorizedSpellsInfo.spellCount;
            }
            
            // Console.WriteLine(creMemorizedSpellsModded.Count);
            // Console.WriteLine(spellName);

            if (creMemorizedSpellsModded.Count == 0)
            {
                creMemorizedSpellsModded.Add(new CreMemorizedSpell(spellName, memorized));
            }
            else
            {
                creMemorizedSpellsModded.Insert(insertIndex, new CreMemorizedSpell(spellName, memorized));
            }

            Boolean spellFound = false;
            foreach (CreKnownSpell creKnownSpell in creKnownSpellsModded)
            {
                if (creKnownSpell.resource.Equals(spellName))
                {
                    spellFound = true;
                }
            }
            
            if (!spellFound)
            {
                creKnownSpellsModded.Add(new CreKnownSpell(spellName, spellLevel, spellType));
                creHeaderModded.knownSpellsCount++;
            }
        }
    }
}