﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlkDlg()
        {
            // CHANGE THALANTYR DIALOG (PRICING)
            identifiers = new String[]{
                "(?<=I('ll| will)? take (only)? )\\d+(?= [Gg]old)",
                "\\d+(?= gold as payment for my work)"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "100", false, false);
            }
            // CHANGE THALANTYR DIALOG (BOW OF THE SNOW STORM)
            identifiers = new String[]{
                "I will also need a Wand of Magic Missiles, a Wand of Frost, and a Wand of Lightning"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "I will also need a Potion of Cold Resistance, a Potion of Insulation, and a Potion of Perception", false, false);
            }
            // CHANGE THALANTYR DIALOG (SWORD OF RAGE)
            identifiers = new String[]{
                "I will need two Scrolls of Remove Curse and two Scrolls of Horror"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "I will need a Scroll of Remove Curse and a Scroll of Horror", false, false);
            }
            // CHANGE THALANTYR DIALOG (CLOAK OF NON DETECTION)
            identifiers = new String[]{
                "I will also need two Scrolls of Invisibility,"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "I will also need a Scroll of Invisibility,", false, false);
            }
            // CHANGE THALANTYR DIALOG (SWORD OF THE MURDERER)
            identifiers = new String[]{
                ", a Rogue Stone, and two Scrolls Hold Person"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    ", and a Scroll Hold Person", false, false);
            }
            // CHANGE THALANTYR DIALOG (GAUNTLETS)
            identifiers = new String[]{
                "I'll also need Bracers of Defense AC 7, "
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "I'll also need ", false, false);
            }
            // CHANGE THALANTYR DIALOG (RING OF PROTECTION +2)
            identifiers = new String[]{
                "I will also need one Diamond and two Pearls"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "I will also need one Pearl", false, false);
            }
            // CHANGE THALANTYR DIALOG (BELT)
            identifiers = new String[]{
                "I'll also need a Potion of Frost Giant Strength, a Potion of Cloud Giant Strength,"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "I'll also need a Potion of Frost Giant Strength,", false, false);
            }
            // CHANGE THALANTYR DIALOG (HELM)
            identifiers = new String[]{
                ", a Scroll of Protection from Fire, a Scroll of Protection from Cold, a Scroll of Protection from Electricity, "
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    ", a Potion of Fire, Cold and Electricity Resistance, ", false, false);
            }
            // CHANGE THALANTYR DIALOG (CLOAK OF BALDURAN)
            identifiers = new String[]{
                ", a Scroll of Protection from Fire, a Scroll of Protection from Cold, a Scroll of Protection from Electricity, "
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    ", a Potion of Fire, Cold and Electricity Resistance, ", false, false);
            }
            
            ///////////////
            ///
            /// 
            
            // CHANGE DENAKS REPONSE TO ALWAYS ATTACK EVEN WITH EDWIN IN THE PARTY WITHOUT DYNAHEIR
            identifiers = new String[]{
                "Good day, travelers. Mmm, Edwin, I did not expect to see you so soon."
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "It is so sad to have met you this fine day. Normally, we would be quite ecstatic to have visitors,", false, false);
            }
        }
    }
}