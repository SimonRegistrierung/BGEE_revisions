﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal class IdsFile
    {
        internal String rawContent;
        internal int lastId;
        internal List<int> decIds = new List<int>();
        internal List<int> hexIds = new List<int>();
        
        internal String fullLinePattern = @"(^)(.*)($)";
        
        internal String idPattern = @"(?<=^)\S+(?= )";
        
        internal String hexPattern = @"(?<=^0x)\S+(?=$)";
        internal String decPattern = @"(?<=^)\d+(?=$)";
        internal IdsFile(String content)
        {
            rawContent = content;
            ParseFile();
            GetFirstFreeId();
        }

        internal void ParseFile()
        {
            MatchCollection mc = Regex.Matches(rawContent, idPattern, RegexOptions.Multiline);
            // Console.WriteLine(mc.Count);
            foreach (Match m in mc)
            {
                Match hexMatch = Regex.Match(m.Value, hexPattern, RegexOptions.Multiline);
                Match decMatch = Regex.Match(m.Value, decPattern, RegexOptions.Multiline);
                // Console.WriteLine(m.Value);
                if (hexMatch.Success)
                {
                    // Console.WriteLine(hexMatch.Value);
                    // lastId = int.Parse(hexMatch.Value, System.Globalization.NumberStyles.HexNumber);
                    hexIds.Add(int.Parse(hexMatch.Value, System.Globalization.NumberStyles.HexNumber));
                }
                else if (decMatch.Success)
                {
                    // Console.WriteLine(decMatch.Value);
                    // lastId = int.Parse(decMatch.Value);
                    decIds.Add(int.Parse(decMatch.Value, NumberStyles.Integer));
                }
            }
        }

        internal void GetLastId()
        {
            if (decIds.Count > 0)
            {
                lastId = decIds.Max();
            }
            else if (hexIds.Count > 0)
            {
                lastId = hexIds.Max();
            }
        }

        internal void GetFirstFreeId()
        {
            int lastNum = 0;
            Boolean firstIteration = true;
            if (decIds.Count > 0)
            {
                foreach (int num in decIds)
                {
                    if (firstIteration)
                    {
                        firstIteration = false;
                        lastNum = num;
                    }
                    else
                    {
                        if (lastNum + 1 != num)
                        {
                            lastId = num;
                        }
                    }
                }
            }
            else if (hexIds.Count > 0)
            {
                foreach (int num in hexIds)
                {
                    if (firstIteration)
                    {
                        firstIteration = false;
                        lastNum = num;
                    }
                    else
                    {
                        if (lastNum + 1 != num)
                        {
                            lastId = num;
                        }
                    }
                }
            }        
        }

        internal void AddNewLine(String content)
        {
            // Console.WriteLine(content);
            rawContent = rawContent.Insert(rawContent.Length, content + "\n");
            // Console.WriteLine(rawContent);
        }
    }
}