﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        public static void RunIds()
        {
            // add frost ray
            if (ContainsCaseInsensitive(currentIdsFileInfo.Name, "PROJECTL."))
            {
                proFrostRayId = (short)(idsFile.lastId + 1);
                // Console.WriteLine(proFrostRayId);
                idsFile.AddNewLine(proFrostRayId + " " + "frostray");
                // proFrostRayId++; // increase by one to facilitate the inclusion in the spell/item header (an id of 10, needs to be referenced as 11 in the spell/item header file)
                FileOperations.WriteFileAsString(idsFile.rawContent, idsOutputPath + "/" + currentIdsFileInfo.Name, false);
            }
            
            // add spell states
            if (ContainsCaseInsensitive(currentIdsFileInfo.Name, "SPLSTATE."))
            {
                magicArmorId = (short)(idsFile.lastId + 1);
                // Console.WriteLine(magicArmorId);
                idsFile.AddNewLine(magicArmorId + " " + "MAGIC_ARMOR");
                // magicArmorId++; // increase by one to facilitate the inclusion in the spell/item header (an id of 10, needs to be referenced as 11 in the spell/item header file)
                ghostArmorId = (short)(idsFile.lastId + 2);
                // Console.WriteLine(ghostArmorId);
                idsFile.AddNewLine(ghostArmorId + " " + "GHOST_ARMOR");
                // ghostArmorId++; // increase by one to facilitate the inclusion in the spell/item header (an id of 10, needs to be referenced as 11 in the spell/item header file)
                FileOperations.WriteFileAsString(idsFile.rawContent, idsOutputPath + "/" + currentIdsFileInfo.Name, false);
            }
        }
    }
}