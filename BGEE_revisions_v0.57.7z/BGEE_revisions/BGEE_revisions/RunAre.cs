﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunAre()
        {
            for (int i = areItemsModded.Count - 1; i >= 0; i--)
            // foreach (AreItem areItem in areItemsModded)
            {
                currentAreItem = (AreItem) areItemsModded[i];
                // CORRECT NON-EXISTING ITEMS
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(currentAreItem))) // if the item file doe not exist in the source path, we can assume this item does not exist
                {
                    Console.WriteLine("Found non-existing item \"" + currentAreItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");
                    
                    if (ContainsCaseInsensitive(currentAreItem.resource, "null"))
                    {
                        currentAreItem.resource = "RNDTRE03";
                        currentAreItem.quantity1 = 1;
                        currentAreItem.quantity2 = 0;
                        currentAreItem.quantity3 = 0;
                    }
                    else // else, we replace this with a random item
                    {
                        currentAreItem.resource = "RNDTRE04";
                        currentAreItem.quantity1 = 1;
                        currentAreItem.quantity2 = 0;
                        currentAreItem.quantity3 = 0;
                    }

                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");

                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    continue;
                }

                // REMOVE ALL WANDS
                if (ContainsCaseInsensitive(currentAreItem.resource, "WAND"))
                {
                    Console.WriteLine("Found WAND item \"" + currentAreItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");

                    currentAreItem.resource = "RNDTRE04";
                    currentAreItem.quantity1 = 1;
                    currentAreItem.quantity2 = 0;
                    currentAreItem.quantity3 = 0;
                    
                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");

                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // convert all buggy random items to functioning
                if (ContainsCaseInsensitive(currentAreItem.resource, "RNDTRE08") || ContainsCaseInsensitive(currentAreItem.resource, "RNDTRE09"))
                {
                    currentAreItem.resource = "RNDTRE04";
                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // // EQUALIZE WAND CHARGES 
                // String fileName = GetItemFileName(currentAreItem);
                // // Console.WriteLine("-----");
                // // Console.WriteLine(fileName);
                // // Console.WriteLine("-----");
                // CreateItmObjects(fileName);
                // if (itmHeaderModded.itemType == 35) // if it's a wand
                // {
                //     if (currentAreItem.quantity1 > 0)
                //     {
                //         currentAreItem.quantity1 = 15;
                //     }
                //
                //     if (currentAreItem.quantity2 > 0)
                //     {
                //         currentAreItem.quantity2 = 15;
                //     }
                //
                //     if (currentAreItem.quantity3 > 0)
                //     {
                //         currentAreItem.quantity3 = 15;
                //     }
                //
                //     // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                //     if (fileName.Contains("WAND06."))
                //     {
                //         currentAreItem.quantity1 = 15;
                //         currentAreItem.quantity2 = 15;
                //     }
                //
                //     FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                // }
                
                // CLOAK OF NYMPH CHARGES
                if (ContainsCaseInsensitive(currentAreItem.resource, "CLCK07")) // cloak of the nymph
                {
                    currentAreItem.quantity1 = 1;
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // change erroneously placed undroppable plate mail in the undercity
                if (ContainsCaseInsensitive(currentAreItem.resource, "PLAT07"))
                {
                    currentAreItem.resource = "PLAT01" + new string(new char[2]);
                    currentAreItem.quantity3 = 0;
                    currentAreItem.flags = GetBitfieldInt(new int[] {0});
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // INCREASE ITEM QUANTITY FOR GOLEM BUILDING
                if (
                    ContainsCaseInsensitive(currentAreItem.resource, "A7!") && !ContainsCaseInsensitive(currentAreItem.resource, "TOM") // GOLEM CONSTRUCTION ITEMS
                )
                {
                    currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 2);
                    // Console.WriteLine(currentAreItem.resource);
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                //
                // REPLACE CURSED SCROLLS WITH RANDOM LOOT
                if (
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL10") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL11") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL12") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL13") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL14") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL15") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL16") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL17") ||
                    ContainsCaseInsensitive(currentAreItem.resource, "SCRL18")
                )
                {
                    // Console.WriteLine("got here");
                    currentAreItem.resource = "RNDTRE03";
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                
            
                // INCREASE MONEY STASHES GLOBALLY
                if (ContainsCaseInsensitive(currentAreItem.resource, "MISC07"))
                {
                    if (currentAreItem.quantity1 == 0)
                    {
                        currentAreItem.quantity1 = 35;
                        Console.WriteLine("FOUND ZERO MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 0 && currentAreItem.quantity1 < 50)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 3);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 50 && currentAreItem.quantity1 < 250)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 2.75);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 250 && currentAreItem.quantity1 < 500)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 2.5);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 500 && currentAreItem.quantity1 < 1000)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 2.25);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 1000 && currentAreItem.quantity1 < 2000)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 2);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 2000 && currentAreItem.quantity1 < 5000)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 1.75);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 5000 && currentAreItem.quantity1 < 10000)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 1.5);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                    else if (currentAreItem.quantity1 > 10000 && currentAreItem.quantity1 < 15000)
                    {
                        currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 1.25);
                        Console.WriteLine("FOUND MONEY IN AREA '" + currentAreFileInfo + "', changed quantity to "+ currentAreItem.quantity1);
                        FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                    }
                }
                
                ////
                ///
                /// 
                // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF SLEEP
                // if (currentAreFileInfo.Name.Contains("BG1900"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND08" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("BG2611"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND08" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF CURSING
                // if (currentAreFileInfo.Name.Contains("BG1200"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND19" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF GLITTERDUST
                // if (currentAreFileInfo.Name.Contains("AR0405"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF POLYMORPHING
                // if (currentAreFileInfo.Name.Contains("BD7400"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND09" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("AR0907"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND09" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF MONSTER SUMMONING
                // if (currentAreFileInfo.Name.Contains("BG1803"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND10" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF THE HEAVENS
                // if (currentAreFileInfo.Name.Contains("BG4010"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND11" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF CLOUDKILL
                // if (currentAreFileInfo.Name.Contains("BG2614"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND13" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF WAND OF SPELLSTRIKING
                // if (currentAreFileInfo.Name.Contains("AR0527"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF WAND OF CURSING
                // if (currentAreFileInfo.Name.Contains("AR2210"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF LIGHTNING TO WAND OF GLITTERDUST
                // if (currentAreFileInfo.Name.Contains("BG0504"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("AR1401"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("BG0109"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FROST TO WAND OF SPELL STRIKING
                // if (currentAreFileInfo.Name.Contains("AR1303"))
                // {
                //     if (currentAreItem.resource.Contains("WAND06"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
            }

            // make all creatures spawn/be available at all day and night times
            // foreach (AreActor areActor in areActorsModded)
            // {
            //     if (areActor.appearanceSchedule != -1)
            //     {
            //         // Console.WriteLine(currentAreFileInfo.Name + " : " + currentAreActor.name);
            //         areActor.appearanceSchedule = -1;
            //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            //     }
            // }

            ////////////
            // ADD GOLD IN SOME AREAS TO COMPENSATE FOR ADDITIONS OF NEW SHOPS AND REQUIRED CASH
            ///////////
            ///
            ///
            /// CANDLEKEEP
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG2600"))
            {
                int containerIndex = 1;
                AddAreItem("MISC45" + new string(new char[2]), 0, 1, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                containerIndex = 4;
                AddAreItem("AMUL12" + new string(new char[2]), 0, 1, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// RAGEFASTS' HOME
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG0126"))
            {
                int containerIndex = 2;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 265, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// UNDERCITY
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG0123"))
            {
                int containerIndex = 0;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 255, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// ULGOTH'S BEARD INN
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG1001"))
            {
                int containerIndex = 1;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 125, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// NASHKEL MANOR L2
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG4805"))
            {
                int containerIndex = 10;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("RING19" + new string(new char[2]), 0, 1, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                AddAreItem("AMUL12" + new string(new char[2]), 0, 1, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                containerIndex = 11;
                AddAreItem("AMUL11" + new string(new char[2]), 0, 1, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// TRAVENSHURST MANOR L2 LOCKED CHEST
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG3321"))
            {
                int containerIndex = 13;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 350, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// UNSHEY'S CHEST
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG2302"))
            {
                int containerIndex = 5;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 195, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// TAZOK'S TENT
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG1901"))
            {
                int containerIndex = FindAreContainerOfItem("POTN33");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 295, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// DAVAEORN'S LAIR
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG1803"))
            {
                int containerIndex = FindAreContainerOfItem("POTN22");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 185, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// FLAMING FIRST HQ CELLAR
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG0606"))
            {
                int containerIndex = FindAreContainerOfItem("HALB02");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 235, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// IRON THRONE BUILDING LEVEL 5
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG0615"))
            {
                int containerIndex = 1;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 285, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// BG SEWERS OGRE MAGE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG0226"))
            {
                int containerIndex = FindAreContainerOfItem("POTN34");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 355, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// WYVERN'S CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG4501"))
            {
                int containerIndex = FindAreContainerOfItem("PLAT01");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 150, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// CENTEOL'S CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG2101"))
            {
                int containerIndex = FindAreContainerOfItem("MISC90");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 290, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// LONELY PEAKS CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG4401"))
            {
                int containerIndex = FindAreContainerOfItem("POTN02");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 120, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// CLOAKWOOD HUNTING CABIN
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG2215"))
            {
                int containerIndex = FindAreContainerOfItem("POTN17");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 370, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// NASHKEL CARNIVAL POTION TENT
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG4905"))
            {
                int containerIndex = FindAreContainerOfItem("POTN09");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 285, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// NASHKEL MINES CABIN
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG5406"))
            {
                int containerIndex = 1;
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 255, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// ANKHEG PIT
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG1401"))
            {
                int containerIndex = FindAreContainerOfItem("SCRL1T");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 150, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            /// LION'S WAY
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG2700"))
            {
                int containerIndex = FindAreContainerOfItem("MISC42");
                Console.WriteLine("========== FOUND IT ==========");
                AddAreItem("MISC07" + new string(new char[2]), 0, 150, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // ALARICS CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG3601"))
            {
                foreach (AreItem areItem in areItemsModded)
                {
                    if (ContainsCaseInsensitive(areItem.resource, "MISC07"))
                    {
                        areItem.quantity1 = 155;
                    }
                }
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // ANCIENT RUINS
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG4101"))
            {
                int containerIndex = FindAreContainerOfItem("MISC48");
                // Console.WriteLine("Found MISC48 in containerindex " + containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 165, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // ULCASTER RUINS
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG3901"))
            {
                int containerIndex = FindAreContainerOfItem("ULBOOK54");
                AddAreItem("MISC07" + new string(new char[2]), 0, 285, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // DRYAD FALLS
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG5200"))
            {
                int containerIndex = FindAreContainerOfItem("MISC62");
                AddAreItem("MISC07" + new string(new char[2]), 0, 350, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                AddAreItem("MISC43" + new string(new char[2]), 0, 3, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // DRYAD FALLS CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG5202"))
            {
                foreach (AreItem areItem in areItemsModded)
                {
                    if (ContainsCaseInsensitive(areItem.resource, "MISC07"))
                    {
                        areItem.quantity1 = 155;
                    }
                }
                int containerIndex = FindAreContainerOfItem("MISC07");
                AddAreItem("MISC41" + new string(new char[2]), 0, 3, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            // MULAHEYS CAVE
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG5405"))
            {
                // Console.WriteLine("GOT HERE");
                int containerIndex = FindAreContainerOfItem("SW1H08");
                AddAreItem("MISC42" + new string(new char[2]), 0, 3, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                AddAreItem("MISC07" + new string(new char[2]), 0, 150, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            
            // RAMAZITHS TOWER L6
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG0138"))
            {
                // Console.WriteLine("GOT HERE");
                int containerIndex = FindAreContainerOfItem("POTN17");
                AddAreItem("MISC07" + new string(new char[2]), 0, 285, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            
            // DEMONKNIGHT'S CHAMBER
            if (ContainsCaseInsensitive(currentAreFileInfo.Name, "BG0516"))
            {
                // Console.WriteLine("GOT HERE");
                int containerIndex = 0;
                AddAreItem("MISC07" + new string(new char[2]), 0, 355, 0, 0, GetBitfieldInt(new int[] {0}), containerIndex);
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
            
            ////////////////////////////////////////
            ///
            /// 
            
            // REMOVE ALL CONTAINERS
            for (int itemIndex = areItemsModded.Count - 1; itemIndex >= 0; itemIndex--)
            {
                currentAreItem = (AreItem) areItemsModded[itemIndex];
                currentItemFileInfo = new FileInfo(itmInputPath + "/" + GetItemFileName(currentAreItem));
                CreateItmObjects(currentItemFileInfo.Name);
                if (itmHeaderModded.itemType == 36)
                {
                    // Console.WriteLine("REMOVED CONTAINER OBJECT");
                    Console.WriteLine("Found container item \"" + currentAreItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");
                    // get containerIndex
                    int containerIndex = 0;
                    int itemCounter = 0;
                    foreach (AreContainer areContainer in areContainersModded)
                    {
                        itemCounter += areContainer.itemCount;
                        if (itemCounter >= itemIndex)
                        {
                            break;
                        }
                        else
                        {
                            containerIndex++;
                        }
                    }
                    RemoveAreItem(itemIndex, containerIndex);
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }
            
            
            // REMOVE ALL TRAPS/MAKE LOCKS BREAKABLE
            Boolean found = false;
            foreach (AreContainer areContainer in areContainersModded)
            {
                if (areContainer.isTrapped != 0 && !GetBitInBitfield(areContainer.flags, 3)) // here bitfield index 3 means "trap resets" and can be used to identify "hidden" traps that trigger dialog events (like in Mulaheys cave) which persist and cannot be disarmed
                {
                    areContainer.isTrapped = 0;
                    found = true;
                }

                if (areContainer.lockDifficulty > 1)
                {
                    areContainer.lockDifficulty = 1;
                    found = true;
                }
            }
            foreach (AreTrigger areTrigger in areTriggersModded)
            {
                if (areTrigger.isTrapped != 0 && GetBitInBitfield(areTrigger.flags, 3))
                {
                    areTrigger.isTrapped = 0;
                    found = true;
                }
            }
            foreach (AreDoor areDoor in areDoorsModded)
            {
                if (areDoor.doorTrapped != 0 && GetBitInBitfield(areDoor.flags, 3))
                {
                    areDoor.doorTrapped = 0;
                    found = true;
                }
                if (areDoor.lockDifficulty > 1)
                {
                    areDoor.lockDifficulty = 1;
                }
            }
            if (found)
            {
                FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            }
        }

        internal static void RemoveAreItem(int itemIndex, int containerIndex)
        {
            // insert the new item to container with index x
            currentAreContainer = (AreContainer)areContainersModded[containerIndex];
            currentAreContainer.itemCount--;
            areContainersModded[containerIndex] = currentAreContainer;
            areItemsModded.RemoveAt(itemIndex);
            
            // decrease item index for all subsequent/succeeding containers
            for (int i = containerIndex + 1; i < areContainersModded.Count; i++)
            {
                currentAreContainer = (AreContainer)areContainersModded[i];
                currentAreContainer.indexFirstItem--;
                areContainersModded[i] = currentAreContainer;
            }
            
            // decreease header item count
            areHeaderModded.numberOfItems--;
        }

        internal static void AddAreItem(String resource, short itemExpirationTime, short quantity1, short quantity2, short quantity3, int flags, int containerIndex)
        {
            // get correct offset of container to insert new item to
            int itemListInsertOffset = 0;
            for (int i = 0; i < areContainers.Count; i++)
            {
                currentAreContainer = (AreContainer)areContainers[i];
                if (i < containerIndex)
                {
                    itemListInsertOffset += currentAreContainer.itemCount;
                }
                else
                {
                    break;
                }
            }
            
            // insert the new item to container with index x
            currentAreContainer = (AreContainer)areContainersModded[containerIndex];
            currentAreContainer.itemCount++;
            currentAreContainer.indexFirstItem = itemListInsertOffset;
            areContainersModded[containerIndex] = currentAreContainer;
            areItemsModded.Insert(itemListInsertOffset, new AreItem(resource, itemExpirationTime, quantity1, quantity2, quantity3, flags));
            
            // increase item index for all subsequent/succeeding containers
            for (int i = containerIndex + 1; i < areContainersModded.Count; i++)
            {
                currentAreContainer = (AreContainer)areContainersModded[i];
                currentAreContainer.indexFirstItem++;
                areContainersModded[i] = currentAreContainer;
            }
            
            // increase header item count
            areHeaderModded.numberOfItems++;
        }

        internal static int FindAreContainerOfItem(String itmResource)
        {
            Boolean found1 = false;
            int itmIndex = 0;
            foreach (AreItem areItem in areItemsModded)
            {
                Console.WriteLine(areItem.resource + ":" + itmResource);
                if (ContainsCaseInsensitive(areItem.resource, itmResource))
                {
                    found1 = true;
                    break;
                }
                itmIndex++;
            }

            Boolean found2 = false;
            int containerIndex = 0;
            int itmOffset = 0;
            foreach (AreContainer areContainer in areContainersModded)
            {
                itmOffset += areContainer.itemCount;
                if (itmOffset >= itmIndex)
                {
                    found2 = true;
                    break;
                }
                containerIndex++;
            }

            if (found1 && found2)
            {
                
                return containerIndex;
            }
            else
            {
                throw new Exception("COULD NOT FIND ITEM IN CONTAINER!\nFOUND1:" + found1 + "\n - FOUND2: " + found2 + "\nitmIndex:" + itmIndex + "\n - containerIndex: " + containerIndex);
            }
        }
    }
}