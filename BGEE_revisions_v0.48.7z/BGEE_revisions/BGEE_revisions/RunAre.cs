﻿using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunAre()
        {
            for (int i = areItemsModded.Count - 1; i >= 0; i--)
            // foreach (AreItem areItem in areItemsModded)
            {
                currentAreItem = (AreItem) areItemsModded[i];
                // CORRECT NON-EXISTING ITEMS
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(currentAreItem))) // if the item file doe not exist in the source path, we can assume this item does not exist
                {
                    Console.WriteLine("Found non-existing item \"" + currentAreItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");
                    
                    if (ContainsCaseInsensitive(currentAreItem.resource, "null"))
                    {
                        currentAreItem.resource = "RNDTRE03";
                        currentAreItem.quantity1 = 1;
                        currentAreItem.quantity2 = 0;
                        currentAreItem.quantity3 = 0;
                    }
                    else // else, we replace this with a random item
                    {
                        currentAreItem.resource = "RNDTRE04";
                        currentAreItem.quantity1 = 1;
                        currentAreItem.quantity2 = 0;
                        currentAreItem.quantity3 = 0;
                    }

                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");

                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // REMOVE ALL WANDS
                if (ContainsCaseInsensitive(currentAreItem.resource, "WAND"))
                {
                    Console.WriteLine("Found WAND item \"" + currentAreItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");

                    currentAreItem.resource = "RNDTRE04";
                    currentAreItem.quantity1 = 1;
                    currentAreItem.quantity2 = 0;
                    currentAreItem.quantity3 = 0;
                    
                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");

                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // convert all buggy random items to functioning
                if (currentAreItem.resource.Contains("RNDTRE08") || currentAreItem.resource.Contains("RNDTRE09"))
                {
                    currentAreItem.resource = "RNDTRE07";
                    Console.WriteLine("replacing with \"" + currentAreItem.quantity1 + "x " + currentAreItem.resource + "\"");
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // // EQUALIZE WAND CHARGES 
                // String fileName = GetItemFileName(currentAreItem);
                // // Console.WriteLine("-----");
                // // Console.WriteLine(fileName);
                // // Console.WriteLine("-----");
                // CreateItmObjects(fileName);
                // if (itmHeaderModded.itemType == 35) // if it's a wand
                // {
                //     if (currentAreItem.quantity1 > 0)
                //     {
                //         currentAreItem.quantity1 = 15;
                //     }
                //
                //     if (currentAreItem.quantity2 > 0)
                //     {
                //         currentAreItem.quantity2 = 15;
                //     }
                //
                //     if (currentAreItem.quantity3 > 0)
                //     {
                //         currentAreItem.quantity3 = 15;
                //     }
                //
                //     // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                //     if (fileName.Contains("WAND06."))
                //     {
                //         currentAreItem.quantity1 = 15;
                //         currentAreItem.quantity2 = 15;
                //     }
                //
                //     FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                // }
                
                // CLOAK OF NYMPH CHARGES
                if (currentAreItem.resource.Contains("CLCK07")) // cloak of the nymph
                {
                    currentAreItem.quantity1 = 1;
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // change erroneously placed undroppable plate mail in the undercity
                if (currentAreItem.resource.Contains("PLAT07"))
                {
                    currentAreItem.resource = "PLAT01" + new string(new char[2]);
                    currentAreItem.quantity3 = 0;
                    currentAreItem.flags = GetBitfieldInt(new int[] {0});
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // INCREASE ITEM QUANTITY FOR GOLEM BUILDING
                if (
                    ContainsCaseInsensitive(currentAreItem.resource, "A7!") && !ContainsCaseInsensitive(currentAreItem.resource, "TOM") // GOLEM CONSTRUCTION ITEMS
                )
                {
                    currentAreItem.quantity1 = (short)(currentAreItem.quantity1 * 2);
                    // Console.WriteLine(currentAreItem.resource);
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // REPLACE CURSED SCROLLS WITH RANDOM LOOT
                if (
                    currentAreItem.resource.Contains("SCRL10") ||
                    currentAreItem.resource.Contains("SCRL11") ||
                    currentAreItem.resource.Contains("SCRL12") ||
                    currentAreItem.resource.Contains("SCRL13") ||
                    currentAreItem.resource.Contains("SCRL14") ||
                    currentAreItem.resource.Contains("SCRL15") ||
                    currentAreItem.resource.Contains("SCRL16") ||
                    currentAreItem.resource.Contains("SCRL17") ||
                    currentAreItem.resource.Contains("SCRL18")
                )
                {
                    // Console.WriteLine("got here");
                    currentAreItem.resource = "RNDTRE03";
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                ////
                ///
                /// 
                // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF SLEEP
                // if (currentAreFileInfo.Name.Contains("BG1900"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND08" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("BG2611"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND08" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF CURSING
                // if (currentAreFileInfo.Name.Contains("BG1200"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND19" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF GLITTERDUST
                // if (currentAreFileInfo.Name.Contains("AR0405"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF POLYMORPHING
                // if (currentAreFileInfo.Name.Contains("BD7400"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND09" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("AR0907"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND09" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FEAR TO WAND OF MONSTER SUMMONING
                // if (currentAreFileInfo.Name.Contains("BG1803"))
                // {
                //     if (currentAreItem.resource.Contains("WAND02"))
                //     {
                //         currentAreItem.resource = "WAND10" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF THE HEAVENS
                // if (currentAreFileInfo.Name.Contains("BG4010"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND11" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF CLOUDKILL
                // if (currentAreFileInfo.Name.Contains("BG2614"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND13" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF WAND OF SPELLSTRIKING
                // if (currentAreFileInfo.Name.Contains("AR0527"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF MAGIC MISSILES TO WAND OF WAND OF CURSING
                // if (currentAreFileInfo.Name.Contains("AR2210"))
                // {
                //     if (currentAreItem.resource.Contains("WAND03"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF LIGHTNING TO WAND OF GLITTERDUST
                // if (currentAreFileInfo.Name.Contains("BG0504"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("AR1401"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                // if (currentAreFileInfo.Name.Contains("BG0109"))
                // {
                //     if (currentAreItem.resource.Contains("WAND07"))
                //     {
                //         currentAreItem.resource = "OHDWAND1";
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
                // // SWITCH UP SOME WAND APPEARANCES - WAND OF FROST TO WAND OF SPELL STRIKING
                // if (currentAreFileInfo.Name.Contains("AR1303"))
                // {
                //     if (currentAreItem.resource.Contains("WAND06"))
                //     {
                //         currentAreItem.resource = "WAND18" + new string(new char[2]);
                //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                //     }
                // }
                //
            }

            // make all creatures spawn/be available at all day and night times
            // foreach (AreActor areActor in areActorsModded)
            // {
            //     if (areActor.appearanceSchedule != -1)
            //     {
            //         // Console.WriteLine(currentAreFileInfo.Name + " : " + currentAreActor.name);
            //         areActor.appearanceSchedule = -1;
            //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            //     }
            // }
        }

        internal static void RemoveAreItem(int index)
        {
            areItemsModded.RemoveAt(index);
        }
    }
}