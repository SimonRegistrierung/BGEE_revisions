﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal class BcsParser
    {
        
        // Greedy will consume as much as possible. From http://www.regular-expressions.info/repeat.html we see the
        // example of trying to match HTML tags with <.+>. Suppose you have the following:
        // <em>Hello World</em>
        // You may think that <.+> (. means any non newline character and + means one or more) would only match the
        // <em> and the </em>, when in reality it will be very greedy, and go from the first < to the last >. This
        // means it will match <em>Hello World</em> instead of what you wanted.
        // Making it lazy (<.+?>) will prevent this. By adding the ? after the +, we tell it to repeat as few times as
        // possible, so the first > it comes across, is where we want to stop the matching.
        //
        //
        
        // OBJECT ELEMENTS
        internal static String objectEnemyPattern = @"(?<=(OB\n))(\S+)(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String factionPattern =     @"(?<=(OB\n)(-?\S+ ))(\S+)(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String teamPattern =        @"(?<=(OB\n)(-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String generalPattern =     @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String racePattern =        @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String classPattern =       @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String specificPattern =    @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String genderPattern =      @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String alignmentPattern =   @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String objectIdPattern =    @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String coordinateXPattern = @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (-?\S+) (""(\S+)?"")(OB\n))";
        internal static String coordinateYPattern = @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) )\S+(?= (""(\S+)?"")(OB\n))";
        internal static String namePattern =        @"(?<=(OB\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) "")(\S+)?(?=""(OB\n))";
        
        // SCRIPT ELEMENTS
        internal static String objectPattern = @"(OB(\n))(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) (""(\S+)?"")(OB\n)";
        internal static String actionPattern = @"(AC\n)(-?\S+)(" + objectPattern + @")(" + objectPattern + @")(" + objectPattern + @")(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+)(""(\S+)?"") (""(\S+)?"") (AC\n)";
        internal static String responsePattern = @"(RE\n)(-?\S+)(" + actionPattern + @"|)+(RE\n)";
        internal static String responseSetPattern = @"(RS\n)(" + responsePattern + @"|)+(RS\n)";
        internal static String triggerPattern = @"(TR\n)(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+) ""(\S+)?"" ""(\S+)?\"" (" + objectPattern + @"|)(TR\n)";
        internal static String conditionPattern = @"(CO\n)(" + triggerPattern + @"|)+(CO\n)";
        internal static String conditionResponseBlockPattern = @"(CR\n)" + conditionPattern + responseSetPattern + @"(CR\n)";
        internal static String scriptBlockPattern = @"(SC\n)(" + conditionResponseBlockPattern + @")+(SC)";
        
        // TRIGGER ELMENTS
        internal static String triggerIdPattern =      @"(?<=(TR\n))\S+(?= (-?\S+) (-?\S+) (-?\S+) (-?\S+) ""(\S+)?"" ""(\S+)?\"" (" + objectPattern + @"|)(TR\n))";
        internal static String triggerNegatePattern =  @"(?<=(TR\n)(-?\S+) (-?\S+) )\S+(?= (-?\S+) (-?\S+) ""(\S+)?"" ""(\S+)?\"" (" + objectPattern + @"|)(TR\n))";
        
        // ACTION ELEMENTS
        internal static String actionIdPattern =       @"(?<=(AC\n))\S+(?=(" + objectPattern + @")(" + objectPattern + @")(" + objectPattern + @")(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+)(""(\S+)?"") (""(\S+)?"") (AC\n))";
        // internal static String actionStrPattern =       @"(?<=(AC\n))\w+\([\w\*:,]*\)?(?=(" + objectPattern + @")(" + objectPattern + @")(" + objectPattern + @")(-?\S+) (-?\S+) (-?\S+) (-?\S+) (-?\S+)(""(\S+)?"") (""(\S+)?"") (AC\n))";
        
        // FORMATTING PATTERNS
        internal static String scriptBlockDecrypt = @"SC(?=\n)";
        
        
        // PARSER OBJECTS
        internal String encryptedFile;
        internal String decryptedFile;

        internal String scriptFile;

        internal ArrayList idFiles;

        internal Hashtable triggersTable = new Hashtable();
        internal Hashtable actionsTable = new Hashtable();
        internal Hashtable objectsTable = new Hashtable();
        internal Hashtable enemyTable = new Hashtable();
        internal Hashtable generalTable = new Hashtable();
        internal Hashtable raceTable = new Hashtable();
        internal Hashtable classTable = new Hashtable();
        internal Hashtable specificTable = new Hashtable();
        internal Hashtable genderTable = new Hashtable();
        internal Hashtable alignmentTable = new Hashtable();

        internal Hashtable negateTable = new Hashtable { {"0", "IS"}, {"1", "NOT"} };

        internal BcsParser(ArrayList idFiles)
        {
            this.idFiles = idFiles;
            ReadIds();
        }

        internal void LoadScript(byte[] byteFile)
        {
            encryptedFile = Encoding.ASCII.GetString(byteFile, 0, byteFile.Length);
            decryptedFile = encryptedFile;

            DecryptObjects();
        }

        internal void DecryptObjects()
        {
            // Console.WriteLine(objectPattern);
            MatchCollection mcObjects = Regex.Matches(decryptedFile, objectPattern, RegexOptions.Multiline);
            if (mcObjects.Count > 0) // if we identify an object
            {
                for (int i = 0; i < mcObjects.Count; i++) // foreach object
                {
                    Match m = Regex.Match(mcObjects[i].Value, objectPattern, RegexOptions.Multiline); // extract the individual object
                    String newVal = m.Value;
                    if (Regex.Match(m.Value, objectEnemyPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, objectEnemyPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindEnemyId(m1.Value));
                    }
                    if (Regex.Match(m.Value, generalPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, generalPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindGeneralId(m1.Value));
                    }
                    if (Regex.Match(m.Value, racePattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, racePattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindRaceId(m1.Value));
                    }
                    if (Regex.Match(m.Value, classPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, classPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindClassId(m1.Value));
                    }
                    if (Regex.Match(m.Value, specificPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, specificPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindSpecificId(m1.Value));
                    }
                    if (Regex.Match(m.Value, genderPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, genderPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindGenderId(m1.Value));
                    }
                    if (Regex.Match(m.Value, alignmentPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, alignmentPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindAlignmentId(m1.Value));
                    }
                    if (Regex.Match(m.Value, objectIdPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, objectIdPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindObjectId(m1.Value));
                    }
                    
                    // Console.WriteLine(newVal);
                    m = Regex.Match(decryptedFile, mcObjects[i].Value, RegexOptions.Multiline); // extract the position of the object in the file
                    decryptedFile = decryptedFile.Remove(m.Index, m.Length).Insert(m.Index, newVal);
                }
            }
            MatchCollection mcTriggers = Regex.Matches(decryptedFile, triggerPattern, RegexOptions.Multiline);
            if (mcTriggers.Count > 0) // if we identify a trigger
            {
                for (int i = 0; i < mcTriggers.Count; i++) // foreach trigger
                {
                    Match m = Regex.Match(mcTriggers[i].Value, triggerPattern, RegexOptions.Multiline); // extract the individual trigger
                    String newVal = m.Value;
                    if (Regex.Match(m.Value, triggerIdPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, triggerIdPattern, RegexOptions.Multiline); // extract the individual trigger element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindTriggerId(m1.Value));
                    }
                    if (Regex.Match(m.Value, triggerNegatePattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, triggerNegatePattern, RegexOptions.Multiline); // extract the individual trigger element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindTriggerNegationId(m1.Value));
                    }
                    m = Regex.Match(decryptedFile, mcTriggers[i].Value, RegexOptions.Multiline); // extract the position of the trigger in the file
                    decryptedFile = decryptedFile.Remove(m.Index, m.Length).Insert(m.Index, newVal);
                }
            }
            MatchCollection mcActions = Regex.Matches(decryptedFile, actionPattern, RegexOptions.Multiline);
            if (mcActions.Count > 0) // if we identify an action
            {
                for (int i = 0; i < mcActions.Count; i++) // foreach action
                {
                    Match m = Regex.Match(mcActions[i].Value, actionPattern, RegexOptions.Multiline); // extract the individual action
                    String newVal = m.Value;
                    if (Regex.Match(m.Value, actionIdPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, actionIdPattern, RegexOptions.Multiline); // extract the individual action element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindActionId(m1.Value));
                    }
                    m = Regex.Match(decryptedFile, mcActions[i].Value, RegexOptions.Multiline); // extract the position of the trigger in the file
                    decryptedFile = decryptedFile.Remove(m.Index, m.Length).Insert(m.Index, newVal);
                }
            }
        }

        internal String FindEnemyId(String id)
        {
            foreach (DictionaryEntry element in enemyTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }

            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindGeneralId(String id)
        {
            foreach (DictionaryEntry element in generalTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindRaceId(String id)
        {
            foreach (DictionaryEntry element in raceTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindClassId(String id)
        {
            foreach (DictionaryEntry element in classTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        
        internal String FindSpecificId(String id)
        {
            foreach (DictionaryEntry element in specificTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindGenderId(String id)
        {
            foreach (DictionaryEntry element in genderTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindAlignmentId(String id)
        {
            foreach (DictionaryEntry element in alignmentTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindObjectId(String id)
        {
            foreach (DictionaryEntry element in objectsTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindTriggerId(String id)
        {
            foreach (DictionaryEntry element in triggersTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindTriggerNegationId(String id)
        {
            foreach (DictionaryEntry element in negateTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        internal String FindActionId(String id)
        {
            foreach (DictionaryEntry element in actionsTable)
            {
                if (element.Key.Equals(id))
                {
                    Match m = Regex.Match(element.Value.ToString(), @"\w+");
                    return m.Value.ToString();
                }
            }
            return id; // if we cannot find the string in the table, return the input
        }
        
        internal void EncryptObjects()
        {
            String tempFile = decryptedFile;
            
            MatchCollection mcObjects = Regex.Matches(tempFile, objectPattern, RegexOptions.Multiline);
            if (mcObjects.Count > 0) // if we identify an object
            {
                for (int i = 0; i < mcObjects.Count; i++) // foreach object
                {
                    Match m = Regex.Match(mcObjects[i].Value, objectPattern, RegexOptions.Multiline); // extract the individual object
                    String newVal = m.Value;
                    if (Regex.Match(m.Value, objectEnemyPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, objectEnemyPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindEnemyStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, generalPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, generalPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindGeneralStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, racePattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, racePattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindRaceStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, classPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, classPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindClassStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, specificPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, specificPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindSpecificStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, genderPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, genderPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindGenderStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, alignmentPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, alignmentPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindAlignmentStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, objectIdPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, objectIdPattern, RegexOptions.Multiline); // extract the individual object element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindObjectStr(m1.Value));
                    }
                    
                    // Console.WriteLine(newVal);
                    m = Regex.Match(tempFile, mcObjects[i].Value, RegexOptions.Multiline); // extract the position of the object in the file
                    tempFile = tempFile.Remove(m.Index, m.Length).Insert(m.Index, newVal);
                }
            }
            MatchCollection mcTriggers = Regex.Matches(tempFile, triggerPattern, RegexOptions.Multiline);
            if (mcTriggers.Count > 0) // if we identify a trigger
            {
                for (int i = 0; i < mcTriggers.Count; i++) // foreach trigger
                {
                    Match m = Regex.Match(mcTriggers[i].Value, triggerPattern, RegexOptions.Multiline); // extract the individual trigger
                    String newVal = m.Value;
                    if (Regex.Match(m.Value, triggerIdPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, triggerIdPattern, RegexOptions.Multiline); // extract the individual trigger element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindTriggerStr(m1.Value));
                    }
                    if (Regex.Match(m.Value, triggerNegatePattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, triggerNegatePattern, RegexOptions.Multiline); // extract the individual trigger element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindTriggerNegationStr(m1.Value));
                    }
                    m = Regex.Match(tempFile, mcTriggers[i].Value, RegexOptions.Multiline); // extract the position of the trigger in the file
                    tempFile = tempFile.Remove(m.Index, m.Length).Insert(m.Index, newVal);
                }
            }
            MatchCollection mcActions = Regex.Matches(tempFile, actionPattern, RegexOptions.Multiline);
            if (mcActions.Count > 0) // if we identify an action
            {
                for (int i = 0; i < mcActions.Count; i++) // foreach action
                {
                    Match m = Regex.Match(mcActions[i].Value, actionPattern, RegexOptions.Multiline); // extract the individual action
                    // Console.WriteLine(m.Value);
                    // Console.WriteLine(mcActions[i].Value);
                    String newVal = m.Value;
                    // Console.WriteLine(m.Value);
                    if (Regex.Match(m.Value, actionIdPattern, RegexOptions.Multiline).Success)
                    {
                        Match m1 = Regex.Match(newVal, actionIdPattern, RegexOptions.Multiline); // extract the individual action element (e.g. id)
                        newVal = newVal.Remove(m1.Index, m1.Length).Insert(m1.Index, FindActionStr(m1.Value));
                    }
                    m = Regex.Match(tempFile, mcActions[i].Value, RegexOptions.Multiline); // extract the position of the trigger in the file
                    // Console.WriteLine(newVal);
                    // Console.WriteLine(mcActions[i].Value);
                    tempFile = tempFile.Remove(m.Index, m.Length).Insert(m.Index, newVal);
                }
            }

            encryptedFile = tempFile;
        }
        
        internal String FindEnemyStr(String str)
        {
            foreach (DictionaryEntry element in enemyTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }

            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindGeneralStr(String str)
        {
            foreach (DictionaryEntry element in generalTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindRaceStr(String str)
        {
            foreach (DictionaryEntry element in raceTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindClassStr(String str)
        {
            foreach (DictionaryEntry element in classTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        
        internal String FindSpecificStr(String str)
        {
            foreach (DictionaryEntry element in specificTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindGenderStr(String str)
        {
            foreach (DictionaryEntry element in genderTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindAlignmentStr(String str)
        {
            foreach (DictionaryEntry element in alignmentTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindObjectStr(String str)
        {
            foreach (DictionaryEntry element in objectsTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindTriggerStr(String str)
        {
            foreach (DictionaryEntry element in triggersTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindTriggerNegationStr(String str)
        {
            foreach (DictionaryEntry element in negateTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        internal String FindActionStr(String str)
        {
            foreach (DictionaryEntry element in actionsTable)
            {
                if (element.Value.ToString().Contains(str))
                {
                    // Console.WriteLine(element.Value.ToString());
                    return element.Key.ToString();
                }
            }
            return str; // if we cannot find the string in the table, return the input
        }
        
        // <summary>
        // MODDING
        // </summary>

        internal void FindReplace(Boolean useDecrypted, String findStr, String replStr)
        {
            if (useDecrypted)
            {
                MatchCollection mc = Regex.Matches(decryptedFile, findStr, RegexOptions.Multiline);
                for (int i = 0; i < mc.Count; i++)
                {
                    decryptedFile.Remove(mc[i].Index, mc[i].Length).Insert(mc[i].Index, replStr);
                }
                EncryptObjects();
            }
            else
            {
                MatchCollection mc = Regex.Matches(encryptedFile, findStr, RegexOptions.Multiline);
                for (int i = 0; i < mc.Count; i++)
                {
                    encryptedFile.Remove(mc[i].Index, mc[i].Length).Insert(mc[i].Index, replStr);
                }
            }
        }

        /// <summary>
        /// READ IDS
        /// </summary>
        internal void ReadIds()
        {
            foreach (FileInfo idFile in idFiles)
            {
                if (idFile.Name.Contains("TRIGGER."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^0x.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match hexMatch = Regex.Match(m.Value, @"(?<=0x)\S{4}(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*?(?=\()");
                            try
                            {
                                int decVal = int.Parse(hexMatch.Value, System.Globalization.NumberStyles.HexNumber);
                                triggersTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                        }
                    }
                }

                if (idFile.Name.Contains("ACTION."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*?(?=\()");
                            try
                            {
                                actionsTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                }
                
                if (idFile.Name.Contains("OBJECT."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                objectsTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                }
                
                if (idFile.Name.Contains("EA."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                enemyTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                }
                
                if (idFile.Name.Contains("GENERAL."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                generalTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                }
                
                if (idFile.Name.Contains("RACE."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                raceTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                    raceTable.Add("0", "NO_RACE");
                }
                
                if (idFile.Name.Contains("CLASS."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                classTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                    classTable.Add("0", "NO_CLASS");
                }
                
                if (idFile.Name.Contains("SPECIFIC."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                specificTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                }
                
                if (idFile.Name.Contains("GENDER."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match decVal = Regex.Match(m.Value, @"(?<=^)\d+(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                genderTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                    genderTable.Add("0", "NO_GENDER");
                }
                
                if (idFile.Name.Contains("ALIGNMEN."))
                {
                    String strFile = FileOperations.ReadFileAsString(idFile.FullName);
                    MatchCollection mc = Regex.Matches(strFile, @"^\d+.*$", RegexOptions.Multiline);
                    if (mc.Count > 0)
                    {
                        foreach (Match m in mc)
                        {
                            Match hexMatch = Regex.Match(m.Value, @"(?<=0x)\S{2}(?= )");
                            Match methodMatch = Regex.Match(m.Value, @"(?<= ).*(?=$)");
                            try
                            {
                                int decVal = int.Parse(hexMatch.Value, System.Globalization.NumberStyles.HexNumber);
                                alignmentTable.Add(decVal.ToString(), methodMatch.Value.ToString());
                            }
                            catch (Exception ignore)
                            {
                                
                            }
                            
                            // Console.WriteLine(decVal + "   " + methodMatch.Value);
                        }
                    }
                }
            }
        }
    }
}