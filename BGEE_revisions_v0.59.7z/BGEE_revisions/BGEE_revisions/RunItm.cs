﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunItm()
        {
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // CASTING FAILURE & ARMOR CHANGES   
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 

            // prevent casting failure & thieving disablement
            if (
                (
                    itmHeader.itemType == 2 ||
                    itmHeader.itemType == 7 ||
                    itmHeader.itemType == 12 ||
                    itmHeader.itemType == 41 ||
                    itmHeader.itemType == 47 ||
                    itmHeader.itemType == 49 ||
                    itmHeader.itemType == 53 ||
                    itmHeader.itemType == 59 ||
                    itmHeader.itemType == 60 ||
                    itmHeader.itemType == 61 ||
                    itmHeader.itemType == 62 ||
                    itmHeader.itemType == 63 ||
                    itmHeader.itemType == 64 ||
                    itmHeader.itemType == 65 ||
                    itmHeader.itemType == 66 ||
                    itmHeader.itemType == 67 ||
                    itmHeader.itemType == 68
                ) && IsDroppable() // if it's an armor, shield, headgear etc. and if it's droppable
            )
            {
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 59 ||
                        currentItmFeatBlock.opcodeNumber == 60 ||
                        currentItmFeatBlock.opcodeNumber == 90 ||
                        currentItmFeatBlock.opcodeNumber == 91 ||
                        currentItmFeatBlock.opcodeNumber == 92 ||
                        currentItmFeatBlock.opcodeNumber == 275 ||
                        currentItmFeatBlock.opcodeNumber == 144 ||
                        currentItmFeatBlock.opcodeNumber == 145
                    )
                    {
                        RemoveItmEffect(i);
                        
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }

                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 59 ||
                        currentItmFeatBlock.opcodeNumber == 60 ||
                        currentItmFeatBlock.opcodeNumber == 90 ||
                        currentItmFeatBlock.opcodeNumber == 91 ||
                        currentItmFeatBlock.opcodeNumber == 92 ||
                        currentItmFeatBlock.opcodeNumber == 275 ||
                        currentItmFeatBlock.opcodeNumber == 144 ||
                        currentItmFeatBlock.opcodeNumber == 145
                    )
                    {
                        // Console.WriteLine(currentItemFileInfo);
                        RemoveItmAbility(i);
                        
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // TLK STRING CHANGES
            //                          all containers should have the same name, even though they have different optical appearances
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            ///

            if (itmHeaderModded.itemType == 36)
            {
                if (
                    EqualsCaseInsensitive(GetTlkStringFromStrRef(itmHeaderModded.nameUnId), "Bag of Holding") ||
                    EqualsCaseInsensitive(GetTlkStringFromStrRef(itmHeaderModded.nameUnId), "Gem Bag") ||
                    EqualsCaseInsensitive(GetTlkStringFromStrRef(itmHeaderModded.nameUnId), "Potion Case") ||
                    EqualsCaseInsensitive(GetTlkStringFromStrRef(itmHeaderModded.nameUnId), "Scroll Case") ||
                    EqualsCaseInsensitive(GetTlkStringFromStrRef(itmHeaderModded.nameUnId), "Ammo Belt") 
                    )
                {
                    itmHeaderModded.nameId = itmHeaderModded.nameUnId;
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // VISUAL ITEM CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            ///
            var gfxItems = new Hashtable();
            gfxItems.Add("BULL07.", "ibull07");
            gfxItems.Add("BULL08.", "ibull08");
            gfxItems.Add("BULL09.", "ibull09");
            gfxItems.Add("DAGG03.", "idagg3a");
            gfxItems.Add("SLNG11.", "islng11");
            gfxItems.Add("BLUN39.", "iblun39");
            gfxItems.Add("BLUN38.", "NRMLCLB");
            gfxItems.Add("X#JACLUB.", "SPKDCLB");
            gfxItems.Add("BLUN37.", "IBLUN37");
            gfxItems.Add("SHLD33.", "BUCKLEY");
            gfxItems.Add("HAMM04.", "KNEECAP");
            gfxItems.Add("K#WAND01.", "RGWANDC2");
            gfxItems.Add("K#WAND02.", "RGWANDC3");
            gfxItems.Add("K#WAND03.", "RGWANDC4");
            gfxItems.Add("BOOK03.", "IBOOK768");
            gfxItems.Add("BOOK04.", "IBOOK768");
            gfxItems.Add("BOOK05.", "IBOOK768");
            gfxItems.Add("BOOK06.", "IBOOK768");
            gfxItems.Add("BOOK07.", "IBOOK768");
            gfxItems.Add("BOOK08.", "IBOOK768");
            gfxItems.Add("BOOK70.", "IBOOK03");
            gfxItems.Add("BOOK01.", "IBOOK03");
            gfxItems.Add("BOOK02.", "IBOOK03");
            gfxItems.Add("ULBOOK54.", "IBOOK03");
            gfxItems.Add("ULBOOK87.", "IBOOK03");
            gfxItems.Add("ULBOOK88.", "IBOOK03");
            gfxItems.Add("ULBOOK89.", "IBOOK03");
            gfxItems.Add("ULBOOK90.", "IBOOK03");
            gfxItems.Add("ULBOOK91.", "IBOOK03");
            gfxItems.Add("ULBOOK92.", "IBOOK03");
            gfxItems.Add("ULBOOK93.", "IBOOK03");
            gfxItems.Add("ULBOOK94.", "IBOOK03");
            gfxItems.Add("ULBOOK95.", "IBOOK03");
            gfxItems.Add("ULBOOK96.", "IBOOK03");
            gfxItems.Add("ULBOOK97.", "IBOOK03");
            gfxItems.Add("ULBOOK98.", "IBOOK03");
            gfxItems.Add("ULBOOK70.", "IBOOK03");
            gfxItems.Add("MISC75.", "VNMDGGR1");
            gfxItems.Add("THDAGG01.", "VNMDGGR2");
            gfxItems.Add("THBOOT01.", "THFBOOTS");
            gfxItems.Add("thclck01.", "IMPCLKND");
            gfxItems.Add("thclck02.", "RBPRPROT");
            gfxItems.Add("thclck03.", "IMPBACLK");
            gfxItems.Add("thbrac01.", "BRACERGM");
            gfxItems.Add("thbow01.", "BOWSNOST");
            gfxItems.Add("thsw1h01.", "SWMURDER");
            gfxItems.Add("thsw2h01.", "SWRDRAGE");
            gfxItems.Add("X#FASH01.", "OAKSHLD1");
            gfxItems.Add("thbelt01.", "GIRDBRAV");
            gfxItems.Add("dw#kakat.", "MAGIKATA");
            gfxItems.Add("clck22.", "SHANDCLK");
            gfxItems.Add("thring01.", "RINGFRE1");
            gfxItems.Add("thring02.", "RINGFRE2");
            gfxItems.Add("X#RINGRO.", "RINGHINF");
            gfxItems.Add("C#STSRVS.", "SWRDSRVK");
            gfxItems.Add("FINSAREV.", "SWRDSRVK");
            gfxItems.Add("FINSRV.", "SWRDSRVK");
            gfxItems.Add("SW1H79.", "HARROWER");
            gfxItems.Add("THHELM01.", "MAGNHELM");
            gfxItems.Add("PLAT24.", "MAGMABUL");
            gfxItems.Add("LEAT25.", "RUGGEDLE");
            gfxItems.Add("MISCAI.", "WORNBOOT");
            gfxItems.Add("CHAINS.", "WORNBOOT");
            gfxItems.Add("BOOT06.", "WORNBOOT");
            gfxItems.Add("POTN47.", "MAREKPOT");
            gfxItems.Add("POTNMARE.", "MAREKPOT");
            gfxItems.Add("DW#PTN47.", "MAREKPOT");
            gfxItems.Add("DAGG09.", "WEREBANE");
            gfxItems.Add("DAGG04.", "LNGTOOTH");
            gfxItems.Add("SW1H45.", "MALAKAR0");
            gfxItems.Add("RING35.", "RINGLOCK");
            gfxItems.Add("BDDAGG03.", "GEMBLAD1");
            gfxItems.Add("BDDAGG3A.", "GEMBLAD2");
            gfxItems.Add("BDDAGG04.", "IDAGG17");
            gfxItems.Add("BDDAGG07.", "IDAGG17");
            gfxItems.Add("WAND12.", "WANDWOND");
            gfxItems.Add("OHNROBE2.", "ROBEINVO");
            gfxItems.Add("RGOHNR2A.", "ROBEINVO");
            gfxItems.Add("RGOHNR2B.", "ROBEINVO");
            // gfxItems.Add("HALB13.", "CHESLEYC"); // done by cdtweaks
            
            foreach (DictionaryEntry pair in gfxItems)
            {
                if (ContainsCaseInsensitive(currentItemFileInfo.Name, pair.Key.ToString()))
                {
                    SetItmIcon(pair.Value.ToString());
                    
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }

            OrderedDictionary gfxItems2 = new OrderedDictionary();

            // quivers
            gfxItems2.Add("CDPLQUIV.", new String[] {"quiarow0", "IAROW01"});
            gfxItems2.Add("QUIVER01.", new String[] {"quiarow1", "IAROW02"});
            gfxItems2.Add("QUIVER03.", new String[] {"quiarow2", "IAROW11"});
            gfxItems2.Add("C2QUIV01.", new String[] {"quiarow2", "IAROW15"});
            //
            gfxItems2.Add("CDPLCASE.", new String[] {"quibolt0", "IBOLT01"});
            gfxItems2.Add("QUIVER02.", new String[] {"quibolt1", "IBOLT02"});
            gfxItems2.Add("QUIVER04.", new String[] {"quibolt2", "IBOLT06"});
            gfxItems2.Add("C2QUIV02.", new String[] {"quibolt3", "IBOLT09"});
            //
            gfxItems2.Add("CDPLBAG.", new String[] {"quibull0", "IBULL01"});
            gfxItems2.Add("QUIVER05.", new String[] {"quibull1", "IBULL02"});
            gfxItems2.Add("QUIVER06.", new String[] {"quibull2", "IBULL03"});
            gfxItems2.Add("C2QUIV03.", new String[] {"quibull3", "IBULL05"});

            int index = 0;
            foreach (DictionaryEntry pair in gfxItems2)
            {
                if (ContainsCaseInsensitive(currentItemFileInfo.Name, pair.Key.ToString()))
                {
                    String[] value = (String[]) gfxItems2[index];
                    // Console.WriteLine(value.Length);
                    SetItmIcon(value);
                    
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }

                index++;
            }
            
            // remove visual effects from ioun stones
            if (itmHeaderModded.itemType == 7)
            {
                Boolean found = false;
                for (int i = itmEffFeatBlocks.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock)itmEffFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 215)
                    {
                        itmEffFeatBlocksModded.RemoveAt(i);
                        found = true;
                    }
                }

                if (found)
                {
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }

            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // ITEM PRICE CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///

            // INCREASE GEM AND OTHER PRICES
            
            Hashtable priceItems = new Hashtable();
            
            priceItems.Add("RSBRAC.", 5000); // RASAADS TALONS
            priceItems.Add("RSBOOT.", 1000); // RASAADS BOOTS
            priceItems.Add("STAFN1.", 1000); // NEERA STAFF
            priceItems.Add("NEBELT01.", 1000); // ADOY'S BELT
            priceItems.Add("X#JACLUB.", 2000); // JAHEIRA'S CLUB
            priceItems.Add("X#FASH01.", 1500); // WHITE OAK SHIELD
            priceItems.Add("X#KISPR.", 2000); // KIVAN'S ELVEN SPEAR
            priceItems.Add("X#TOME.", 1000); // IMOEN TOME
            
            priceItems.Add("SCRL10.", 50); // CURSED SCROLL
            priceItems.Add("SCRL11.", 50); // CURSED SCROLL
            priceItems.Add("SCRL12.", 50); // CURSED SCROLL
            priceItems.Add("SCRL13.", 50); // CURSED SCROLL
            priceItems.Add("SCRL14.", 50); // CURSED SCROLL
            priceItems.Add("SCRL16.", 50); // CURSED SCROLL
            priceItems.Add("SCRL17.", 50); // CURSED SCROLL
            priceItems.Add("SCRL18.", 50); // CURSED SCROLL

            priceItems.Add("K#WAND01.", 200); // WAND CASE
            priceItems.Add("K#WAND02.", 200); // WAND CASE
            priceItems.Add("K#WAND03.", 200); // WAND CASE
            priceItems.Add("RGWANDC1.", 200); // WAND CASE

            foreach (DictionaryEntry pair in priceItems)
            {
                if (ContainsCaseInsensitive(currentItemFileInfo.Name, pair.Key.ToString()))
                {
                    itmHeaderModded.price = Int32.Parse(pair.Value.ToString());
                    
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            // MAKE CRITICAL ITEMS SELLABLE AND NON-CRITICAL
            if ((IsCritical() || itmHeaderModded.price != 0) && itmHeaderModded.itemType != 36)
            {
                Console.WriteLine("CRITICAL ITEM: " + currentItemFileInfo.Name +  " - " + currentName);
                itmHeaderModded.flags = ModExistingBitfield(itmHeaderModded.flags, new int[] {0}, false);
                if (itmHeaderModded.price == 0)
                {
                    itmHeaderModded.price = 5; // set price, if 0
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // MAKE PREVIOUSLY UNSELLABLE ITEMS (NON-AMMO) SELLABLE (CERTAIN SCROLLS etc.)
            if (
                IsDroppable() && 
                itmHeaderModded.price == 0 && 
                !ContainsCaseInsensitive(currentItemFileInfo.Name, "A7!RD") &&
                !ContainsCaseInsensitive(currentItemFileInfo.Name, "dw#rnd") &&
                !ContainsCaseInsensitive(currentItemFileInfo.Name, "dwrndsc") &&
                !ContainsCaseInsensitive(currentItemFileInfo.Name, "dwrnscr") &&
                !ContainsCaseInsensitive(currentItemFileInfo.Name, "MISC07") &&
                !ContainsCaseInsensitive(currentItemFileInfo.Name, @"\ARND") &&
                !ContainsCaseInsensitive(currentItemFileInfo.Name, "SODTRE") &&
                !ContainsCaseInsensitive(currentItemFileInfo.Name, "dw#sh") &&
                
                    itmHeaderModded.itemType != 5 && // ARROW
                    itmHeaderModded.itemType != 14 && // BULLET
                    itmHeaderModded.itemType != 24 && // DART
                    itmHeaderModded.itemType != 31 && // BOLT
                    itmHeaderModded.itemType != 36 && // CONTAINER
                    itmHeaderModded.itemType != 45 && // BODY
                    itmHeaderModded.itemType != 48 // BODY
                
            )
            {
                Console.WriteLine("UNSELLABLE ITEM: " + currentItemFileInfo.Name +  " - " + currentName);
                itmHeaderModded.flags = ModExistingBitfield(itmHeaderModded.flags, new int[] {0}, false);
                if (itmHeaderModded.price == 0)
                {
                    itmHeaderModded.price = 5; // set price, if 0
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // equalize store prices
            // rings, amulets
            // if (
            //     itmHeaderModded.itemType == 1 ||
            //     itmHeaderModded.itemType == 10 ||
            //     itmHeaderModded.itemType == 34
            // )
            // {
            //     EqualizePrices(100, 50000);
            //     // Console.WriteLine(currentName + ": " + itmHeaderModded.price);
            //     // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
            //     //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            // }

            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // MISC SMALL CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            ///
            ///
            ///
            
            // IMPROVED PEARLY WHITE IOUN STONE
            if (GetTlkStringFromStrRef(itmHeaderModded.nameId).Equals("Pearly White Ioun Stone"))
            {
                CreateItmObjects(itmModDirectory + @"\", "GREENSTONE_AMULET_EFFECTS_NO_STUN.ITM");
                itmHeaderModded.nameUnId = FindExactTlkEntry("Ioun Stone");
                itmHeaderModded.nameId = FindExactTlkEntry("Pearly White Ioun Stone");
                itmHeaderModded.flags = ModExistingBitfield(itmHeaderModded.flags, new int[] {2, 3, 5, 6, 25}, true);
                itmHeaderModded.itemType = 7;
                itmHeaderModded.price = 5000;
                itmHeaderModded.stackAmount = 1;
                itmHeaderModded.invIcon = "IHELM18" + new char();
                itmHeaderModded.groundIcon = "GGEM01" + new string(new char[2]);
                itmHeaderModded.weight = 0;
                itmHeaderModded.descUnId = FindFirstMatchingTlkEntry("This is a small stone that floats in an orbit around the owner");
                itmHeaderModded.descId = FindFirstMatchingTlkEntry("Legend tells us that this particular type of ioun stone is crafted with the enslaved soul of a troll"); // THESE STRING WILL BE CHANGED BY RunTlkItm!!
                itmHeaderModded.descIcon = "CHELM18" + new char();
                
                foreach (ItmFeatBlock itmFeatBlock in itmEffFeatBlocksModded)
                {
                    itmFeatBlock.timingMode = 2;
                    itmFeatBlock.duration = 0;
                }

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/HELM18.ITM");
            }
            
            // IMPROVED EYES OF TRUTH 
            if (GetTlkStringFromStrRef(itmHeaderModded.nameId).Equals("The Eyes of Truth"))
            {
                AddItmExtHeader(3, 0, 3, 0, "SPWI515B", 5, 0, 1, 0, 0, 0, 0, 0, 6, 3, 0, 5, 0, 1, 0, itmHeaderModded.effectsCount, 2, 3, GetBitfieldInt(new int[]{9, 11}), 94, 34, 33, 33, 0, 0, 0);
                AddItmAbility(146, 1, 1, 1, 1, 1, 3, 0, 100, 0, "SPWI515" + new char(), 0, 0, 0, 0, 0, 0);
                itmHeader.price = 2500;
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/HELM06.ITM");
            }
            
            // MAKE HELM OF CHARM PROTECTION A HELM OF MIND PROTECTION
            if (GetTlkStringFromStrRef(itmHeaderModded.nameId).Equals("Helm of Charm Protection"))
            {
                // Console.WriteLine(itmModDirectory + @"\GREENSTONE_AMULET_EFFECTS.ITM");
                CreateItmObjects(itmModDirectory + @"\", "GREENSTONE_AMULET_EFFECTS_NO_STUN.ITM");
                itmHeaderModded.nameUnId = FindExactTlkEntry("Helmet");
                itmHeaderModded.nameId = AddExactTlkEntryIfNotFound("Helm of Mind Protection");
                itmHeaderModded.flags = ModExistingBitfield(itmHeaderModded.flags, new int[] {2, 3, 5, 6}, true);
                itmHeaderModded.itemType = 7;
                itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {6, 18, 19, 22, 29}, true);
                itmHeaderModded.itemAnimation = "JA";
                itmHeaderModded.usability4 = ModExistingBitfield(itmHeaderModded.usability4, new int[] {2}, true);
                itmHeaderModded.price = 5000;
                itmHeaderModded.stackAmount = 1;
                itmHeaderModded.invIcon = "1HELM18" + new char();
                itmHeaderModded.groundIcon = "GHELM01" + new char();
                itmHeaderModded.weight = 4;
                itmHeaderModded.descUnId = FindFirstMatchingTlkEntry("This class of open-face helmet, made of reinforced leather or metal");
                itmHeaderModded.descId = FindFirstMatchingTlkEntry("As its name suggests, the Helm of Charm Protection protects"); // THESE STRING WILL BE CHANGED BY RunTlkItm!!
                itmHeaderModded.descIcon = "1CHELM18";

                foreach (ItmFeatBlock itmFeatBlock in itmEffFeatBlocksModded)
                {
                    itmFeatBlock.timingMode = 2;
                    itmFeatBlock.duration = 0;
                }

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/HELM06.ITM");
            }
            
            // RENAME THE STRENGTH SCROLL TO BULL'S STRENGTH
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "scrl98."))
            {
                itmHeaderModded.nameId = FindExactTlkEntry("Bull's Strength");
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // make stupefier mor useful (partial un-nerf) & change visual effect to something more sensible
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "blun41."))
            {
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock)itmAbilFeatBlocksModded[i];
                    if (currentItmFeatBlock.probability1 == 10 && currentItmFeatBlock.opcodeNumber == 45)
                    {
                        currentItmFeatBlock.probability1 = 25;
                        currentItmFeatBlock.probability2 = 0;
                        itmAbilFeatBlocksModded[i] = currentItmFeatBlock;
                    }
                    if (currentItmFeatBlock.duration == 6 && currentItmFeatBlock.opcodeNumber == 45)
                    {
                        RemoveItmAbility(i);
                    }

                    if (currentItmFeatBlock.opcodeNumber == 139 || currentItmFeatBlock.opcodeNumber == 41)
                    {
                        currentItmFeatBlock.probability1 = 25;
                        currentItmFeatBlock.probability2 = 0;
                    }
                    if (currentItmFeatBlock.opcodeNumber == 215)
                    {
                        RemoveItmAbility(i); // remove previous visual effect
                    }
                }
                rgb = new byte[]{0, 60, 90, 120};
                AddItmAbility(141, 2, 0, 0, 1, 1, 0, 0, 25, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(61, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 25, 1, 0, 0, 25, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(142, 2, 0, 0, 55, 0, 1, 12, 25, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(174, 2, 0, 0, 0, 1, 0, 0, 25, 0, "EFF_P11" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(174, 2, 0, 0, 0, 4, 0, 12, 25, 0, "EFF_E05" + new char(), 0, 0, 0, 0, 0, 0);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change appearance of wizard hat in bgsod
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "bdhelm12."))
            {
                itmHeaderModded.itemAnimation = "MH";
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // increase charges of horn of good/evil
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "MH#MISC5."))
            {
                currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[0];
                currentItmExtHeader.maxCharges = 3;
                itmExtHeadersModded[0] = currentItmExtHeader;
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // remove potion of longevity's negative effects (base on chance)
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "MH#potn5."))
            {
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock)itmAbilFeatBlocksModded[i];
                    if (currentItmFeatBlock.probability1 == 99 && currentItmFeatBlock.probability2 == 95)
                    {
                        RemoveItmAbility(i);
                        Console.WriteLine("Removed");
                    }
                    else if (currentItmFeatBlock.probability1 == 94)
                    {
                        currentItmFeatBlock.probability1 = 100;
                        Console.WriteLine("Set Prob");
                    }
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // make crystal ball more usable and add detect illusion ability
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "MH#MISC3."))
            {
                // AddItmExtHeader(3, GetBitfieldByte(new int[]{0}), 3, 0, "MH#MISC3", 4, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 1, 0, 159, 0, 0, 0, 0, 0, 0);
                // AddItmAbility(146, 1, 0, 6, 0, 1, 0, 0, 100, 0, "SPWI322" + new char(), 0, 0, 0, 0, 0, 1);
                AddItmExtHeader(3, GetBitfieldByte(new int[]{0}), 3, 0, "SPWI203B", 5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 1, 0, 1, 0, 0, 0, 0, 0, 0);
                AddItmAbility(146, 1, 0, 6, 0, 1, 0, 0, 100, 0, "SPWI203" + new char(), 0, 0, 0, 0, 0, 1);

                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPWI301B";
                splExtHeadersModded[0] = currentSplExtendedHeader;

                foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                {
                    itmExtHeader.maxCharges = 10;
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // change sandthief's ring charges (making it more usable)
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "RING05."))
            {
                currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[0];
                currentItmExtHeader.maxCharges = 3;
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change bonus of evermemory / ring of Wizardry
            if (GetTlkStringFromStrRef(itmHeaderModded.nameId).Equals("Evermemory") || GetTlkStringFromStrRef(itmHeaderModded.nameId).Equals("Ring of Wizardry"))
            {
                RemoveItmEffect(2);
                AddItmEffect(42, 1, 0, 1, GetBitfieldInt(new int[]{0, 1}), 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change bonus of the amplifier
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "AMUL16."))
            {
                RemoveAllItmEffects();
                AddItmEffect(42, 1, 0, 1, GetBitfieldInt(new int[]{2, 3}), 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change bonus of ring of beauty
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "X#RINGRO"))
            {
                RemoveAllItmEffects();
                AddItmEffect(6, 1, 0, 2, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change bonuses on edwins amulet to only give +2 level 1, 2, 3, 4 spells
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "MISC89"))
            {
                RemoveAllItmEffects();
                
                AddItmEffect(42, 1, 0, 2, GetBitfieldInt(new int[]{0, 1, 2, 3, 4}), 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // composite longbows str requirement fix
            if (itmHeaderModded.itemType == 15)
            {
                if (itmHeaderModded.minStr > 12)
                {
                    // Console.WriteLine(currentItemFileInfo.Name);
                    itmHeaderModded.minStr -= 6;
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            // increase/decrease charges of multiple items
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "AMUL01") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "AMUL15") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "AMUL17") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "BDAMUL21") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "CHALCY3") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "CLCK20") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "IPSION") ||
                //
                ContainsCaseInsensitive(currentItemFileInfo.Name, "CLCK20") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "mh#ring4") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "mh#staf5") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "mh#staf6") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "MISC2P") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "MISC73") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "MISC98") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "OHRCLCK3") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "rgtlsoa") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "RING03") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "RING20") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "ROSSLAND") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "STAF05") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "STAF09") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "STAF16") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "STAF17")
                )
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    if (extHeader.maxCharges >= 10)
                    {
                        extHeader.maxCharges = 20;
                    }
                }
                
                // Console.WriteLine("ITM MODDED:" + currentItemFileInfo.Name);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // increase charges on spectacles of spectacle
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "BDMISC01.ITM"))
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    extHeader.maxCharges = 20;
                }

                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // decrease max charges for wands
            if (itmHeader.itemType == 35 && !currentItemFileInfo.Name.Equals("MH#WAND2")) // exclude wand of blasting   
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    extHeader.maxCharges = 20;
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change elmiras wand of blasting
            if (ContainsCaseInsensitive(currentItemFileInfo.Name,"MH#WAND2"))
            {
                RemoveAllItmExtHeadersAndItmAbilities();
                
                // AddItmExtHeader(3, GetBitfieldByte(new int[] {0}), 3, 0, "IWAND06" + new char(), 1, 0, 40, 0, 0, 0, 0, 0, 6, 6, 0, 10, 0, 1, 0, 0, 10, 1, GetBitfieldInt(new int[] {9}), proFrostRayId, 34, 33, 33, 0, 0, 0);
                AddItmExtHeader(3, GetBitfieldByte(new int[] {0}), 3, 0, "MH#WAND2", 1, 0, 70, 0, 0, 0, 0, 0, 0, 6, 0, 10, 0, 0, 0, 0, 3, 1, GetBitfieldInt(new int[] {10, 11}), 1, 34, 33, 33, 0, 0, 0);
                AddItmAbility(146, 2, 4, 12, 2, 0, 0, 0, 100, 0, "SPWI429" + new char(), 0, 0, 0, 0, 0, 0);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // change wand of water elemental summoning
            if (ContainsCaseInsensitive(currentItemFileInfo.Name,"BDWAND01"))  
            {
                foreach (ItmFeatBlock itmFeatBlock in itmAbilFeatBlocksModded)
                {
                    if (itmFeatBlock.opcodeNumber == 331)
                    {
                        itmFeatBlock.duration = 2400;
                    }
                }

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // increase duration of potion of mirrored eyes
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "POTN38.ITM"))
            {
                
                RemoveAllItmAbilitiesFromExtHeader(0);
                
                AddItmAbility(267, 1, 1, AddExactTlkEntryIfNotFound("Petrified"), 0, 0, 0, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(101, 1, 1, 0, 134, 0, 0, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 1, -1, 0, 0, 0, 1800, 100, 0, "P5DROP3" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(328, 1, 1, 0, 107, 0, 0, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(142, 1, 1, 0, 10, 0, 0, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                String findStr = "Protected from Petrification";
                AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 0, 0, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                
                AddItmAbility(83, 1, 0, 0, 64, 0, 0, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN883" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN839" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "INSANITY", 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "BEGUILE" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "D0QPMGAZ", 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN784" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN996" + new char(), 0, 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // make magic missile want more useful
            if (EqualsCaseInsensitive(currentName, "Wand of Magic Missiles"))
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    if (extHeader.projectileAnimation == 37)
                    {
                        extHeader.projectileAnimation = 72;
                    }
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // make wand of glitterdust party only
            if (EqualsCaseInsensitive(currentName, "Wand of Glitterdust"))
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    if (extHeader.projectileAnimation == 150)
                    {
                        extHeader.projectileAnimation = 170;
                    }
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // restore BG1 Wand of Frost Function
            if (EqualsCaseInsensitive(currentName, "Wand of Frost"))
            {
                AddItmExtHeader(3, GetBitfieldByte(new int[] {0}), 3, 0, "SPWI424B", 1, 0, 40, 0, 0, 0, 0, 0, 6, 6, 0, 10, 0, 1, 0, 0, 20, 1, GetBitfieldInt(new int[] {9}), proFrostRayId, 34, 33, 33, 0, 0, 0);
                AddItmAbility(177, 2, 3, 129, 4, 1, 1, 0, 100, 0, "DRTROLCO", 0, 0, 0, 0, 0, 1);
                AddItmAbility(12, 2, 3, 6, 0, 2, 1, 1, 0, 100, 0, new string(new char[8]), 4, 6, GetBitfieldInt(new int[] {3, 24}), 0, GetBitfieldInt(new int[] {8}), 1);
                
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[0];
                currentSplExtendedHeader.memorizedIcon = "SPWI503B";
                splExtHeadersModded[0] = currentSplExtendedHeader;
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // nerf wand of fire's agannazars scorcher
            if (EqualsCaseInsensitive(currentName, "Wand of Fire"))
            {
                foreach (ItmFeatBlock itmAbil in itmAbilFeatBlocksModded)
                {
                    if (itmAbil.diceThrown == 6 && itmAbil.diceSides == 6)
                    {
                        itmAbil.diceThrown = 3;
                        itmAbil.parameter21 = 0;
                        // itmAbil.stackingId = GetBitfieldInt(new int[] {8});
                        
                    }
                    else if (itmAbil.diceThrown == 6 && itmAbil.diceSides == 5)
                    {
                        // itmAbil.stackingId = GetBitfieldInt(new int[] {8});
                        itmAbil.diceSides = 6;
                        itmAbil.parameter21 = 0;
                    }
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // wand of lightning not bounce effect
            if (EqualsCaseInsensitive(currentName, "Wand of Lightning"))
            {
                foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                {
                    if (itmExtHeader.projectileAnimation == 40 || itmExtHeader.projectileAnimation == 206)
                    {
                        itmExtHeader.projectileAnimation = 207;
                    }
                }

                // foreach (ItmFeatBlock itmAbilFeatBlock in itmAbilFeatBlocks)
                // {
                //     if (itmAbilFeatBlock.opcodeNumber == 12)
                //     {
                //         itmAbilFeatBlock.diceThrown = 6;
                //     }
                // }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // wand of sleep
            if (EqualsCaseInsensitive(currentName, "Wand of Sleep"))
            {
                RemoveAllItmAbilities();
                
                AddItmAbility(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL0", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL1", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL2", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL3", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 2, 4, 0, 0, 0, 90, 0, "CDELFSL4", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL0", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL1", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL2", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL3", 0, 0,0, 0, 0, 0);
                AddItmAbility(177, 2, 0, 3, 4, 0, 0, 0, 30, 0, "CDELFSL4", 0, 0,0, 0, 0, 0);
                
                AddItmAbility(39, 2, 1, 0, 0, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0,GetBitfieldInt(new int[]{3}), 0, 0, 0);
                AddItmAbility(142, 2, 1, 0, 14, 0, 1, 60, 100, 0, new string(new char[8]), 0, 0,GetBitfieldInt(new int[]{3}), 0, 0, 0);
                AddItmAbility(215, 2, 1, 0, 1, 0, 1, 1, 100, 0, "SPNWCHRM", 0, 0,GetBitfieldInt(new int[]{3}), 0, 0, 0);
                // AddSplFeatureBlockToSplExtendedHeader(232, 2, 1, 0, 0, 0, 1, 60, 100, 0, "WAND80D" + new string(new char[1]), 0, 0,0, 0, 0, 0);
                AddItmAbility(139, 2, 1, AddExactTlkEntryIfNotFound("Unconscious"), 0, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[]{3}), 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // wand of polymorphing
            if (EqualsCaseInsensitive(currentName, "Wand of Polymorphing"))
            {
                RemoveAllItmAbilities();

                rgb = new byte[]{0, 60, 60, 120};
                AddItmAbility(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "SPPOLYMP", 0, 0, 16, 0, 0, 0);
                AddItmAbility(215, 2, 5, 0, 1, 0, 1, 3, 100, 0, "POLYBACK", 0, 0, 16, 0, 0, 0);
                AddItmAbility(111, 2, 5, 0, 0, 1, 1, 0, 100, 0, "DVSQUIR" + new char(), 0, 0, 16, 0, 0, 0);
                AddItmAbility(174, 2, 4, 0, 0, 1, 1, 0, 100, 0, "EFF_P07" + new char(), 0, 0, 16, 0, 0, 0);
                AddItmAbility(174, 2, 4, 0, 4, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 16, 0, 0, 0);
                AddItmAbility(61, 2, 4, BitConverter.ToInt32(rgb, 0), 4, 1, 1, 0, 100, 0, new string(new char[8]), 0, 0, 16, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // nerf wand of paralyzation
            if (EqualsCaseInsensitive(currentName, "Wand of Paralyzation"))
            {
                foreach (ItmFeatBlock itmAbilFeatBlock in itmAbilFeatBlocks)
                {
                    if (itmAbilFeatBlock.savingThrowBonus < 0)
                    {
                        itmAbilFeatBlock.savingThrowBonus = 0;
                    }
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // druid's ring summons animals instead od charming them
            if (EqualsCaseInsensitive(currentName, "Druid's Ring"))
            {
                RemoveAllItmAbilities();

                itmHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 22, 29});
                
                AddItmEffect(62, 1, 0, 1, GetBitfieldInt(new int[] {0}), 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(62, 1, 0, 1, GetBitfieldInt(new int[] {1}), 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmAbility(331, 1, 3, 0, FindInSmTables("ASUMMO1"), 0, 3, 300, 100, 0, "ASUMMO1" + new char(), 2, 2, 0, 0, 0, 0);
                
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[0];
                currentItmExtHeader.targetType = 4;
                itmExtHeadersModded[0] = currentItmExtHeader;
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // Sune Ring usable for paladins
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "RING22"))
            {
                itmHeaderModded.exclusionFlags = GetBitfieldInt(new int[] {6, 11, 13, 16, 17, 18, 19, 21, 22});
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // // fix golem tome item type (scroll) & allow more golem repairs per day & always give banish golem spirit
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "0") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "1") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "2") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "3") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "4") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "5") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "6") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "7") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "8") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "9") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "a") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "b") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "c") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "d")
            )
            {
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 172 ||
                        currentItmFeatBlock.opcodeNumber == 171
                    )
                    {
                        // Console.WriteLine(currentItem);
                        RemoveItmAbility(i);
                        
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                    if (
                        currentItmFeatBlock.opcodeNumber == 122
                    )
                    {
                        currentItmFeatBlock.probability1 = 100;
                        
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }

                itmHeaderModded.itemType = 11; // make it a scroll, so it cans be stored in scroll cases

                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!smgl" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!smgl" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // fix mutamin's cloak
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "mh#clck1."))
            {
                RemoveAllItmEffects();

                AddItmEffect(267, 1, 1, AddExactTlkEntryIfNotFound("Petrified"), 0, 2, 0, 0, 100, 0,
                    new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 1, 0, 134, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 1, -1, 0, 2, 0, 0, 100, 0, "P5DROP3" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 1, 0, 107, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(142, 1, 1, 0, 10, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                
                String findStr = "Protected from Petrification";
                AddItmEffect(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);

                AddItmEffect(83, 1, 0, 0, 64, 2, 0, 0, 100, 2, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 2, 0, 0, 100, 0, "SPIN883" + new string(new char[1]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 2, 0, 0, 100, 0, "SPIN839" + new string(new char[1]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 2, 0, 0, 100, 0, "INSANITY", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 2, 0, 0, 100, 0, "BEGUILE" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 2, 0, 0, 100, 0, "D0QPMGAZ", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 2, 0, 0, 100, 0, "SPIN784" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 2, 0, 0, 100, 0, "SPIN996" + new char(), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // HIDDEN UNDROPPABLE ITEM CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            ///
            ///
            
            // remove immunities to spell levels for enemy only items possessed by liches (MAGEAMUL) etc. 
            if (!IsDroppable())
            {
                Boolean found = true;
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 102 || currentItmFeatBlock.opcodeNumber == 155)
                    {
                        RemoveItmEffect(i);
                        found = true;

                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
                if (found) // also remove immunities to particular spell immunities (e.g. silence), if we detect the immunity to spell level variable
                {
                    for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                    {
                        currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                        if (currentItmFeatBlock.opcodeNumber == 206)
                        {
                            RemoveItmEffect(i);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                    }
                }

                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 102)
                    {
                        RemoveItmAbility(i);
                        found = true;
                        
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
                if (found) // also remove immunities to particular spell immunities (e.g. silence), if we detect the immunity to spell level variable
                {
                    for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                    {
                        currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                        if (currentItmFeatBlock.opcodeNumber == 206)
                        {
                            RemoveItmAbility(i);
                            found = true;
                        
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                    }
                }
            }

            // prevent seeing through invisibility per item SEEALL.ITM ETC
            if (!IsDroppable())
            {
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 193)
                    {
                        RemoveItmEffect(i);
                        
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }

                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 193)
                    {
                        Console.WriteLine(currentItemFileInfo);
                        RemoveItmAbility(i);
                        
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }
            
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // WEAPON DAMAGE CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 
            ///
            /// 

            // WAR HAMMERS
            if (itmHeaderModded.itemType == 21 && itmHeaderModded.weapProf == 97) // if itemType and prof type matches
            {
                ItmExtHeader currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[0];
                if (currentItmExtHeader.diceSides == 4 && currentItmExtHeader.diceThrown == 1) // make sure damage matches
                {
                    currentItmExtHeader.dmgBonus++;
                    itmExtHeadersModded[0] = currentItmExtHeader;
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            // SPEARS
            if (itmHeaderModded.itemType == 29 && itmHeaderModded.weapProf == 98) // if itemType and prof type matches
            {
                ItmExtHeader currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[0];
                if (currentItmExtHeader.diceSides == 8 && currentItmExtHeader.diceThrown == 1) // make sure damage matches
                {
                    currentItmExtHeader.diceSides = 10;
                    itmExtHeadersModded[0] = currentItmExtHeader;
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            // QUARTERSTAVES
            if (itmHeaderModded.itemType == 26 && itmHeaderModded.weapProf == 102) // if itemType and prof type matches
            {
                ItmExtHeader currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[0];
                if (currentItmExtHeader.diceSides == 6 && currentItmExtHeader.diceThrown == 1) // make sure damage matches
                {
                    currentItmExtHeader.diceSides = 8;
                    itmExtHeadersModded[0] = currentItmExtHeader;
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }

            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // CUSTOM SPELL REVISION CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 
            ///
            ///
            ///
            ///

            // SCROLL OF CONFUSION TO MIND SHIELD
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "SCRL1U."))
            {
                itmHeaderModded.nameId = AddExactTlkEntryIfNotFound("Mind Shield");
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            // SCROLL OF BLOOD RAGE TO MIND SHIELD
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "cdid421."))
            {
                itmHeaderModded.nameId = AddExactTlkEntryIfNotFound("Mind Shield");
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // SCROLL OF ANIMATE DEAD TO REVIVE SKELETON ARCHER
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "SCRL2D."))
            {
                itmHeaderModded.nameId = AddExactTlkEntryIfNotFound("Revive Skeleton Archer");
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // CHANGE NISHRUU ATTACK 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "NISHRUU."))
            {
                String addStr = "Magic drained";
                AddTlkEntry(addStr);
                for (int i = 0; i < itmExtHeadersModded.Count; i++)
                {
                    AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound("Magic drained"), 0, 1, 2, 0, 100, 0,
                        new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, i);
                }

                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // CHANGE HAKESHAR ATTACK 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "HAKESHAR."))
            {
                String addStr = "Magic drained";
                AddTlkEntry(addStr);
                for (int i = 0; i < itmExtHeadersModded.Count; i++)
                {
                    AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound("Magic drained"), 0, 1, 2, 0, 100, 0,
                        new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, i);
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change potion of infravision to cure blindness
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "POTN30"))
            {
                AddItmAbility(75, 1, 3, 0, 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(337, 1, 3, 0, 74, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(240, 1, 3, 0, 8, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(169, 1, 3, 0, 8, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(267, 1, 3, AddExactTlkEntryIfNotFound("Blinded"), 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(267, 1, 3, AddExactTlkEntryIfNotFound("Blindness"), 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(267, 1, 3, AddExactTlkEntryIfNotFound("Blind"), 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(101, 1, 3, 0, 74, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change various infravision items to also protect against blindness (NOTE: DOES NOT CURE BLINDNESS!)
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "cdioun1") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "^HELM05") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "mh#belt1") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "mh#belt3") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "RING21")
            )
            {
                // Console.WriteLine(currentItemFileInfo.Name);
                AddItmEffect(169, 1, 3, 0, 8, 2, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 1, 3, AddExactTlkEntryIfNotFound("Blinded"), 0, 2, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 1, 3, AddExactTlkEntryIfNotFound("Blindness"), 0, 2, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 1, 3, AddExactTlkEntryIfNotFound("Blind"), 0, 2, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 3, 0, 74, 2, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change potion of clairvoyance to accord with the new clairvoyance spell
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "MH#POTN2"))
            {
                RemoveAllItmAbilities();
                AddItmAbility(141, 2, 3, 0, 37, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(215, 1, 3, 0, 1, 0, 3, 2, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 0);
                AddItmAbility(0, 1, 3, 2, 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(36, 1, 2, 3, 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(292, 1, 3, 0, 1, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(142, 1, 3, 0, 57, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);

                AddItmAbility(75, 1, 3, 0, 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(337, 1, 3, 0, 74, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(240, 1, 3, 0, 8, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(169, 1, 3, 0, 8, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(267, 1, 3, AddExactTlkEntryIfNotFound("Blinded"), 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(267, 1, 3, AddExactTlkEntryIfNotFound("Blindness"), 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(267, 1, 3, AddExactTlkEntryIfNotFound("Blind"), 0, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(101, 1, 3, 0, 74, 0, 3, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // CHANGE NAME OF POTION OF CLAIRVOYANCE IN SOD (ITS MISLEADING)
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "OHDPOTN1"))
            {
                AddTlkEntry("Potion of Revelation");
                itmHeaderModded.nameId = AddExactTlkEntryIfNotFound("Potion of Revelation");

                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // POTION OF FIRE COLD ELECTRICAL RESISTANCE 75%
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "POTN02") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "POTN22") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "POTN31")
            )
            {
                foreach (ItmFeatBlock featBlock in itmAbilFeatBlocks)
                {
                    if (
                        featBlock.opcodeNumber == 28 ||
                        featBlock.opcodeNumber == 29 ||
                        featBlock.opcodeNumber == 30
                    )
                    {
                        featBlock.parameter1 = 75;
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }

            // adapt wand of monster summoning 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "WAND10"))
            {
                RemoveAllItmAbilities();
                AddItmAbility(174, 1, 3, 0, 0, 1, 0, 0, 100, 0, "EFF_M13" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(331, 1, 3, 0, FindInSmTables("MSUMMO1"), 0, 3, 300, 100, 50, "MSUMMO1" + new char(), 2, 2,
                    0, 0, 0, 0);
                AddItmAbility(331, 1, 3, 0, FindInSmTables("MSUMMO2"), 0, 3, 300, 49, 15, "MSUMMO2" + new char(), 2, 2,
                    0, 0, 0, 0);
                AddItmAbility(331, 1, 3, 0, FindInSmTables("MSUMMO3"), 0, 3, 300, 14, 0, "MSUMMO3" + new char(), 2, 2,
                    0, 0, 0, 0);

                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // replace imoen's wand of magic missiles
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "X#XZMIRI."))
            {
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/WAND12_.ITM");
            }
            
            // adapt Albruins Protection from Poison & Detect Invisibility to match BGEE_REVISIONS
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "COMPS34.") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "SW1H34.")
            )
            {
                RemoveItmAbility(0);
                RemoveItmAbility(0);
                RemoveItmAbility(0);
                RemoveItmAbility(0);
                RemoveItmAbility(0);
                RemoveItmAbility(0);
                RemoveItmAbility(0);
                
                RemoveAllItmEffects();
                
                // ADD NEW POISON PROTECTION EFFECT
                AddItmEffect(267, 2, 0, AddExactTlkEntryIfNotFound("Poison"), 25, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 2, 0, AddExactTlkEntryIfNotFound("Poisoned"), 25, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 2, 0, 0, 137, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 2, 0, 0, 6, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 2, 0, 0, 25, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(173, 2, 0, 100, 0, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(142, 2, 0, 0, 30, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(164, 2, 0, 0, 0, 2, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI502" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI016" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPIN673" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI213" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWM187" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI004" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPIN940" + new char(), 0, 0, 0, 0, 0);
                
                // ADD NEW DETECT INVISIBILITY
                // AddItmAbility(318, 2, 0, 0, 143, 0, 2, 0, 100, 0, "SPWI203" + new char(), 0, 0, 0, 0, 0, 1);
                // AddItmAbility(116, 2, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 1);
                // AddItmAbility(141, 2, 0, 0, 30, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 1);
                // AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound("Dispel Invisible"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 1);
                // AddItmAbility(215, 1, 0, 0, 1, 0, 2, 2, 100, 0, "SPTRUSEE", 0, 0, 0, 0, 0, 1);
                // AddItmAbility(174, 2, 0, 0, 0, 0, 2, 0, 100, 0, "EFF_M04" + new char(), 0, 0, 0, 0, 0, 1);
                AddItmAbility(146, 1, 1, 1, 1, 1, 3, 0, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 1);
                AddItmAbility(146, 1, 1, 1, 1, 4, 3, 6, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 1);
                AddItmAbility(146, 1, 1, 1, 1, 4, 3, 12, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 1);
                AddItmAbility(146, 1, 1, 1, 1, 4, 3, 18, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 1);
                AddItmAbility(146, 1, 1, 1, 1, 4, 3, 24, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 1);
                AddItmAbility(146, 1, 1, 1, 1, 4, 3, 30, 100, 0, "SPWI203B", 0, 0, 0, 0, 0, 1);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // adapt Alicorn Spear Protection from Poison to match BGEE_REVISIONS
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "MH#SPER1.")
            )
            {
                RemoveAllItmEffects();
                
                // ADD NEW POISON PROTECTION EFFECT
                AddItmEffect(267, 2, 0, AddExactTlkEntryIfNotFound("Poison"), 25, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 2, 0, AddExactTlkEntryIfNotFound("Poisoned"), 25, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 2, 0, 0, 137, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 2, 0, 0, 6, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 2, 0, 0, 25, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(173, 2, 0, 100, 0, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(142, 2, 0, 0, 30, 2, 1, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(164, 2, 0, 0, 0, 2, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI502" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI016" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPIN673" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI213" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWM187" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPWI004" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 2, 0, 0, 100, 0, "SPIN940" + new char(), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // Upgrade the Generic Protection Scrolls (make them provide 100% resistance)
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL03.ITM") ||
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL04.ITM") ||
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL05.ITM") ||
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL06.ITM") ||
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL08.ITM")
            )
            {
                foreach (ItmFeatBlock itmFeatBlock in itmAbilFeatBlocksModded)
                {
                    if (
                        itmFeatBlock.opcodeNumber == 27 ||
                        itmFeatBlock.opcodeNumber == 28 ||
                        itmFeatBlock.opcodeNumber == 29 ||
                        itmFeatBlock.opcodeNumber == 30 ||
                        itmFeatBlock.opcodeNumber == 173
                    )
                    {
                        itmFeatBlock.parameter1 = 100;
                    }
                }

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // Add Protection String to Generic Protection Scrolls individually
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL03.ITM")
            )
            {
                String findStr = "Protected from Acid";
                Console.WriteLine(currentItemFileInfo.Name);
                AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 1, 0, 3600, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL04.ITM")
            )
            {
                String findStr = "Protected from Cold";
                AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 1, 0, 3600, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL05.ITM")
            )
            {
                String findStr = "Protected from Lightning";
                AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 1, 0, 3600, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL06.ITM")
            )
            {
                String findStr = "Protected from Fire";
                AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 1, 0, 3600, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL08.ITM")
            )
            {
                RemoveAllItmAbilities();
                
                rgb = new byte[] {0, 50, 255, 255};
            
                AddItmAbility(267, 2, 0, AddExactTlkEntryIfNotFound("Poison"), 25, 0, 1, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(267, 2, 0, AddExactTlkEntryIfNotFound("Poisoned"), 25, 0, 1, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(169, 2, 0, 0, 137, 0, 1, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(169, 2, 0, 0, 6, 0, 1, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(101, 2, 0, 0, 25, 0, 1, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(173, 2, 0, 100, 0, 0, 1, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(142, 2, 0, 0, 30, 0, 1, 1800, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(141, 2, 0, 0, 2, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(50, 2, 0, BitConverter.ToInt32(rgb, 0), 0, 0, 30, 0, 0, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(164, 2, 0, 0, 0, 1, 3, 1, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(174, 2, 0, 0, 0, 1, 3, 1, 100, 0, "EFF_P06" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 0, 0, 1800, 100, 0, "SPWI502" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 0, 0, 1800, 100, 0, "SPWI016" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 0, 0, 1800, 100, 0, "SPIN673" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 0, 0, 1800, 100, 0, "SPWI213" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 0, 0, 1800, 100, 0, "SPWM187" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 0, 0, 1800, 100, 0, "SPWI004" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Immunity To Effect"), 0, 0, 0, 1800, 100, 0, "SPIN940" + new char(), 0, 0, 0, 0, 0, 0);

                String displayString = "Protected from Poison";
                AddExactTlkEntryIfNotFound(displayString);
                AddItmAbility(139, 2, 3, AddExactTlkEntryIfNotFound(displayString), 0, 1, 3, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL09.ITM")
            )
            {
                String findStr = "Protected from Undead";
                AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 1, 0, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (
                EqualsCaseInsensitive(currentItemFileInfo.Name, "SCRL15.ITM")
            )
            {
                String findStr = "Protected from Petrification";
                AddItmAbility(139, 2, 0, AddExactTlkEntryIfNotFound(findStr), 0, 0, 0, 1800, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {2}), 0, 0, 0);

                AddItmAbility(83, 1, 0, 0, 64, 0, 0, 300, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN883" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN839" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "INSANITY", 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "BEGUILE" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "D0QPMGAZ", 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN784" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(206, 1, 0, AddExactTlkEntryIfNotFound("Protected from Gaze"), 64, 0, 0, 1800, 100, 0, "SPIN996" + new char(), 0, 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            /////////////////////////
            // MAKE BUFF SPELLS AOE
            /////////////////////////
            
            // scroll of Bull's Strength only castable on self
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "scrl98."))
            {
                foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                {
                    itmExtHeader.targetType = 5;
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // scroll of Haste & improved Haste only castable on self
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "scrl1h.") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "scrl7q.")
            )
            {
                foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                {
                    itmExtHeader.targetType = 5;
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // scroll of True Strike only castable on self
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "scrl76."))
            {
                foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                {
                    itmExtHeader.targetType = 5;
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // scroll of Cat's grace only castable on self
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "cdia225."))
            {
                foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                {
                    itmExtHeader.targetType = 5;
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // scroll of Protection from Poison only castable on self
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "scrl5j.") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "scrl08.")
            )
            {
                foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                {
                    itmExtHeader.targetType = 5;
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            identifiers = new String[]
            {
                "Aid",
                "Barkskin",
                "Bless",
                "Blood Rage",
                "Cat's Grace",
                // "Cure Disease",
                "Chaotic Commands",
                "Champion's Strength",
                // "Cure Light Wounds",
                // "Cure Medium Wounds",
                // "Cure Moderate Wounds",
                // "Cure Serious Wounds",
                // "Cure Critical Wounds",
                "Death Ward",
                "Defensive Harmony",
                "Detect Evil",
                "Emotion, Courage",
                "Emotion, Hope",
                "Enchanted Weapon",
                "Free Action",
                "Exaltation",
                "Haste",
                "Improved Haste",
                // "Improved Invisibility",
                // "Invisibility",
                "Invisibility, 10' Radius",
                "Lesser Restoration",
                "Luck",
                "Greater Restoration",
                "Mass Invisibility",
                "Negative Plane Protection",
                "Non-Detection",
                "Prayer",
                "Protection From Acid",
                "Protection From Cold",
                "Protection From Electricity",
                "Protection From Energy",
                "Protection From Evil",
                "Protection From Evil, 10' Radius",
                "Protection From Fire",
                "Protection From Lightning",
                "Protection From Magic Energy",
                "Protection From Magical Weapons",
                "Protection From Normal Missiles",
                "Protection From Normal Weapons",
                "Protection From Petrification",
                "Protection From The Elements",
                "Recitation",
                "Remove Fear",
                "Resist Fear",
                "Resist Fire and Cold",
                "Righteous Wrath of the Faithful",
                "Spirit Armor",
                "Spiritual Clarity",
                "Spirit Ward",
                "Strength",
                "Strength of One",
                "Undead Ward"
            };
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "SCRL"))
            {
                foreach (String identifier in identifiers)
                {
                    if (ContainsCaseInsensitive(GetTlkStringFromStrRef(itmHeaderModded.nameId), identifier))
                    {
                        foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
                        {
                            if (itmExtHeader.targetType == 1 || itmExtHeader.targetType == 4)
                            {
                                itmExtHeader.targetType = 5;
                                itmExtHeader.projectileAnimation = 1;
                            }
                        }

                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }

            /////////////////////////////////////
            /////////////////////////////////////
            //      CHANGE ITEMS OF SPEED    ///
            /////////////////////////////////////
            /////////////////////////////////////

            // MAKE RING OF FREE ACTION +1/+2 ACTUAL RINGS OF FREE ACTION +1/+2
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "thring01"))
            {
                RemoveAllItmEffects();
                
                AddItmEffect(267, 1, 0, FindExactTlkEntry("Held"), 0, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 1, 0, FindExactTlkEntry("Slowed"), 0, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 1, 0, FindExactTlkEntry("Slow"), 0, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWI312" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWISH25", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN983" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN977" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWM164" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 145, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "CDSW1H58", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "CDMOUND" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "CDHGNYA1", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWM111" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPPR105" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN688" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 144, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 145, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 144, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 129, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 55, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 41, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 13, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(162, 1, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(46, 1, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(163, 1, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 144, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 40, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 148, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 109, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 0, 0, 158, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 0, 0, 157, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 0, 0, 154, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(142, 1, 0, 0, 19, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 13, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 41, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 148, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 175, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 148, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 175, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(296, 1, 0, 0, 0, 2, 2, 0, 100, 0, "SPMINDAT", 0, 0, 0, 0, 0);
                AddItmEffect(296, 1, 0, 0, 0, 2, 2, 0, 100, 0, "SPFLAYER", 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 129, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                
                AddItmEffect(0, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(33, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(34, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(35, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(36, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(37, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "thring02"))
            {
                RemoveAllItmEffects();
                
                AddItmEffect(267, 1, 0, FindExactTlkEntry("Held"), 0, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 1, 0, FindExactTlkEntry("Slowed"), 0, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(267, 1, 0, FindExactTlkEntry("Slow"), 0, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN575" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWI312" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWISH25", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN983" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN977" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWM164" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 145, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "CDSW1H58", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "CDMOUND" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "CDHGNYA1", 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPWM111" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPPR105" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 0, -1, 0, 2, 2, 0, 100, 0, "SPIN688" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 144, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 145, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 144, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 129, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 55, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 41, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(240, 1, 0, 0, 13, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(162, 1, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(46, 1, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(163, 1, 0, 0, 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 144, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 40, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 148, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 109, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 0, 0, 158, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 0, 0, 157, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 0, 0, 154, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(142, 1, 0, 0, 19, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 13, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 41, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 148, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 175, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 0, 0, 148, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(101, 1, 0, 0, 175, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(296, 1, 0, 0, 0, 2, 2, 0, 100, 0, "SPMINDAT", 0, 0, 0, 0, 0);
                AddItmEffect(296, 1, 0, 0, 0, 2, 2, 0, 100, 0, "SPFLAYER", 0, 0, 0, 0, 0);
                AddItmEffect(169, 1, 0, 0, 129, 2, 2, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                
                AddItmEffect(0, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(33, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(34, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(35, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(36, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(37, 1, 0, 1, 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // CHANGE ALL ITEMS THAT SET ATTACKS TO "INCREMENT" INSTEAD OF "SET" BECAUSE SET RESETS THE HASTE EFFECTS
            if (IsDroppable())
            {
                foreach (ItmFeatBlock itmFeatBlock in itmEffFeatBlocksModded)
                {
                    if (itmFeatBlock.opcodeNumber == 1) // if modify attacks per round
                    {
                        if (itmFeatBlock.parameter2 == 1) // if set attacks per round
                        {
                            itmFeatBlock.parameter2 = 0; // set to increment
                            itmFeatBlock.parameter1--;
                            // Console.WriteLine("WEAPON: " + currentName + " attacks per round set to +" +
                                              // itmFeatBlock.parameter1);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                    }
                }
            }

            // change amulet of cheetah speed ItmAbility
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "AMUL26."))
            {
                RemoveAllItmExtHeadersAndItmAbilities();
                AddItmEffect(1, 1, 0, 125, 2, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // change bracers of blinding strike
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "BRAC16."))
            {
                RemoveAllItmAbilities();
                AddItmAbility(146, 1, 0, 8, 0, 9, 2, 0, 100, 0, "SPWI613"+ new char(), 0, 0, 0, 0, 0, 0);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // remove movement speed setting for potion of freedom 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "POTN45.") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "DW#POTN45.")
            )
            {
                
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 126
                    )
                    {
                        // Console.WriteLine(i + "   " + itmAbilFeatBlocksModded.Count);
                        RemoveItmAbility(i);
                    }
                }
            
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // remove movement speed setting for spider's bane 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "SW2H06.") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "SW2H13.") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "u!spbane."))
            {
                
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 126 || currentItmFeatBlock.opcodeNumber == 176
                    )
                    {
                        RemoveItmEffect(i);
                    }
                }

                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // replace opcode HASTE for all items and standardize Change Movements speed
            // GLOBAL EFFECTS (WHILE EQUIPPED)
            for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 16 ||
                    currentItmFeatBlock.opcodeNumber == 317 ||
                    currentItmFeatBlock.opcodeNumber == 126 ||
                    currentItmFeatBlock.opcodeNumber == 176
                )
                {
                    ModifyItmEffectOpcode(176);
                    ModifyItmEffectParam1(125);
                    ModifyItmEffectParam2(2);
                    AddItmEffect(1, 1, 0, 150, 2, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                    
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }

            // USED ABILITIES (E.G. WHEN CONSUMED)
            for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 16 ||
                    currentItmFeatBlock.opcodeNumber == 317 ||
                    currentItmFeatBlock.opcodeNumber == 126 ||
                    currentItmFeatBlock.opcodeNumber == 176
                )
                {
                    ModifyItmEffectOpcode(176);
                    ModifyItmEffectParam1(125);
                    ModifyItmEffectParam2(2);
                    DuplicateItmAbility(176, 1, 2);
                    //AddItmAbility(1, 1, 0, 150, 2, 0, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                    
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            // stop the prevention of haste blocking for rings of free action, spider's bane & ADD PROTECTION FROM GREASE
            for (int i = 0; i < itmEffFeatBlocksModded.Count; i++)
            {
                Boolean found = false;
                currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 163 && IsDroppable()
                )
                {
                    // Console.WriteLine(currentItemFileInfo.Name + " : " + currentItmFeatBlock.opcodeNumber);
                    
                    // add protection from grease
                    AddItmEffect(206, 2, 4, -1, 0, 0, 3, 300, 100, 0, "SPWI101" + new char(), 0, 0, 0, 0, 0);
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    
                    for (int j = itmEffFeatBlocksModded.Count - 1; j >= 0; j--)
                    {
                        currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[j];
                        if (
                            currentItmFeatBlock.opcodeNumber == 267 &&
                            (
                                currentItmFeatBlock.parameter1 == AddExactTlkEntryIfNotFound("Hasted") ||
                                currentItmFeatBlock.parameter1 == AddExactTlkEntryIfNotFound("Haste") // prevent string
                            )
                        )
                        {
                            found = true;
                            RemoveItmEffect(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            currentItmFeatBlock.opcodeNumber == 206 &&
                            (
                                currentItmFeatBlock.resource.Contains("spin828") ||
                                currentItmFeatBlock.resource.Contains("spin572") ||
                                currentItmFeatBlock.resource.Contains("spra301") ||
                                currentItmFeatBlock.resource.Contains("spwi305") ||
                                currentItmFeatBlock.resource.Contains("SPIN828") ||
                                currentItmFeatBlock.resource.Contains("SPIN572") ||
                                currentItmFeatBlock.resource.Contains("SPRA301") ||
                                currentItmFeatBlock.resource.Contains("SPWI305") // protection from spell
                            )
                        )
                        {
                            found = true;
                            RemoveItmEffect(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            currentItmFeatBlock.opcodeNumber == 101 &&
                            (
                                currentItmFeatBlock.parameter2 == 1 ||
                                currentItmFeatBlock.parameter2 == 190 ||
                                currentItmFeatBlock.parameter2 == 189 ||
                                currentItmFeatBlock.parameter2 == 16 ||
                                currentItmFeatBlock.parameter2 == 126 ||
                                currentItmFeatBlock.parameter2 == 176 ||
                                currentItmFeatBlock.parameter2 == 317 // protection from spell
                            )
                        )
                        {
                            found = true;
                            RemoveItmEffect(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            (
                                currentItmFeatBlock.opcodeNumber == 169 ||
                                currentItmFeatBlock.opcodeNumber == 240
                            )
                            &&
                            (
                                currentItmFeatBlock.parameter2 == 38 ||
                                currentItmFeatBlock.parameter2 == 195 ||
                                currentItmFeatBlock.parameter2 == 110 // prevent / remove portrait icon
                            )
                        )
                        {
                            found = true;
                            RemoveItmEffect(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + current       ItemFileInfo);
                        }
                    }
                }

                if (found)
                {
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }


            // stop the prevention of haste blocking for CONSUMABLE ABILITIES (Potion of freedom) & ADD PROTECTION FROM GREASE
            for (int i = 0; i < itmAbilFeatBlocksModded.Count; i++)
            {
                Boolean found = false;
                currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 163 && IsDroppable()
                )
                {
                    // add protection from grease
                    for (int k = 0; k < itmExtHeadersModded.Count; k++)
                    {
                        currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[k];
                        for (int l = 0; l < currentItmExtHeader.abilitiesCount; l++)
                        {
                            currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[l];
                            if (currentItmFeatBlock.opcodeNumber == 163)
                            {
                                AddItmAbility(206, 2, 4, -1, 0, 0, 3, 300, 100, 0, "SPWI101" + new char(), 0, 0, 0, 0, 0, k);
                                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                            }
                        }
                    }
                    
                    // Console.WriteLine(currentItemFileInfo.Name);
                    for (int j = itmAbilFeatBlocksModded.Count - 1; j >= 0; j--)
                    {
                        currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[j];
                        
                        // Console.WriteLine(currentItemFileInfo.Name + ":" + currentItmFeatBlock.opcodeNumber);
                        // if (
                        //     currentItmFeatBlock.opcodeNumber == 206 && currentItmFeatBlock.resource.Contains("spin828")
                        // )
                        // {
                        //     Console.WriteLine(currentItmFeatBlock.resource);
                        // }

                        if (
                            currentItmFeatBlock.opcodeNumber == 267 &&
                            (
                                currentItmFeatBlock.parameter1 == AddExactTlkEntryIfNotFound("Hasted") ||
                                currentItmFeatBlock.parameter1 == AddExactTlkEntryIfNotFound("Haste") // prevent string
                            )
                        )
                        {
                            found = true;
                            RemoveItmAbility(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            currentItmFeatBlock.opcodeNumber == 206 &&
                            (
                                currentItmFeatBlock.resource.Contains("spin828") ||
                                currentItmFeatBlock.resource.Contains("spin572") ||
                                currentItmFeatBlock.resource.Contains("spra301") ||
                                currentItmFeatBlock.resource.Contains("spwi305") ||
                                currentItmFeatBlock.resource.Contains("SPIN828") ||
                                currentItmFeatBlock.resource.Contains("SPIN572") ||
                                currentItmFeatBlock.resource.Contains("SPRA301") ||
                                currentItmFeatBlock.resource.Contains("SPWI305") // protection from spell
                            )
                        )
                        {
                            found = true;
                            RemoveItmAbility(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            currentItmFeatBlock.opcodeNumber == 101 &&
                            (
                                currentItmFeatBlock.parameter2 == 1 ||
                                currentItmFeatBlock.parameter2 == 190 ||
                                currentItmFeatBlock.parameter2 == 189 ||
                                currentItmFeatBlock.parameter2 == 16 ||
                                currentItmFeatBlock.parameter2 == 126 ||
                                currentItmFeatBlock.parameter2 == 176 ||
                                currentItmFeatBlock.parameter2 == 317 // protection from spell
                            )
                        )
                        {
                            found = true;
                            RemoveItmAbility(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            (
                                currentItmFeatBlock.opcodeNumber == 169 ||
                                currentItmFeatBlock.opcodeNumber == 240
                            )
                            &&
                            (
                                currentItmFeatBlock.parameter2 == 38 ||
                                currentItmFeatBlock.parameter2 == 195 ||
                                currentItmFeatBlock.parameter2 == 110 // prevent / remove portrait icon
                            )
                        )
                        {
                            found = true;
                            RemoveItmAbility(j);
                            
                            // FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                            //     itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                    }
                }
                if (found)
                {
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                        itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // SEVERAL ITEM USABILITY CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 
            ///
            /// 
            // CONSISTENT WAND USE (E.G. for thieves)
            if (itmHeaderModded.itemType == 35 && IsDroppable())
            {
                if (!UnusableBy("cleric"))
                {
                    itmHeaderModded.exclusionFlags =
                        ModExistingBitfield(itmHeaderModded.exclusionFlags, new[] {10, 20, 21},
                            false); // usable by cleric ranger, paladin, ranger
                }

                if (!UnusableBy("mage"))
                {
                    itmHeaderModded.exclusionFlags =
                        ModExistingBitfield(itmHeaderModded.exclusionFlags, new[] {9, 17, 22},
                            false); // usable by cleric thief, thief, fighter-thief
                }
            }

            
            // ItmAbilities
            for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 163 && IsDroppable()
                )
                {
                    for (int j = itmAbilFeatBlocksModded.Count - 1; j >= 0; j--)
                    {
                        currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[j];
                        if (
                            currentItmFeatBlock.opcodeNumber == 267 &&
                            (
                                currentItmFeatBlock.parameter1 == AddExactTlkEntryIfNotFound("Hasted") ||
                                currentItmFeatBlock.parameter1 == AddExactTlkEntryIfNotFound("Haste") // prevent string
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            currentItmFeatBlock.opcodeNumber == 206 &&
                            (
                                currentItmFeatBlock.resource.Equals("SPIN828") ||
                                currentItmFeatBlock.resource.Equals("SPIN572") ||
                                currentItmFeatBlock.resource.Equals("SPRA301") ||
                                currentItmFeatBlock.resource.Equals("SPWI305") // protection from spell
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            currentItmFeatBlock.opcodeNumber == 101 &&
                            (
                                currentItmFeatBlock.parameter2 == 1 ||
                                currentItmFeatBlock.parameter2 == 190 ||
                                currentItmFeatBlock.parameter2 == 189 ||
                                currentItmFeatBlock.parameter2 == 16 ||
                                currentItmFeatBlock.parameter2 == 126 ||
                                currentItmFeatBlock.parameter2 == 176 ||
                                currentItmFeatBlock.parameter2 == 317 // protection from spell
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }

                        if (
                            (
                                currentItmFeatBlock.opcodeNumber == 169 ||
                                currentItmFeatBlock.opcodeNumber == 240
                            )
                            &&
                            (
                                currentItmFeatBlock.parameter2 == 38 ||
                                currentItmFeatBlock.parameter2 == 110 // prevent / remove portrait icon
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                                itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                    }
                }
            }

            // make every weapon usable for thieves (strength limitations and proficiency limitations remain!!) & thus backstab-eligible
            if (
                (
                    itmHeaderModded.itemType == 44 ||
                    itmHeaderModded.itemType == 30 ||
                    itmHeaderModded.itemType == 29 ||
                    itmHeaderModded.itemType == 28 ||
                    itmHeaderModded.itemType == 26 ||
                    itmHeaderModded.itemType == 25 ||
                    itmHeaderModded.itemType == 23 ||
                    itmHeaderModded.itemType == 22 ||
                    itmHeaderModded.itemType == 21 ||
                    itmHeaderModded.itemType == 20 ||
                    itmHeaderModded.itemType == 19 ||
                    itmHeaderModded.itemType == 17 ||
                    itmHeaderModded.itemType == 16 ||
                    itmHeaderModded.itemType == 16
                )
                && IsDroppable()
            )
            {
                itmHeaderModded.exclusionFlags =
                    ModExistingBitfield(itmHeaderModded.exclusionFlags, new[] {9, 19, 22},
                        false); // usable for mage thief, thief, cleric thief
            }

            // homogenize item restrictions for monks and kensai (monks & kensais can use bracers but not use helmets)
            if (
                itmHeaderModded.itemType == 6
            )
            {
                itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {29}, false);
                itmHeaderModded.usability4 = ModExistingBitfield(itmHeaderModded.usability4, new int[] {2}, false);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            if (
                itmHeaderModded.itemType == 7 && (UnusableBy("kensai") || UnusableBy("monk"))
            )
            {
                itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {29}, true);
                itmHeaderModded.usability4 = ModExistingBitfield(itmHeaderModded.usability4, new int[] {2}, true);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // make clubs universally usable (in conjunction with a 2da weapprof mods allowing mages to put prof points in clubs)

            if (itmHeaderModded.weapProf == 115) // WEAP PROF == CLUBS
            {
                itmHeaderModded.exclusionFlags = 0;
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // make bows usable for druids (in conjunction with a 2da weapprof mods allowing druid to put prof points in bows)

            if (itmHeaderModded.weapProf == 104 || itmHeaderModded.weapProf == 105) // WEAP PROF == LONGBOW OR SHORTBOW
            {
                itmHeaderModded.exclusionFlags =
                    ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {30}, false);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // make xbows & bolts usable for clerics (in conjunction with a 2da weapprof mods allowing clerics to put prof points in xbows) 
            if (itmHeaderModded.itemType == 27 || itmHeaderModded.itemType == 31) 
            {
                itmHeaderModded.exclusionFlags =
                    ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {7, 8, 9, 19, 22}, false);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // make shortbows / arrows usable for clerics (in conjunction with a 2da weapprof mods allowing clerics to put prof points in xbows) 
            // if (itmHeaderModded.weapProf == 105 || itmHeaderModded.itemType == 5) // WEAP PROF == SHORTBOW OR ITEMTYP = ARROW
            // {
            //     itmHeaderModded.exclusionFlags =
            //         ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {7, 8, 9, 19, 22}, false);
            //     
            //     FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
            //         itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            // }
            
            // make darts usable for clerics (in conjunction with a 2da weapprof mods allowing clerics to put prof points in xbows) 
            if (itmHeaderModded.itemType == 24) // WEAP PROF == DART
            {
                itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {7, 8, 9, 19, 22}, false);
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // make elven chainmail usable for all classes (As it should be imho)
            if (ContainsCaseInsensitive(currentName, "Elven Chain"))
            {
                itmHeaderModded.exclusionFlags = 0;
                itmHeaderModded.usability1 = 0;
                itmHeaderModded.usability2 = 0;
                itmHeaderModded.usability3 = 0;
                itmHeaderModded.usability4 = 0;
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            ///
            /// TESTING
            ///
            ///
            // foreach (ItmExtHeader extHeader in itmExtHeadersModded)
            // {
            //     if (extHeader.maxCharges > 10)
            //     {
            //         Console.WriteLine(extHeader.maxCharges + " : " + currentItemFileInfo.Name + " : " + currentName);
            //     }
            // }

            // if (isCritical())
            // {
            //     Console.WriteLine("CRITICAL ITEM: " + currentItemFileInfo.Name +  " - " + currentName);
            // }
            
            
            // for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
            // {
            //     currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
            //     if (currentItmFeatBlock.opcodeNumber == 63)
            //     {
            //         Console.WriteLine(currentItemFileInfo.Name);
            //     }
            // }
            // for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
            // {
            //     currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
            //     if (currentItmFeatBlock.opcodeNumber == 63)
            //     {
            //         Console.WriteLine(currentItemFileInfo.Name);
            //     }
            // }
        }

        internal static void EqualizePrices(int priceStep, int priceLimit)
        {
            for (int i = 0; i <= priceLimit; i += priceStep)
            {
                if (itmHeaderModded.price > 0 && itmHeaderModded.price <= i)
                {
                    itmHeaderModded.price = i;
                    Console.WriteLine(currentName + ": " + itmHeaderModded.price);
                    break;
                }
            }
        }

        internal static void SetItmIcon(String iconName)
        {
            int strLength = 8;
            int delta = strLength - iconName.Length;
            if (delta > 0)
            {
                itmHeaderModded.invIcon = iconName + new string(new char[delta]);
            }
            else
            {
                itmHeaderModded.invIcon = iconName;
            }

            foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
            {
                if (delta > 0)
                {
                    itmExtHeader.useIcon = iconName + new string(new char[delta]);
                }
                else
                {
                    itmExtHeader.useIcon = iconName;
                }
            }
            // Console.WriteLine(iconName);
        }
        
        internal static void SetItmIcon(String[] iconNames)
        {
            int strLength = 8;
            int delta1 = strLength - iconNames[0].Length;
            int delta2 = strLength - iconNames[1].Length;
            if (delta1 > 0)
            {
                itmHeaderModded.invIcon = iconNames[0] + new string(new char[delta1]);
            }
            else
            {
                itmHeaderModded.invIcon = iconNames[0];
            }

            foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
            {
                if (delta2 > 0)
                {
                    itmExtHeader.useIcon = iconNames[1] + new string(new char[delta2]);
                }
                else
                {
                    itmExtHeader.useIcon = iconNames[1];
                }
            }
            // Console.WriteLine(iconName);
        }

        internal static void ModifyItmEffectOpcode(short newOpcode)
        {
            currentItmFeatBlock.opcodeNumber = newOpcode;
        }

        internal static void ModifyItmEffectParam1(byte param1)
        {
            currentItmFeatBlock.parameter1 = param1;
        }

        internal static void ModifyItmEffectParam2(byte param2)
        {
            currentItmFeatBlock.parameter2 = param2;
        }

        internal static void RemoveItmEffect(int index)
        {
            itmEffFeatBlocksModded.RemoveAt(index);
            itmHeaderModded.effectsCount--;
            foreach (ItmExtHeader extHeader in itmExtHeadersModded)
            {
                extHeader.abilitiesIndex--;
            }
        }

        internal static void RemoveAllItmEffects()
        {
            itmEffFeatBlocksModded = new ArrayList();
            itmHeaderModded.effectsCount = 0;
        }

        internal static void RemoveItmAbility(int index)
        {
            itmAbilFeatBlocksModded.RemoveAt(index);

            int matchIndex = 0;
            for (int i = 0; i < itmExtHeadersModded.Count; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                for (int j = 0; j < currentItmExtHeader.abilitiesCount; j++)
                {
                    if (matchIndex == index)
                    {
                        currentItmExtHeader.abilitiesCount--;
                        itmExtHeadersModded[i] = currentItmExtHeader;
                        return;
                    }

                    matchIndex++;
                }
            }
        }

        internal static void RemoveAllItmExtHeadersAndItmAbilities()
        {
            itmExtHeadersModded = new ArrayList();
            itmAbilFeatBlocksModded = new ArrayList();
            itmHeaderModded.abilitiesCount = 0;
            itmHeaderModded.abilitiesOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
            itmHeaderModded.effectsOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
        }

        internal static void RemoveAllItmAbilities()
        {
            itmAbilFeatBlocksModded = new ArrayList();
            for (int i = 0; i < itmExtHeadersModded.Count; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                currentItmExtHeader.abilitiesCount = 0;
            }
        }
        
        internal static void RemoveAllItmAbilitiesFromExtHeader(int extHeaderIndex)
        {
            currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[extHeaderIndex];
            for (int i = currentItmExtHeader.abilitiesIndex + currentItmExtHeader.abilitiesCount - 1; i >= currentItmExtHeader.abilitiesIndex; i--)
            {
                // Console.WriteLine(i + "_" + itmAbilFeatBlocksModded.Count);
                itmAbilFeatBlocksModded.RemoveAt(i);
            }

            currentItmExtHeader.abilitiesCount = 0;
            itmExtHeadersModded[extHeaderIndex] = currentItmExtHeader;
        }

        internal static void AddItmAbility(short opcode, byte target, byte power, int parameter1, int parameter2,
            byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource,
            int diceThrown, int diceSize, int saveType, int saveBonus, int special, int extHeaderIndex)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter2, timingMode,
                resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType, saveBonus,
                special);

            int abilityInsertPos = 0;
            for (int i = 0; i <= extHeaderIndex; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                abilityInsertPos += currentItmExtHeader.abilitiesCount;
            }

            currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[extHeaderIndex];
            currentItmExtHeader.abilitiesCount++;

            // Console.WriteLine(abilityInsertPos + " : " + itmAbilFeatBlocksModded.Count);

            itmAbilFeatBlocksModded.Insert(abilityInsertPos, newFeatBlock);
        }

        internal static void AddItmAbility(short opcode, byte target, byte power, int parameter1, short parameter21,
            short parameter22, byte timingMode, byte resistance, int duration, byte probability1, byte probability2,
            String resource, int diceThrown, int diceSize, int saveType, int saveBonus, int special, int extHeaderIndex)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter21, parameter22,
                timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType,
                saveBonus, special);

            int abilityInsertPos = 0;
            for (int i = 0; i <= extHeaderIndex; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                abilityInsertPos += currentItmExtHeader.abilitiesCount;
            }

            currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[extHeaderIndex];
            currentItmExtHeader.abilitiesCount++;

            itmAbilFeatBlocksModded.Insert(abilityInsertPos, newFeatBlock);
        }
        
        internal static void AddItmAbility(short opcode, byte target, byte power, int parameter1, byte parameter23,
            byte parameter24, byte parameter25, byte parameter26, byte timingMode, byte resistance, int duration, byte probability1, byte probability2,
            String resource, int diceThrown, int diceSize, int saveType, int saveBonus, int special, int extHeaderIndex)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter23, parameter24, parameter25, parameter26,
                timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType,
                saveBonus, special);

            int abilityInsertPos = 0;
            for (int i = 0; i <= extHeaderIndex; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                abilityInsertPos += currentItmExtHeader.abilitiesCount;
            }

            currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[extHeaderIndex];
            currentItmExtHeader.abilitiesCount++;

            itmAbilFeatBlocksModded.Insert(abilityInsertPos, newFeatBlock);
        }

        internal static void DuplicateItmAbility(short opcodeNumber, short newOpcode, short newParam2)
        {
            int[] headerIndex = new int[itmExtHeadersModded.Count];
            int j = 0;
            foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
            {
                headerIndex[j] += itmExtHeader.abilitiesCount;
                j++;
            }

            j = 0;
            int index = 0;
            for (int i = 0; i < itmAbilFeatBlocksModded.Count; i++)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                if (currentItmFeatBlock.opcodeNumber == opcodeNumber)
                {
                    ItmFeatBlock newFeatBlock = new ItmFeatBlock(newOpcode, currentItmFeatBlock.targetType, currentItmFeatBlock.power, currentItmFeatBlock.parameter1, newParam2,
                        currentItmFeatBlock.timingMode, currentItmFeatBlock.resistance, currentItmFeatBlock.duration, currentItmFeatBlock.probability1, currentItmFeatBlock.probability2, currentItmFeatBlock.resource, currentItmFeatBlock.diceThrown, currentItmFeatBlock.diceSides, currentItmFeatBlock.savingThrowType,
                        currentItmFeatBlock.savingThrowBonus, currentItmFeatBlock.stackingId);

                    itmAbilFeatBlocksModded.Insert(index, newFeatBlock);
                    currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[j];
                    currentItmExtHeader.abilitiesCount++;
                    itmExtHeadersModded[j] = currentItmExtHeader;
                    break;
                }

                if (index == headerIndex[j])
                {
                    j++;
                }

                index++;
            }
        }

        internal static void AddItmExtHeader(
            byte attackType,
            byte idReq,
            byte location,
            byte altDiceSides,
            String useIcon,
            byte targetType,
            byte targetCount,
            short range,
            byte launcher,
            byte altDiceThrown,
            byte speed,
            byte altDmgBonus,
            short thacoBonus,
            byte diceSides,
            byte primaryType,
            byte diceThrown,
            byte secondaryType,
            short dmgBonus,
            short dmgType,
            short abilitiesCount,
            short abilitiesIndex,
            short maxCharges,
            short onDepletion,
            int flags,
            short projectileAnimation,
            short animProbOverhand,
            short animProbBackhand,
            short animProbThrust,
            short isArrow,
            short isBolt,
            short isBullet
        )
        {
            ItmExtHeader newExtHeader = new ItmExtHeader(attackType, idReq, location, altDiceSides, useIcon, targetType,
                targetCount, range, launcher, altDiceThrown, speed, altDmgBonus, thacoBonus, diceSides, primaryType,
                diceThrown, secondaryType, dmgBonus, dmgType, abilitiesCount, abilitiesIndex, maxCharges, onDepletion,
                flags, projectileAnimation, animProbOverhand, animProbBackhand, animProbThrust, isArrow, isBolt,
                isBullet);

            itmExtHeadersModded.Add(newExtHeader);
            itmHeaderModded.abilitiesCount++;
            itmHeaderModded.effectsOffset += ItmExtHeader.size;
        }

        internal static void AddItmEffect(short opcode, byte target, byte power, int parameter1, int parameter2,
            byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource,
            int diceThrown, int diceSize, int saveType, int saveBonus, int special)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter2, timingMode,
                resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType, saveBonus,
                special);

            itmHeaderModded.effectsCount++;
            itmEffFeatBlocksModded.Add(newFeatBlock);
        }

        internal static Boolean IsDroppable()
        {
            BitArray bitArray = new BitArray(new int[] {itmHeaderModded.flags});
            return bitArray[2];
        }

        internal static Boolean IsCritical()
        {
            BitArray bitArray = new BitArray(new int[] {itmHeaderModded.flags});
            return bitArray[0];
        }

        internal static Boolean UnusableBy(String identifier)
        {
            BitArray bitArray = new BitArray(new int[] {BitConverter.ToInt32(itmByteArray, 30)});
            if (identifier.Equals("chaotic"))
            {
                return bitArray[0];
            }

            if (identifier.Equals("evil"))
            {
                return bitArray[1];
            }

            if (identifier.Equals("good"))
            {
                return bitArray[2];
            }

            if (identifier.Equals("neutral1"))
            {
                return bitArray[3];
            }

            if (identifier.Equals("lawful"))
            {
                return bitArray[4];
            }

            if (identifier.Equals("neutral2"))
            {
                return bitArray[5];
            }

            if (identifier.Equals("bard"))
            {
                return bitArray[6];
            }

            if (identifier.Equals("cleric"))
            {
                return bitArray[7];
            }

            if (identifier.Equals("clericmage"))
            {
                return bitArray[8];
            }

            if (identifier.Equals("clericthief"))
            {
                return bitArray[9];
            }

            if (identifier.Equals("clericranger"))
            {
                return bitArray[10];
            }

            if (identifier.Equals("fighter"))
            {
                return bitArray[11];
            }

            if (identifier.Equals("fighterdruid"))
            {
                return bitArray[12];
            }

            if (identifier.Equals("fightermage"))
            {
                return bitArray[13];
            }

            if (identifier.Equals("fightercleric"))
            {
                return bitArray[14];
            }

            if (identifier.Equals("fightermagecleric"))
            {
                return bitArray[15];
            }

            if (identifier.Equals("fightermagethief"))
            {
                return bitArray[16];
            }

            if (identifier.Equals("fighterthief"))
            {
                return bitArray[17];
            }

            if (identifier.Equals("mage"))
            {
                return bitArray[18];
            }

            if (identifier.Equals("magethief"))
            {
                return bitArray[19];
            }

            if (identifier.Equals("paladin"))
            {
                return bitArray[20];
            }

            if (identifier.Equals("ranger"))
            {
                return bitArray[21];
            }

            if (identifier.Equals("thief"))
            {
                return bitArray[22];
            }

            if (identifier.Equals("elf"))
            {
                return bitArray[23];
            }

            if (identifier.Equals("dwarf"))
            {
                return bitArray[24];
            }

            if (identifier.Equals("halfelf"))
            {
                return bitArray[25];
            }

            if (identifier.Equals("halfling"))
            {
                return bitArray[26];
            }

            if (identifier.Equals("human"))
            {
                return bitArray[27];
            }

            if (identifier.Equals("gnome"))
            {
                return bitArray[28];
            }

            if (identifier.Equals("monk"))
            {
                return bitArray[29];
            }

            if (identifier.Equals("druid"))
            {
                return bitArray[30];
            }

            if (identifier.Equals("halforc"))
            {
                return bitArray[31];
            }

            if (identifier.Equals("halfling"))
            {
                return bitArray[26];
            }

            bitArray = new BitArray(new int[] {BitConverter.ToInt32(itmByteArray, 47)});
            if (identifier.Equals("kensai"))
            {
                return bitArray[2];
            }
            else
            {
                throw new Exception("COULD NOT GET BITFIELD");
            }
        }
        
        internal static void FixItmEffectDurations()
        {
            DirectoryInfo itmDir = new DirectoryInfo(splOutputPath);
            FileInfo[] itmFiles = itmDir.GetFiles("*.itm");
            foreach (FileInfo itmFile in itmFiles)
            {
                CreateItmObjects(itmOutputPath,  itmFile.Name);
                foreach (SplFeatureBlock featBlock in itmAbilFeatBlocks)
                {
                    if (IsOpcodeMatch(featBlock) == 1)
                    {
                        FixDuration(featBlock, 6);
                    }
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded,
                    itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
        }
        internal static int IsOpcodeMatch(ItmFeatBlock featBlock)
        {
            if (
                featBlock.opcodeNumber == 9 || 
                featBlock.opcodeNumber == 7 || 
                featBlock.opcodeNumber == 50 || 
                featBlock.opcodeNumber == 51 || 
                featBlock.opcodeNumber == 52 || 
                featBlock.opcodeNumber == 8
            )
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        internal static void FixDuration(ItmFeatBlock featBlock, int dur)
        {
            featBlock.duration = dur;
        }
        
        internal static String GetRandomItem()
        {
            String[] randomItems = new[]
            {
                "RNDPTN01"
            };
            Random rnd = new Random();
            return randomItems[rnd.Next(randomItems.Length)];
        }
    }
}