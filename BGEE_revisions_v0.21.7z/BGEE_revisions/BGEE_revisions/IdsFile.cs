﻿using System;
using System.Collections;
using System.Linq;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal class IdsFile
    {
        internal String rawContent;
        internal int lastId;
        
        internal String fullLinePattern = @"(^)(.*)($)";
        
        internal String idPattern = @"(?<=^)\S+(?= )";
        
        internal String hexPattern = @"(?<=^0x)\S+(?=$)";
        internal String decPattern = @"(?<=^)\d+(?=$)";
        internal IdsFile(String content)
        {
            rawContent = content;
            GetLastId();
        }

        internal void GetLastId()
        {
            MatchCollection mc = Regex.Matches(rawContent, idPattern, RegexOptions.Multiline);
            // Console.WriteLine(mc.Count);
            foreach (Match m in mc)
            {
                Match hexMatch = Regex.Match(m.Value, hexPattern, RegexOptions.Multiline);
                Match decMatch = Regex.Match(m.Value, decPattern, RegexOptions.Multiline);
                // Console.WriteLine(m.Value);
                if (hexMatch.Success)
                {
                    // Console.WriteLine(hexMatch.Value);
                    lastId = int.Parse(hexMatch.Value, System.Globalization.NumberStyles.HexNumber);
                }
                else if (decMatch.Success)
                {
                    // Console.WriteLine(decMatch.Value);
                    lastId = int.Parse(decMatch.Value);
                }
            }
            // Console.WriteLine(lastId);
        }

        internal void AddNewLine(String content)
        {
            // Console.WriteLine(content);
            rawContent = rawContent.Insert(rawContent.Length, content + "\n");
            // Console.WriteLine(rawContent);
        }
    }
}