﻿using System;
using System.Collections;
using System.IO;
using System.Text;

namespace BGEE_revisions
{
    internal class FileOperations
    {
        internal static Boolean CheckFilePath(String path)
        {
            if (!File.Exists(path))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        internal static void CheckBasePath(String path)
        {
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        internal static byte[] ReadFile(String filePath)
        {
            if (File.Exists(filePath))
            {
                // NEW METHOD: ALL AT ONCE
                return File.ReadAllBytes(filePath);
            }
            else
            {
                // Console.WriteLine("File doesn't exist!");
                return null;
            }
        }
        
        internal static String ReadFileAsString(String filePath)
        {
            if (File.Exists(filePath))
            {
                return System.IO.File.ReadAllText(filePath);
            }
            else
            {
                throw new FileNotFoundException();
            }
        }

        internal static void WriteFile(String filePath, byte[] byteFile)
        {
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(String sourcePath, String destPath)
        {
            File.Copy(sourcePath, destPath, true);
        }
        
        internal static void WriteFileAsString(String fileContent, String filePath)
        {
            File.WriteAllText(filePath, fileContent);
        }
        
        internal static void WriteFile(ItmHeader itmHeader, ArrayList itmExtHeaders, ArrayList itmEffectFeatBlocks, ArrayList itmAbilityFeatBlocks, String filePath)
        {
            byte[] byteFile = new byte[
                ItmHeader.size + 
                itmExtHeaders.Count * ItmExtHeader.size + 
                itmEffectFeatBlocks.Count * ItmFeatBlock.size + 
                itmAbilityFeatBlocks.Count * ItmFeatBlock.size
            ];
            int offset = 0;

            byte[] bytes = itmHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += ItmHeader.size;

            itmHeader.abilitiesOffset = offset;
            itmHeader.abilitiesCount = (short)itmExtHeaders.Count;
            if (itmExtHeaders.Count != 0)
            {
                int effectIndex = 0;
                foreach (ItmExtHeader extHeader in itmExtHeaders)
                {
                    // ONLY FOR THE EXTENDED HEADER ABILITY INDICES
                    extHeader.abilitiesIndex += (short)(itmEffectFeatBlocks.Count + effectIndex);
                    effectIndex += extHeader.abilitiesCount;
                    //
                    bytes = extHeader.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmExtHeader.size;
                }
            }

            itmHeader.effectsOffset = offset;
            itmHeader.effectsCount = (short)itmEffectFeatBlocks.Count;
            if (itmEffectFeatBlocks.Count != 0)
            {
                foreach (ItmFeatBlock featureBlock in itmEffectFeatBlocks)
                {
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmFeatBlock.size;
                }
            }
            
            if (itmAbilityFeatBlocks.Count != 0)
            {
                foreach (ItmFeatBlock featureBlock in itmAbilityFeatBlocks)
                {
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmFeatBlock.size;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(CreHeader creHeader, ArrayList knownSpells, ArrayList memorizedSpellsInfos, ArrayList memorizedSpells, ArrayList effects, ArrayList items, CreItemSlots itemSlots, String filePath)
        {
            byte[] byteFile = new byte[
                CreHeader.size + 
                knownSpells.Count * CreKnownSpell.size + 
                memorizedSpellsInfos.Count * CreMemorizedSpellsInfo.size + 
                memorizedSpells.Count * CreMemorizedSpell.size + 
                effects.Count * CreEffect.size + 
                items.Count * CreItem.size + 
                CreItemSlots.size
            ];
            int offset = 0;
            byte[] bytes = creHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += CreHeader.size;

            creHeader.knownSpellsOffset = offset;
            creHeader.knownSpellsCount = knownSpells.Count;
            if (knownSpells.Count != 0)
            {
                foreach (CreKnownSpell knownSpell in knownSpells)
                {
                    bytes = knownSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreKnownSpell.size;
                }
            }

            creHeader.spellsMemoInfoOffset = offset;
            creHeader.spellsMemoInfoCount = memorizedSpellsInfos.Count;
            if (memorizedSpellsInfos.Count != 0)
            {
                foreach (CreMemorizedSpellsInfo memorizedSpellsInfo in memorizedSpellsInfos)
                {
                    bytes = memorizedSpellsInfo.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpellsInfo.size;
                }
            }
            
            creHeader.memoSpellsOffset = offset;
            creHeader.memoSpellsCount = memorizedSpells.Count;
            if (memorizedSpells.Count != 0)
            {
                foreach (CreMemorizedSpell memorizedSpell in memorizedSpells)
                {
                    bytes = memorizedSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpell.size;
                }
            }
            
            creHeader.effectsOffset = offset;
            creHeader.effectsCount = effects.Count;
            if (effects.Count != 0)
            {
                foreach (CreEffect effect in effects)
                {
                    bytes = effect.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreEffect.size;
                }
            }
            
            creHeader.itemsOffset = offset;
            creHeader.itemsCount = items.Count;
            if (items.Count != 0)
            {
                foreach (CreItem item in items)
                {
                    bytes = item.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreItem.size;
                }
            }
            
            creHeader.itemSlotsOffset = offset;
            bytes = itemSlots.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(SplHeader splHeader, ArrayList extendedHeaders, ArrayList castingFeatureBlocks, ArrayList featureBlocks, String filePath)
        {
            byte[] byteFile = new byte[
                SplHeader.size + 
                extendedHeaders.Count * SplExtendedHeader.size +
                castingFeatureBlocks.Count * SplFeatureBlock.size +
                featureBlocks.Count * SplFeatureBlock.size
            ];

            int offset = 0;

            byte[] bytes = splHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += SplHeader.size;

            splHeader.extendedHeaderOffset = offset;
            splHeader.extendedHeaderCount = (short)extendedHeaders.Count;
            if (extendedHeaders.Count != 0)
            {
                int spellIndex = 0;
                foreach (SplExtendedHeader extendedHeader in extendedHeaders)
                {
                    // ONLY FOR THE EXTENDED HEADER SPELL INDICES
                    extendedHeader.featureBlockIndex = (short)(castingFeatureBlocks.Count + spellIndex);
                    spellIndex += extendedHeader.featureBlockCount;
                    //
                    bytes = extendedHeader.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplExtendedHeader.size;
                    
                    // Console.WriteLine(filePath + ":" + extendedHeader.featureBlockOffset);
                }
            }

            splHeader.castingFeatureBlockCount = (short)castingFeatureBlocks.Count;
            if (castingFeatureBlocks.Count != 0)
            {
                foreach (SplFeatureBlock castingFeatureBlock in castingFeatureBlocks)
                {
                    bytes = castingFeatureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplFeatureBlock.size;
                }
            }

            if (featureBlocks.Count != 0)
            {
                foreach (SplFeatureBlock featureBlock in featureBlocks)
                {
                    // Console.WriteLine(featureBlock.resource);
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplFeatureBlock.size;
                }
            }
            
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(TlkHeader tlkHeader, ArrayList tlkEntries, String filePath)
        {
            int strSize = 0;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                strSize += tlkEntry.stringLength;
            }
            
            byte[] byteFile = new byte[
                TlkHeader.size + 
                tlkEntries.Count * TlkEntry.size + 
                strSize
            ];
            byte[] tlkHeaderBytes = tlkHeader.GetByteData();
            
            int offset = 0;
            System.Buffer.BlockCopy(tlkHeader.GetByteData(), 0, byteFile, offset, TlkHeader.size);
            offset += TlkHeader.size;

            
            tlkHeader.numberOfStrRefs = tlkEntries.Count;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                System.Buffer.BlockCopy(tlkEntry.GetByteData(tlkHeader.offsetToStringData), 0, byteFile, offset, TlkEntry.size);
                offset += TlkEntry.size;
                // tlkEntry.PrintValues();
                // Console.WriteLine(tlkEntry.stringLength);
            }

            tlkHeader.offsetToStringData = offset;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                System.Buffer.BlockCopy(tlkEntry.textByteData, 0, byteFile, offset, tlkEntry.stringLength);
                offset += tlkEntry.stringLength;
                // Console.WriteLine("index: " + index + "    " + tlkEntry.textString.Length);
            }
            
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(DlgHeader header, ArrayList stateTables, ArrayList transitionTables, ArrayList stateTriggers, ArrayList transitionTriggers, ArrayList actionTables, byte[] stringSection, String filePath)
        {
            byte[] byteFile = new byte[
                DlgHeader.size + 
                stateTables.Count * DlgStateTable.size + 
                transitionTables.Count * DlgTransitionTable.size + 
                stateTriggers.Count * DlgStateTrigger.size +  
                transitionTriggers.Count * DlgTransitionTrigger.size + 
                actionTables.Count * DlgActionTable.size +
                stringSection.Length
            ];
            int offset = 0;

            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += DlgHeader.size;
            
            header.offsetToStateTables = offset;
            header.numberOfStates = stateTables.Count;
            if (stateTables.Count != 0)
            {
                foreach (DlgStateTable stateTable in stateTables)
                {
                    bytes = stateTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgStateTable.size;
                }
            }

            header.offsetToTransitionTables = offset;
            header.numberOfTransitions = transitionTables.Count;
            if (transitionTables.Count != 0)
            {
                foreach (DlgTransitionTable transitionTable in transitionTables)
                {
                    bytes = transitionTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgTransitionTable.size;
                }
            }

            header.offsetToStateTriggerTables = offset;
            header.numberOfStateTriggers = stateTriggers.Count;
            if (stateTriggers.Count != 0)
            {
                foreach (DlgStateTrigger stateTrigger in stateTriggers)
                {
                    bytes = stateTrigger.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgStateTrigger.size;
                }
            }
            
            header.offsetToTransitionTriggerTables = offset;
            header.numberOfTransitionTriggers = transitionTriggers.Count;
            if (transitionTriggers.Count != 0)
            {
                foreach (DlgTransitionTrigger transitionTrigger in transitionTriggers)
                {
                    bytes = transitionTrigger.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgTransitionTrigger.size;
                }
            }
            
            header.offsetToActionTables = offset;
            header.numberOfActions = actionTables.Count;
            if (actionTables.Count != 0)
            {
                foreach (DlgActionTable actionTable in actionTables)
                {
                    bytes = actionTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgActionTable.size;
                }
            }
            
            System.Buffer.BlockCopy(stringSection, 0, byteFile, offset, stringSection.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(WmpHeader header, ArrayList worldMapEntries, ArrayList areaEntries, ArrayList areaLinkEntries, String filePath)
        {
            byte[] byteFile = new byte[
                WmpHeader.size + 
                worldMapEntries.Count * WmpWorldMapEntry.size + 
                areaEntries.Count * WmpAreaEntry.size + 
                areaLinkEntries.Count * WmpAreaLinkEntry.size
            ];
            int offset = 0;

            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += WmpHeader.size;
            
            header.worldmapEntriesOffset = offset;
            header.worldmapEntriesCount = worldMapEntries.Count;
            if (worldMapEntries.Count != 0)
            {
                foreach (WmpWorldMapEntry worldmapEntry in worldMapEntries)
                {
                    bytes = worldmapEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpWorldMapEntry.size;

                    worldmapEntry.areaEntriesOffset = WmpWorldMapEntry.size * worldMapEntries.Count;
                    worldmapEntry.areaEntriesCount = areaEntries.Count;
                    worldmapEntry.areaLinkEntriesOffset = WmpWorldMapEntry.size * worldMapEntries.Count + WmpAreaEntry.size * areaEntries.Count;
                    worldmapEntry.areaLinkEntriesCount = areaLinkEntries.Count;
                }
            }

            if (areaEntries.Count != 0)
            {
                foreach (WmpAreaEntry areaEntry in areaEntries)
                {
                    bytes = areaEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpAreaEntry.size;
                }
            }
            
            if (areaLinkEntries.Count != 0)
            {
                foreach (WmpAreaLinkEntry areaLinkEntry in areaLinkEntries)
                {
                    bytes = areaLinkEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpAreaLinkEntry.size;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(StoHeader header, ArrayList drinks, ArrayList itemsForSale, ArrayList cures, ArrayList itemsPurchased, String filePath)
        {
            int offset = 0;
            byte[] byteFile = new byte[
                StoHeader.size +
                drinks.Count * StoDrink.size + 
                itemsForSale.Count * StoItem.size +
                cures.Count * StoCure.size +
                itemsPurchased.Count * 4
            ];

            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += StoHeader.size;

            header.drinksForSaleOffset = offset;
            header.drinksForSaleCount = drinks.Count;
            if (drinks.Count != 0)
            {
                foreach (StoDrink drink in drinks)
                {
                    bytes = drink.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoDrink.size;
                }
            }
            
            header.itemsForSaleOffset = offset;
            header.itemsForSaleCount = itemsForSale.Count;
            if (itemsForSale.Count != 0)
            {
                foreach (StoItem item in itemsForSale)
                {
                    bytes = item.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoItem.size;
                }
            }
            
            header.curesForSaleOffset = offset;
            header.curesForSaleCount = cures.Count;
            if (cures.Count != 0)
            {
                foreach (StoCure cure in cures)
                {
                    bytes = cure.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoCure.size;
                }
            }
            
            header.itemsPurchasedOffset = offset;
            header.itemsPurchasedCount = itemsPurchased.Count;
            if (itemsPurchased.Count != 0)
            {
                foreach (int item in itemsPurchased)
                {
                    System.Buffer.BlockCopy(BitConverter.GetBytes(item), 0, byteFile, offset, 4);
                    offset += 4;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(
            AreHeader areHeaderModded,
            ArrayList areActorsModded,
            ArrayList areTriggersModded,
            ArrayList areSpawnPointsModded,
            ArrayList areEntrancesModded,
            ArrayList areContainersModded,
            ArrayList areItemsModded,
            ArrayList areVerticesModded,
            ArrayList areAmbientsModded,
            ArrayList areVariablesModded,
            byte[] areExploredBitmasksModded,
            ArrayList areDoorsModded,
            ArrayList areAnimationsModded,
            ArrayList areTiledObjectsModded,
            AreSong areSongModded,
            AreRestEncounter areRestEncounterModded,
            ArrayList areAutomapNotesModded,
            ArrayList areProjectileTrapsModded,
            String filePath
        )
        {
            // Console.WriteLine(areActorsModded.Count);
            // Console.WriteLine(areTriggersModded.Count);
            // Console.WriteLine(areSpawnPointsModded.Count);
            // Console.WriteLine(areEntrancesModded.Count);
            // Console.WriteLine(areContainersModded.Count);
            // Console.WriteLine(areItemsModded.Count);
            // Console.WriteLine(areVerticesModded.Count);
            // Console.WriteLine(areAmbientsModded.Count);
            // Console.WriteLine(areVariablesModded.Count);
            // Console.WriteLine(areExploredBitmasksModded.Length);
            // Console.WriteLine(areDoorsModded.Count);
            // Console.WriteLine(areAnimationsModded.Count);
            // Console.WriteLine(areTiledObjectsModded.Count);
            // Console.WriteLine(AreSong.size);
            // Console.WriteLine(AreRestEncounter.size);
            // Console.WriteLine(areAutomapNotesModded.Count);
            // Console.WriteLine(areProjectileTrapsModded.Count);
            
            // Console.WriteLine(AreHeader.size);
            // Console.WriteLine(areActorsModded.Count * AreActor.size); 
            // Console.WriteLine(areTriggersModded.Count * AreTrigger.size); 
            // Console.WriteLine(areSpawnPointsModded.Count * AreSpawnPoint.size);
            // Console.WriteLine(areEntrancesModded.Count * AreEntrance.size);
            // Console.WriteLine(areContainersModded.Count * AreContainer.size);
            // Console.WriteLine(areItemsModded.Count * AreItem.size);
            // Console.WriteLine(areVerticesModded.Count * AreVertex.size);
            // Console.WriteLine(areAmbientsModded.Count * AreAmbient.size);
            // Console.WriteLine(areVariablesModded.Count * AreVariable.size);
            // Console.WriteLine(areExploredBitmasksModded.Length);
            // Console.WriteLine(areDoorsModded.Count * AreDoor.size);
            // Console.WriteLine(areAnimationsModded.Count * AreAnimation.size);
            // Console.WriteLine(areTiledObjectsModded.Count * AreTiledObject.size);
            // Console.WriteLine(AreSong.size);
            // Console.WriteLine(AreRestEncounter.size);
            // Console.WriteLine(areAutomapNotesModded.Count * AreAutomapNote.size);
            // Console.WriteLine(areProjectileTrapsModded.Count * AreProjectileTrap.size);
            
            // Console.WriteLine(AreActor.size);
            // Console.WriteLine(AreTrigger.size);
            // Console.WriteLine(AreSpawnPoint.size);
            // Console.WriteLine(AreEntrance.size);
            // Console.WriteLine(AreContainer.size);
            // Console.WriteLine(AreItem.size);
            // Console.WriteLine(AreVertex.size);
            // Console.WriteLine(AreAmbient.size);
            // Console.WriteLine(AreVariable.size);
            //
            // Console.WriteLine(AreDoor.size);
            // Console.WriteLine(AreAnimation.size);
            // Console.WriteLine(AreTiledObject.size);
            // Console.WriteLine(AreSong.size);
            // Console.WriteLine(AreRestEncounter.size);
            // Console.WriteLine(AreAutomapNote.size);
            // Console.WriteLine(AreProjectileTrap.size);

            int offset = 0;
            byte[] byteFile = new byte[
                AreHeader.size +
                areActorsModded.Count * AreActor.size + 
                areTriggersModded.Count * AreTrigger.size + 
                areSpawnPointsModded.Count * AreSpawnPoint.size +
                areEntrancesModded.Count * AreEntrance.size +
                areContainersModded.Count * AreContainer.size +
                areItemsModded.Count * AreItem.size +
                areVerticesModded.Count * AreVertex.size +
                areAmbientsModded.Count * AreAmbient.size +
                areVariablesModded.Count * AreVariable.size +
                areExploredBitmasksModded.Length +
                areDoorsModded.Count * AreDoor.size +
                areAnimationsModded.Count * AreAnimation.size +
                areTiledObjectsModded.Count * AreTiledObject.size +
                AreSong.size +
                AreRestEncounter.size +
                areAutomapNotesModded.Count * AreAutomapNote.size +
                areProjectileTrapsModded.Count * AreProjectileTrap.size
            ];

            byte[] bytes = areHeaderModded.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);

            offset = 0;
            if (areActorsModded.Count != 0)
            {
                foreach (AreActor element in areActorsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetActors + offset, bytes.Length);
                    offset += AreActor.size;
                }
            }
            
            offset = 0;
            if (areTriggersModded.Count != 0)
            {
                foreach (AreTrigger element in areTriggersModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetTriggers + offset, bytes.Length);
                    offset += AreTrigger.size;
                }
            }
            
            offset = 0;
            if (areSpawnPointsModded.Count != 0)
            {
                foreach (AreSpawnPoint element in areSpawnPointsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetSpawnPoints + offset, bytes.Length);
                    offset += AreSpawnPoint.size;
                }
            }
            
            offset = 0;
            if (areEntrancesModded.Count != 0)
            {
                foreach (AreEntrance element in areEntrancesModded)
                {
                    // Console.WriteLine(areHeaderModded.offsetEntrances + offset);
                    // Console.WriteLine(filePath + ":" + element.name);
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetEntrances + offset, bytes.Length);
                    offset += AreEntrance.size;
                }
            }
            
            offset = 0;
            if (areContainersModded.Count != 0)
            {
                foreach (AreContainer element in areContainersModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetContainers + offset, bytes.Length);
                    offset += AreContainer.size;
                }
            }
            
            offset = 0;
            if (areItemsModded.Count != 0)
            {
                foreach (AreItem element in areItemsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetItems + offset, bytes.Length);
                    offset += AreItem.size;
                }
            }
            
            offset = 0;
            if (areVerticesModded.Count != 0)
            {
                foreach (AreVertex element in areVerticesModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetVertices + offset, bytes.Length);
                    offset += AreVertex.size;
                }
            }
            
            offset = 0;
            if (areAmbientsModded.Count != 0)
            {
                foreach (AreAmbient element in areAmbientsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetAmbients + offset, bytes.Length);
                    offset += AreAmbient.size;
                }
            }
            
            offset = 0;
            if (areVariablesModded.Count != 0)
            {
                foreach (AreVariable element in areVariablesModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetVariables + offset, bytes.Length);
                    offset += AreVariable.size;
                }
            }
            
            if (areExploredBitmasksModded.Length != 0)
            {
                // Console.WriteLine(byteFile.Length + " " + areHeaderModded.exploredBitmaskOffset + " " + areHeaderModded.exploredBitmaskSize);
                System.Buffer.BlockCopy(areExploredBitmasksModded, 0, byteFile, areHeaderModded.exploredBitmaskOffset, areHeaderModded.exploredBitmaskSize);
            }
            
            offset = 0;
            if (areDoorsModded.Count != 0)
            {
                foreach (AreDoor element in areDoorsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetDoors + offset, bytes.Length);
                    offset += AreDoor.size;
                }
            }
            
            offset = 0;
            if (areAnimationsModded.Count != 0)
            {
                foreach (AreAnimation element in areAnimationsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetAnimations + offset, bytes.Length);
                    offset += AreAnimation.size;
                }
            }
            
            offset = 0;
            if (areTiledObjectsModded.Count != 0)
            {
                foreach (AreTiledObject element in areTiledObjectsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetTiledObjects + offset, bytes.Length);
                    offset += AreTiledObject.size;
                }
            }
            
            // Console.WriteLine(areHeaderModded.offsetEntrances + offset);
            // Console.WriteLine(filePath + ":" + element.name);
            // Console.WriteLine(filePath + "    " + areHeaderModded.songsOffset);
            // Console.WriteLine(filePath + "    " + AreSong.size);
            
            bytes = areSongModded.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.songsOffset + offset, bytes.Length);

            // Console.WriteLine(filePath + "    " + areHeaderModded.restEncountersOffset);
            // Console.WriteLine(filePath + "    " + AreRestEncounter.size);
            // Console.WriteLine(filePath + "    " + (areHeaderModded.restEncountersOffset + AreRestEncounter.size));
            // Console.WriteLine(filePath + "    " + byteFile.Length);
            
            bytes = areRestEncounterModded.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.restEncountersOffset + offset, bytes.Length);

            offset = 0;
            if (areAutomapNotesModded.Count != 0)
            {
                foreach (AreAutomapNote element in areAutomapNotesModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.automapNotesOffset + offset, bytes.Length);
                    offset += AreAutomapNote.size;
                }
            }
            
            offset = 0;
            if (areProjectileTrapsModded.Count != 0)
            {
                foreach (AreProjectileTrap element in areProjectileTrapsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, areHeaderModded.offsetProjectileTraps + offset, bytes.Length);
                    offset += AreProjectileTrap.size;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
    }
}