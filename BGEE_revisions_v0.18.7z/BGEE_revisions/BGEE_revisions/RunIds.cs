﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        public static void RunIds()
        {
            // add frost ray
            if (ContainsCaseInsensitive(currentIdsFileInfo.Name, "PROJECTL."))
            {
                proFrostRayId = (short)(idsFile.lastId + 1);
                // Console.WriteLine(proFrostRayId);
                idsFile.AddNewLine(proFrostRayId + " " + "frostray");
                FileOperations.WriteFileAsString(idsFile.rawContent, idsOutputPath + "/" + currentIdsFileInfo.Name);
            }
        }
    }
}