﻿using System;
using System.Collections;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static String newFileContent;
        
        internal static void RunTwoda()
        {
            // if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "MXSPL"))
            // {
            //     // Console.WriteLine(currentTwodaFileInfo.Name + "    " + twodaFile.twodaLines.Count);
            //     // foreach (TwodaLine twodaLine in twodaFile.twodaLines)
            //     // {
            //     //     Console.WriteLine(twodaLine.content + "     " + twodaLine.isContent);
            //     // }
            //     if (
            //         currentTwodaFileInfo.Name.Contains("BRD") ||
            //         currentTwodaFileInfo.Name.Contains("DD") ||
            //         currentTwodaFileInfo.Name.Contains("DRU") ||
            //         currentTwodaFileInfo.Name.Contains("PRS") ||
            //         currentTwodaFileInfo.Name.Contains("SHM") ||
            //         currentTwodaFileInfo.Name.Contains("SRC") ||
            //         currentTwodaFileInfo.Name.Contains("WIZ")
            //     )
            //     {
            //         // give spell casters +5 spells
            //         IncreaseSpells(@"(BRD|DD|DRU|PRS|SHM|SRC|WIZ)\.", 5);
            //         FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            //     }
            //     
            //     if (
            //         currentTwodaFileInfo.Name.Contains("PAL") ||
            //         currentTwodaFileInfo.Name.Contains("RAN")
            //     )
            //     {
            //         // give fighters +2 spells
            //         IncreaseSpells(@"(PAL|RAN)\.", 2);
            //         FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            //     }
            // }
            //
            // // give sorcs and shamans 10/12 spells per spell level
            // if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "SPL") && ContainsCaseInsensitive(currentTwodaFileInfo.Name, "KN."))
            // {
            //     IncreaseSpells(@"(splshmkn|splsrckn|SPLSHMKN|SPLSRCKN)\.(2da|2DA)", 7);
            //     FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            // }
            
            // double innate ability count
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "CLAB"))
            {
                DoubleInnateAbilities(@"(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO)(.*)\.(2da|2DA)");
                // Console.WriteLine("got here");
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // make edwins amulet removable
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "ITEM_USE"))
            {
                RemoveLine("MISC89");
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
        }
        internal static void IncreaseSpells(String regexStr, int xSpells)
        {
            // *********************************************************
            // +x spells for class x
            // *********************************************************

            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.isContent)
                {
                    MatchCollection singleSpellMatches = Regex.Matches(currentLine.content, @"(?<=\d+( |\t)+)\d+(?=(\d+|\n|\r|$| |\t))", RegexOptions.Multiline);
                    int offset = 0;
                    String newRow = currentLine.content;
                    foreach (Match sm in singleSpellMatches)
                    {
                        int oldNum = Int32.Parse(sm.Value);
                        if (oldNum != 0)
                        {
                            int newNum = oldNum + xSpells;
                            // String newRow = r.Value.Remove(sm.Index, sm.Length).Insert(sm.Index, (Int32.Parse(sm.Value) * 2).ToString());
                            newRow = newRow.Remove(sm.Index + offset, sm.Length)
                                .Insert(sm.Index + offset, newNum.ToString());
                            if (oldNum.ToString().Length < newNum.ToString().Length)
                            {
                                offset += newNum.ToString().Length - oldNum.ToString().Length;
                            }
                        }
                    }
                    twodaFile.UpdateLine(newRow, i);
                }
            }
        }
        
        internal static void DoubleInnateAbilities(String regexStr)
        {
            ArrayList newLines = new ArrayList();
            
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.isContent)
                {
                    String newContent = "";
                    if (Regex.Match(currentLine.content, @"(?<= )GA_.*?(?= )", RegexOptions.Multiline).Success) // if we find a general ability in the line
                    {
                        newContent = currentLine.content;
                        MatchCollection mc = Regex.Matches(currentLine.content, "(?<= )AP_.*?(?= )", RegexOptions.Multiline);
                        if (mc.Count > 0)
                        {
                            foreach (Match m in mc)
                            {
                                newContent = currentLine.content.Replace(m.Value, "****      ");
                            }
                        }

                        newLines.Add(new TwodaLine(currentLine.index, true, newContent));
                    }
                }
            }

            foreach (TwodaLine newLine in newLines)
            {
                twodaFile.AddLine(newLine);
            }
        }

        internal static void RemoveLine(String pattern)
        {
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.content.Contains(pattern))
                {
                    twodaFile.twodaLines.RemoveAt(i);
                }
            }
            twodaFile.UpdateRawContent();
        }
        
        // MISC FUNCTIONS
    
        internal static int FindInSmTables(String findStr)
        {
            // Console.WriteLine(twodaInputDirectory.FullName + "/SMTABLES.2DA");
            String file = FileOperations.ReadFileAsString(twodaInputDirectory.FullName + "/SMTABLES.2DA");
            MatchCollection lines = Regex.Matches(file, @"^.*$", RegexOptions.Multiline);
            foreach (Match line in lines)
            {
                if (Regex.Match(line.Value, findStr, RegexOptions.Multiline).Success)
                {
                    // Console.WriteLine(line.Value);
                    Match num = Regex.Match(line.Value, @"(?<=^)\d+(?=_)", RegexOptions.Multiline);
                    return Int32.Parse(num.Value);
                }
            }

            return 0;
        }
    }
}