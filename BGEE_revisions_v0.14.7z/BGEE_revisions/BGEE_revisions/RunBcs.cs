﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunBcs(BcsParser bcsParser)
        {
            // prevent edwin murdering dynaheir
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "EDWIN_.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplace(
                    false, 
                    @"131OB\n0 0 0 0 0 0 0 0 0 0 0 0 \""OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 ""dynaheir""OB\n", 
                    @""
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // bgsod : edwin & dynaheir in same team
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"BDEDWIN.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplace(
                    false, 
                    @"198OB\n0 0 0 0 0 0 0 0 0 0 0 0 \""OB\nOB\n2 0 0 0 0 0 0 0 0 0 0 0 \""OB\n", 
                    @""
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change golem building times
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"a7!ct0"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplace(
                    false, 
                    @"(3600|7200|10800|14400)", 
                    @"6"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
        }
    }
}