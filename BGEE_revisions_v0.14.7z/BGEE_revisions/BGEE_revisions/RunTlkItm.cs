﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlkItm()
        {
            // WAND OF MONSTER SUMMONING
            String id = "This wand will summon 12 HD of monsters";
            EditTlkExistingEntry(id, 
                id + ".*", 
                "This wand will summon 2d2 monsters of different kinds. Each time the wand is used, there is a chance of conjuring either level I, II or III monsters, corresponding to the Monster Summoning I, II and III spells:\n\n- 50% chance of getting level I monsters\n- 30% chance of getting level II monsters\n- 20% chance of getting level III monsters\n\nThe monsters appear within the area of effect and attack the user's enemies. They remain until the spell duration expires or the monsters are slain. These creatures vanish when slain. If no opponent exists to fight and the wizard can communicate with them, the summoned monsters can perform other services for the summoning wizard.\n\nSTATISTICS:\n\nCharge abilities:\n- Summon level I, II or III monsters\n  Range: 20 ft.\n  Duration: 1 hour\n\nRequires:\n 9 Intelligence\n\nWeight: 1");
            
            // WAND OF MAGIC MISSILES
            id = "When activated, the wand will eject a missile of magical energy";
            EditTlkExistingEntry(id, 
                id + ".*", 
                "When activated, the wand will eject 5 magic missiles. The target creature must be seen or otherwise detected to be hit, however, so near-total concealment, such as that offered by arrow slits, can render the spell ineffective. The missiles will inflict 5x(1d4+1) total points of damage.\n\nSTATISTICS:\n\nCharge abilities:\n- 5 magic missiles will strike the target\n  Damage: 5x(1d4+1) magic damage\n  Range: 100 ft.\n  Area of Effect: 1 creature\n\nRequires:\n 9 Intelligence\n\nWeight: 1");

        }
    }
}