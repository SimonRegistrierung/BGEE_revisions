﻿using System;
using System.Collections;
using System.IO;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunItm()
        {
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // CASTING FAILURE & ARMOR CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 
            
            // prevent casting failure & thieving disablement
            if (
                (
                    itmHeader.itemType == 2 ||
                    itmHeader.itemType == 7 ||
                    itmHeader.itemType == 12 ||
                    itmHeader.itemType == 41 ||
                    itmHeader.itemType == 47 ||
                    itmHeader.itemType == 49 ||
                    itmHeader.itemType == 53 ||
                    itmHeader.itemType == 59 ||
                    itmHeader.itemType == 60 ||
                    itmHeader.itemType == 61 ||
                    itmHeader.itemType == 62 ||
                    itmHeader.itemType == 63 ||
                    itmHeader.itemType == 64 ||
                    itmHeader.itemType == 65 ||
                    itmHeader.itemType == 66 ||
                    itmHeader.itemType == 67 ||
                    itmHeader.itemType == 68
                ) && isDroppable() // if it's an armor, shield, headgear etc. and if it's droppable
            )
            {
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 59 ||
                        currentItmFeatBlock.opcodeNumber == 60 ||
                        currentItmFeatBlock.opcodeNumber == 90 ||
                        currentItmFeatBlock.opcodeNumber == 91 ||
                        currentItmFeatBlock.opcodeNumber == 92 ||
                        currentItmFeatBlock.opcodeNumber == 275
                    )
                    {
                        RemoveItmEffect(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
                
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 59 ||
                        currentItmFeatBlock.opcodeNumber == 60 ||
                        currentItmFeatBlock.opcodeNumber == 90 ||
                        currentItmFeatBlock.opcodeNumber == 91 ||
                        currentItmFeatBlock.opcodeNumber == 92 ||
                        currentItmFeatBlock.opcodeNumber == 275
                    )
                    {
                        Console.WriteLine(currentItemFileInfo);
                        RemoveItmAbility(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // VISUAL ITEM CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            ///
            Hashtable gfxItems = new Hashtable();
            gfxItems.Add("BULL07.", "ibull07");
            gfxItems.Add("BULL08.", "ibull08");
            gfxItems.Add("BULL09.", "ibull09");
            gfxItems.Add("DAGG03.", "idagg3a");
            gfxItems.Add("SLNG11.", "islng11");
            gfxItems.Add("BLUN39.", "iblun39");
            gfxItems.Add("BLUN38.", "NRMLCLB");
            gfxItems.Add("X#JACLUB.", "SPKDCLB");
            gfxItems.Add("BLUN37.", "IBLUN37");
            gfxItems.Add("SHLD33.", "BUCKLEY");
            gfxItems.Add("HAMM04.", "KNEECAP");
            gfxItems.Add("K#WAND01.", "RGWANDC2");
            gfxItems.Add("K#WAND02.", "RGWANDC3");
            gfxItems.Add("K#WAND03.", "RGWANDC4");
            gfxItems.Add("BOOK03.", "IBOOK768");
            gfxItems.Add("BOOK04.", "IBOOK768");
            gfxItems.Add("BOOK05.", "IBOOK768");
            gfxItems.Add("BOOK06.", "IBOOK768");
            gfxItems.Add("BOOK07.", "IBOOK768");
            gfxItems.Add("BOOK08.", "IBOOK768");
            gfxItems.Add("BOOK70.", "IBOOK03");
            gfxItems.Add("BOOK01.", "IBOOK03");
            gfxItems.Add("BOOK02.", "IBOOK03");
            gfxItems.Add("ULBOOK54.", "IBOOK03");
            gfxItems.Add("ULBOOK87.", "IBOOK03");
            gfxItems.Add("ULBOOK88.", "IBOOK03");
            gfxItems.Add("ULBOOK89.", "IBOOK03");
            gfxItems.Add("ULBOOK90.", "IBOOK03");
            gfxItems.Add("ULBOOK91.", "IBOOK03");
            gfxItems.Add("ULBOOK92.", "IBOOK03");
            gfxItems.Add("ULBOOK93.", "IBOOK03");
            gfxItems.Add("ULBOOK94.", "IBOOK03");
            gfxItems.Add("ULBOOK95.", "IBOOK03");
            gfxItems.Add("ULBOOK96.", "IBOOK03");
            gfxItems.Add("ULBOOK97.", "IBOOK03");
            gfxItems.Add("ULBOOK98.", "IBOOK03");
            gfxItems.Add("ULBOOK70.", "IBOOK03");

            foreach (DictionaryEntry pair in gfxItems)
            {
                if (ContainsCaseInsensitive(currentItemFileInfo.Name, pair.Key.ToString()))
                {
                    SetItmIcon(pair.Value.ToString());
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // ITEM PRICE CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            
            Hashtable priceItems = new Hashtable();
            priceItems.Add("RSBRAC.", 1000);
            priceItems.Add("RSBOOT.", 1000);
            priceItems.Add("MISC89.", 2000);
            priceItems.Add("STAFN1.", 1000);
            priceItems.Add("SCRL10.", 50);
            priceItems.Add("SCRL11.", 50);
            priceItems.Add("SCRL12.", 50);
            priceItems.Add("SCRL13.", 50);
            priceItems.Add("SCRL14.", 50);
            priceItems.Add("SCRL15.", 50);
            priceItems.Add("SCRL16.", 50);
            priceItems.Add("SCRL17.", 50);
            priceItems.Add("SCRL18.", 50);
            priceItems.Add("AMUL09.", 400);
            priceItems.Add("AMUL10.", 700);
            priceItems.Add("RING10.", 600);
            priceItems.Add("RING11.", 300);
            priceItems.Add("MISC24.", 500);
            
            foreach (DictionaryEntry pair in priceItems)
            {
                if (ContainsCaseInsensitive(currentItemFileInfo.Name, pair.Key.ToString()))
                {
                    SetItmPrice(Int32.Parse(pair.Value.ToString()));
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // MISC SMALL CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            ///

            // make daerraghs ring droppable and a regular "batalistas passport"
            // if (ContainsCaseInsensitive(currentItemFileInfo.Name, "RING02.ITM"))
            // {
            //     FileOperations.WriteFile(itmOutputPath + "/RING02.ITM", itmByteArray);
            // }

            // increase charges on spectacles of spectacle
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "BDMISC01.ITM"))
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    extHeader.maxCharges = 15;
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }

            // replace edwin amulet with a common amulet (it's a broken piece of shit)
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "MISC89"))
            {
                File.Copy(itmInputPath + "/AMUL11.itm", itmOutputPath + "\\" + currentItemFileInfo, true);
            }
            
            // decrease max charges for wands
            if (itmHeader.itemType == 35)
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    if (extHeader.maxCharges == 100)
                    {
                        extHeader.maxCharges = 20;
                    }
                    else if (extHeader.maxCharges == 50)
                    {
                        extHeader.maxCharges = 15;
                    }
                    else
                    {
                        extHeader.maxCharges = 10;
                    }
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // make magic missile want more useful
            if (currentName.Equals("Wand of Magic Missiles"))
            {
                foreach (ItmExtHeader extHeader in itmExtHeadersModded)
                {
                    if (extHeader.projectileAnimation == 37)
                    {
                        extHeader.projectileAnimation = 72;
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }

            // allow more golem repairs per day
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "0") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "1") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "2") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "3") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "4") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "5") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "6") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "7") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "8") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "9") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "a") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "b") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "c") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "a7!tom0" + "d")
            )
            {
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 172 ||
                        currentItmFeatBlock.opcodeNumber == 171
                    )
                    {
                        // Console.WriteLine(currentItem);
                        RemoveItmAbility(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
                
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(172, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!smgl" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!glr" + new string(new char[2]), 0, 0, 0, 0, 0, 0);
                AddItmAbility(171, 1, 0, 0, 0, 9, 0, 0, 100, 0, "a7!smgl" + new string(new char[1]), 0, 0, 0, 0, 0, 0);
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // fix mutamin's cloak
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "mh#clck1."))
            {
                RemoveAllItmEffects();
                
                AddItmEffect(267, 1, 1, FindFirstExactTlkEntry("Petrified"), 0, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(101, 1, 1, 0, 134, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 1, -1, 0, 2, 0, 0, 100, 0, "P5DROP3" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(328, 1, 1, 0, 107, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 1);
                AddItmEffect(142, 1, 1, 0, 10, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(83, 1, 1, 0, 64, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 2, 0, 0, 100, 0, "SPIN883" + new char(), 0, 0, 0, 0, 0);
                AddItmEffect(206, 1, 1, FindFirstExactTlkEntry("You cannot cast this spell until the current casting has run out."), 0, 2, 0, 0, 100, 0, "SPIN839" + new char(), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // HIDDEN UNDROPPABLE ITEM CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            ///
            /// 

            // remove immunities to spell levels for enemy only items possessed by liches etc.
            if (
                ContainsCaseInsensitive(currentItemFileInfo.Name, "BDLICH") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "DEMILICH") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "DEMOGORG") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "FINMEL01") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "finsend") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "LICH") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "RAKRING") ||
                ContainsCaseInsensitive(currentItemFileInfo.Name, "RAVAG03")
            )
            {
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 102)
                    {
                        RemoveItmEffect(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
                
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 102)
                    {
                        Console.WriteLine(currentItemFileInfo);
                        RemoveItmAbility(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }
            
            // prevent seeing through invisibility per item SEEALL.ITM
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "SEEALL.") || ContainsCaseInsensitive(currentItemFileInfo.Name, "SEEINVIS."))
            {
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 193)
                    {
                        RemoveItmEffect(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
                
                for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                    if (currentItmFeatBlock.opcodeNumber == 193)
                    {
                        Console.WriteLine(currentItemFileInfo);
                        RemoveItmAbility(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // CUSTOM SPELL REVISION CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 
            ///
            ///
            ///
            ///
            
            // adapt wand spells
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "WAND10"))
            {
                RemoveAllItmAbilities();
                AddItmAbility(174, 1 ,3, 0, 0, 1, 0, 0, 100, 0, "EFF_M13" + new char(), 0, 0, 0, 0, 0, 0);
                AddItmAbility(331, 1 ,3, 0, FindInSmTables("MSUMMO1"), 0, 3, 300, 100, 50, "MSUMMO1" + new char(), 2, 2, 0, 0, 0, 0);
                AddItmAbility(331, 1 ,3, 0, FindInSmTables("MSUMMO2"), 0, 3, 300, 49, 20, "MSUMMO2" + new char(), 2, 2, 0, 0, 0, 0);
                AddItmAbility(331, 1 ,3, 0, FindInSmTables("MSUMMO3"), 0, 3, 300, 19, 0, "MSUMMO3" + new char(), 2, 2, 0, 0, 0, 0);
            }

            //      CHANGE ITEMS OF SPEED    ///
            
            // change amulet of cheetah speed ItmAbility
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "AMUL26."))
            {
                RemoveAllItmExtHeadersAndItmAbilities();
                AddItmEffect(1, 1, 0, 150, 2, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);

                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // remove movement speed setting for spider's bane 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "SW2H06.") || ContainsCaseInsensitive(currentItemFileInfo.Name, "SW2H13.") || ContainsCaseInsensitive(currentItemFileInfo.Name, "u!spbane."))
            {
                for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
                {
                    currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                    if (
                        currentItmFeatBlock.opcodeNumber == 126 || currentItmFeatBlock.opcodeNumber == 176
                    )
                    {
                        RemoveItmEffect(i);
                        FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                    }
                }
                
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // replace opcode HASTE for all items and standardize Change Movements speed
            for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 16 ||
                    currentItmFeatBlock.opcodeNumber == 317 ||
                    currentItmFeatBlock.opcodeNumber == 126 ||
                    currentItmFeatBlock.opcodeNumber == 176
                )
                {
                    ModifyItmOpcode(176);
                    ModifyItmParam1(150);
                    ModifyItmParam2(2);
                    AddItmEffect(1, 1, 0, 150, 2, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0);
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 16 ||
                    currentItmFeatBlock.opcodeNumber == 317 ||
                    currentItmFeatBlock.opcodeNumber == 126 ||
                    currentItmFeatBlock.opcodeNumber == 176
                )
                {
                    ModifyItmOpcode(176);
                    ModifyItmParam1(150);
                    ModifyItmParam2(2);
                    AddItmAbility(1, 1, 0, 150, 2, 2, 0, 0, 100, 0, new string(new char[8]), 0, 0, 0, 0, 0, 0);
                    FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                }
            }
            
            // CHANGE NISHRUU ATTACK 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "NISHRUU."))
            {
                String addStr = "Magic drained";
                AddTlkEntry(addStr);
                for (int i = 0; i < itmExtHeadersModded.Count; i++)
                {
                    AddItmAbility(139, 2, 0, FindFirstExactTlkEntry("Magic drained"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, i);
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // CHANGE HAKESHAR ATTACK 
            if (ContainsCaseInsensitive(currentItemFileInfo.Name, "HAKESHAR."))
            {
                String addStr = "Magic drained";
                AddTlkEntry(addStr);
                for (int i = 0; i < itmExtHeadersModded.Count; i++)
                {
                    AddItmAbility(139, 2, 0, FindFirstExactTlkEntry("Magic drained"), 0, 1, 2, 0, 100, 0, new string(new char[8]), 0, 0, GetBitfieldInt(new int[] {1}), 0, 0, i);
                }
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            ///
            ///
            ///
            /// 
            /////////////////////////////////////////
            // // SEVERAL ITEM USItmAbilitY CHANGES
            /////////////////////////////////////////
            ///
            ///
            ///
            /// 
            ///
            /// 
            // CONSISTENT WAND USE (E.G. for thieves)
            if (itmHeaderModded.itemType == 35 && isDroppable())
            {
                if (!unusableBy("cleric"))
                {
                    itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new[] {10, 20, 21}, false); // usable by cleric ranger, paladin, ranger
                }
                if (!unusableBy("mage"))
                {
                    itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new[] {9, 17, 22}, false); // usable by cleric thief, thief, fighter-thief
                }
            }
            
            // stop the prevention of haste blocking for rings of free action, spider's bane 
            for (int i = itmEffFeatBlocksModded.Count - 1; i >= 0; i--)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 163 && isDroppable()
                )
                {
                    for (int j = itmEffFeatBlocksModded.Count - 1; j >= 0; j--)
                    {
                        currentItmFeatBlock = (ItmFeatBlock) itmEffFeatBlocksModded[j];
                        if (
                            currentItmFeatBlock.opcodeNumber == 267 &&
                            (
                                currentItmFeatBlock.parameter1 == FindFirstExactTlkEntry("Hasted") ||
                                currentItmFeatBlock.parameter1 == FindFirstExactTlkEntry("Haste") // prevent string
                            )
                        )
                        {
                            RemoveItmEffect(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                        if (
                            currentItmFeatBlock.opcodeNumber == 206 &&
                            (
                                currentItmFeatBlock.resource.Equals("SPIN828") ||
                                currentItmFeatBlock.resource.Equals("SPIN572") ||
                                currentItmFeatBlock.resource.Equals("SPRA301") ||
                                currentItmFeatBlock.resource.Equals("SPWI305") // protection from spell
                            )
                        )
                        {
                            RemoveItmEffect(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                        if (
                            currentItmFeatBlock.opcodeNumber == 101 &&
                            (
                                currentItmFeatBlock.parameter2 == 1 ||
                                currentItmFeatBlock.parameter2 == 190 ||
                                currentItmFeatBlock.parameter2 == 189 ||
                                currentItmFeatBlock.parameter2 == 16 ||
                                currentItmFeatBlock.parameter2 == 126 ||
                                currentItmFeatBlock.parameter2 == 176 ||
                                currentItmFeatBlock.parameter2 == 317 // protection from spell
                            )
                        )
                        {
                            RemoveItmEffect(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                        if (
                            (
                                currentItmFeatBlock.opcodeNumber == 169 || 
                                currentItmFeatBlock.opcodeNumber == 240
                            )
                            &&
                            (
                                currentItmFeatBlock.parameter2 == 38 ||
                                currentItmFeatBlock.parameter2 == 110 // prevent / remove portrait icon
                            )
                        )
                        {
                            RemoveItmEffect(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                    }
                }
            }
            // ItmAbilities
            for (int i = itmAbilFeatBlocksModded.Count - 1; i >= 0; i--)
            {
                currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[i];
                if (
                    currentItmFeatBlock.opcodeNumber == 163 && isDroppable()
                )
                {
                    for (int j = itmAbilFeatBlocksModded.Count - 1; j >= 0; j--)
                    {
                        currentItmFeatBlock = (ItmFeatBlock) itmAbilFeatBlocksModded[j];
                        if (
                            currentItmFeatBlock.opcodeNumber == 267 &&
                            (
                                currentItmFeatBlock.parameter1 == FindFirstExactTlkEntry("Hasted") ||
                                currentItmFeatBlock.parameter1 == FindFirstExactTlkEntry("Haste") // prevent string
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                        if (
                            currentItmFeatBlock.opcodeNumber == 206 &&
                            (
                                currentItmFeatBlock.resource.Equals("SPIN828") ||
                                currentItmFeatBlock.resource.Equals("SPIN572") ||
                                currentItmFeatBlock.resource.Equals("SPRA301") ||
                                currentItmFeatBlock.resource.Equals("SPWI305") // protection from spell
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                        if (
                            currentItmFeatBlock.opcodeNumber == 101 &&
                            (
                                currentItmFeatBlock.parameter2 == 1 ||
                                currentItmFeatBlock.parameter2 == 190 ||
                                currentItmFeatBlock.parameter2 == 189 ||
                                currentItmFeatBlock.parameter2 == 16 ||
                                currentItmFeatBlock.parameter2 == 126 ||
                                currentItmFeatBlock.parameter2 == 176 ||
                                currentItmFeatBlock.parameter2 == 317 // protection from spell
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                        if (
                            (
                                currentItmFeatBlock.opcodeNumber == 169 || 
                                currentItmFeatBlock.opcodeNumber == 240
                            )
                            &&
                            (
                                currentItmFeatBlock.parameter2 == 38 ||
                                currentItmFeatBlock.parameter2 == 110 // prevent / remove portrait icon
                            )
                        )
                        {
                            RemoveItmAbility(j);
                            FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
                        }
                    }
                }
            }
            
            // make every weapon usable for thieves (strength limitations and proficiency limitations remain!!) & thus backstab-eligible
            if (
                (
                    itmHeaderModded.itemType == 44 ||
                    itmHeaderModded.itemType == 30 ||
                    itmHeaderModded.itemType == 29 ||
                    itmHeaderModded.itemType == 28 ||
                    itmHeaderModded.itemType == 26 ||
                    itmHeaderModded.itemType == 25 ||
                    itmHeaderModded.itemType == 23 ||
                    itmHeaderModded.itemType == 22 ||
                    itmHeaderModded.itemType == 21 ||
                    itmHeaderModded.itemType == 20 ||
                    itmHeaderModded.itemType == 19 ||
                    itmHeaderModded.itemType == 17 ||
                    itmHeaderModded.itemType == 16 ||
                    itmHeaderModded.itemType == 16
                )
                && isDroppable()
            )
            {
                itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new[] { 9, 19, 22 }, false); // usable for mage thief, thief, cleric thief
            }
            
            // homogenize item restrictions for monks and kensai (kensais can use bracers)
            if (
                (unusableBy("kensai") && !unusableBy("monk")) ||
                (!unusableBy("kensai") && unusableBy("monk"))
            )
            {
                itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new int[] {29}, false);
                itmHeaderModded.usability4 = ModExistingBitfield(itmHeaderModded.usability4, new int[] {2}, false);
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // make clubs universally usable (in conjunction with a 2da weapprof mods allowing mages to put prof points in clubs)
            
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // ++++ WARNING!!!! THIS IS CONFIGURED FOR THE CDTWEAKS MOD "IWD WEAPON PROFICIENCIES + WEAPON STYLES!!!! +++++
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            if (itmHeaderModded.weapProf == 96) // if weap prof == bows (bg original) / club (cdtweaks iwd profs mod)
            {
                itmHeaderModded.exclusionFlags = 0;
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
            
            // make bows usable for druids (in conjunction with a 2da weapprof mods allowing druid to put prof points in bows)
            
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // ++++ WARNING!!!! THIS IS CONFIGURED FOR THE CDTWEAKS MOD "IWD WEAPON PROFICIENCIES + WEAPON STYLES!!!! +++++
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            if (itmHeaderModded.weapProf == 95) // if weap prof == cdtweaks iwd profs mod
            {
                itmHeaderModded.exclusionFlags = ModExistingBitfield(itmHeaderModded.exclusionFlags, new int [] {30}, false);
                FileOperations.WriteFile(itmHeaderModded, itmExtHeadersModded, itmEffFeatBlocksModded, itmAbilFeatBlocksModded, itmOutputPath + "/" + currentItemFileInfo);
            }
        }
        
        internal static void SetItmPrice(int price)
        {
            itmHeaderModded.price = price;
        }

        internal static void SetItmIcon(String iconName)
        {
            int strLength = 8;
            int delta = strLength - iconName.Length;
            if (delta > 0)
            {
                itmHeaderModded.invIcon = iconName + new string(new char[delta]);
            }
            else
            {
                itmHeaderModded.invIcon = iconName;
            }
            foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
            {
                if (delta > 0)
                {
                    itmExtHeader.useIcon = iconName + new string(new char[delta]);
                }
                else
                {
                    itmExtHeader.useIcon = iconName;
                }
            }
            // Console.WriteLine(iconName);
        }

        internal static void ModifyItmOpcode(short newOpcode)
        {
            currentItmFeatBlock.opcodeNumber = newOpcode;
        }
        
        internal static void ModifyItmParam1(byte param1)
        {
            currentItmFeatBlock.parameter1 = param1;
        }
        internal static void ModifyItmParam2(byte param2)
        {
            currentItmFeatBlock.parameter2 = param2;
        }

        internal static void RemoveItmEffect(int index)
        {
            itmEffFeatBlocksModded.RemoveAt(index);
            itmHeaderModded.effectsCount--;
            foreach (ItmExtHeader extHeader in itmExtHeadersModded)
            {
                extHeader.abilitiesIndex--;
            }
        }

        internal static void RemoveAllItmEffects()
        {
            itmEffFeatBlocksModded = new ArrayList();
            itmHeaderModded.effectsCount = 0;
            itmHeaderModded.abilitiesOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
            itmHeaderModded.effectsOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;

            foreach (ItmExtHeader extHeader in itmExtHeadersModded)
            {
                extHeader.abilitiesIndex = 0;
            }
        }
        
        internal static void RemoveItmAbility(int index)
        {
            itmAbilFeatBlocksModded.RemoveAt(index);

            int matchIndex = 0;
            for (int i = 0; i < itmExtHeadersModded.Count; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                for (int j = 0; j < currentItmExtHeader.abilitiesCount; j++)
                {
                    if (matchIndex == index)
                    {
                        currentItmExtHeader.abilitiesCount--;
                        itmExtHeadersModded[i] = currentItmExtHeader;
                        return;
                    }
                    matchIndex++;
                }
            }
        }
        
        internal static void RemoveAllItmExtHeadersAndItmAbilities()
        {
            itmExtHeadersModded = new ArrayList();
            itmAbilFeatBlocksModded = new ArrayList();
            itmHeaderModded.abilitiesCount = 0;
            itmHeaderModded.abilitiesOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
            itmHeaderModded.effectsOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
        }
        
        internal static void RemoveAllItmAbilities()
        {
            itmAbilFeatBlocksModded = new ArrayList();
            for (int i = 0; i < itmExtHeadersModded.Count; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                currentItmExtHeader.abilitiesCount = 0;
            }
        }

        internal static void AddItmAbility(short opcode, byte target, byte power, int parameter1, int parameter2, byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource, int diceThrown, int diceSize, int saveType, int saveBonus, int special, int extHeaderIndex)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter2, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType, saveBonus, special);

            int abilityInsertPos = 0;
            for (int i = 0; i <= extHeaderIndex; i++)
            {
                currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[i];
                abilityInsertPos += currentItmExtHeader.abilitiesCount;
            }
            
            currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[extHeaderIndex];
            currentItmExtHeader.abilitiesCount++;
            
            itmAbilFeatBlocksModded.Insert(abilityInsertPos, newFeatBlock);
        }

        internal static void AddItmEffect(short opcode, byte target, byte power, int parameter1, int parameter2, byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource, int diceThrown, int diceSize, int saveType, int saveBonus, int special)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter2, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType, saveBonus, special);

            itmHeaderModded.effectsCount++;
            itmEffFeatBlocksModded.Add(newFeatBlock);
        }
        
        internal static Boolean isDroppable()
        {
            BitArray bitArray = new BitArray(new int [] {itmHeader.flags});
            return bitArray[2];
        }

        internal static Boolean unusableBy(String identifier)
        {
            BitArray bitArray = new BitArray(new int[] {BitConverter.ToInt32(itmByteArray, 30)});
            if (identifier.Equals("chaotic"))
            {
                return bitArray[0];
            }
            if (identifier.Equals("evil"))
            {
                return bitArray[1];
            }
            if (identifier.Equals("good"))
            {
                return bitArray[2];
            }
            if (identifier.Equals("neutral1"))
            {
                return bitArray[3];
            }
            if (identifier.Equals("lawful"))
            {
                return bitArray[4];
            }
            if (identifier.Equals("neutral2"))
            {
                return bitArray[5];
            }
            if (identifier.Equals("bard"))
            {
                return bitArray[6];
            }
            if (identifier.Equals("cleric"))
            {
                return bitArray[7];
            }
            if (identifier.Equals("clericmage"))
            {
                return bitArray[8];
            }
            if (identifier.Equals("clericthief"))
            {
                return bitArray[9];
            }
            if (identifier.Equals("clericranger"))
            {
                return bitArray[10];
            }
            if (identifier.Equals("fighter"))
            {
                return bitArray[11];
            }
            if (identifier.Equals("fighterdruid"))
            {
                return bitArray[12];
            }
            if (identifier.Equals("fightermage"))
            {
                return bitArray[13];
            }
            if (identifier.Equals("fightercleric"))
            {
                return bitArray[14];
            }
            if (identifier.Equals("fightermagecleric"))
            {
                return bitArray[15];
            }
            if (identifier.Equals("fightermagethief"))
            {
                return bitArray[16];
            }
            if (identifier.Equals("fighterthief"))
            {
                return bitArray[17];
            }
            if (identifier.Equals("mage"))
            {
                return bitArray[18];
            }
            if (identifier.Equals("magethief"))
            {
                return bitArray[19];
            }
            if (identifier.Equals("paladin"))
            {
                return bitArray[20];
            }
            if (identifier.Equals("ranger"))
            {
                return bitArray[21];
            }
            if (identifier.Equals("thief"))
            {
                return bitArray[22];
            }
            if (identifier.Equals("elf"))
            {
                return bitArray[23];
            }
            if (identifier.Equals("dwarf"))
            {
                return bitArray[24];
            }
            if (identifier.Equals("halfelf"))
            {
                return bitArray[25];
            }
            if (identifier.Equals("halfling"))
            {
                return bitArray[26];
            }
            if (identifier.Equals("human"))
            {
                return bitArray[27];
            }
            if (identifier.Equals("gnome"))
            {
                return bitArray[28];
            }
            if (identifier.Equals("monk"))
            {
                return bitArray[29];
            }
            if (identifier.Equals("druid"))
            {
                return bitArray[30];
            }
            if (identifier.Equals("halforc"))
            {
                return bitArray[31];
            }
            if (identifier.Equals("halfling"))
            {
                return bitArray[26];
            }
            bitArray = new BitArray(new int[] {BitConverter.ToInt32(itmByteArray, 47)});
            if (identifier.Equals("kensai"))
            {
                return bitArray[2];
            }
            else
            {
                throw new Exception("COULD NOT GET BITFIELD");
            }
        }
    }
}