﻿using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static String[] nonControllable =
        {
            "DEMONKNI",
            "TANARRI",
            "GLABREZU",
            "PITFIEND"
        };

        internal static Boolean ContainsCaseInsensitive(String srcStr, String findStr)
        {
            if (findStr.Contains("."))
            {
                findStr = findStr.Replace(".", @"\.");
            }
            return Regex.IsMatch(srcStr, findStr, RegexOptions.IgnoreCase);
        }
        
        internal static void AddSplExtendedHeader(
            byte spellForm, 
            byte friendlyAbility, 
            short location, 
            String memorizedIcon, 
            byte target, 
            byte targetNumber, 
            short range, 
            short levelRequired, 
            short castingTime, 
            short timesPerDay, 
            short diceSides, 
            short diceThrown, 
            short enchanted, 
            short damageType, 
            short featureBlockCount, 
            short featureBlockOffset, 
            short charges, 
            short chargeDepletionBehaviour, 
            short projectile
        )
        {
            SplExtendedHeader newSplExtendedHeader = new SplExtendedHeader( 
                spellForm, 
                friendlyAbility, 
                location, 
                memorizedIcon, 
                target, 
                targetNumber, 
                range, 
                levelRequired, 
                castingTime, 
                timesPerDay, 
                diceSides, 
                diceThrown, 
                enchanted, 
                damageType, 
                featureBlockCount, 
                featureBlockOffset, 
                charges, 
                chargeDepletionBehaviour, 
                projectile
            );
            splExtHeadersModded.Add(newSplExtendedHeader);
        }
        
        internal static int GetBitfieldInt(int[] pos)
        {
            BitArray bitArray = new BitArray(32, false);

            foreach (int p in pos)
            {
                bitArray[p] = true;
            }

            byte[] newByte = new byte[4];
                            
            bitArray.CopyTo(newByte, 0);

            return BitConverter.ToInt32(newByte, 0);
        }
        
        internal static int ModExistingBitfield(int bitField, int[] pos, Boolean setTo)
        {
            BitArray bitArray = new BitArray(new int[] {bitField});
            
            foreach (int p in pos)
            {
                bitArray[p] = setTo;
            }
            
            byte[] newByte = new byte[4];
                            
            bitArray.CopyTo(newByte, 0);

            return BitConverter.ToInt32(newByte, 0);
        }
        
        internal static byte ModExistingBitfield(byte bitField, int[] pos, Boolean setTo)
        {
            BitArray bitArray = new BitArray(new byte[] {bitField});
            
            foreach (int p in pos)
            {
                bitArray[p] = setTo;
            }

            byte[] newByte = new byte[1];
            bitArray.CopyTo(newByte, 0);
            return newByte[0];
        }
        
        internal static Boolean isDroppable()
        {
            BitArray bitArray = new BitArray(new int [] {itmHeader.flags});
            return bitArray[2];
        }

        internal static Boolean unusableBy(String identifier)
        {
            BitArray bitArray = new BitArray(new int[] {BitConverter.ToInt32(itmByteArray, 30)});
            if (identifier.Equals("chaotic"))
            {
                return bitArray[0];
            }
            if (identifier.Equals("evil"))
            {
                return bitArray[1];
            }
            if (identifier.Equals("good"))
            {
                return bitArray[2];
            }
            if (identifier.Equals("neutral1"))
            {
                return bitArray[3];
            }
            if (identifier.Equals("lawful"))
            {
                return bitArray[4];
            }
            if (identifier.Equals("neutral2"))
            {
                return bitArray[5];
            }
            if (identifier.Equals("bard"))
            {
                return bitArray[6];
            }
            if (identifier.Equals("cleric"))
            {
                return bitArray[7];
            }
            if (identifier.Equals("clericmage"))
            {
                return bitArray[8];
            }
            if (identifier.Equals("clericthief"))
            {
                return bitArray[9];
            }
            if (identifier.Equals("clericranger"))
            {
                return bitArray[10];
            }
            if (identifier.Equals("fighter"))
            {
                return bitArray[11];
            }
            if (identifier.Equals("fighterdruid"))
            {
                return bitArray[12];
            }
            if (identifier.Equals("fightermage"))
            {
                return bitArray[13];
            }
            if (identifier.Equals("fightercleric"))
            {
                return bitArray[14];
            }
            if (identifier.Equals("fightermagecleric"))
            {
                return bitArray[15];
            }
            if (identifier.Equals("fightermagethief"))
            {
                return bitArray[16];
            }
            if (identifier.Equals("fighterthief"))
            {
                return bitArray[17];
            }
            if (identifier.Equals("mage"))
            {
                return bitArray[18];
            }
            if (identifier.Equals("magethief"))
            {
                return bitArray[19];
            }
            if (identifier.Equals("paladin"))
            {
                return bitArray[20];
            }
            if (identifier.Equals("ranger"))
            {
                return bitArray[21];
            }
            if (identifier.Equals("thief"))
            {
                return bitArray[22];
            }
            if (identifier.Equals("elf"))
            {
                return bitArray[23];
            }
            if (identifier.Equals("dwarf"))
            {
                return bitArray[24];
            }
            if (identifier.Equals("halfelf"))
            {
                return bitArray[25];
            }
            if (identifier.Equals("halfling"))
            {
                return bitArray[26];
            }
            if (identifier.Equals("human"))
            {
                return bitArray[27];
            }
            if (identifier.Equals("gnome"))
            {
                return bitArray[28];
            }
            if (identifier.Equals("monk"))
            {
                return bitArray[29];
            }
            if (identifier.Equals("druid"))
            {
                return bitArray[30];
            }
            if (identifier.Equals("halforc"))
            {
                return bitArray[31];
            }
            if (identifier.Equals("halfling"))
            {
                return bitArray[26];
            }
            bitArray = new BitArray(new int[] {BitConverter.ToInt32(itmByteArray, 47)});
            if (identifier.Equals("kensai"))
            {
                return bitArray[2];
            }
            else
            {
                throw new Exception("COULD NOT GET BITFIELD");
            }
        }

        internal static void CopySplExtendedHeaderAndSplFeatureBlocks(int extHeaderIndex)
        {
            SplExtendedHeader firstSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0];
            splExtHeadersModded[0] = firstSplExtendedHeader;
            //
            SplExtendedHeader oldSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extHeaderIndex];
            // we need to create a fresh extended header (NOT A COPY!!!) since arraylists only contain references, not complete copies of objects
            SplExtendedHeader newSplExtendedHeader = new SplExtendedHeader( 
                    oldSplExtendedHeader.spellForm, 
                    oldSplExtendedHeader.friendlyAbility, 
                    oldSplExtendedHeader.location, 
                    oldSplExtendedHeader.memorizedIcon, 
                    oldSplExtendedHeader.target, 
                    oldSplExtendedHeader.targetNumber, 
                    oldSplExtendedHeader.range, 
                    oldSplExtendedHeader.levelRequired, 
                    oldSplExtendedHeader.castingTime, 
                    oldSplExtendedHeader.timesPerDay, 
                    oldSplExtendedHeader.diceSides, 
                    oldSplExtendedHeader.diceThrown, 
                    oldSplExtendedHeader.enchanted, 
                    oldSplExtendedHeader.damageType, 
                    oldSplExtendedHeader.featureBlockCount, 
                    oldSplExtendedHeader.featureBlockOffset, 
                    oldSplExtendedHeader.charges, 
                    oldSplExtendedHeader.chargeDepletionBehaviour, 
                    oldSplExtendedHeader.projectile
                );
            
            // get feature block offset for the old extended header
            int oldExtendedHeaderFeatureBlockOffset = 0;
            for (int i = 0; i < extHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                oldExtendedHeaderFeatureBlockOffset += currentSplExtendedHeader.featureBlockCount;
            }

            // copy all featureblocks of the old extendedheader as a new instance to to feature blocks modded array list
            for (int i = 0; i < oldSplExtendedHeader.featureBlockCount; i++)
            {
                // we need to create a fresh feature block (NOT A COPY!!!) since arraylists only contain references, not complete copies of objects
                SplFeatureBlock oldSplFeatureBlock = (SplFeatureBlock)splFeatBlocksModded[i + oldExtendedHeaderFeatureBlockOffset];
                SplFeatureBlock newSplFeatureBlock = null;
                if (oldSplFeatureBlock.opcodeNumber == 12 || oldSplFeatureBlock.opcodeNumber == 233)
                {
                    newSplFeatureBlock = new SplFeatureBlock(
                        oldSplFeatureBlock.opcodeNumber,
                        oldSplFeatureBlock.targetType,
                        oldSplFeatureBlock.power,
                        oldSplFeatureBlock.parameter1,
                        oldSplFeatureBlock.parameter21,
                        oldSplFeatureBlock.parameter22,
                        oldSplFeatureBlock.timingMode,
                        oldSplFeatureBlock.resistance,
                        oldSplFeatureBlock.duration,
                        oldSplFeatureBlock.probability1,
                        oldSplFeatureBlock.probability2,
                        oldSplFeatureBlock.resource,
                        oldSplFeatureBlock.diceThrown,
                        oldSplFeatureBlock.diceSides,
                        oldSplFeatureBlock.savingThrowType,
                        oldSplFeatureBlock.savingThrowBonus,
                        oldSplFeatureBlock.stackingId
                    );
                }
                else if (oldSplFeatureBlock.opcodeNumber == 50)
                {
                    newSplFeatureBlock = new SplFeatureBlock(
                        oldSplFeatureBlock.opcodeNumber,
                        oldSplFeatureBlock.targetType,
                        oldSplFeatureBlock.power,
                        oldSplFeatureBlock.parameter1,
                        oldSplFeatureBlock.parameter23,
                        oldSplFeatureBlock.parameter24,
                        oldSplFeatureBlock.parameter25,
                        oldSplFeatureBlock.parameter26,
                        oldSplFeatureBlock.timingMode,
                        oldSplFeatureBlock.resistance,
                        oldSplFeatureBlock.duration,
                        oldSplFeatureBlock.probability1,
                        oldSplFeatureBlock.probability2,
                        oldSplFeatureBlock.resource,
                        oldSplFeatureBlock.diceThrown,
                        oldSplFeatureBlock.diceSides,
                        oldSplFeatureBlock.savingThrowType,
                        oldSplFeatureBlock.savingThrowBonus,
                        oldSplFeatureBlock.stackingId
                    );
                    
                }
                else
                {
                    newSplFeatureBlock = new SplFeatureBlock(
                        oldSplFeatureBlock.opcodeNumber,
                        oldSplFeatureBlock.targetType,
                        oldSplFeatureBlock.power,
                        oldSplFeatureBlock.parameter1,
                        oldSplFeatureBlock.parameter2,
                        oldSplFeatureBlock.timingMode,
                        oldSplFeatureBlock.resistance,
                        oldSplFeatureBlock.duration,
                        oldSplFeatureBlock.probability1,
                        oldSplFeatureBlock.probability2,
                        oldSplFeatureBlock.resource,
                        oldSplFeatureBlock.diceThrown,
                        oldSplFeatureBlock.diceSides,
                        oldSplFeatureBlock.savingThrowType,
                        oldSplFeatureBlock.savingThrowBonus,
                        oldSplFeatureBlock.stackingId
                    );
                }

                splFeatBlocksModded.Add(newSplFeatureBlock);
            }
            
            splExtHeadersModded.Add(newSplExtendedHeader);
            // Console.WriteLine(headerModded.featureBlockTableOffset);
            splHeaderModded.featureBlockTableOffset += SplExtendedHeader.size; // increase effects offset by byte size of newly added extended header 
            splHeaderModded.extendedHeaderCount += 1;
        }
        
        internal static void CopySplExtendedHeaderOnly(int extHeaderIndex)
        {
            SplExtendedHeader oldSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extHeaderIndex];
            // we need to create a fresh extended header (NOT A COPY!!!) since arraylists only contain references, not complete copies of objects
            SplExtendedHeader newSplExtendedHeader = new SplExtendedHeader( 
                    oldSplExtendedHeader.spellForm, 
                    oldSplExtendedHeader.friendlyAbility, 
                    oldSplExtendedHeader.location, 
                    oldSplExtendedHeader.memorizedIcon, 
                    oldSplExtendedHeader.target, 
                    oldSplExtendedHeader.targetNumber, 
                    oldSplExtendedHeader.range, 
                    oldSplExtendedHeader.levelRequired, 
                    oldSplExtendedHeader.castingTime, 
                    oldSplExtendedHeader.timesPerDay, 
                    oldSplExtendedHeader.diceSides, 
                    oldSplExtendedHeader.diceThrown, 
                    oldSplExtendedHeader.enchanted, 
                    oldSplExtendedHeader.damageType, 
                    0, // Copy extended header only, no feature blocks yet!!
                    oldSplExtendedHeader.featureBlockOffset, 
                    oldSplExtendedHeader.charges, 
                    oldSplExtendedHeader.chargeDepletionBehaviour, 
                    oldSplExtendedHeader.projectile
                );
            splExtHeadersModded.Add(newSplExtendedHeader);
            // Console.WriteLine(headerModded.featureBlockTableOffset);
            splHeaderModded.featureBlockTableOffset += SplExtendedHeader.size; // increase effects offset by byte size of newly added extended header 
            splHeaderModded.extendedHeaderCount += 1;
        }

        internal static void AddSplFeatureBlockToSplExtendedHeader(
            short opcodeNumber, 
            byte targetType, 
            byte power, 
            int parameter1, 
            int parameter2, 
            byte timingMode, 
            byte resistance, 
            int duration, 
            byte probability1, 
            byte probability2, 
            String resource, 
            int diceThrown, 
            int diceSides, 
            int savingThrowType, 
            int savingThrowBonus, 
            int stackingId,
            int extendedHeaderIndex
            )
        {
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount += 1; // increase featureBlock count for the modded extended heaeder 

            // get offset to insert the new featureblocks at the correct position in the featureblock array
            int fbOffset = 0;
            for (int i = 0; i < extendedHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += currentSplExtendedHeader.featureBlockCount;
            }
            
            // add the offset of the last extended header we want to add the featureblock to, if the new effect shall be added AFTER the already existing effects
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            fbOffset += currentSplExtendedHeader.featureBlockCount - 1;

            // headerModded.featureBlockTableOffset = extendedHeadersModded.Count * 40; // set the offset to the correct amount
            SplFeatureBlock newSplFeatureBlock = new SplFeatureBlock(opcodeNumber, targetType, power, parameter1, parameter2, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSides, savingThrowType, savingThrowBonus, stackingId);
            // splFeatBlocksModded.Add(newSplFeatureBlock);
            splFeatBlocksModded.Insert(fbOffset, newSplFeatureBlock);
        }
        
        internal static void AddSplFeatureBlockToSplExtendedHeader(
            short opcodeNumber, 
            byte targetType, 
            byte power, 
            int parameter1, 
            short parameter21, 
            short parameter22, 
            byte timingMode, 
            byte resistance, 
            int duration, 
            byte probability1, 
            byte probability2, 
            String resource, 
            int diceThrown, 
            int diceSides, 
            int savingThrowType, 
            int savingThrowBonus, 
            int stackingId,
            int extendedHeaderIndex
        )
        {
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount += 1; // increase featureBlock count for the modded extended heaeder 

            // get offset to insert the new featureblocks at the correct position in the featureblock array
            int fbOffset = 0;
            for (int i = 0; i < extendedHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += currentSplExtendedHeader.featureBlockCount;
            }
            
            // add the offset of the last extended header we want to add the featureblock to, if the new effect shall be added AFTER the already existing effects
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            fbOffset += currentSplExtendedHeader.featureBlockCount - 1;

            // headerModded.featureBlockTableOffset = extendedHeadersModded.Count * 40; // set the offset to the correct amount
            SplFeatureBlock newSplFeatureBlock = new SplFeatureBlock(opcodeNumber, targetType, power, parameter1, parameter21, parameter22, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSides, savingThrowType, savingThrowBonus, stackingId);
            // featureBlocksModded.Add(newFeatureBlock);
            splFeatBlocksModded.Insert(fbOffset, newSplFeatureBlock);
        }
        
        internal static void AddSplFeatureBlockToSplExtendedHeader(
            short opcodeNumber, 
            byte targetType, 
            byte power, 
            int parameter1, 
            byte parameter23, 
            byte parameter24, 
            byte parameter25, 
            byte parameter26, 
            byte timingMode, 
            byte resistance, 
            int duration, 
            byte probability1, 
            byte probability2, 
            String resource, 
            int diceThrown, 
            int diceSides, 
            int savingThrowType, 
            int savingThrowBonus, 
            int stackingId,
            int extendedHeaderIndex
        )
        {
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount += 1; // increase featureBlock count for the modded extended heaeder 

            // get offset to insert the new featureblocks at the correct position in the featureblock array
            int fbOffset = 0;
            for (int i = 0; i < extendedHeaderIndex; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += currentSplExtendedHeader.featureBlockCount;
            }
            
            // add the offset of the last extended header we want to add the featureblock to, if the new effect shall be added AFTER the already existing effects
            currentSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[extendedHeaderIndex];
            fbOffset += currentSplExtendedHeader.featureBlockCount - 1;

            // headerModded.featureBlockTableOffset = extendedHeadersModded.Count * 40; // set the offset to the correct amount
            SplFeatureBlock newSplFeatureBlock = new SplFeatureBlock(opcodeNumber, targetType, power, parameter1, parameter23, parameter24, parameter25, parameter26, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSides, savingThrowType, savingThrowBonus, stackingId);
            // featureBlocksModded.Add(newFeatureBlock);
            splFeatBlocksModded.Insert(fbOffset, newSplFeatureBlock);
        }

        internal static void ModifyAllSplDurations(int thresholdDuration, int newDuration, int[]excludeOpcodes, int extHeaderStart)
        {
            int featureBlockStart = 0;
            for (int i = 0; i < extHeaderStart; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                featureBlockStart += currentSplExtendedHeader.featureBlockCount;
            }

            // Console.WriteLine(extHeaderStart);
            // Console.WriteLine(featureBlockStart + " : " + featureBlocksModded.Count);
            
            for (int j = featureBlockStart; j <= splFeatBlocksModded.Count-1; j++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[j];
                if (currentSplFeatBlock.duration >= thresholdDuration && Array.IndexOf(excludeOpcodes, currentSplFeatBlock.opcodeNumber) == -1)
                {
                    currentSplFeatBlock.duration = newDuration;
                }
            }
        }
        
        internal static void ModifySplOpcode(int opcodeNum, String propName, int oldVal, int newVal)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
                    {
                        if (currentSplFeatBlock.targetType == oldVal)
                        {
                            currentSplFeatBlock.targetType = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[1]))
                    {
                        if (currentSplFeatBlock.power == oldVal)
                        {
                            currentSplFeatBlock.power = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[2]))
                    {
                        if (currentSplFeatBlock.parameter1 == oldVal)
                        {
                            currentSplFeatBlock.parameter1 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[3]))
                    {
                        if (currentSplFeatBlock.parameter2 == oldVal)
                        {
                            currentSplFeatBlock.parameter2 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[4]))
                    {
                        if (currentSplFeatBlock.parameter21 == oldVal)
                        {
                            currentSplFeatBlock.parameter21 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[5]))
                    {
                        if (currentSplFeatBlock.parameter22 == oldVal)
                        {
                            currentSplFeatBlock.parameter22 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[6]))
                    {
                        if (currentSplFeatBlock.timingMode == oldVal)
                        {
                            currentSplFeatBlock.timingMode = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[7]))
                    {
                        if (currentSplFeatBlock.resistance == oldVal)
                        {
                            currentSplFeatBlock.resistance = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[8]))
                    {
                        if (currentSplFeatBlock.duration == oldVal)
                        {
                            currentSplFeatBlock.duration = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[9]))
                    {
                        if (currentSplFeatBlock.probability1 == oldVal)
                        {
                            currentSplFeatBlock.probability1 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[10]))
                    {
                        if (currentSplFeatBlock.probability2 == oldVal)
                        {
                            currentSplFeatBlock.probability2 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[11]))
                    {
                        if (currentSplFeatBlock.diceThrown == oldVal)
                        {
                            currentSplFeatBlock.diceThrown = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[12]))
                    {
                        if (currentSplFeatBlock.diceSides == oldVal)
                        {
                            currentSplFeatBlock.diceSides = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[13]))
                    {
                        if (currentSplFeatBlock.savingThrowType == oldVal)
                        {
                            currentSplFeatBlock.savingThrowType = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[14]))
                    {
                        if (currentSplFeatBlock.savingThrowBonus == oldVal)
                        {
                            currentSplFeatBlock.savingThrowBonus = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[15]))
                    {
                        if (currentSplFeatBlock.stackingId == oldVal)
                        {
                            currentSplFeatBlock.stackingId = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[16]))
                    {
                        if (currentSplFeatBlock.parameter23 == oldVal)
                        {
                            currentSplFeatBlock.parameter23 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[17]))
                    {
                        if (currentSplFeatBlock.parameter24 == oldVal)
                        {
                            currentSplFeatBlock.parameter24 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[18]))
                    {
                        if (currentSplFeatBlock.parameter25 == oldVal)
                        {
                            currentSplFeatBlock.parameter25 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[19]))
                    {
                        if (currentSplFeatBlock.parameter26 == oldVal)
                        {
                            currentSplFeatBlock.parameter26 = (byte)newVal;
                        }
                    }
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String propName, int oldVal, int newVal, int extHeaderIndex)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
                    {
                        if (currentSplFeatBlock.targetType == oldVal)
                        {
                            currentSplFeatBlock.targetType = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[1]))
                    {
                        if (currentSplFeatBlock.power == oldVal)
                        {
                            currentSplFeatBlock.power = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[2]))
                    {
                        if (currentSplFeatBlock.parameter1 == oldVal)
                        {
                            currentSplFeatBlock.parameter1 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[3]))
                    {
                        if (currentSplFeatBlock.parameter2 == oldVal)
                        {
                            currentSplFeatBlock.parameter2 = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[4]))
                    {
                        if (currentSplFeatBlock.parameter21 == oldVal)
                        {
                            currentSplFeatBlock.parameter21 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[5]))
                    {
                        if (currentSplFeatBlock.parameter22 == oldVal)
                        {
                            currentSplFeatBlock.parameter22 = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[6]))
                    {
                        if (currentSplFeatBlock.timingMode == oldVal)
                        {
                            currentSplFeatBlock.timingMode = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[7]))
                    {
                        if (currentSplFeatBlock.resistance == oldVal)
                        {
                            currentSplFeatBlock.resistance = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[8]))
                    {
                        if (currentSplFeatBlock.duration == oldVal)
                        {
                            currentSplFeatBlock.duration = (short)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[9]))
                    {
                        if (currentSplFeatBlock.probability1 == oldVal)
                        {
                            currentSplFeatBlock.probability1 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[10]))
                    {
                        if (currentSplFeatBlock.probability2 == oldVal)
                        {
                            currentSplFeatBlock.probability2 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[11]))
                    {
                        if (currentSplFeatBlock.diceThrown == oldVal)
                        {
                            currentSplFeatBlock.diceThrown = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[12]))
                    {
                        if (currentSplFeatBlock.diceSides == oldVal)
                        {
                            currentSplFeatBlock.diceSides = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[13]))
                    {
                        if (currentSplFeatBlock.savingThrowType == oldVal)
                        {
                            currentSplFeatBlock.savingThrowType = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[14]))
                    {
                        if (currentSplFeatBlock.savingThrowBonus == oldVal)
                        {
                            currentSplFeatBlock.savingThrowBonus = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[15]))
                    {
                        if (currentSplFeatBlock.stackingId == oldVal)
                        {
                            currentSplFeatBlock.stackingId = newVal;
                        }
                    }
                    if (propName.Equals(propNameList[16]))
                    {
                        if (currentSplFeatBlock.parameter23 == oldVal)
                        {
                            currentSplFeatBlock.parameter23 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[17]))
                    {
                        if (currentSplFeatBlock.parameter24 == oldVal)
                        {
                            currentSplFeatBlock.parameter24 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[18]))
                    {
                        if (currentSplFeatBlock.parameter25 == oldVal)
                        {
                            currentSplFeatBlock.parameter25 = (byte)newVal;
                        }
                    }
                    if (propName.Equals(propNameList[19]))
                    {
                        if (currentSplFeatBlock.parameter26 == oldVal)
                        {
                            currentSplFeatBlock.parameter26 = (byte)newVal;
                        }
                    }
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String propName, int newVal, int extHeaderIndex)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
					{
						currentSplFeatBlock.targetType = (byte)newVal;
					}
					if (propName.Equals(propNameList[1]))
					{
						currentSplFeatBlock.power = (byte)newVal;
					}
					if (propName.Equals(propNameList[2]))
					{
						currentSplFeatBlock.parameter1 = newVal;
					}
					if (propName.Equals(propNameList[3]))
					{
						currentSplFeatBlock.parameter2 = newVal;
					}
					if (propName.Equals(propNameList[4]))
					{
						currentSplFeatBlock.parameter21 = (short)newVal;
					}
					if (propName.Equals(propNameList[5]))
					{
						currentSplFeatBlock.parameter22 = (short)newVal;
					}
					if (propName.Equals(propNameList[6]))
					{
						currentSplFeatBlock.timingMode = (byte)newVal;
					}
					if (propName.Equals(propNameList[7]))
					{
						currentSplFeatBlock.resistance = (byte)newVal;
					}
					if (propName.Equals(propNameList[8]))
					{
						currentSplFeatBlock.duration = (short)newVal;
					}
					if (propName.Equals(propNameList[9]))
					{
						currentSplFeatBlock.probability1 = (byte)newVal;
					}
					if (propName.Equals(propNameList[10]))
					{
						currentSplFeatBlock.probability2 = (byte)newVal;
					}
					if (propName.Equals(propNameList[11]))
					{
						currentSplFeatBlock.diceThrown = newVal;
					}
					if (propName.Equals(propNameList[12]))
					{
						currentSplFeatBlock.diceSides = newVal;
					}
					if (propName.Equals(propNameList[13]))
					{
						currentSplFeatBlock.savingThrowType = newVal;
					}
					if (propName.Equals(propNameList[14]))
					{
						currentSplFeatBlock.savingThrowBonus = newVal;
					}
					if (propName.Equals(propNameList[15]))
					{
						currentSplFeatBlock.stackingId = newVal;
					}
					if (propName.Equals(propNameList[16]))
					{
						currentSplFeatBlock.parameter23 = (byte)newVal;
					}
					if (propName.Equals(propNameList[17]))
					{
						currentSplFeatBlock.parameter24 = (byte)newVal;
					}
					if (propName.Equals(propNameList[18]))
					{
						currentSplFeatBlock.parameter25 = (byte)newVal;
					}
					if (propName.Equals(propNameList[19]))
					{
						currentSplFeatBlock.parameter26 = (byte)newVal;
					}
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String newVal, int extHeaderIndex)
        {
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }

            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    currentSplFeatBlock.resource = newVal;
                }
            }
        }
        
        internal static void ModifySplOpcodeSpecific(int opcodeNum, String oldVal, String newVal, int extHeaderIndex)
        {
            SplExtendedHeader modHeader = (SplExtendedHeader) splExtHeadersModded[extHeaderIndex];
            int fbOffset = 0;
            int fbNum = modHeader.featureBlockCount;
            
            for (int i = 0; i < extHeaderIndex; i++)
            {
                SplExtendedHeader startSplExtendedHeader = (SplExtendedHeader)splExtHeadersModded[i];
                fbOffset += startSplExtendedHeader.featureBlockCount;
            }

            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = fbOffset; i < fbOffset + fbNum; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (currentSplFeatBlock.resource.Equals(oldVal))
                    {
                        currentSplFeatBlock.resource = newVal;
                    }
                }
            }
        }

        internal static void RemoveSplOpcode(int opcodeNum, int keepNum)
        {
            ArrayList savedOpcodeInstances = new ArrayList();
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    // Console.WriteLine(index);
                    savedOpcodeInstances.Add(i);
                }
            }

            for (int j = savedOpcodeInstances.Count - 1 - keepNum; j >= 0; j--) // keep the specified number of instances
            {
                int indexToDel = (int)savedOpcodeInstances[j];
                // Console.WriteLine(indexToDel + " " + featureBlocksModded.Count);
                splFeatBlocksModded.RemoveAt(indexToDel); // remove the value stored in the savedOpcodeInstances
            }
            
            foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
            {
                int newCount = extendedHeader.featureBlockCount - ((savedOpcodeInstances.Count - keepNum) / splExtHeadersModded.Count);
                extendedHeader.featureBlockCount = Convert.ToInt16(newCount);
            }
        }
        
        internal static void RemoveSplOpcode(int opcodeNum, String propName, int val)
        {
            String[] propNameList =
            {
                "targetType", "power", "parameter1", "parameter2", "parameter21", "parameter22",
                "timingMode", "resistance", "duration", "probability1", "probability2", "diceThrown",
                "diceSides", "savingThrowType", "savingThrowBonus", "stackingId",
                "parameter23", "parameter24", "parameter25", "parameter26"
            };
            
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (propName.Equals(propNameList[0]))
                    {
                        if (currentSplFeatBlock.targetType == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[1]))
                    {
                        if (currentSplFeatBlock.power == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[2]))
                    {
                        if (currentSplFeatBlock.parameter1 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[3]))
                    {
                        if (currentSplFeatBlock.parameter2 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[4]))
                    {
                        if (currentSplFeatBlock.parameter21 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[5]))
                    {
                        if (currentSplFeatBlock.parameter22 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[6]))
                    {
                        if (currentSplFeatBlock.timingMode == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[7]))
                    {
                        if (currentSplFeatBlock.resistance == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[8]))
                    {
                        if (currentSplFeatBlock.duration == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[9]))
                    {
                        if (currentSplFeatBlock.probability1 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[10]))
                    {
                        if (currentSplFeatBlock.probability2 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[11]))
                    {
                        if (currentSplFeatBlock.diceThrown == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[12]))
                    {
                        if (currentSplFeatBlock.diceSides == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[13]))
                    {
                        if (currentSplFeatBlock.savingThrowType == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[14]))
                    {
                        if (currentSplFeatBlock.savingThrowBonus == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[15]))
                    {
                        if (currentSplFeatBlock.stackingId == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[16]))
                    {
                        if (currentSplFeatBlock.parameter23 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[17]))
                    {
                        if (currentSplFeatBlock.parameter24 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[18]))
                    {
                        if (currentSplFeatBlock.parameter25 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                    if (propName.Equals(propNameList[19]))
                    {
                        if (currentSplFeatBlock.parameter26 == val)
                        {
                            savedOpcodeInstances.Add(i);
                        }
                    }
                }
            }

            for (int j = savedOpcodeInstances.Count - 1; j >= 0; j--) // keep the specified number of instances
            {
                int indexToDel = (int)savedOpcodeInstances[j];
                // Console.WriteLine(indexToDel + " " + featureBlocksModded.Count);
                splFeatBlocksModded.RemoveAt(indexToDel); // remove the value stored in the savedOpcodeInstances
            }
            
            foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
            {
                int newCount = extendedHeader.featureBlockCount - ((savedOpcodeInstances.Count) / splExtHeadersModded.Count);
                extendedHeader.featureBlockCount = Convert.ToInt16(newCount);
            }
        }
        
        internal static void RemoveSplOpcode(int opcodeNum, String val)
        {
            ArrayList savedOpcodeInstances = new ArrayList();
            
            for (int i = 0; i < splFeatBlocksModded.Count; i++)
            {
                currentSplFeatBlock = (SplFeatureBlock) splFeatBlocksModded[i];
                if (currentSplFeatBlock.opcodeNumber == opcodeNum)
                {
                    if (currentSplFeatBlock.resource.Contains(val))
                    {
                        savedOpcodeInstances.Add(i);
                    }
                }
            }

            for (int j = savedOpcodeInstances.Count - 1; j >= 0; j--) // keep the specified number of instances
            {
                int indexToDel = (int)savedOpcodeInstances[j];
                // Console.WriteLine(indexToDel + " " + featureBlocksModded.Count);
                splFeatBlocksModded.RemoveAt(indexToDel); // remove the value stored in the savedOpcodeInstances
            }
            
            foreach (SplExtendedHeader extendedHeader in splExtHeadersModded)
            {
                int newCount = extendedHeader.featureBlockCount - ((savedOpcodeInstances.Count) / splExtHeadersModded.Count);
                extendedHeader.featureBlockCount = Convert.ToInt16(newCount);
            }
        }
        
        internal static void RemoveSplExtendedHeadersAndSplFeatureBlocks(int keepNum)
        {
            // Console.WriteLine(headerModded.extendedHeaderCount);
            
            int extendedHeadersCount = splExtHeadersModded.Count;
            for (int i = extendedHeadersCount; i > keepNum; i--)
            {
                splExtHeadersModded.RemoveAt(i - 1);
                splHeaderModded.extendedHeaderCount -= 1;
            }

            // determine, how many dependent featureblocks to remove after the extended headers have been removed
            int featureBlocksCount = splFeatBlocksModded.Count;
            int numFeatureBlocksToSpare = 0;
            if (splExtHeadersModded.Count != 0) // only do this, if, after the extendedHeaders are deleted, there is still one remaining, otherwise the number of feature blocks to spare can be set to 0
            {
                SplExtendedHeader firstSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[0]; // only check this, if, after the extendedHeaders are deleted, there is still one remaining
                numFeatureBlocksToSpare = keepNum * firstSplExtendedHeader.featureBlockCount;
            }
            
            for (int j = featureBlocksCount; j > numFeatureBlocksToSpare; j--)
            {
                splFeatBlocksModded.RemoveAt(j - 1);
            }
            
            extendedHeadersCount = splExtHeadersModded.Count;
            splHeaderModded.featureBlockTableOffset = SplHeader.size + SplExtendedHeader.size * extendedHeadersCount; // we have to adapt the offset to the featureblock data, since we have modified the number of extended header by deletion. the structure of the file is header - all extendedheaders - all featureblocks. hence we can calculate the offset to the first featureblock by header size + extendedheader size * extendedheader count

            // Console.WriteLine(featureBlocksModded.Count);
            // Console.WriteLine(headerModded.extendedHeaderCount);
        }
        
        internal static void RemoveAllSplFeatureBlocks()
        {
            // determine, how many featureblocks to remove
            int featureBlocksCount = splFeatBlocksModded.Count;
            // Console.WriteLine(featureBlocksModded.Count);

            for (int j = featureBlocksCount; j > 0; j--)
            {
                splFeatBlocksModded.RemoveAt(j - 1);
            }

            for (int i = 0; i < splExtHeadersModded.Count; i++)
            {
                currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[i];
                currentSplExtendedHeader.featureBlockCount = 0;
            }
        }
        
        internal static void RemoveAllSplFeatureBlocks(int extendedHeaderIndex)
        {
            int fbBegin = 0;
            int fbEnd = 0;
            for (int i = 0; i < extendedHeaderIndex - 1; i++)
            {
                SplExtendedHeader currentSplExtendedHeader1 = (SplExtendedHeader) splExtHeadersModded[i];
                fbBegin += currentSplExtendedHeader1.featureBlockCount;
            }
            
            SplExtendedHeader currentSplExtendedHeader2 = (SplExtendedHeader) splExtHeadersModded[extendedHeaderIndex];
            fbEnd += currentSplExtendedHeader2.featureBlockCount;
            
            for (int j = fbBegin; j < fbBegin + fbEnd; j++)
            {
                splFeatBlocksModded.RemoveAt(j);
            }
            
            currentSplExtendedHeader = (SplExtendedHeader) splExtHeadersModded[extendedHeaderIndex];
            currentSplExtendedHeader.featureBlockCount = 0;
        }
        
        internal static void RemoveAllSplCastingFeatureBlocks()
        {
            // determine, how many featureblocks to remove
            int castingFeatureBlocksCount = splCastFeatBlocksModded.Count;
            // Console.WriteLine(featureBlocksModded.Count);

            for (int j = castingFeatureBlocksCount; j > 0; j--)
            {
                splCastFeatBlocksModded.RemoveAt(j - 1);
            }

            splHeaderModded.castingFeatureBlockCount = 0;
        }

        internal static int FindFirstExactTlkEntry(String findStr)
        {
            index = 0;
            Regex regex = new Regex(@"\A" + findStr + @"\Z");
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            return -1;
        }
        
        internal static int FindFirstMatchingTlkEntry(String findStr)
        {
            index = 0;
            Regex regex = new Regex(findStr);
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            return -1;
        }
        
        internal static String GetTlkStringFromStrRef(int strRef)
        {
            if (strRef == -1)
            {
                return "";
            }
            else
            {
                TlkEntry tlkEntry = (TlkEntry)tlkEntries[strRef];
                return tlkEntry.textString;
            }
        }
        
        internal static void AddTlkEntry(String addString)
        {
            TlkEntry lastEntry = (TlkEntry)tlkEntries[tlkEntries.Count - 1];
            int offset = lastEntry.offsetToString + lastEntry.stringLength;
            
            tlkEntries.Add(new TlkEntry(addString, (short)GetBitfieldInt(new int[] {0, 2}), offset));
            
            // increase the offset for all tlkentries by the size of the new entry (remember that the properties of the tlks come before the string section itself)
            // structure: header -> tlk props (offsets pointing to the location in the string section) -> string section
            tlkHeader.numberOfStrRefs++;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                tlkEntry.offsetToString += TlkEntry.size;
            }
        }
        
        internal static void CreateTlkObjects()
        {
            // preceding validity check TLK
            if (FileOperations.CheckFilePath(tlkInputPath)) // check validity
            {
                Console.WriteLine("TLK file does not exist, cannot continue!");
                return;
            }
            
            // TLK run logic
            // -----------------------------------
            
            tlkByteArray = FileOperations.ReadFile(tlkInputPath);
            tlkHeader = new TlkHeader(tlkByteArray);
            
            // tlkHeader.PrintValues();

            tlkEntries = new ArrayList();
            
            // Console.WriteLine("Working on TLK...");

            // 1. find the number of tlkEntries (weirdly, this has not been predesigned in the tlk file)
            int baseOffset = TlkHeader.size;
            int stringSectionBegin = tlkHeader.offsetToStringData;
            // Console.WriteLine(tlkHeader.numberOfStrRefs);
            int previousStringLengths = 0;
            for (int i = 0; i < tlkHeader.numberOfStrRefs; i++)
            {
                TlkEntry currentTlkEntry = new TlkEntry(tlkByteArray, baseOffset); // size of each tlkEntry is 26 bytes
                
                // Console.WriteLine(currentTlkEntry.offsetToString);
                // Console.WriteLine(currentTlkEntry.stringLength);
                // Console.WriteLine(i);
                
                if (currentTlkEntry.bitField >= 0 && currentTlkEntry.bitField <= 15 )
                {
                    // Console.WriteLine(i);
                    tlkEntries.Add(currentTlkEntry);
                    currentTlkEntry.GetStringData(tlkByteArray, stringSectionBegin + previousStringLengths);
                    // Console.WriteLine(currentTlkEntry.textString);
                    previousStringLengths += currentTlkEntry.stringLength;
                }
                else
                {
                    stringSectionBegin = previousStringLengths;
                    break;
                }
                
                // Console.WriteLine(stringSectionBegin);
                baseOffset += TlkEntry.size;
            }
            
            // Console.WriteLine(tlkEntries.Count);

            // -----------------------------
        }
        
        internal static SplHeader ChangeTlkName(SplHeader splHeader, String namePattern, String descPattern)
        {
            Boolean nameFound = false;
            Boolean descFound = false;
            Regex regexName = new Regex(@"\A" + namePattern + @"\Z");
            Regex regexDesc = new Regex(descPattern);
            Match matchName;
            Match matchDesc;
            int tlkCounter = 0;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                if (regexName.IsMatch(tlkEntry.textString))
                {
                    matchName = regexName.Match(tlkEntry.textString);
                    nameFound = true;
                    splHeader.spellNameUnId = tlkCounter;
                    // Console.WriteLine(tlkEntry.textString);
                    Console.WriteLine("found and changed tlk name: " + tlkEntry.textString);
                }
                if (regexDesc.IsMatch(tlkEntry.textString))
                {
                    matchDesc = regexDesc.Match(tlkEntry.textString);
                    descFound = true;
                    splHeader.spellDescriptionUnId = tlkCounter;
                    Console.WriteLine("found and changed tlk desc: " + tlkEntry.textString);
                }
                
                tlkCounter++;
            }

            return splHeader;
        }

        internal static void CreateSplObjects()
        {
            // Console.WriteLine("Working on file " + spell);
            splByteArray = FileOperations.ReadFile(currentSpellFileInfo.FullName);

            // create header
            splHeader = new SplHeader(splByteArray);
            
            // GET CURRENT SPELL NAME
            if (splHeader.spellNameUnId > 0)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[splHeader.spellNameUnId];
                currentSpellName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentSpellName = "";
            }

            int byteCount = SplHeader.size; // increase the byte count

            // create extended headers
            splExtHeaders = new ArrayList();
            SplExtendedHeader firstSplExtendedHeader = null;
            if (splHeader.extendedHeaderCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < splHeader.extendedHeaderCount; i++)
                {
                    currentSplExtendedHeader = new SplExtendedHeader(splByteArray, byteCount);
                    if (i == 0)
                    {
                        firstSplExtendedHeader = currentSplExtendedHeader;
                    }
                    splExtHeaders.Add(currentSplExtendedHeader);
                    byteCount += SplExtendedHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create casting feature blocks
            splCastFeatBlocks = new ArrayList();
            if (splHeader.castingFeatureBlockCount > 0)
            {
                for (int j = 0; j < splHeader.castingFeatureBlockCount; j++)
                {
                    currentSplCastFeatBlock = new SplFeatureBlock(splByteArray, byteCount);
                    splCastFeatBlocks.Add(currentSplCastFeatBlock);
                    byteCount += SplFeatureBlock.size; // increase offset by the size of the casting feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks
            splFeatBlocks = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                foreach (SplExtendedHeader extendedHeader in splExtHeaders)
                {
                    for (int j = 0; j < extendedHeader.featureBlockCount; j++)
                    {
                        currentSplFeatBlock = new SplFeatureBlock(splByteArray, byteCount);
                        splFeatBlocks.Add(currentSplFeatBlock);
                        byteCount += SplFeatureBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }

            // modding objects
            splHeaderModded = splHeader;
            splExtHeadersModded = splExtHeaders;
            splCastFeatBlocksModded = splCastFeatBlocks;
            splFeatBlocksModded = splFeatBlocks;
        }
        internal static void CreateSplObjects(String spell)
        {
            // Console.WriteLine("Working on file " + spell);
            splByteArray = FileOperations.ReadFile(splInputDirectory + "/" + spell);

            // create header
            splHeader = new SplHeader(splByteArray);
            
            // GET CURRENT SPELL NAME
            if (splHeader.spellNameUnId > 0)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[splHeader.spellNameUnId];
                currentSpellName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentSpellName = "";
            }

            int byteCount = SplHeader.size; // increase the byte count

            // create extended headers
            splExtHeaders = new ArrayList();
            SplExtendedHeader firstSplExtendedHeader = null;
            if (splHeader.extendedHeaderCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < splHeader.extendedHeaderCount; i++)
                {
                    currentSplExtendedHeader = new SplExtendedHeader(splByteArray, byteCount);
                    if (i == 0)
                    {
                        firstSplExtendedHeader = currentSplExtendedHeader;
                    }
                    splExtHeaders.Add(currentSplExtendedHeader);
                    byteCount += SplExtendedHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create casting feature blocks
            splCastFeatBlocks = new ArrayList();
            if (splHeader.castingFeatureBlockCount > 0)
            {
                for (int j = 0; j < splHeader.castingFeatureBlockCount; j++)
                {
                    currentSplCastFeatBlock = new SplFeatureBlock(splByteArray, byteCount);
                    splCastFeatBlocks.Add(currentSplCastFeatBlock);
                    byteCount += SplFeatureBlock.size; // increase offset by the size of the casting feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks
            splFeatBlocks = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                foreach (SplExtendedHeader extendedHeader in splExtHeaders)
                {
                    for (int j = 0; j < extendedHeader.featureBlockCount; j++)
                    {
                        currentSplFeatBlock = new SplFeatureBlock(splByteArray, byteCount);
                        splFeatBlocks.Add(currentSplFeatBlock);
                        byteCount += SplFeatureBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }

            // modding objects
            splHeaderModded = splHeader;
            splExtHeadersModded = splExtHeaders;
            splCastFeatBlocksModded = splCastFeatBlocks;
            splFeatBlocksModded = splFeatBlocks;
        }
        internal static void CreateSplObjects(String path, String spell)
        {
            // Console.WriteLine("Working on file " + spell);
            splByteArray = FileOperations.ReadFile(path + "/" + spell);

            // create header
            splHeader = new SplHeader(splByteArray);

            int byteCount = SplHeader.size; // increase the byte count

            // create extended headers
            splExtHeaders = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < splHeader.extendedHeaderCount; i++)
                {
                    // Console.WriteLine(path + "/" + spell + ":" + splByteArray.Length + " " + byteCount);
                    currentSplExtendedHeader = new SplExtendedHeader(splByteArray, byteCount);
                    splExtHeaders.Add(currentSplExtendedHeader);
                    byteCount += SplExtendedHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create casting feature blocks
            splCastFeatBlocks = new ArrayList();
            if (splHeader.castingFeatureBlockCount > 0)
            {
                for (int j = 0; j < splHeader.castingFeatureBlockCount; j++)
                {
                    currentSplCastFeatBlock = new SplFeatureBlock(splByteArray, byteCount);
                    splCastFeatBlocks.Add(currentSplCastFeatBlock);
                    byteCount += SplFeatureBlock.size; // increase offset by the size of the casting feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks
            splFeatBlocks = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                foreach (SplExtendedHeader extendedHeader in splExtHeaders)
                {
                    for (int k = 0; k < extendedHeader.featureBlockCount; k++)
                    {
                        currentSplFeatBlock = new SplFeatureBlock(splByteArray, byteCount);
                        splFeatBlocks.Add(currentSplFeatBlock);
                        byteCount += SplFeatureBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }

            // modding objects
            splHeaderModded = splHeader;
            splExtHeadersModded = splExtHeaders;
            splCastFeatBlocksModded = splCastFeatBlocks;
            splFeatBlocksModded = splFeatBlocks;
        }
        
        internal static void CreateItmObjects()
        {
            // Console.WriteLine("Working on file " + spell);
            itmByteArray = FileOperations.ReadFile(currentItemFileInfo.FullName);

            // create header
            itmHeader = new ItmHeader(itmByteArray);

            int byteCount = ItmHeader.size; // increase the byte count

            // create extended headers
            itmExtHeaders = new ArrayList();
            ItmExtHeader firstItmExtHeader = null;
            if (itmHeader.abilitiesCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < itmHeader.abilitiesCount; i++)
                {
                    currentItmExtHeader = new ItmExtHeader(itmByteArray, byteCount);
                    if (i == 0)
                    {
                        firstItmExtHeader = currentItmExtHeader;
                    }
                    itmExtHeaders.Add(currentItmExtHeader);
                    byteCount += ItmExtHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create feature blocks of effects
            itmEffFeatBlocks = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (itmHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < itmHeader.effectsCount; j++)
                {
                    currentItmFeatBlock = new ItmFeatBlock(itmByteArray, byteCount);
                    itmEffFeatBlocks.Add(currentItmFeatBlock);
                    byteCount += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks of abilities
            itmAbilFeatBlocks = new ArrayList();
            foreach (ItmExtHeader extHeader in itmExtHeaders)
            {
                if (extHeader.abilitiesCount > 0) // if there are any extended headers (only then can there be feature blocks)
                {
                    // Console.WriteLine(item);
                    // Console.WriteLine(extHeader.useIcon);
                    for (int k = 0; k < extHeader.abilitiesCount; k++)
                    {
                        currentItmFeatBlock = new ItmFeatBlock(itmByteArray, byteCount);
                        itmAbilFeatBlocks.Add(currentItmFeatBlock);
                        byteCount += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }
                

            // MODDING OBJECTS
            itmHeaderModded = itmHeader;
            itmExtHeadersModded = itmExtHeaders;
            itmEffFeatBlocksModded = itmEffFeatBlocks;
            itmAbilFeatBlocksModded = itmAbilFeatBlocks;
        }
        
        internal static void CreateCreObjects()
        {
            // Console.WriteLine("Working on file " + spell);
            creByteArray = FileOperations.ReadFile(currentCreFileInfo.FullName);

            // create header
            creHeader = new CreHeader(creByteArray);

            int byteCount = CreHeader.size; // increase the byte count

            // create known spells
            creKnownSpells = new ArrayList();
            if (creHeader.knownSpellsCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < creHeader.knownSpellsCount; i++)
                {
                    // Console.WriteLine(creByteArray.Length);
                    // Console.WriteLine(byteCount);
                    currentCreKnownSpell = new CreKnownSpell(creByteArray, byteCount);
                    creKnownSpells.Add(currentCreKnownSpell);
                    byteCount += CreKnownSpell.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }

            // create memorized spells infos
            creMemorizedSpellsInfos = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.spellsMemoInfoCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.spellsMemoInfoCount; j++)
                {
                    currentCreMemorizedSpellsInfo = new CreMemorizedSpellsInfo(creByteArray, byteCount);
                    creMemorizedSpellsInfos.Add(currentCreMemorizedSpellsInfo);
                    byteCount += CreMemorizedSpellsInfo.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    // Console.WriteLine(creHeader.memoSpellsCount);
                }
            }
            
            // create memorized spells
            creMemorizedSpells = new ArrayList();
            foreach (CreMemorizedSpellsInfo creMemorizedSpellsInfo in creMemorizedSpellsInfos)
            {
                for (int i = 0; i < creMemorizedSpellsInfo.spellCount; i++)
                {
                    currentCreMemorizedSpell = new CreMemorizedSpell(creByteArray, byteCount);
                    creMemorizedSpells.Add(currentCreMemorizedSpell);
                    byteCount += CreMemorizedSpell.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create effects
            creEffects = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.effectsCount; j++)
                {
                    currentCreEffect = new CreEffect(creByteArray, byteCount);
                    creEffects.Add(currentCreEffect);
                    byteCount += CreEffect.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create items
            creItems = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.itemsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.itemsCount; j++)
                {
                    currentCreItem = new CreItem(creByteArray, byteCount);
                    creItems.Add(currentCreItem);
                    byteCount += CreItem.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }
            
            // create itemslots
            creItemSlots = new CreItemSlots(creByteArray, byteCount);

            // MODDING OBJECTS
            creHeaderModded = creHeader;
            creKnownSpellsModded = creKnownSpells;
            creMemorizedSpellsInfosModded = creMemorizedSpellsInfos;
            creMemorizedSpellsModded = creMemorizedSpells;
            creEffectsModded = creEffects;
            creItemsModded = creItems;
            creItemSlotsModded = creItemSlots;
        }

        internal static void CreateTwodaObject()
        {
            String rawStr = FileOperations.ReadFileAsString(currentTwodaFileInfo.FullName);
            twodaFile = new TwodaFile(rawStr);
        }

        internal static void CreateDlgObjects()
        {
            // read file
            dlgByteArray = FileOperations.ReadFile(dlgInputPath + "/" + currentDlgFileInfo.Name);

            //generate header
            dlgHeader = new DlgHeader(dlgByteArray);

            int baseOffset = DlgHeader.size;

            // generate state tables
            dlgStateTables = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfStates; i++)
            {
                currentDlgStateTable = new DlgStateTable(dlgByteArray, baseOffset);
                dlgStateTables.Add(currentDlgStateTable);
                baseOffset += DlgStateTable.size;

                // currentStateTable.PrintValues();
            }


            // generate transition tables
            dlgTransitionTables = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfTransitions; i++)
            {
                currentDlgTransitionTable = new DlgTransitionTable(dlgByteArray, baseOffset);
                dlgTransitionTables.Add(currentDlgTransitionTable);
                baseOffset += DlgTransitionTable.size;

                // currentTransitionTable.PrintValues();
            }

            // generate state triggers
            dlgStateTriggers = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfStateTriggers; i++)
            {
                currentDlgStateTrigger = new DlgStateTrigger(dlgByteArray, baseOffset);
                dlgStateTriggers.Add(currentDlgStateTrigger);
                baseOffset += DlgStateTrigger.size;

                // currentStateTrigger.PrintValues();
            }

            // generate transition triggers
            dlgTransitionTriggers = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfTransitionTriggers; i++)
            {
                currentDlgTransitionTrigger = new DlgTransitionTrigger(dlgByteArray, baseOffset);
                dlgTransitionTriggers.Add(currentDlgTransitionTrigger);
                baseOffset += DlgTransitionTrigger.size;

                // currentTransitionTrigger.PrintValues();
            }

            // generate action tables
            dlgActionTables = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfActions; i++)
            {
                currentDlgActionTable = new DlgActionTable(dlgByteArray, baseOffset);
                dlgActionTables.Add(currentDlgActionTable);
                baseOffset += DlgActionTable.size;

                // currentAction.PrintValues();
            }

            // MODDING OBJECTS
            dlgHeaderModded = dlgHeader;
            dlgStateTablesModded = dlgStateTables;
            dlgTransitionTablesModded = dlgTransitionTables;
            dlgStateTriggersModded = dlgStateTriggers;
            dlgTransitionTriggersModded = dlgTransitionTriggers;
            dlgActionTablesModded = dlgActionTables;
        }

        internal static void CreateWmpObjects()
        {
            // read file
            wmpByteArray = FileOperations.ReadFile(wmpInputPath + "/" + currentWmpFileInfo.Name);
            
            // get header
            wmpHeader = new WmpHeader(wmpByteArray);

            // get world map entries
            wmpWorldMapEntries = new ArrayList();
            int offset = WmpHeader.size;
            for (int i = 0; i < wmpHeader.worldmapEntriesCount; i++)
            {
                currentWmpWorldMapEntry = new WmpWorldMapEntry(wmpByteArray, offset);
                wmpWorldMapEntries.Add(currentWmpWorldMapEntry);
                //currentWorldmapEntry.PrintValues();
                offset += WmpWorldMapEntry.size;
            }
            
            // get area entries
            wmpAreaEntries = new ArrayList();
            foreach (WmpWorldMapEntry worldmapEntry in wmpWorldMapEntries)
            {
                for (int i = 0; i < worldmapEntry.areaEntriesCount; i++)
                {
                    currentWmpAreaEntry = new WmpAreaEntry(wmpByteArray, offset);
                    wmpAreaEntries.Add(currentWmpAreaEntry);
                    //currentAreaEntry.PrintValues();
                    offset += WmpAreaEntry.size;
                }
            }
            
            // get area link entries
            wmpAreaLinkEntries = new ArrayList();
            foreach (WmpAreaEntry areaEntry in wmpAreaEntries)
            {
                int numberOfAreaLinkEntries = areaEntry.linkCountNorth + areaEntry.linkCountWest +
                                              areaEntry.linkCountSouth + areaEntry.linkCountEast;
                for (int i = 0; i < numberOfAreaLinkEntries; i++) // get number of area link entries
                {
                    currentWmpAreaLinkEntry = new WmpAreaLinkEntry(wmpByteArray, offset);
                    wmpAreaLinkEntries.Add(currentWmpAreaLinkEntry);
                    offset += WmpAreaLinkEntry.size;
                    //currentAreaLinkEntry.PrintValues();
                }
            }
            
            // MODDING OBJECTS
            wmpHeaderModded = wmpHeader;
            wmpWorldMapEntriesModded = wmpWorldMapEntries;
            wmpAreaEntriesModded = wmpAreaEntries;
            wmpAreaLinkEntriesModded = wmpAreaLinkEntries;
        }
        
        internal static void CreateStoObjects()
        {
            // read file
            stoByteArray = FileOperations.ReadFile(stoInputPath + "/" + currentStoFileInfo.Name);
            
            // get header
            stoHeader = new StoHeader(stoByteArray);
            // Console.WriteLine(currentStoFileInfo.Name + " " + stoHeader.curesForSaleOffset);
            // Console.WriteLine(currentStoFileInfo.Name + " " + stoHeader.curesForSaleCount);
            int offset = StoHeader.size;

            // get items for sale
            stoItemsForSale = new ArrayList();
            for (int i = 0; i < stoHeader.itemsForSaleCount; i++)
            {
                currentStoItemForSale = new StoItem(stoByteArray, offset);
                // Console.WriteLine(currentStoItemForSale.itmFileName);
                stoItemsForSale.Add(currentStoItemForSale);
                //currentWorldmapEntry.PrintValues();
                offset += StoItem.size;
            }

            // get drinks
            stoDrinks = new ArrayList();
            for (int i = 0; i < stoHeader.drinksForSaleCount; i++)
            {
                currentStoDrink = new StoDrink(stoByteArray, offset);
                stoDrinks.Add(currentStoDrink);
                // currentWorldmapEntry.PrintValues();
                offset += StoDrink.size;
            }
            
            // get cures
            stoCures = new ArrayList();
            for (int i = 0; i < stoHeader.curesForSaleCount; i++)
            {
                currentStoCure = new StoCure(stoByteArray, offset);
                stoCures.Add(currentStoCure);
                //currentWorldmapEntry.PrintValues();
                offset += StoCure.size;
            }
            
            // get items for purchase
            stoItemsPurchased = new ArrayList();
            for (int i = 0; i < stoHeader.itemsPurchasedCount; i++)
            {
                currentStoItemPurchased = BitConverter.ToInt32(stoByteArray, offset);
                // Console.WriteLine(currentStoItemPurchased);
                stoItemsPurchased.Add(currentStoItemPurchased);
                //currentWorldmapEntry.PrintValues();
                offset += 4;
            }

            // MODDING OBJECTS
            stoHeaderModded = stoHeader;
            stoItemsPurchasedModded = stoItemsPurchased;
            stoItemsForSaleModded = stoItemsForSale;
            stoDrinksModded = stoDrinks;
            stoCuresModded = stoCures;
        }

        internal static void StartPriorChecks()
        {
            // Regex regex  = new Regex("((SP|sp)(PR|pr|WI|wi|IN|in|CL|cl)[1-9][0-5][0-9]|BDPWEAPN|a7!smgl|A7!SMGL|A7!GLR(1[AB])|a7!glr(1[ab])?|amul25|SPDWD02|#PRAYER[GB]|QD_\\w{3}\\d{2}|a7!in\\d{2})\\.(SPL|spl)");
            // Regex regex  = new Regex(@"(SP|sp|BDPWEAPN|a7!smgl|A7!SMGL|A7!GLR|a7!glr|amul25|SPDWD02|#PRAYER|QD_).*\.(SPL|spl)");
            foreach (FileInfo spell in splsRaw)
            {
                
                if (Regex.IsMatch(spell.Name, @"(SP|sp|BDPWEAPN|a7!smgl|A7!SMGL|A7!GLR|a7!glr|amul25|SPDWD02|#PRAYER|QD_).*\.(SPL|spl)"))
                {
                    spells.Add(spell);
                }
            }
            // preceding validity check SPL
            foreach (FileInfo spell in spells)
            {
                if (FileOperations.CheckFilePath(splInputPath + "/" + spell)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // ITEMS
            foreach (FileInfo item in itmsRaw)
            {
                items.Add(item);
            }
            // preceding validity check ITM
            foreach (FileInfo item in items)
            {
                if (FileOperations.CheckFilePath(itmInputPath + "/" + item)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }

            // CRES
            foreach (FileInfo cre in cresRaw)
            {
                cres.Add(cre);
            }
            // preceding validity check ITM
            foreach (FileInfo cre in cres)
            {
                if (FileOperations.CheckFilePath(creInputPath + "/" + cre)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // DLGS
            // regex  = new Regex(@"(THALAN|JARED|ARKION|NEMPHR|TAEROM|X#DRIZZT|A7!SMDLG|A7!CMD|A7!CMD2|A7!CMD3|MH#PHEND|MH#BROKK|KORAX).(dlg|DLG)");
            foreach (FileInfo dlg in dlgsRaw)
            {
                // if (Regex.IsMatch(dlg.Name, @"(THALAN|JARED|ARKION|NEMPHR|TAEROM|X#DRIZZT|A7!SMDLG|A7!CMD|A7!CMD2|A7!CMD3|MH#PHEND|MH#BROKK|KORAX).(dlg|DLG)"))
                // {
                //     dlgs.Add(dlg);
                // }

                dlgs.Add(dlg);
            }

            // preceding validity check DLG
            foreach (FileInfo dlg in dlgs)
            {
                if (FileOperations.CheckFilePath(dlgInputDirectory + "/" + dlg)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // 2DA
            // regex = new Regex(@"(SPSD\d+|(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO).*)\.(2da|2DA)");
            foreach (FileInfo twoda in twodasRaw)
            {
                if (Regex.IsMatch(twoda.Name, @"(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO)(.*)\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
                else if (Regex.IsMatch(twoda.Name, @"(splshmkn|splsrckn|SPLSHMKN|SPLSRCKN)\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
                else if (Regex.IsMatch(twoda.Name, @"(MXSPL)(BRD|DD|DRU|PRS|SHM|SRC|WIZ|PAL|RAN)\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
                else if (Regex.IsMatch(twoda.Name, @"ITEM_USE\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
            }
            // preceding validity check 2DA
            foreach (FileInfo twoda in twodas)
            {
                if (FileOperations.CheckFilePath(dlgInputDirectory + "/" + twoda)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // IDS
            // regex = new Regex(@"(SPSD\d+|(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO).*)\.(2da|2DA)");
            foreach (FileInfo id in idsRaw)
            {
                ids.Add(id);
            }
            // preceding validity check 2DA
            foreach (FileInfo id in ids)
            {
                if (FileOperations.CheckFilePath(idsInputDirectory + "/" + id)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // IDS
            // regex = new Regex(@"(SPSD\d+|(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO).*)\.(2da|2DA)");
            foreach (FileInfo bcs in bcssRaw)
            {
                bcss.Add(bcs);
            }
            // preceding validity check 2DA
            foreach (FileInfo bcs in bcss)
            {
                if (FileOperations.CheckFilePath(idsInputDirectory + "/" + bcs)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // WMP
            foreach (FileInfo wmp in wmpsRaw)
            {
                wmps.Add(wmp);
            }
            // preceding validity check 2DA
            foreach (FileInfo wmp in wmps)
            {
                if (FileOperations.CheckFilePath(wmpInputDirectory + "/" + wmp)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // STO
            foreach (FileInfo sto in stosRaw)
            {
                stos.Add(sto);
            }
            // preceding validity check 2DA
            foreach (FileInfo sto in stos)
            {
                if (FileOperations.CheckFilePath(stoInputDirectory + "/" + sto)) // check validity of all input paths
                {
                    Console.WriteLine("As least one input file doesn't exist, cannot continue!");
                    return;
                }
            }
            
            // FileOperations.CheckBasePath(splOutputPath); // create dir if output base path doesn't exist  
            // FileOperations.CheckBasePath(splInputPath); // create dir if output base path doesn't exist  
        }

        internal static void CheckForPreModdedFile()
        {
            // Console.WriteLine(itmsModRaw.Length);
            // Console.WriteLine(cresModRaw.Length);
            if (null != currentItemFileInfo)
            {
                foreach (FileInfo itmMod in itmsModRaw)
                {
                    if (itmMod.Name.Equals(currentItemFileInfo.Name))
                    {
                        currentItemFileInfo = itmMod;
                    }
                }
            }

            if (null != currentCreFileInfo)
            {
                foreach (FileInfo creMod in cresModRaw)
                {
                    if (creMod.Name.Equals(currentCreFileInfo.Name))
                    {
                        currentCreFileInfo = creMod;
                    }
                }
            }
        }
        
        internal static void EditTlkExistingEntry(String identifier, String regex, String repl)
        {
            Boolean spellFound = false;
            Boolean regexFound = false;
            
            int tlkIndex = 0;
            int[] tlkNewOffsets = new int[tlkHeader.numberOfStrRefs];
            for (int i = 0; i < tlkEntries.Count; i++)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[i];

                Match match = Regex.Match(currentTlkEntry.textString, @"\A" + identifier, RegexOptions.Singleline);

                if (match.Success)
                {
                    // Console.WriteLine("Found spell...");
                    spellFound = true;
                    String oldString = currentTlkEntry.textString;
                    String newString = "";
                    int newOffsetDeltaNextEntry = 0;
                    MatchCollection matches = Regex.Matches(currentTlkEntry.textString, regex, RegexOptions.Singleline);
                    if (matches.Count != 0)
                    {
                        regexFound = true;
                        Console.WriteLine("Found regex pattern, patching...");

                        Boolean firstRun = true;
                        foreach (Match m in matches)
                        {
                            // Console.WriteLine("OLDTEXT:\n========\n" + m.Value + "\nNEWTEXT:\n========\n" + repl);
                            if (firstRun)
                            {
                                newString = oldString.Remove(m.Index, m.Length).Insert(m.Index, repl);
                            }
                            else
                            {
                                newString = newString.Remove(m.Index, m.Length).Insert(m.Index, repl);
                            }
                            firstRun = false;
                        }
                        
                        // error control: check if the old string length calculated via the string is different from the pre-set size within the byte file
                        // we need to make sure here, that the preset size takes precedence over the newly calculated length of the string via C#
                        //
                        int newLength = 0;
                        if (oldString.Length != currentTlkEntry.stringLength)
                        {
                            if (newString.Length < oldString.Length)
                            {
                                newLength = currentTlkEntry.stringLength - (oldString.Length - newString.Length);
                            }
                            else if (newString.Length > oldString.Length)
                            {
                                newLength = currentTlkEntry.stringLength + (newString.Length - oldString.Length);
                            }
                            else
                            {
                                newLength = currentTlkEntry.stringLength;
                            }
                        }
                        else
                        {
                            newLength = newString.Length;
                        }
                        currentTlkEntry.UpdateInstance(globalOffset, newLength, newString); // keep the offset for the current tlkEntry
                        newOffsetDeltaNextEntry += newString.Length - oldString.Length;
                        globalOffset += newOffsetDeltaNextEntry; // add the newOffset to the global to be used by later iterations
                    }
                    else // only use the globalOffset up to this point
                    {
                        currentTlkEntry.UpdateInstance(globalOffset);
                    }
                }
                else // only use the globalOffset up to this point
                {
                    currentTlkEntry.UpdateInstance(globalOffset);
                }
            }
            
            
            if (!spellFound || !regexFound)
            {
                Console.WriteLine("**** DEBUG RELEVANT: NOTHING FOUND ****");
            }

            globalOffset = 0; // reset offset for next run
        }
        
        internal static void CopyTwoDAs()
        {
            foreach (FileInfo twoda in twodasModRaw)
            {
                // copy to output dir
                FileOperations.WriteFile(twodaModPath + "/" + twoda, twodaOutputPath + "/" + twoda);
            }
        }
        
        internal static void CopyAndPatchItms()
        {
            Hashtable ht = new Hashtable();
            ht.Add("SCRL86.ITM", "Resist Elements");
            ht.Add("CDIA525.ITM", "Waves of Fatigue");
            ht.Add("CDIA432.ITM", "Jelly Conjuring");
            ht.Add("CDIA527.ITM", "Mind Fog");
            ht.Add("SCRL82.ITM", "Dimension Jump");
            ht.Add("SCRL5D.ITM", "Protection from Poison");
            ht.Add("SCRL5J.ITM", "Protection from Poison");
            ht.Add("SCRL67.ITM", "Magic Armor");
            
            foreach (FileInfo itm in itmsModRaw)
            {
                byte[] byteFile = FileOperations.ReadFile(itm.FullName);
                foreach (DictionaryEntry pair in ht)
                {
                    if (itm.Name.Equals(pair.Key))
                    {
                        Buffer.BlockCopy(BitConverter.GetBytes(FindFirstExactTlkEntry(pair.Value.ToString())), 0, byteFile, 12, 4);
                        Buffer.BlockCopy(BitConverter.GetBytes(FindFirstMatchingTlkEntry(pair.Value.ToString() + @"()?\n")), 0, byteFile, 84, 4);
                    }
                }
                FileOperations.WriteFile(itmOutputPath + "/" + itm.Name, byteFile);
            }
        }
        
        internal static void PatchAndCopyEffs()
        {
            foreach (FileInfo eff in effsModRaw)
            {
                effByteArray = FileOperations.ReadFile(effModPath + "/" + eff.Name);

                // fix allegiance in eff file
                Boolean found = nonControllable.Contains(eff.Name.Substring(0, 8).Replace(".", ""));
                // Console.WriteLine(eff.Name.Substring(0, 7));
                // Console.WriteLine(found);
                if (found)
                {
                    Buffer.BlockCopy(BitConverter.GetBytes(4), 0, effByteArray, 32, 4);
                }
                else
                {
                    Buffer.BlockCopy(BitConverter.GetBytes(0), 0, effByteArray, 32, 4);
                }
                
                FileOperations.WriteFile(effOutputPath + "/" + eff, effByteArray);
            }
        }

        internal static void CopyBams()
        {
            foreach (FileInfo bam in bamsModRaw)
            {
                // copy to output dir
                FileOperations.WriteFile(bamModPath + "/" + bam, bamOutputPath + "/" + bam);
            }
        }
        
        internal static void CopyMiscs()
        {
            foreach (FileInfo misc in miscsModRaw)
            {
                // copy to output dir
                FileOperations.WriteFile(miscModPath + "/" + misc, miscOutputPath + "/" + misc);
            }
        }
        
        internal static void PatchAndCopyCres()
        {
            String gbb1 = "Stinking Beetle";
            String gbb2 = "Battle Beetle";
            AddTlkEntry(gbb1);
            AddTlkEntry(gbb2);
            
            Hashtable ht = new Hashtable();
            ht.Add("MONSUM1A.CRE", "Gnoll Veteran");
            ht.Add("MONSUM1B.CRE", "Hobgoblin Scout");
            ht.Add("MONSUM1C.CRE", "Half Ogre");
            ht.Add("MONSUM1D.CRE", "Ogrillon");
            ht.Add("MONSUM2A.CRE", "Hobgoblin Elite");
            ht.Add("MONSUM2B.CRE", "Hobgoblin Captain");
            ht.Add("MONSUM2C.CRE", "Hobgoblin Marksman");
            ht.Add("MONSUM2D.CRE", "Hobgoblin Priest");
            ht.Add("MONSUM2E.CRE", "Hobgoblin Wizard");
            ht.Add("MONSUM2F.CRE", "Gnoll Captain");
            ht.Add("MONSUM2G.CRE", "Gnoll Chieftain");
            ht.Add("MONSUM2H.CRE", "Gnoll Slasher");
            ht.Add("MONSUM3A.CRE", "Ogre");
            ht.Add("MONSUM3B.CRE", "Half-Ogre Veteran");
            ht.Add("MONSUM3C.CRE", "Ogre Berserker");
            ht.Add("MONSUM3D.CRE", "Ogre Mage");
            ht.Add("MONSUM4A.CRE", "Ogre Mage");
            ht.Add("MONSUM4B.CRE", "Ogre Chieftain");
            ht.Add("MONSUM4C.CRE", "Ogre Shaman");
            ht.Add("MONSUM5A.CRE", "Greater Ghast");
            ht.Add("MONSUM5B.CRE", "Greater Ghoul");
            ht.Add("MONSUM5C.CRE", "Ghoul Lord");
            ht.Add("MONSUM5D.CRE", "Mummy");
            ht.Add("MONSUM5E.CRE", "Doppelganger");
            ht.Add("MONSUM5F.CRE", "Battle Horror");
            ht.Add("MONSUM5G.CRE", "Doom Guard");
            ht.Add("MONSUM6A.CRE", "Giant Troll");
            ht.Add("MONSUM6B.CRE", "Snow Troll");
            ht.Add("MONSUM6C.CRE", "Troll Shaman");
            ht.Add("MONSUM6D.CRE", "Fire Troll");
            ht.Add("MONSUM7A.CRE", "Greater Doppelganger");
            ht.Add("MONSUM7B.CRE", "Doomsayer");
            ht.Add("MONSUM7C.CRE", "Revenant");
            ht.Add("MONSUM7D.CRE", "Greater Mummy");
            ht.Add("SKELWARR.CRE", "Skeleton Warrior");
            ht.Add("SKELAR04.CRE", "Skeleton Archer");
            ht.Add("SKELAR06.CRE", "Skeleton Archer");
            ht.Add("SKELAR08.CRE", "Skeleton Archer");
            ht.Add("SKELAR10.CRE", "Skeleton Archer");
            ht.Add("ANISUM1A.CRE", "Dread Wolf");
            ht.Add("ANISUM1B.CRE", "Black Bear");
            ht.Add("ANISUM1C.CRE", "Jaguar");
            ht.Add("ANISUM1D.CRE", "Leopard");
            ht.Add("ANISUM2A.CRE", "Winter Wolf");
            ht.Add("ANISUM2B.CRE", "Old Boar");
            ht.Add("ANISUM2C.CRE", "Wild Tiger");
            ht.Add("ANISUM2D.CRE", "Brown Bear");
            ht.Add("ANISUM3A.CRE", "Polar Bear");
            ht.Add("ANISUM3B.CRE", "Stone Snake");
            ht.Add("ANISUM3C.CRE", "Cave Bear");
            ht.Add("ANISUM3D.CRE", "Panther");
            ht.Add("MNTNBEAR.CRE", "Mountain Bear");
            ht.Add("LESSERAE.CRE", "Lesser Air Elemental");
            ht.Add("LESSEREE.CRE", "Lesser Earth Elemental");
            ht.Add("LESSERFE.CRE", "Lesser Fire Elemental");
            ht.Add("LESSERWE.CRE", "Lesser Water Elemental");
            ht.Add("AELEM1.CRE", "Water Elemental");
            ht.Add("AELEM2.CRE", "Greater Water Elemental");
            ht.Add("AELEM3.CRE", "Elder Water Elemental");
            ht.Add("EELEM1.CRE", "Earth Elemental");
            ht.Add("EELEM2.CRE", "Greater Earth Elemental");
            ht.Add("EELEM3.CRE", "Elder Earth Elemental");
            ht.Add("FELEM1.CRE", "Fire Elemental");
            ht.Add("FELEM2.CRE", "Greater Fire Elemental");
            ht.Add("FELEM3.CRE", "Elder Fire Elemental");
            ht.Add("WELEM1.CRE", "Water Elemental");
            ht.Add("WELEM2.CRE", "Greater Water Elemental");
            ht.Add("WELEM3.CRE", "Elder Water Elemental");
            ht.Add("SPIDER1A.CRE", "Giant Spider");
            ht.Add("SPIDER2A.CRE", "Sword Spider");
            ht.Add("SPIDER2B.CRE", "Wraith Spider");
            ht.Add("SPIDER2C.CRE", "Phase Spider");
            ht.Add("SPIDER3A.CRE", "Vortex Spider");
            ht.Add("SPIDER3B.CRE", "Gargantuan Spider");
            ht.Add("SPIDER3C.CRE", "Astral Phase Spider");
            ht.Add("OTYUGH01.CRE", "Otyugh");
            ht.Add("OTYUGH02.CRE", "Greater Otyugh");
            ht.Add("OTYUGH03.CRE", "Neo-Otyugh");
            ht.Add("ISTALKER.CRE", "Invisible Stalker");
            ht.Add("ASHIRUKU.CRE", "Ashirukuru");
            ht.Add("HELMHORR.CRE", "Helmed Horror");
            ht.Add("NISHRUU.CRE", "Nishruu");
            ht.Add("WYVERNGR.CRE", "Greater Wyvern");
            ht.Add("WYVERNLE.CRE", "Wyvern");
            ht.Add("HAKESHAR.CRE", "Hakeashar");
            ht.Add("DEMONKNI.CRE", "Demon Knight");
            ht.Add("EFREETI.CRE", "Efreeti");
            ht.Add("BONEGUAR.CRE", "Boneguard");
            ht.Add("SLIME2A.CRE", "Ochre Jelly");
            ht.Add("SLIME2B.CRE", "Olive Jelly");
            ht.Add("SLIME3.CRE", "Mustard Jelly");
            ht.Add("SLIME4.CRE", "Fission Slime");
            ht.Add("TANARRI.CRE", "Tanar'ri");
            ht.Add("GLABREZU.CRE", "Glabrezu");
            ht.Add("PITFIEND.CRE", "Pit Fiend");
            ht.Add("BEETLE1B.CRE", "Bombardier Beetle");
            ht.Add("BEETLE1A.CRE", "Boring Beetle");
            ht.Add("BEETLE2B.CRE", gbb1);
            ht.Add("BEETLE2A.CRE", gbb2);

            Console.WriteLine("Patching cre files...");
            foreach (FileInfo cre in cresModRaw)
            {
                creByteArray = FileOperations.ReadFile(creModPath + "/" + cre.Name);

                // fix display name
                index = 0;
                foreach (DictionaryEntry pair in ht)
                {
                    if (cre.Name.Equals(pair.Key))
                    {
                        Console.WriteLine("Patching " + cre.Name + "...");
                        String creatureName1 = GetTlkStringFromStrRef(BitConverter.ToInt32(creByteArray, 8));
                        String creatureName2 = GetTlkStringFromStrRef(BitConverter.ToInt32(creByteArray, 12));
                        if (!creatureName1.Equals(pair.Value.ToString()) || !creatureName2.Equals(pair.Value.ToString()))
                        {
                            Console.WriteLine("Found incorrect cre name, patching...");
                            int correctedName = FindFirstExactTlkEntry(pair.Value.ToString());
                            byte[] correctedBytes = BitConverter.GetBytes(correctedName);
                            Buffer.BlockCopy(correctedBytes, 0, creByteArray, 8, 4);
                            Buffer.BlockCopy(correctedBytes, 0, creByteArray, 12, 4);
                        }
                        else
                        {
                            Console.WriteLine("Cre name correct, skipping...");
                        }
                    }
                }
                
                // fix script name
                int race = BitConverter.ToInt32(creByteArray, 626);
                
                String scriptName = Encoding.ASCII.GetString(creByteArray, 640, 32);
                Console.WriteLine(scriptName);
                if (!scriptName.Equals("fix_summons") && race != 121) // if not a demon
                {
                    Console.WriteLine("Found incorrect script name, patching...");
                    Buffer.BlockCopy(Encoding.ASCII.GetBytes("fix_summons" + new string(new char[21])), 0, creByteArray, 640, 32);
                }
                else
                {
                    Console.WriteLine("Script name correct, skipping...");
                }
                
                scriptName = Encoding.ASCII.GetString(creByteArray, 616, 8);
                Console.WriteLine(scriptName);
                if (!scriptName.Equals("wtasight") && race != 121)  // if not a demon
                {
                    Console.WriteLine("Found incorrect script name, patching...");
                    Buffer.BlockCopy(Encoding.ASCII.GetBytes("wtasight"), 0, creByteArray, 616, 8);
                }
                else
                {
                    Console.WriteLine("Script name correct, skipping...");
                }
                
                // fix xp value
                Buffer.BlockCopy(BitConverter.GetBytes(0), 0, creByteArray, 20, 4);
                Buffer.BlockCopy(BitConverter.GetBytes(0), 0, creByteArray, 24, 4);

                // fix gender
                Buffer.BlockCopy(BitConverter.GetBytes(6), 0, creByteArray, 275, 1);
                
                // fix no corpse
                Buffer.BlockCopy(BitConverter.GetBytes(GetBitfieldInt(new int[] {1})), 0, creByteArray, 16, 4);
                
                // fix allegiance in the cre file
                Boolean found = nonControllable.Contains(cre.Name.Substring(0, 8).Replace(".", ""));
                if (found)
                {
                    Buffer.BlockCopy(BitConverter.GetBytes(28), 0, creByteArray, 624, 1);
                }
                else
                {
                    Buffer.BlockCopy(BitConverter.GetBytes(128), 0, creByteArray, 624, 1);
                }

                // copy to output dir
                FileOperations.WriteFile(creOutputPath + "/" + cre, creByteArray);
            }
        }
        ///
        ///
        ///
        /// ////////////// ///
        /// ITEM FUNCTIONS ///
        /// ////////////// ///
        /// 
        /// 
        /// 
        internal static void SetItmPrice(int price)
        {
            itmHeaderModded.price = price;
        }

        internal static void SetItmIcon(String iconName)
        {
            int strLength = 8;
            int delta = strLength - iconName.Length;
            if (delta > 0)
            {
                itmHeaderModded.invIcon = iconName + new string(new char[delta]);
            }
            else
            {
                itmHeaderModded.invIcon = iconName;
            }
            foreach (ItmExtHeader itmExtHeader in itmExtHeadersModded)
            {
                if (delta > 0)
                {
                    itmExtHeader.useIcon = iconName + new string(new char[delta]);
                }
                else
                {
                    itmExtHeader.useIcon = iconName;
                }
            }
            // Console.WriteLine(iconName);
        }

        internal static void ModifyItmOpcode(short newOpcode)
        {
            currentItmFeatBlock.opcodeNumber = newOpcode;
        }
        
        internal static void ModifyItmParam1(byte param1)
        {
            currentItmFeatBlock.parameter1 = param1;
        }
        internal static void ModifyItmParam2(byte param2)
        {
            currentItmFeatBlock.parameter2 = param2;
        }

        internal static void RemoveItmEffect(int index)
        {
            itmEffFeatBlocksModded.RemoveAt(index);
            itmHeaderModded.effectsCount--;
            foreach (ItmExtHeader extHeader in itmExtHeadersModded)
            {
                extHeader.abilitiesIndex--;
            }
        }

        internal static void RemoveAllItmEffects()
        {
            itmEffFeatBlocksModded = new ArrayList();
            itmHeaderModded.effectsCount = 0;
            itmHeaderModded.abilitiesOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
            itmHeaderModded.effectsOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;

            foreach (ItmExtHeader extHeader in itmExtHeadersModded)
            {
                extHeader.abilitiesIndex = 0;
            }
        }
        
        internal static void RemoveItmAbility(int index)
        {
            itmAbilFeatBlocksModded.RemoveAt(index);

            int matchIndex = 0;
            for (int i = 0; i < itmExtHeadersModded.Count; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                for (int j = 0; j < currentItmExtHeader.abilitiesCount; j++)
                {
                    if (matchIndex == index)
                    {
                        currentItmExtHeader.abilitiesCount--;
                        itmExtHeadersModded[i] = currentItmExtHeader;
                        return;
                    }
                    matchIndex++;
                }
            }
        }
        
        internal static void RemoveAllItmExtHeadersAndItmAbilities()
        {
            itmExtHeadersModded = new ArrayList();
            itmAbilFeatBlocksModded = new ArrayList();
            itmHeaderModded.abilitiesCount = 0;
            itmHeaderModded.abilitiesOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
            itmHeaderModded.effectsOffset = ItmHeader.size + itmExtHeadersModded.Count * ItmExtHeader.size;
        }
        
        internal static void RemoveAllItmAbilities()
        {
            itmAbilFeatBlocksModded = new ArrayList();
            for (int i = 0; i < itmExtHeadersModded.Count; i++)
            {
                currentItmExtHeader = (ItmExtHeader) itmExtHeadersModded[i];
                currentItmExtHeader.abilitiesCount = 0;
            }
        }

        internal static void AddItmAbility(short opcode, byte target, byte power, int parameter1, int parameter2, byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource, int diceThrown, int diceSize, int saveType, int saveBonus, int special, int extHeaderIndex)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter2, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType, saveBonus, special);

            int abilityInsertPos = 0;
            for (int i = 0; i <= extHeaderIndex; i++)
            {
                currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[i];
                abilityInsertPos += currentItmExtHeader.abilitiesCount;
            }
            
            currentItmExtHeader = (ItmExtHeader)itmExtHeadersModded[extHeaderIndex];
            currentItmExtHeader.abilitiesCount++;
            
            itmAbilFeatBlocksModded.Insert(abilityInsertPos, newFeatBlock);
        }

        internal static void AddItmEffect(short opcode, byte target, byte power, int parameter1, int parameter2, byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource, int diceThrown, int diceSize, int saveType, int saveBonus, int special)
        {
            ItmFeatBlock newFeatBlock = new ItmFeatBlock(opcode, target, power, parameter1, parameter2, timingMode, resistance, duration, probability1, probability2, resource, diceThrown, diceSize, saveType, saveBonus, special);

            itmHeaderModded.effectsCount++;
            itmEffFeatBlocksModded.Add(newFeatBlock);
        }
        
        ///
        ///
        ///
        /// ////////////// ///
        /// CHAR FUNCTIONS ///
        /// ////////////// ///
        /// 
        /// 
        ///
        ///
        
        internal static void RemoveCreEffect(int index)
        {
            creEffectsModded.RemoveAt(index);
            creHeaderModded.effectsCount--;
            creHeaderModded.itemsOffset -= CreEffect.size;
            creHeaderModded.itemSlotsOffset -= CreEffect.size;
        }
        
        internal static void ModifyCreOpcode(short newOpcode)
        {
            currentCreEffect.opcode = newOpcode;
        }
        
        internal static void ModifyCreParam1(byte param1)
        {
            currentCreEffect.parameter1 = param1;
        }
        internal static void ModifyCreParam2(byte param2)
        {
            currentCreEffect.parameter2 = param2;
        }

        ///
        ///
        ///
        /// ////////////// ///
        /// DIALOG FUNCTIONS ///
        /// ////////////// ///
        /// 
        /// 
        ///
        ///
        
        internal static void GenerateDlgStringSection()
        {
            int byteSize = 0;
            foreach (DlgStateTrigger stateTrigger in dlgStateTriggersModded)
            {
                byteSize += stateTrigger.strLength;
            }
            foreach (DlgTransitionTrigger transitionTrigger in dlgTransitionTriggersModded)
            {
                byteSize += transitionTrigger.strLength;
            }
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                byteSize += actionTable.strLength;
            }
            
            dlgStringSectionModded = new byte[byteSize];
            int offset = 0;
            foreach (DlgStateTrigger stateTrigger in dlgStateTriggersModded)
            {
                System.Buffer.BlockCopy(stateTrigger.GetByteStringData(), 0, dlgStringSectionModded, offset,stateTrigger.strLength);
                offset += stateTrigger.strLength;
            }
            foreach (DlgTransitionTrigger transitionTrigger in dlgTransitionTriggersModded)
            {
                System.Buffer.BlockCopy(transitionTrigger.GetByteStringData(), 0, dlgStringSectionModded, offset,transitionTrigger.strLength);
                offset += transitionTrigger.strLength;
            }
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                System.Buffer.BlockCopy(actionTable.GetByteStringData(), 0, dlgStringSectionModded, offset,actionTable.strLength);
                offset += actionTable.strLength;
            }
        }

        // FIND/REPLACE ACTION TABLE
        internal static void ReplaceDlgActionTableString(String findRegexStr, String replStr)
        {
            int cumulativeDeltaNegative = 0;
            int cumulativeDeltaPositive = 0;
            
            Boolean isFirstMod = true;

            for (int i = 0; i < dlgActionTablesModded.Count; i++)
            {
                currentDlgActionTable = (DlgActionTable) dlgActionTablesModded[i];
                String oldText = currentDlgActionTable.str;
                int oldLength = currentDlgActionTable.strLength;
                int oldOffset = currentDlgActionTable.strOffset;
                int newOffset = oldOffset + cumulativeDeltaNegative + cumulativeDeltaPositive;
                int oldNewDelta = 0;

                if (Regex.IsMatch(oldText, findRegexStr))
                {
                    String newText = Regex.Replace(oldText, findRegexStr, replStr);

                    int newLength = newText.Length;
                    // Console.WriteLine(oldLength + "    " + newLength);
                    if (newLength < oldLength)
                    {
                        oldNewDelta = oldLength - newLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgActionTable.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgActionTable.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaNegative -= oldNewDelta;
                    }
                    else if (newLength > oldLength)
                    {
                        oldNewDelta = newLength - oldLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgActionTable.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgActionTable.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaPositive += oldNewDelta;
                    }
                    else // if old and new string have the same length
                    {
                        currentDlgActionTable.UpdateInstance(newOffset, newText);
                    }
                }
                else
                {
                    currentDlgActionTable.UpdateInstance(newOffset, oldText); // if there is no match only the offset needs to be updated  
                }
            }
        }

        internal static Boolean FindDlgActionTableString(String findRegexStr, int index)
        {
            currentDlgActionTable = (DlgActionTable) dlgActionTablesModded[index];
            if (Regex.IsMatch(currentDlgActionTable.str, findRegexStr))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // FIND/REPLACE TRANSITION TRIGGER
        
        internal static void ReplaceDlgTransitionTriggerString(String findRegexStr, String replStr)
        {
            int cumulativeDeltaNegative = 0;
            int cumulativeDeltaPositive = 0;
            
            Boolean isFirstMod = true;

            for (int i = 0; i < dlgTransitionTriggersModded.Count; i++)
            {
                currentDlgTransitionTrigger = (DlgTransitionTrigger) dlgTransitionTriggersModded[i];
                String oldText = currentDlgTransitionTrigger.str;
                int oldLength = currentDlgTransitionTrigger.strLength;
                int oldOffset = currentDlgTransitionTrigger.strOffset;
                int newOffset = oldOffset + cumulativeDeltaNegative + cumulativeDeltaPositive;
                int oldNewDelta = 0;

                if (Regex.IsMatch(oldText, findRegexStr))
                {
                    String newText = Regex.Replace(oldText, findRegexStr, replStr);

                    int newLength = newText.Length;
                    // Console.WriteLine(oldLength + "    " + newLength);
                    if (newLength < oldLength)
                    {
                        oldNewDelta = oldLength - newLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgTransitionTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaNegative -= oldNewDelta;
                    }
                    else if (newLength > oldLength)
                    {
                        oldNewDelta = newLength - oldLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgTransitionTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaPositive += oldNewDelta;
                    }
                    else // if old and new string have the same length
                    {
                        currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                    }
                }
                else
                {
                    currentDlgTransitionTrigger.UpdateInstance(newOffset, oldText); // if there is no match only the offset needs to be updated  
                }

                // dlgTransitionTriggersModded[i] = currentDlgTransitionTrigger;
            }
            
            // !!!!!!!!!!!!!!!!!
            // we also have to update the offsets for each of the action tables, because these come next in the file structure
            // !!!!!!!!!!!!!!!!!
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                actionTable.strOffset += cumulativeDeltaNegative + cumulativeDeltaPositive;
            }
        }
        
        internal static Boolean FindDlgTransitionTriggerString(String findRegexStr, int index)
        {
            currentDlgTransitionTrigger = (DlgTransitionTrigger) dlgTransitionTriggersModded[index];
            if (Regex.IsMatch(currentDlgTransitionTrigger.str, findRegexStr))
            {
                // Console.WriteLine(currentDlgFileInfo.Name + "    " + dlgTransitionTriggersModded.Count);
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // FIND/REPLACE State TRIGGER
        
        internal static void ReplaceDlgStateTriggerString(String findRegexStr, String replStr)
        {
            int cumulativeDeltaNegative = 0;
            int cumulativeDeltaPositive = 0;
            
            Boolean isFirstMod = true;

            for (int i = 0; i < dlgStateTriggersModded.Count; i++)
            {
                currentDlgStateTrigger = (DlgStateTrigger) dlgStateTriggersModded[i];
                String oldText = currentDlgStateTrigger.str;
                int oldLength = currentDlgStateTrigger.strLength;
                int oldOffset = currentDlgStateTrigger.strOffset;
                int newOffset = oldOffset + cumulativeDeltaNegative + cumulativeDeltaPositive;
                int oldNewDelta = 0;

                if (Regex.IsMatch(oldText, findRegexStr))
                {
                    String newText = Regex.Replace(oldText, findRegexStr, replStr);

                    int newLength = newText.Length;
                    // Console.WriteLine(oldLength + "    " + newLength);
                    if (newLength < oldLength)
                    {
                        oldNewDelta = oldLength - newLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgStateTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgStateTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaNegative -= oldNewDelta;
                    }
                    else if (newLength > oldLength)
                    {
                        oldNewDelta = newLength - oldLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgStateTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgStateTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaPositive += oldNewDelta;
                    }
                    else // if old and new string have the same length
                    {
                        currentDlgStateTrigger.UpdateInstance(newOffset, newText);
                    }
                }
                else
                {
                    currentDlgStateTrigger.UpdateInstance(newOffset, oldText); // if there is no match only the offset needs to be updated  
                }

                // dlgStateTriggersModded[i] = currentDlgStateTrigger;
            }
            
            // !!!!!!!!!!!!!!!!!
            // we also have to update the offsets for each of the action tables, because these come next in the file structure
            // !!!!!!!!!!!!!!!!!
            foreach (DlgTransitionTrigger transitionTrigger in dlgTransitionTriggersModded)
            {
                transitionTrigger.strOffset += cumulativeDeltaNegative + cumulativeDeltaPositive;
            }
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                actionTable.strOffset += cumulativeDeltaNegative + cumulativeDeltaPositive;
            }
        }
        
        internal static Boolean FindDlgStateTriggerString(String findRegexStr, int index)
        {
            currentDlgStateTrigger = (DlgStateTrigger) dlgStateTriggersModded[index];
            if (Regex.IsMatch(currentDlgStateTrigger.str, findRegexStr))
            {
                // Console.WriteLine(currentDlgFileInfo.Name + "    " + dlgStateTriggersModded.Count);
                return true;
            }
            else
            {
                return false;
            }
        }

        ///
        ///
        ///
        /// ////////////// ///
        /// 2DA FUNCTIONS ///
        /// ////////////// ///
        /// 
        /// 
        ///
        
        internal static void IncreaseSpells(String regexStr, int xSpells)
        {
            // *********************************************************
            // +x spells for class x
            // *********************************************************

            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.isContent)
                {
                    MatchCollection singleSpellMatches = Regex.Matches(currentLine.content, @"(?<=\d+( |\t)+)\d+(?=(\d+|\n|\r|$| |\t))", RegexOptions.Multiline);
                    int offset = 0;
                    String newRow = currentLine.content;
                    foreach (Match sm in singleSpellMatches)
                    {
                        int oldNum = Int32.Parse(sm.Value);
                        if (oldNum != 0)
                        {
                            int newNum = oldNum + xSpells;
                            // String newRow = r.Value.Remove(sm.Index, sm.Length).Insert(sm.Index, (Int32.Parse(sm.Value) * 2).ToString());
                            newRow = newRow.Remove(sm.Index + offset, sm.Length)
                                .Insert(sm.Index + offset, newNum.ToString());
                            if (oldNum.ToString().Length < newNum.ToString().Length)
                            {
                                offset += newNum.ToString().Length - oldNum.ToString().Length;
                            }
                        }
                    }
                    twodaFile.UpdateLine(newRow, i);
                }
            }
        }
        
        internal static void DoubleInnateAbilities(String regexStr)
        {
            ArrayList newLines = new ArrayList();
            
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.isContent)
                {
                    String newContent = "";
                    if (Regex.Match(currentLine.content, @"(?<= )GA_.*?(?= )", RegexOptions.Multiline).Success) // if we find a general ability in the line
                    {
                        newContent = currentLine.content;
                        MatchCollection mc = Regex.Matches(currentLine.content, "(?<= )AP_.*?(?= )", RegexOptions.Multiline);
                        if (mc.Count > 0)
                        {
                            foreach (Match m in mc)
                            {
                                newContent = currentLine.content.Replace(m.Value, "****      ");
                            }
                        }

                        newLines.Add(new TwodaLine(currentLine.index, true, newContent));
                    }
                }
            }

            foreach (TwodaLine newLine in newLines)
            {
                twodaFile.AddLine(newLine);
            }
        }

        internal static void RemoveLine(String pattern)
        {
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.content.Contains(pattern))
                {
                    twodaFile.twodaLines.RemoveAt(i);
                }
            }
            twodaFile.UpdateRawContent();
        }
        
        // MISC FUNCTIONS
    
        internal static int FindInSmTables(String findStr)
        {
            // Console.WriteLine(twodaInputDirectory.FullName + "/SMTABLES.2DA");
            String file = FileOperations.ReadFileAsString(twodaInputDirectory.FullName + "/SMTABLES.2DA");
            MatchCollection lines = Regex.Matches(file, @"^.*$", RegexOptions.Multiline);
            foreach (Match line in lines)
            {
                if (Regex.Match(line.Value, findStr, RegexOptions.Multiline).Success)
                {
                    // Console.WriteLine(line.Value);
                    Match num = Regex.Match(line.Value, @"(?<=^)\d+(?=_)", RegexOptions.Multiline);
                    return Int32.Parse(num.Value);
                }
            }

            return 0;
        }

        internal static void CopyAllFiles(String src, String dest)
        {
            DirectoryInfo srcDir = new DirectoryInfo(src);
            FileInfo[] srcItems = srcDir.GetFiles();
            foreach (FileInfo srcItem in srcItems)
            {
                File.Copy(srcItem.FullName, dest + "/" + srcItem.Name, true);
            }
        }
    }
}