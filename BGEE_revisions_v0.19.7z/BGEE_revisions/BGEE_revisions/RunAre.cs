﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunAre()
        {
            // Console.WriteLine(currentAreFileInfo.Name + " " + areHeader.numberOfProjectileTraps + " " + areHeader.offsetProjectileTraps);
            // if (currentAreFileInfo.Name.Contains("BG2600"))
            // {
            //     Console.WriteLine(areHeader.numberOfAutomapNotes);
            //     foreach (AreActor c in areActors)
            //     {
            //         Console.WriteLine(c.name);
            //         Console.WriteLine(c.animation);
            //     }
            // }
            
            // if (currentAreFileInfo.Name.Contains("BG2700"))
            // {
            //     Console.WriteLine(areHeader.numberOfAutomapNotes);
            //     foreach (AreActor c in areActors)
            //     {
            //         Console.WriteLine(c.name);
            //         Console.WriteLine(c.appearanceSchedule);
            //         if (c.appearanceSchedule != -1)
            //         {
            //             Console.WriteLine("got here");
            //         }
            //     }
            // }
            
            // correct empty items in containers (NULL.itm, RNDTRS.ITM... etc...)
            foreach (AreItem areItem in areItemsModded)
            {
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(areItem))) // if the item file doe not exist in the source path, we can assume this item does not exists
                {
                    areItem.resource = "MISC07" + new string(new char[2]);
                    areItem.quantity1 = 100;
                    areItem.quantity2 = 0;
                    areItem.quantity3 = 0;
                    areItem.flags = GetBitfieldInt(new int[] {0});
                    
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }
            
            // make all creatures spawn/be available at all day and night times
            foreach (AreActor areActor in areActorsModded)
            {
                if (areActor.appearanceSchedule != -1)
                {
                    // Console.WriteLine(currentAreFileInfo.Name + " : " + currentAreActor.name);
                    areActor.appearanceSchedule = -1;
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }

            // equalize wand charges for all areas (see item mod for wands)
            foreach (AreItem areItem in areItemsModded)
            {
                String fileName = GetItemFileName(areItem);
                CreateItmObjects(fileName);
                if (itmHeaderModded.itemType == 35) // if it's a wand
                {
                    if (areItem.quantity1 > 0)
                    {
                        areItem.quantity1 = 10;
                    }

                    if (areItem.quantity2 > 0)
                    {
                        areItem.quantity2 = 10;
                    }

                    if (areItem.quantity3 > 0)
                    {
                        areItem.quantity3 = 10;
                    }

                    // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                    if (fileName.Contains("WAND06."))
                    {
                        areItem.quantity1 = 10;
                        areItem.quantity2 = 10;
                    }
                    
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }
        }
    }
}