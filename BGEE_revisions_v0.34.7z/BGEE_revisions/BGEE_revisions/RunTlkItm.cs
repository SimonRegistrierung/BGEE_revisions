﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlkItm()
        {
            // WAND OF MONSTER SUMMONING
            identifiers = new String[]{
                "This wand will summon 12 HD of monsters"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "This wand will summon 2d2 monsters of different kinds. Each time the wand is used, there is a chance of conjuring either level I, II or III monsters, corresponding to the Monster Summoning I, II and III spells:\n\n- 50% chance of getting level I monsters\n- 35% chance of getting level II monsters\n- 15% chance of getting level III monsters\n\nThe monsters appear within the area of effect and attack the user's enemies. They remain until the spell duration expires or the monsters are slain. These creatures vanish when slain. If no opponent exists to fight and the wizard can communicate with them, the summoned monsters can perform other services for the summoning wizard.\n\nSTATISTICS:\n\nCharge abilities:\n- Summon level I, II or III monsters\n  Range: 20 ft.\n  Duration: 1 hour\n\nRequires:\n 9 Intelligence\n\nWeight: 1", true, false);
            }
            
            // WAND OF MAGIC MISSILES
            identifiers = new String[]{
                "When activated, the wand will eject a missile of magical energy"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "When activated, the wand will eject 5 magic missiles. The target creature must be seen or otherwise detected to be hit, however, so near-total concealment, such as that offered by arrow slits, can render the spell ineffective. The missiles will inflict 5x(1d4+1) total points of damage.\n\nSTATISTICS:\n\nCharge abilities:\n- 5 magic missiles will strike the target\n  Damage: 5x(1d4+1) magic damage\n  Range: 100 ft.\n  Area of Effect: 1 creature\n\nRequires:\n 9 Intelligence\n\nWeight: 1", true, false);
            }
            
            // POTION OF CLAIRVOYANCE
            identifiers = new String[]{
                "Upon drinking this potion, the user will see in <PRO_HISHER> mind a bird's eye view of the surrounding terrain.*"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "Upon drinking this potion, the user will be granted an unnatural perception of things to come. The user receives instantaneous warnings of impending danger or harm. He becomes impossible to surprise and cannot be backstabbed. In addition, the spell gives a general idea of what action might be taken to best protect oneself, granting a +2 insight bonus to AC and saves vs. breath. The effect lasts for 10 turns or until dispelled.\n\nSTATISTICS:\n\nUser gains Clairvoyance\nDuration: 6 hours\n\nWeight: 1", true, false);
            }
            
            // POTION OF INFRAVISION
            identifiers = new String[]{
                "This potion will grant the person drinking it the ability to see in the infrared spectrum.*"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "This potion will grant the person drinking it exceptional visual abilities. It instantly cures blindness and immunizes against any blindness effects. Furthermore, the imbiber will be able to see in the infrared spectrum up to 120 feet. The effects of the potion will last for 4 hours or until dispelled.\n\nSTATISTICS:\n\nSpecial: Infravision\nCures/innoculates against Blindness\nDuration: 4 hours\n\nWeight: 1", true, false);
            }
            
            // POTION OF MIRRORED EYES
            identifiers = new String[]{
                "This potion will protect the drinker from all gaze attacks.*"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    "10 rounds", 
                    "6 hours", true, false);
            }
            
            // POTIONS OF ELEMENTAL RESISTANCE
            identifiers = new String[]{
                "This potion will imbue the person drinking it with 50% resistance"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                EditExistingTlkEntry(identifier, 
                    "50%", 
                    "75%", false, false);
            }   
            
            // change various infravision items to also protect against blindness (NOTE: DOES NOT CURE BLINDNESS!)
            identifiers = new String[]{
                "Special ability: 60' infravision",
                "Infravision 60'",
                "Infravision up to 120 ft."
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");

                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "Infravision, protection against blindness", false, false);
            }
            
            // WAND OF FIRE
            identifiers = new String[]{
                "The wand will cough forth a huge, burning ball of fire that streaks out to the desired.*"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "The wand will cough forth a huge, burning ball of fire that streaks out to the desired range (to a maximum of 90 ft.) and bursts in a fiery, violent blast, just like the Fireball spell. The Fireball inflicts 6d6 points of damage, but all 1s rolled are counted as 2s. The victim(s) may make a Save vs. Wand in order to take only half damage. The second ability of the wand is akin to the spell Agannazar's Scorcher in that a column of flame will streak toward the victim inflicting 3d6 damage.\n\nSTATISTICS:\n\nCharge abilities:\n-  Fireball\n  Damage: 6d6 fire (Save vs. Wand for half)\n  Range: 90 ft.\n  Area of Effect: 15-ft. radius\n\n -  Agannazar's Scorcher\n  Damage: 3d6 fire\n  Range: 40 ft.\n  Area of Effect: 2-ft. by 40-ft. jet\n\nRequires:\n 9 Intelligence\n\nWeight: 1", true, false);
            }
            
            // WAND OF FROST
            identifiers = new String[]{
                "A wand of frost acts in a similar fashion to the Cone of Cold spell..*"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "A wand of frost acts in a similar fashion to the Cone of Cold spell. Crystallized particles of snow and ice fan out from the wand's tip, defining an area wherein the temperature drops to -100 degrees F. Like all wands, the wand of frost can only be used a limited number of times before it melts into a harmless pool of water. The second ability of the wand is akin to the spell Ray of Frost (albeit a significantly weaker one) in that a column of ice will streak toward the victim inflicting 4d6 damage.\n\nSTATISTICS:\n\nCharge abilities:\n-  Cone of Cold\n  Damage: 8d6 cold (Save vs. Wand for half)\n  Range: 100 ft.\n  Area of Effect: 17-ft. cone with 90-deg. arc\n\n -  Minor Ray of Frost\n  Damage: 4d6 cold\n  Range: 40 ft.\n  Area of Effect: 2-ft. by 40-ft. jet\n\nRequires:\n 9 Intelligence\n\nWeight: 1", true, false);
            }
            
            // DRUIDS RING
            identifiers = new String[]{
                "Ring of Animal Friendship: Druid's Ring"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    @"Charm animal \(Save vs\. Wand negates\)", 
                    "Summon Animals I", false, false);
                
                EditExistingTlkEntry(identifier, 
                    "Duration: 2 hours", 
                    "Duration: 1 hour", false, false);
                
                EditExistingTlkEntry(identifier, 
                    "Area of Effect: 1 animal", 
                    "\nEquipped abilities:\n  Can memorize one extra 1st and 2nd level druid spell", false, false);
            }
            
            // WHITE OAK SHIELD NAME CHANGE
            identifiers = new String[]{
                "Great Shield - White Oak"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "White Oak Shield", true, true);
            }
            
            // MISC ITEMS OF SPEED
            identifiers = new String[]{
                "Doubles movement rate",
                @"Movement rate: \+2"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "Movement rate & attacks per round set to 150%", false, false);
            }
            
            identifiers = new String[]{
                "Charge abilities:\n.*?Improved Haste \\(once per.*"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    identifier, 
                    "", false, false);
                
                // Console.WriteLine(GetTlkStringFromStrRef(FindFirstMatchingTlkEntry("Amulet of Cheetah Speed\n")));
            }
            
            // GENERIC PROTECTION SCROLLS DESCRIPTIONS
            identifiers = new String[]{
                "A Protection From (Acid|Cold|Electricity|Fire|Poison|Undead|Petrification) scroll offers.*"
            };
            foreach (String identifier in identifiers)
            {
                Console.WriteLine("=== \tWorking on\t" + identifier + "\t ===");
            
                EditExistingTlkEntry(identifier, 
                    @"Area of Effect: 1 creature", 
                    "Area of Effect: 30-ft. radius", false, false);
                
                EditExistingTlkEntry(identifier, 
                    @"Target is", 
                    "Targets are", false, false);
                
                EditExistingTlkEntry(identifier, 
                    @"Renders the target", 
                    "Renders the targets", false, false);
                
                EditExistingTlkEntry(identifier, 
                    @"affecting the target", 
                    "affecting the targets", false, false);
                
                EditExistingTlkEntry(identifier, 
                    @"Target receives", 
                    "Targets receive", false, false);

                // Console.WriteLine(GetTlkStringFromStrRef(FindFirstMatchingTlkEntry("Amulet of Cheetah Speed\n")));
            }
        }
    }
}