﻿using System;
using System.Collections;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunSto()
        {
            // if (currentStoFileInfo.Name.Contains("INN2616"))
            // {
            //     foreach (StoDrink item in stoDrinks)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.drinkName);
            //     }
            //     
            //     foreach (StoCure item in stoCures)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.splResource);
            //     }
            //     
            //     foreach (StoItem item in stoItemsForSale)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.itmFileName);
            //     }
            //     
            //     foreach (int item in stoItemsPurchasedModded)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item);
            //     }
            // }

            // adjust container sizes
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Ammo Belt"))
            {
                stoHeaderModded.capacity = 1000;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Gem Bag"))
            {
                stoHeaderModded.capacity = 75;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Scroll Case"))
            {
                stoHeaderModded.capacity = 150;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Potion Case"))
            {
                stoHeaderModded.capacity = 125;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Holding"))
            {
                stoHeaderModded.capacity = 250;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // correct wrong string in keyring stores
            if (ContainsCaseInsensitive(currentStoFileInfo.Name, "KEYR"))
            {
                // Console.WriteLine(currentStoFileInfo.Name);
                stoHeaderModded.capacity = 50;
                stoHeaderModded.name = FindExactTlkEntry("Key ring");
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wand Case") ||
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wandcase")
            )
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // remove all items from all containers
            if (stoHeaderModded.type == 5) // if it's a container
            {
                stoHeaderModded.itemsForSaleCount = 0;
                stoHeaderModded.itemsForSaleOffset = 156;
                stoHeaderModded.drinksForSaleCount = 0;
                stoHeaderModded.drinksForSaleOffset = 156;
                stoHeaderModded.curesForSaleCount = 0;
                stoHeaderModded.curesForSaleOffset = 156;
                stoItemsForSaleModded = new ArrayList();
                stoDrinksModded = new ArrayList();
                stoCuresModded = new ArrayList();
                
                // change the offset for the items purchased by the store
                stoHeaderModded.itemsPurchasedOffset = 156;

                // Console.WriteLine(StoHeader.size);
                // Console.WriteLine(stoItemsForSaleModded.Count * StoItem.size);
                // Console.WriteLine(stoDrinksModded.Count * StoDrink.size);
                // Console.WriteLine(stoCuresModded.Count * StoCure.size);
                // Console.WriteLine(stoItemsPurchased.Count * 4);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // equalize prizes of all stores (prevent stealing exploit)
            if (
                stoHeaderModded.type == 0 ||
                stoHeaderModded.type == 1 ||
                stoHeaderModded.type == 2 ||
                stoHeaderModded.type == 3
            ) // if it's a store
            {
                stoHeaderModded.sellPriceMarkup = 150;
                stoHeaderModded.buyPriceMarkup = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                stoHeaderModded.type == 0 ||
                stoHeaderModded.type == 1 ||
                stoHeaderModded.type == 2 ||
                stoHeaderModded.type == 3
            ) // if it's a store
            {
                stoHeaderModded.flags = ModExistingBitfield(stoHeaderModded.flags, new int[] {3}, false);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                    stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            ////
            ///
            // correct empty items in containers (NULL.itm, RNDTRS.ITM... etc...)
            Random rnd = new Random();
            foreach (StoItem stoItem in stoItemsForSaleModded)
            {
                // CORRECT NON-EXISTING ITEMS
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(stoItem))) // if the item file doe not exist in the source path, we can assume this item does not exist
                {
                    String newItem = "OHDWAND1"; // WAND OF GLITTERDUST
                    Console.WriteLine("Found non-existing item \"" + stoItem.itmFileName + "\" in \"" + currentStoFileInfo.Name + "\"");
                    
                    stoItem.itmFileName = newItem;
                    stoItem.quantity1 = 1;
                    stoItem.quantity2 = 0;
                    stoItem.quantity3 = 0;
                    stoItem.flags = GetBitfieldInt(new int[] {0});
                    
                    Console.WriteLine("replacing with \"" + newItem + "\"");

                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }

                // OTHER ITEM CHARGE CHANGES
                if (stoItem.itmFileName.Contains("CLCK07")) // cloak of the nymph
                {
                    stoItem.quantity1 = 1;
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            
                // equalize wand charges for all stores (see item mod for wands)
                String fileName = GetItemFileName(stoItem);
                CreateItmObjects(fileName);
                if (itmHeaderModded.itemType == 35) // if it's a wand
                {
                    if (stoItem.quantity1 > 0)
                    {
                        stoItem.quantity1 = 10;
                    }

                    if (stoItem.quantity2 > 0)
                    {
                        stoItem.quantity2 = 10;
                    }

                    if (stoItem.quantity3 > 0)
                    {
                        stoItem.quantity3 = 10;
                    }

                    // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                    if (fileName.Contains("WAND06."))
                    {
                        stoItem.quantity1 = 10;
                        stoItem.quantity2 = 10;
                    }
                    
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            }
        }
    }
}