﻿using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static String[] nonControllable =
        {
            "DEMONKNI",
            "TANARRI",
            "GLABREZU",
            "PITFIEND"
        };
        
        ///
        ///
        ///
        ///  MULTI_PURPOSE FUNCTIONS
        ///
        ///
        ///

        internal static Boolean ContainsCaseInsensitive(String srcStr, String findStr)
        {
            if (findStr.Contains("."))
            {
                findStr = findStr.Replace(".", @"\.");
            }
            return Regex.IsMatch(srcStr, findStr, RegexOptions.IgnoreCase);
        }
        internal static Boolean EqualsCaseInsensitive(String srcStr, String findStr)
        {
            if (findStr.Contains("."))
            {
                findStr = findStr.Replace(".", @"\.");
            }
            return Regex.IsMatch(srcStr, "^" + findStr + "$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
        }

        internal static Boolean CheckBitfieldValue(int bitField, int bitNum)
        {
            BitArray bitArray = new BitArray(new int[] {bitField});

            if (bitArray[bitNum])
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        internal static int GetBitfieldInt(int[] pos)
        {
            BitArray bitArray = new BitArray(32, false);

            foreach (int p in pos)
            {
                bitArray[p] = true;
            }

            byte[] newByte = new byte[4];
                            
            bitArray.CopyTo(newByte, 0);

            return BitConverter.ToInt32(newByte, 0);
        }
        
        internal static short GetBitfieldShort(int[] pos)
        {
            BitArray bitArray = new BitArray(16, false);

            foreach (int p in pos)
            {
                bitArray[p] = true;
            }

            byte[] newByte = new byte[2];
                            
            bitArray.CopyTo(newByte, 0);

            return BitConverter.ToInt16(newByte, 0);
        }
        
        internal static byte GetBitfieldByte(int[] pos)
        {
            BitArray bitArray = new BitArray(8, false);

            for (int i = 0 ; i < 8; i++)
            {
                if (pos.Contains(i))
                {
                    bitArray[i] = true;
                }
            }

            byte[] newByte = new byte[1];
                            
            bitArray.CopyTo(newByte, 0);

            return newByte[0];
        }
        
        internal static int ModExistingBitfield(int bitField, int[] pos, Boolean setTo)
        {
            BitArray bitArray = new BitArray(new int[] {bitField});
            
            foreach (int p in pos)
            {
                bitArray[p] = setTo;
            }
            
            byte[] newByte = new byte[4];
                            
            bitArray.CopyTo(newByte, 0);

            return BitConverter.ToInt32(newByte, 0);
        }
        
        internal static byte ModExistingBitfield(byte bitField, int[] pos, Boolean setTo)
        {
            BitArray bitArray = new BitArray(new byte[] {bitField});
            
            foreach (int p in pos)
            {
                bitArray[p] = setTo;
            }

            byte[] newByte = new byte[1];
            bitArray.CopyTo(newByte, 0);
            return newByte[0];
        }

        internal static String GetItemFileName(AreItem areItem)
        {
            return areItem.resource.Replace("\u0000", "") + ".ITM";
        }
        
        internal static String GetItemFileName(CreItem creItem)
        {
            return creItem.resource.Replace("\u0000", "") + ".ITM";
        }
        
        internal static String GetItemFileName(StoItem stoItem)
        {
            return stoItem.itmFileName.Replace("\u0000", "") + ".ITM";
        }
        
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        /////////////// CREATE OBJECTS ///////////////
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        internal static void CreateTlkObjects()
        {
            // preceding validity check TLK
            if (!FileOperations.CheckFilePath(tlkInputPath)) // check validity
            {
                Console.WriteLine("TLK file does not exist, cannot continue!");
                return;
            }
            
            // TLK run logic
            // -----------------------------------
            
            tlkByteArray = FileOperations.ReadFile(tlkInputPath);
            tlkHeader = new TlkHeader(tlkByteArray);
            
            // tlkHeader.PrintValues();

            tlkEntries = new ArrayList();
            
            // 1. find the number of tlkEntries (weirdly, this has not been predesigned in the tlk file)
            int baseOffset = TlkHeader.size;
            int stringSectionBegin = tlkHeader.offsetToStringData;
            // Console.WriteLine(tlkHeader.numberOfStrRefs);
            int previousStringLengths = 0;
            for (int i = 0; i < tlkHeader.numberOfStrRefs; i++)
            {
                currentTlkEntry = new TlkEntry(tlkByteArray, baseOffset); // size of each tlkEntry is 26 bytes
                
                // Console.WriteLine(currentTlkEntry.offsetToString);
                // Console.WriteLine(currentTlkEntry.stringLength);
                // Console.WriteLine(i);
                
                if (currentTlkEntry.bitField >= 0 && currentTlkEntry.bitField <= 15 )
                {
                    // Console.WriteLine(i);
                    tlkEntries.Add(currentTlkEntry);
                    currentTlkEntry.GetStringData(tlkByteArray, stringSectionBegin + previousStringLengths);
                    previousStringLengths += currentTlkEntry.stringLength;

                    if (i == 228635)
                    {
                        Console.WriteLine(currentTlkEntry.textString);
                    }
                }
                else
                {
                    stringSectionBegin = previousStringLengths;
                    break;
                }
                
                // Console.WriteLine(stringSectionBegin);
                baseOffset += TlkEntry.size;
            }
            
            // Console.WriteLine(tlkEntries.Count);

            // -----------------------------
        }

        internal static SplHeader ChangeTlkName(SplHeader splHeader, String namePattern, String descPattern)
        {
            Boolean nameFound = false;
            Boolean descFound = false;
            Regex regexName = new Regex(@"\A" + namePattern + @"\Z");
            Regex regexDesc = new Regex(descPattern);
            Match matchName;
            Match matchDesc;
            int tlkCounter = 0;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                if (regexName.IsMatch(tlkEntry.textString))
                {
                    matchName = regexName.Match(tlkEntry.textString);
                    nameFound = true;
                    splHeader.spellNameUnId = tlkCounter;
                    // Console.WriteLine(tlkEntry.textString);
                    Console.WriteLine("found and changed tlk name: " + tlkEntry.textString);
                }
                if (regexDesc.IsMatch(tlkEntry.textString))
                {
                    matchDesc = regexDesc.Match(tlkEntry.textString);
                    descFound = true;
                    splHeader.spellDescriptionUnId = tlkCounter;
                    Console.WriteLine("found and changed tlk desc: " + tlkEntry.textString);
                }
                
                tlkCounter++;
            }

            return splHeader;
        }

        internal static void CreateSplObjects()
        {
            // Console.WriteLine("Working on file " + spell);
            splByteArray = FileOperations.ReadFile(currentSpellFileInfo.FullName);

            // create header
            splHeader = new SplHeader(splByteArray);
            
            // GET CURRENT SPELL NAME
            if (splHeader.spellNameUnId > 0 && splHeader.spellNameUnId <= tlkEntries.Count - 1)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[splHeader.spellNameUnId];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create extended headers
            offset = splHeader.extendedHeaderOffset;
            splExtHeaders = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < splHeader.extendedHeaderCount; i++)
                {
                    // Console.WriteLine(path + "/" + spell + ":" + splByteArray.Length + " " + byteCount);
                    currentSplExtendedHeader = new SplExtendedHeader(splByteArray, offset);
                    splExtHeaders.Add(currentSplExtendedHeader);
                    offset += SplExtendedHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create casting feature blocks
            splCastFeatBlocks = new ArrayList();
            if (splHeader.castingFeatureBlockCount > 0)
            {
                for (int j = 0; j < splHeader.castingFeatureBlockCount; j++)
                {
                    currentSplCastFeatBlock = new SplFeatureBlock(splByteArray, offset);
                    splCastFeatBlocks.Add(currentSplCastFeatBlock);
                    offset += SplFeatureBlock.size; // increase offset by the size of the casting feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks
            splFeatBlocks = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                // currentSplExtendedHeader = (SplExtendedHeader) splExtHeaders[0];
                // offset = currentSplExtendedHeader.featureBlockIndex;
                foreach (SplExtendedHeader extendedHeader in splExtHeaders)
                {
                    for (int k = 0; k < extendedHeader.featureBlockCount; k++)
                    {
                        currentSplFeatBlock = new SplFeatureBlock(splByteArray, offset);
                        splFeatBlocks.Add(currentSplFeatBlock);
                        offset += SplFeatureBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }

            // modding objects
            splHeaderModded = splHeader;
            splExtHeadersModded = splExtHeaders;
            splCastFeatBlocksModded = splCastFeatBlocks;
            splFeatBlocksModded = splFeatBlocks;
        }
        internal static void CreateSplObjects(String spell)
        {
            // Console.WriteLine("Working on file " + spell);
            splByteArray = FileOperations.ReadFile(splInputDirectory + "/" + spell);

            // create header
            splHeader = new SplHeader(splByteArray);
            
            // GET CURRENT SPELL NAME
            if (splHeader.spellNameUnId > 0 && splHeader.spellNameUnId <= tlkEntries.Count - 1)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[splHeader.spellNameUnId];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create extended headers
            offset = splHeader.extendedHeaderOffset;
            splExtHeaders = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < splHeader.extendedHeaderCount; i++)
                {
                    // Console.WriteLine(path + "/" + spell + ":" + splByteArray.Length + " " + byteCount);
                    currentSplExtendedHeader = new SplExtendedHeader(splByteArray, offset);
                    splExtHeaders.Add(currentSplExtendedHeader);
                    offset += SplExtendedHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create casting feature blocks
            splCastFeatBlocks = new ArrayList();
            if (splHeader.castingFeatureBlockCount > 0)
            {
                for (int j = 0; j < splHeader.castingFeatureBlockCount; j++)
                {
                    currentSplCastFeatBlock = new SplFeatureBlock(splByteArray, offset);
                    splCastFeatBlocks.Add(currentSplCastFeatBlock);
                    offset += SplFeatureBlock.size; // increase offset by the size of the casting feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks
            splFeatBlocks = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                // currentSplExtendedHeader = (SplExtendedHeader) splExtHeaders[0];
                // offset = currentSplExtendedHeader.featureBlockIndex;
                foreach (SplExtendedHeader extendedHeader in splExtHeaders)
                {
                    for (int k = 0; k < extendedHeader.featureBlockCount; k++)
                    {
                        currentSplFeatBlock = new SplFeatureBlock(splByteArray, offset);
                        splFeatBlocks.Add(currentSplFeatBlock);
                        offset += SplFeatureBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }

            // modding objects
            splHeaderModded = splHeader;
            splExtHeadersModded = splExtHeaders;
            splCastFeatBlocksModded = splCastFeatBlocks;
            splFeatBlocksModded = splFeatBlocks;
        }
        internal static void CreateSplObjects(String path, String spell)
        {
            // Console.WriteLine("Working on file " + spell);
            splByteArray = FileOperations.ReadFile(path + "/" + spell);

            // create header
            splHeader = new SplHeader(splByteArray);
            
            // GET CURRENT SPELL NAME
            if (splHeader.spellNameUnId > 0 && splHeader.spellNameUnId <= tlkEntries.Count - 1)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[splHeader.spellNameUnId];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create extended headers
            offset = splHeader.extendedHeaderOffset;
            splExtHeaders = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < splHeader.extendedHeaderCount; i++)
                {
                    // Console.WriteLine(path + "/" + spell + ":" + splByteArray.Length + " " + byteCount);
                    currentSplExtendedHeader = new SplExtendedHeader(splByteArray, offset);
                    splExtHeaders.Add(currentSplExtendedHeader);
                    offset += SplExtendedHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create casting feature blocks
            splCastFeatBlocks = new ArrayList();
            if (splHeader.castingFeatureBlockCount > 0)
            {
                for (int j = 0; j < splHeader.castingFeatureBlockCount; j++)
                {
                    currentSplCastFeatBlock = new SplFeatureBlock(splByteArray, offset);
                    splCastFeatBlocks.Add(currentSplCastFeatBlock);
                    offset += SplFeatureBlock.size; // increase offset by the size of the casting feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks
            splFeatBlocks = new ArrayList();
            if (splHeader.extendedHeaderCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                // currentSplExtendedHeader = (SplExtendedHeader) splExtHeaders[0];
                // offset = currentSplExtendedHeader.featureBlockIndex;
                foreach (SplExtendedHeader extendedHeader in splExtHeaders)
                {
                    for (int k = 0; k < extendedHeader.featureBlockCount; k++)
                    {
                        currentSplFeatBlock = new SplFeatureBlock(splByteArray, offset);
                        splFeatBlocks.Add(currentSplFeatBlock);
                        offset += SplFeatureBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }

            // modding objects
            splHeaderModded = splHeader;
            splExtHeadersModded = splExtHeaders;
            splCastFeatBlocksModded = splCastFeatBlocks;
            splFeatBlocksModded = splFeatBlocks;
        }
        
        internal static void CreateItmObjects()
        {
            // Console.WriteLine("Working on file " + spell);
            itmByteArray = FileOperations.ReadFile(currentItemFileInfo.FullName);

            // create header
            itmHeader = new ItmHeader(itmByteArray);
            
            // GET CURRENT ITEM NAME
            if (itmHeader.nameId > 0 && itmHeader.nameId <= tlkEntries.Count - 1)
            {
                // Console.WriteLine(itmHeader.nameUnId + ":" + tlkEntries.Count);
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[itmHeader.nameId];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create extended headers
            offset = itmHeader.abilitiesOffset;
            itmExtHeaders = new ArrayList();
            ItmExtHeader firstItmExtHeader = null;
            if (itmHeader.abilitiesCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < itmHeader.abilitiesCount; i++)
                {
                    currentItmExtHeader = new ItmExtHeader(itmByteArray, offset);
                    if (i == 0)
                    {
                        firstItmExtHeader = currentItmExtHeader;
                    }
                    itmExtHeaders.Add(currentItmExtHeader);
                    offset += ItmExtHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create feature blocks of effects
            offset = itmHeader.effectsOffset;
            itmEffFeatBlocks = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (itmHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < itmHeader.effectsCount; j++)
                {
                    currentItmFeatBlock = new ItmFeatBlock(itmByteArray, offset);
                    itmEffFeatBlocks.Add(currentItmFeatBlock);
                    offset += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks of abilities
            itmAbilFeatBlocks = new ArrayList();
            foreach (ItmExtHeader extHeader in itmExtHeaders)
            {
                if (extHeader.abilitiesCount > 0) // if there are any extended headers (only then can there be feature blocks)
                {
                    // Console.WriteLine(item);
                    // Console.WriteLine(extHeader.useIcon);
                    for (int k = 0; k < extHeader.abilitiesCount; k++)
                    {
                        currentItmFeatBlock = new ItmFeatBlock(itmByteArray, offset);
                        itmAbilFeatBlocks.Add(currentItmFeatBlock);
                        offset += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }
                

            // MODDING OBJECTS
            itmHeaderModded = itmHeader;
            itmExtHeadersModded = itmExtHeaders;
            itmEffFeatBlocksModded = itmEffFeatBlocks;
            itmAbilFeatBlocksModded = itmAbilFeatBlocks;
        }
        
        internal static void CreateItmObjects(String fileName)
        {
            // Console.WriteLine("Working on file " + spell);
            itmByteArray = FileOperations.ReadFile(itmInputPath + "/" + fileName);

            // create header
            itmHeader = new ItmHeader(itmByteArray);
            
            // GET CURRENT ITEM NAME
            if (itmHeader.nameId > 0 && itmHeader.nameId <= tlkEntries.Count - 1)
            {
                // Console.WriteLine(itmHeader.nameUnId + ":" + tlkEntries.Count);
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[itmHeader.nameId];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create extended headers
            offset = itmHeader.abilitiesOffset;
            itmExtHeaders = new ArrayList();
            ItmExtHeader firstItmExtHeader = null;
            if (itmHeader.abilitiesCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < itmHeader.abilitiesCount; i++)
                {
                    currentItmExtHeader = new ItmExtHeader(itmByteArray, offset);
                    if (i == 0)
                    {
                        firstItmExtHeader = currentItmExtHeader;
                    }
                    itmExtHeaders.Add(currentItmExtHeader);
                    offset += ItmExtHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create feature blocks of effects
            offset = itmHeader.effectsOffset;
            itmEffFeatBlocks = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (itmHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < itmHeader.effectsCount; j++)
                {
                    currentItmFeatBlock = new ItmFeatBlock(itmByteArray, offset);
                    itmEffFeatBlocks.Add(currentItmFeatBlock);
                    offset += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks of abilities
            itmAbilFeatBlocks = new ArrayList();
            foreach (ItmExtHeader extHeader in itmExtHeaders)
            {
                if (extHeader.abilitiesCount > 0) // if there are any extended headers (only then can there be feature blocks)
                {
                    // Console.WriteLine(item);
                    // Console.WriteLine(extHeader.useIcon);
                    for (int k = 0; k < extHeader.abilitiesCount; k++)
                    {
                        currentItmFeatBlock = new ItmFeatBlock(itmByteArray, offset);
                        itmAbilFeatBlocks.Add(currentItmFeatBlock);
                        offset += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }
                

            // MODDING OBJECTS
            itmHeaderModded = itmHeader;
            itmExtHeadersModded = itmExtHeaders;
            itmEffFeatBlocksModded = itmEffFeatBlocks;
            itmAbilFeatBlocksModded = itmAbilFeatBlocks;
        }
        
        internal static void CreateItmObjects(String path, String item)
        {
            // Console.WriteLine("Working on file " + spell);
            itmByteArray = FileOperations.ReadFile(path + "/" + item);

            // create header
            itmHeader = new ItmHeader(itmByteArray);
            
            // GET CURRENT ITEM NAME
            if (itmHeader.nameId > 0 && itmHeader.nameId <= tlkEntries.Count - 1)
            {
                // Console.WriteLine(itmHeader.nameUnId + ":" + tlkEntries.Count);
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[itmHeader.nameId];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create extended headers
            offset = itmHeader.abilitiesOffset;
            itmExtHeaders = new ArrayList();
            ItmExtHeader firstItmExtHeader = null;
            if (itmHeader.abilitiesCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < itmHeader.abilitiesCount; i++)
                {
                    currentItmExtHeader = new ItmExtHeader(itmByteArray, offset);
                    if (i == 0)
                    {
                        firstItmExtHeader = currentItmExtHeader;
                    }
                    itmExtHeaders.Add(currentItmExtHeader);
                    offset += ItmExtHeader.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // create feature blocks of effects
            offset = itmHeader.effectsOffset;
            itmEffFeatBlocks = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (itmHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < itmHeader.effectsCount; j++)
                {
                    currentItmFeatBlock = new ItmFeatBlock(itmByteArray, offset);
                    itmEffFeatBlocks.Add(currentItmFeatBlock);
                    offset += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create feature blocks of abilities
            itmAbilFeatBlocks = new ArrayList();
            foreach (ItmExtHeader extHeader in itmExtHeaders)
            {
                if (extHeader.abilitiesCount > 0) // if there are any extended headers (only then can there be feature blocks)
                {
                    // Console.WriteLine(item);
                    // Console.WriteLine(extHeader.useIcon);
                    for (int k = 0; k < extHeader.abilitiesCount; k++)
                    {
                        currentItmFeatBlock = new ItmFeatBlock(itmByteArray, offset);
                        itmAbilFeatBlocks.Add(currentItmFeatBlock);
                        offset += ItmFeatBlock.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    }
                }
            }
                

            // MODDING OBJECTS
            itmHeaderModded = itmHeader;
            itmExtHeadersModded = itmExtHeaders;
            itmEffFeatBlocksModded = itmEffFeatBlocks;
            itmAbilFeatBlocksModded = itmAbilFeatBlocks;
        }
        
        internal static void CreateCreObjects()
        {
            // Console.WriteLine("Working on file " + spell);
            creByteArray = FileOperations.ReadFile(currentCreFileInfo.FullName);

            // create header
            creHeader = new CreHeader(creByteArray);
            
            // GET CURRENT CHAR NAME
            if (creHeader.name > 0 && creHeader.name <= tlkEntries.Count - 1)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[creHeader.name];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create known spells
            offset = creHeader.knownSpellsOffset;
            creKnownSpells = new ArrayList();
            if (creHeader.knownSpellsCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < creHeader.knownSpellsCount; i++)
                {
                    // Console.WriteLine(creByteArray.Length);
                    // Console.WriteLine(byteCount);
                    currentCreKnownSpell = new CreKnownSpell(creByteArray, offset);
                    creKnownSpells.Add(currentCreKnownSpell);
                    offset += CreKnownSpell.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }

            // create memorized spells infos
            offset = creHeader.spellsMemoInfoOffset;
            creMemorizedSpellsInfos = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.spellsMemoInfoCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.spellsMemoInfoCount; j++)
                {
                    currentCreMemorizedSpellsInfo = new CreMemorizedSpellsInfo(creByteArray, offset);
                    creMemorizedSpellsInfos.Add(currentCreMemorizedSpellsInfo);
                    offset += CreMemorizedSpellsInfo.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    // Console.WriteLine(creHeader.memoSpellsCount);
                }
            }
            
            // create memorized spells
            offset = creHeader.memoSpellsOffset;
            creMemorizedSpells = new ArrayList();
            foreach (CreMemorizedSpellsInfo creMemorizedSpellsInfo in creMemorizedSpellsInfos)
            {
                for (int i = 0; i < creMemorizedSpellsInfo.spellCount; i++)
                {
                    currentCreMemorizedSpell = new CreMemorizedSpell(creByteArray, offset);
                    creMemorizedSpells.Add(currentCreMemorizedSpell);
                    offset += CreMemorizedSpell.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create effects
            offset = creHeader.effectsOffset;
            creEffects = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.effectsCount; j++)
                {
                    currentCreEffect = new CreEffect(creByteArray, offset);
                    creEffects.Add(currentCreEffect);
                    offset += CreEffect.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create items
            offset = creHeader.itemsOffset;
            creItems = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.itemsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.itemsCount; j++)
                {
                    currentCreItem = new CreItem(creByteArray, offset);
                    creItems.Add(currentCreItem);
                    offset += CreItem.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }
            
            // create itemslots
            offset = creHeader.itemSlotsOffset;
            creItemSlots = new CreItemSlots(creByteArray, offset);

            // MODDING OBJECTS
            creHeaderModded = creHeader;
            creKnownSpellsModded = creKnownSpells;
            creMemorizedSpellsInfosModded = creMemorizedSpellsInfos;
            creMemorizedSpellsModded = creMemorizedSpells;
            creEffectsModded = creEffects;
            creItemsModded = creItems;
            creItemSlotsModded = creItemSlots;
        }
        
        internal static void CreateCreObjects(String fullPath)
        {
            // Console.WriteLine("Working on file " + spell);
            creByteArray = FileOperations.ReadFile(fullPath);

            // create header
            creHeader = new CreHeader(creByteArray);
            
            // GET CURRENT CHAR NAME
            if (creHeader.name > 0 && creHeader.name <= tlkEntries.Count - 1)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[creHeader.name];
                currentName = currentTlkEntry.textString;
                // Console.WriteLine(currentSpellName);
            }
            else
            {
                currentName = "";
            }

            int offset; // increase the byte count

            // create known spells
            offset = creHeader.knownSpellsOffset;
            creKnownSpells = new ArrayList();
            if (creHeader.knownSpellsCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < creHeader.knownSpellsCount; i++)
                {
                    // Console.WriteLine(creByteArray.Length);
                    // Console.WriteLine(byteCount);
                    currentCreKnownSpell = new CreKnownSpell(creByteArray, offset);
                    creKnownSpells.Add(currentCreKnownSpell);
                    offset += CreKnownSpell.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }

            // create memorized spells infos
            offset = creHeader.spellsMemoInfoOffset;
            creMemorizedSpellsInfos = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.spellsMemoInfoCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.spellsMemoInfoCount; j++)
                {
                    currentCreMemorizedSpellsInfo = new CreMemorizedSpellsInfo(creByteArray, offset);
                    creMemorizedSpellsInfos.Add(currentCreMemorizedSpellsInfo);
                    offset += CreMemorizedSpellsInfo.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    // Console.WriteLine(creHeader.memoSpellsCount);
                }
            }
            
            // create memorized spells
            offset = creHeader.memoSpellsOffset;
            creMemorizedSpells = new ArrayList();
            foreach (CreMemorizedSpellsInfo creMemorizedSpellsInfo in creMemorizedSpellsInfos)
            {
                for (int i = 0; i < creMemorizedSpellsInfo.spellCount; i++)
                {
                    currentCreMemorizedSpell = new CreMemorizedSpell(creByteArray, offset);
                    creMemorizedSpells.Add(currentCreMemorizedSpell);
                    offset += CreMemorizedSpell.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create effects
            offset = creHeader.effectsOffset;
            creEffects = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.effectsCount; j++)
                {
                    currentCreEffect = new CreEffect(creByteArray, offset);
                    creEffects.Add(currentCreEffect);
                    offset += CreEffect.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create items
            offset = creHeader.itemsOffset;
            creItems = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.itemsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.itemsCount; j++)
                {
                    currentCreItem = new CreItem(creByteArray, offset);
                    creItems.Add(currentCreItem);
                    offset += CreItem.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }
            
            // create itemslots
            offset = creHeader.itemSlotsOffset;
            creItemSlots = new CreItemSlots(creByteArray, offset);

            // MODDING OBJECTS
            creHeaderModded = creHeader;
            creKnownSpellsModded = creKnownSpells;
            creMemorizedSpellsInfosModded = creMemorizedSpellsInfos;
            creMemorizedSpellsModded = creMemorizedSpells;
            creEffectsModded = creEffects;
            creItemsModded = creItems;
            creItemSlotsModded = creItemSlots;
        }

        internal static void CreateTwodaObject()
        {
            String rawStr = FileOperations.ReadFileAsString(currentTwodaFileInfo.FullName);
            twodaFile = new TwodaFile(rawStr);
        }
        
        internal static void CreateIdsObject()
        {
            String rawStr = FileOperations.ReadFileAsString(currentIdsFileInfo.FullName);
            idsFile = new IdsFile(rawStr);
        }

        internal static void CreateDlgObjects()
        {
            // read file
            dlgByteArray = FileOperations.ReadFile(dlgInputPath + "/" + currentDlgFileInfo.Name);

            //generate header
            dlgHeader = new DlgHeader(dlgByteArray);

            int offset;

            // generate state tables
            offset = dlgHeader.offsetToStateTables;
            dlgStateTables = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfStates; i++)
            {
                currentDlgStateTable = new DlgStateTable(dlgByteArray, offset);
                dlgStateTables.Add(currentDlgStateTable);
                offset += DlgStateTable.size;

                // currentStateTable.PrintValues();
            }

            // generate transition tables
            offset = dlgHeader.offsetToTransitionTables;
            dlgTransitionTables = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfTransitions; i++)
            {
                currentDlgTransitionTable = new DlgTransitionTable(dlgByteArray, offset);
                dlgTransitionTables.Add(currentDlgTransitionTable);
                offset += DlgTransitionTable.size;

                // currentTransitionTable.PrintValues();
            }

            // generate state triggers
            offset = dlgHeader.offsetToStateTriggerTables;
            dlgStateTriggers = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfStateTriggers; i++)
            {
                currentDlgStateTrigger = new DlgStateTrigger(dlgByteArray, offset);
                dlgStateTriggers.Add(currentDlgStateTrigger);
                offset += DlgStateTrigger.size;

                // currentStateTrigger.PrintValues();
            }

            // generate transition triggers
            offset = dlgHeader.offsetToTransitionTriggerTables;
            dlgTransitionTriggers = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfTransitionTriggers; i++)
            {
                currentDlgTransitionTrigger = new DlgTransitionTrigger(dlgByteArray, offset);
                dlgTransitionTriggers.Add(currentDlgTransitionTrigger);
                offset += DlgTransitionTrigger.size;

                // currentTransitionTrigger.PrintValues();
            }

            // generate action tables
            offset = dlgHeader.offsetToActionTables;
            dlgActionTables = new ArrayList();
            for (int i = 0; i < dlgHeader.numberOfActions; i++)
            {
                currentDlgActionTable = new DlgActionTable(dlgByteArray, offset);
                dlgActionTables.Add(currentDlgActionTable);
                offset += DlgActionTable.size;

                // currentAction.PrintValues();
            }

            // MODDING OBJECTS
            dlgHeaderModded = dlgHeader;
            dlgStateTablesModded = dlgStateTables;
            dlgTransitionTablesModded = dlgTransitionTables;
            dlgStateTriggersModded = dlgStateTriggers;
            dlgTransitionTriggersModded = dlgTransitionTriggers;
            dlgActionTablesModded = dlgActionTables;
        }

        internal static void CreateWmpObjects()
        {
            // read file
            wmpByteArray = FileOperations.ReadFile(wmpInputPath + "/" + currentWmpFileInfo.Name);
            
            // get header
            wmpHeader = new WmpHeader(wmpByteArray);
            int offset;

            // get world map entries
            offset = wmpHeader.worldmapEntriesOffset;
            wmpWorldMapEntries = new ArrayList();
            for (int i = 0; i < wmpHeader.worldmapEntriesCount; i++)
            {
                currentWmpWorldMapEntry = new WmpWorldMapEntry(wmpByteArray, offset);
                wmpWorldMapEntries.Add(currentWmpWorldMapEntry);
                //currentWorldmapEntry.PrintValues();
                offset += WmpWorldMapEntry.size;
            }
            
            // get area entries
            wmpAreaEntries = new ArrayList();
            foreach (WmpWorldMapEntry worldmapEntry in wmpWorldMapEntries)
            {
                for (int i = 0; i < worldmapEntry.areaEntriesCount; i++)
                {
                    currentWmpAreaEntry = new WmpAreaEntry(wmpByteArray, offset);
                    wmpAreaEntries.Add(currentWmpAreaEntry);
                    //currentAreaEntry.PrintValues();
                    offset += WmpAreaEntry.size;
                }
            }
            
            // get area link entries
            wmpAreaLinkEntries = new ArrayList();
            foreach (WmpAreaEntry areaEntry in wmpAreaEntries)
            {
                int numberOfAreaLinkEntries = areaEntry.linkCountNorth + areaEntry.linkCountWest +
                                              areaEntry.linkCountSouth + areaEntry.linkCountEast;
                for (int i = 0; i < numberOfAreaLinkEntries; i++) // get number of area link entries
                {
                    currentWmpAreaLinkEntry = new WmpAreaLinkEntry(wmpByteArray, offset);
                    wmpAreaLinkEntries.Add(currentWmpAreaLinkEntry);
                    offset += WmpAreaLinkEntry.size;
                    //currentAreaLinkEntry.PrintValues();
                }
            }
            
            // MODDING OBJECTS
            wmpHeaderModded = wmpHeader;
            wmpWorldMapEntriesModded = wmpWorldMapEntries;
            wmpAreaEntriesModded = wmpAreaEntries;
            wmpAreaLinkEntriesModded = wmpAreaLinkEntries;
        }
        
        internal static void CreateStoObjects()
        {
            // read file
            stoByteArray = FileOperations.ReadFile(stoInputPath + "/" + currentStoFileInfo.Name);
            
            // get header
            stoHeader = new StoHeader(stoByteArray);
            // Console.WriteLine(currentStoFileInfo.Name + " " + stoHeader.curesForSaleOffset);
            // Console.WriteLine(currentStoFileInfo.Name + " " + stoHeader.curesForSaleCount);
            int offset;
            
            // get drinks
            offset = stoHeader.drinksForSaleOffset;
            stoDrinks = new ArrayList();
            for (int i = 0; i < stoHeader.drinksForSaleCount; i++)
            {
                currentStoDrink = new StoDrink(stoByteArray, offset);
                stoDrinks.Add(currentStoDrink);
                // currentWorldmapEntry.PrintValues();
                offset += StoDrink.size;
            }
            
            // get items for sale
            offset = stoHeader.itemsForSaleOffset;
            stoItemsForSale = new ArrayList();
            for (int i = 0; i < stoHeader.itemsForSaleCount; i++)
            {
                currentStoItemForSale = new StoItem(stoByteArray, offset);
                // Console.WriteLine(currentStoItemForSale.itmFileName);
                stoItemsForSale.Add(currentStoItemForSale);
                //currentWorldmapEntry.PrintValues();
                offset += StoItem.size;
            }
            
            // get cures
            offset = stoHeader.curesForSaleOffset;
            stoCures = new ArrayList();
            for (int i = 0; i < stoHeader.curesForSaleCount; i++)
            {
                currentStoCure = new StoCure(stoByteArray, offset);
                stoCures.Add(currentStoCure);
                //currentWorldmapEntry.PrintValues();
                offset += StoCure.size;
            }
            
            // get items for purchase
            offset = stoHeader.itemsPurchasedOffset;
            stoItemsPurchased = new ArrayList();
            for (int i = 0; i < stoHeader.itemsPurchasedCount; i++)
            {
                currentStoItemPurchased = BitConverter.ToInt32(stoByteArray, offset);
                // Console.WriteLine(currentStoItemPurchased);
                stoItemsPurchased.Add(currentStoItemPurchased);
                //currentWorldmapEntry.PrintValues();
                offset += 4;
            }

            // MODDING OBJECTS
            stoHeaderModded = stoHeader;
            stoDrinksModded = stoDrinks;
            stoItemsForSaleModded = stoItemsForSale;
            stoCuresModded = stoCures;
            stoItemsPurchasedModded = stoItemsPurchased;
        }
        
        internal static void CreateAreObjects()
        {
            // Console.WriteLine("Working on file " + spell);
            areByteArray = FileOperations.ReadFile(currentAreFileInfo.FullName);
        
            // create header
            areHeader = new AreHeader(areByteArray);
            
            int offset;
        
            //
            offset = 0;
            areActors = new ArrayList();
            if (areHeader.numberOfActors > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfActors; i++)
                {
                    currentAreActor = new AreActor(areByteArray, areHeader.offsetActors + offset);
                    areActors.Add(currentAreActor);
                    offset += AreActor.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                    // Console.WriteLine(currentAreFileInfo + " : " + areActors.Count);
                }
            }
            // Console.WriteLine(currentAreFileInfo + " : " + areActors.Count);
            //
            offset = 0;
            areTriggers = new ArrayList();
            if (areHeader.numberOfTrigger > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfTrigger; i++)
                {
                    currentAreTrigger = new AreTrigger(areByteArray, areHeader.offsetTriggers + offset);
                    areTriggers.Add(currentAreTrigger);
                    offset += AreTrigger.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areSpawnPoints = new ArrayList();
            if (areHeader.numberOfSpawnPoints > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfSpawnPoints; i++)
                {
                    currentAreSpawnPoint = new AreSpawnPoint(areByteArray, areHeader.offsetSpawnPoints + offset);
                    areSpawnPoints.Add(currentAreSpawnPoint);
                    offset += AreSpawnPoint.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areEntrances = new ArrayList();
            if (areHeader.numberOfEntraces > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfEntraces; i++)
                {
                    currentAreEntrance = new AreEntrance(areByteArray, areHeader.offsetEntrances + offset);
                    areEntrances.Add(currentAreEntrance);
                    offset += AreEntrance.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areContainers = new ArrayList();
            if (areHeader.numberOfContainers > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfContainers; i++)
                {
                    currentAreContainer = new AreContainer(areByteArray, areHeader.offsetContainers + offset);
                    areContainers.Add(currentAreContainer);
                    offset += AreContainer.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areItems = new ArrayList();
            if (areHeader.numberOfItems > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfItems; i++)
                {
                    currentAreItem = new AreItem(areByteArray, areHeader.offsetItems + offset);
                    areItems.Add(currentAreItem);
                    offset += AreItem.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
                // Console.WriteLine(currentAreFileInfo.Name + ":" + currentAreItem.resource);
            }
            //
            offset = 0;
            areVertices = new ArrayList();
            if (areHeader.numberOfVertices > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfVertices; i++)
                {
                    currentAreVertex = new AreVertex(areByteArray, areHeader.offsetVertices + offset);
                    areVertices.Add(currentAreVertex);
                    offset += AreVertex.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
                // Console.WriteLine(currentAreFileInfo.Name + ":" + currentAreVertex.x);
            }
            //
            offset = 0;
            areAmbients = new ArrayList();
            if (areHeader.numberOfAmbients > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfAmbients; i++)
                {
                    currentAreAmbient = new AreAmbient(areByteArray, areHeader.offsetAmbients + offset);
                    areAmbients.Add(currentAreAmbient);
                    offset += AreAmbient.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
                // Console.WriteLine(currentAreFileInfo.Name + ":" + currentAreAmbient.name);
            }
            //
            offset = 0;
            areVariables = new ArrayList();
            if (areHeader.numberOfVariables > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfVariables; i++)
                {
                    currentAreVariable = new AreVariable(areByteArray, areHeader.offsetVariables);
                    areVariables.Add(currentAreVariable);
                    offset += AreVariable.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areExploredBitmasks = new byte[areHeader.exploredBitmaskSize];
            Buffer.BlockCopy(areByteArray, areHeader.exploredBitmaskOffset, areExploredBitmasks, 0, areHeader.exploredBitmaskSize);
            //
            offset = 0;
            areDoors = new ArrayList();
            if (areHeader.numberOfDoors > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfDoors; i++)
                {
                    currentAreDoor = new AreDoor(areByteArray, areHeader.offsetDoors + offset);
                    areDoors.Add(currentAreDoor);
                    offset += AreDoor.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areAnimations = new ArrayList();
            if (areHeader.numberOfAnimations > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfAnimations; i++)
                {
                    currentAreAnimation = new AreAnimation(areByteArray, areHeader.offsetAnimations + offset);
                    areAnimations.Add(currentAreAnimation);
                    offset += AreAnimation.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areTiledObjects = new ArrayList();
            if (areHeader.numberOfTiledObjects > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfTiledObjects; i++)
                {
                    currentAreTiledObject = new AreTiledObject(areByteArray, areHeader.offsetTiledObjects + offset);
                    areTiledObjects.Add(currentAreTiledObject);
                    offset += AreTiledObject.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areSong = new AreSong(areByteArray, areHeader.songsOffset);
            // Console.WriteLine(currentAreFileInfo.Name + ":" + areSong.daySong);
            //
            areRestEncounter = new AreRestEncounter(areByteArray, areHeader.restEncountersOffset);
            //
            offset = 0;
            areAutomapNotes = new ArrayList();
            if (areHeader.numberOfAutomapNotes > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfAutomapNotes; i++)
                {
                    currentAreAutomapNote = new AreAutomapNote(areByteArray, areHeader.automapNotesOffset + offset);
                    areAutomapNotes.Add(currentAreAutomapNote);
                    offset += AreAutomapNote.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            //
            offset = 0;
            areProjectileTraps = new ArrayList();
            if (areHeader.numberOfProjectileTraps > 0) // check if there is an extended Header
            {
                for (int i = 0; i < areHeader.numberOfProjectileTraps; i++)
                {
                    currentAreProjectileTrap = new AreProjectileTrap(areByteArray, areHeader.offsetProjectileTraps + offset);
                    areProjectileTraps.Add(currentAreProjectileTrap);
                    offset += AreProjectileTrap.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }
            
            // MODDING OBJECTS
            areHeaderModded = areHeader;
            areActorsModded = areActors;
            areTriggersModded = areTriggers;
            areSpawnPointsModded = areSpawnPoints;
            areEntrancesModded = areEntrances;
            areContainersModded = areContainers;
            areItemsModded = areItems;
            areVerticesModded = areVertices;
            areAmbientsModded = areAmbients;
            areVariablesModded = areVariables;
            areExploredBitmasksModded = areExploredBitmasks;
            areDoorsModded = areDoors;
            areAnimationsModded = areAnimations;
            areTiledObjectsModded = areTiledObjects;
            areSongModded = areSong;
            areRestEncounterModded = areRestEncounter;
            areAutomapNotesModded = areAutomapNotes;
            areProjectileTrapsModded = areProjectileTraps;
        }

        
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        ///////////////   FILE CHECKS  ///////////////
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        /////////////// ////////////// ///////////////
        internal static void FilterFiles()
        {
            // Regex regex  = new Regex("((SP|sp)(PR|pr|WI|wi|IN|in|CL|cl)[1-9][0-5][0-9]|BDPWEAPN|a7!smgl|A7!SMGL|A7!GLR(1[AB])|a7!glr(1[ab])?|amul25|SPDWD02|#PRAYER[GB]|QD_\\w{3}\\d{2}|a7!in\\d{2})\\.(SPL|spl)");
            // Regex regex  = new Regex(@"(SP|sp|BDPWEAPN|a7!smgl|A7!SMGL|A7!GLR|a7!glr|amul25|SPDWD02|#PRAYER|QD_).*\.(SPL|spl)");
            foreach (FileInfo spell in splsRaw)
            {
                // Console.WriteLine(spell.Name);
                if (Regex.IsMatch(spell.Name, @"(SP|sp|BDPWEAPN|a7!smgl|A7!SMGL|A7!GLR|a7!glr|amul25|SPDWD02|#PRAYER|QD_).*\.(SPL|spl)"))
                {
                    spells.Add(spell);
                }
            }
            
            // ITEMS
            foreach (FileInfo item in itmsRaw)
            {
                items.Add(item);
            }

            // CRES
            foreach (FileInfo cre in cresRaw)
            {
                cres.Add(cre);
            }
            
            // DLGS
            // regex  = new Regex(@"(THALAN|JARED|ARKION|NEMPHR|TAEROM|X#DRIZZT|A7!SMDLG|A7!CMD|A7!CMD2|A7!CMD3|MH#PHEND|MH#BROKK|KORAX).(dlg|DLG)");
            foreach (FileInfo dlg in dlgsRaw)
            {
                dlgs.Add(dlg);
            }
            
            // 2DA
            // regex = new Regex(@"(SPSD\d+|(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO).*)\.(2da|2DA)");
            foreach (FileInfo twoda in twodasRaw)
            {
                if (Regex.IsMatch(twoda.Name, @"(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO)(.*)\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
                else if (Regex.IsMatch(twoda.Name, @"(splshmkn|splsrckn|SPLSHMKN|SPLSRCKN)\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
                else if (Regex.IsMatch(twoda.Name, @"(MXSPL)(BRD|DD|DRU|PRS|SHM|SRC|WIZ|PAL|RAN)\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
                else if (Regex.IsMatch(twoda.Name, @"ITEM_USE\.(2da|2DA)"))
                {
                    twodas.Add(twoda);
                }
            }
            
            // IDS
            // regex = new Regex(@"(SPSD\d+|(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO).*)\.(2da|2DA)");
            foreach (FileInfo id in idsRaw)
            {
                idss.Add(id);
            }

            // BCS
            // regex = new Regex(@"(SPSD\d+|(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO).*)\.(2da|2DA)");
            foreach (FileInfo bcs in bcssRaw)
            {
                bcss.Add(bcs);
            }
            
            // WMP
            foreach (FileInfo wmp in wmpsRaw)
            {
                wmps.Add(wmp);
            }
            
            // STO
            foreach (FileInfo sto in stosRaw)
            {
                stos.Add(sto);
            }
            
            // ARE
            foreach (FileInfo are in aresRaw)
            {
                ares.Add(are);
            }
            
            // FileOperations.CheckBasePath(splOutputPath); // create dir if output base path doesn't exist  
            // FileOperations.CheckBasePath(splInputPath); // create dir if output base path doesn't exist  
        }

        
        /////////////// ////////////////////// ///////////////
        /////////////// ////////////////////// ///////////////
        /////////////// ////////////////////// ///////////////
        /////////////// MODDED FILES FUNCTIONS ///////////////
        /////////////// ////////////////////// ///////////////
        /////////////// ////////////////////// ///////////////
        /////////////// ////////////////////// ///////////////
        internal static void CheckForPreModdedFile()
        {
            // Console.WriteLine(itmsModRaw.Length);
            // Console.WriteLine(cresModRaw.Length);
            if (null != currentItemFileInfo)
            {
                foreach (FileInfo itmMod in itmsModRaw)
                {
                    if (ContainsCaseInsensitive(currentItemFileInfo.Name, itmMod.Name))
                    {
                        currentItemFileInfo = itmMod;
                    }
                }
            }

            if (null != currentCreFileInfo)
            {
                foreach (FileInfo creMod in cresModRaw)
                {
                    if (ContainsCaseInsensitive(currentCreFileInfo.Name, creMod.Name))
                    {
                        currentCreFileInfo = creMod;
                    }
                }
            }
        }

        internal static void CopyTwoDAs()
        {
            foreach (FileInfo twoda in twodasModRaw)
            {
                // copy to output dir
                FileOperations.WriteFile(twodaModPath + "/" + twoda, twodaOutputPath + "/" + twoda);
            }
        }
        
        internal static void CopyAndPatchItms()
        {
            Hashtable ht = new Hashtable();
            ht.Add("SCRL86.ITM", "Resist Elements");
            ht.Add("CDIA525.ITM", "Waves of Fatigue");
            ht.Add("CDIA432.ITM", "Jelly Conjuring");
            ht.Add("CDIA527.ITM", "Mind Fog");
            ht.Add("SCRL82.ITM", "Dimension Jump");
            ht.Add("SCRL5D.ITM", "Protection from Poison");
            ht.Add("SCRL5J.ITM", "Protection from Poison");
            ht.Add("SCRL67.ITM", "Magic Armor");

            foreach (FileInfo itm in itmsModRaw)
            {
                byte[] byteFile = FileOperations.ReadFile(itm.FullName);
                foreach (DictionaryEntry pair in ht)
                {
                    if (ContainsCaseInsensitive(itm.Name, pair.Key.ToString()))
                    {
                        // Console.WriteLine(itm.Name + " - " + AddExactTlkEntryIfNotFound(pair.Value.ToString()));
                        Buffer.BlockCopy(BitConverter.GetBytes(AddExactTlkEntryIfNotFound(pair.Value.ToString())), 0, byteFile, 12, 4);
                        Buffer.BlockCopy(BitConverter.GetBytes(FindFirstMatchingTlkEntry(pair.Value.ToString() + @"( )?\n")), 0, byteFile, 84, 4);
                        FileOperations.WriteFile(itmOutputPath + "/" + itm.Name, byteFile);
                    }
                }
            }
            
            // polymorph Items
            ht = new Hashtable();
            ht.Add("spwi461.itm", @"Attack");
            ht.Add("spwi462.itm", @"Morning Star");
            ht.Add("spwi463.itm", @"Spear \+2");
            ht.Add("spwi464.itm", @"Attack");
            ht.Add("spwi465.itm", @"Attack");
            ht.Add("spwi466.itm", @"Attack");

            foreach (FileInfo itm in itmsModRaw)
            {
                byte[] byteFile = FileOperations.ReadFile(itm.FullName);
                foreach (DictionaryEntry pair in ht)
                {
                    if (ContainsCaseInsensitive(itm.Name, pair.Key.ToString()))
                    {
                        Buffer.BlockCopy(BitConverter.GetBytes(AddExactTlkEntryIfNotFound(pair.Value.ToString())), 0, byteFile, 8, 4);
                        Buffer.BlockCopy(BitConverter.GetBytes(AddExactTlkEntryIfNotFound(pair.Value.ToString())), 0, byteFile, 12, 4);
                        FileOperations.WriteFile(itmOutputPath + "/" + itm.Name, byteFile);
                    }
                }
            }
        }
        
        internal static void PatchAndCopyEffs()
        {
            foreach (FileInfo eff in effsModRaw)
            {
                effByteArray = FileOperations.ReadFile(effModPath + "/" + eff.Name);

                // fix allegiance in eff file
                Boolean found = nonControllable.Contains(eff.Name.Substring(0, 8).Replace(".", ""));
                // Console.WriteLine(eff.Name.Substring(0, 7));
                // Console.WriteLine(found);
                if (found)
                {
                    Buffer.BlockCopy(BitConverter.GetBytes(4), 0, effByteArray, 32, 4);
                }
                else
                {
                    Buffer.BlockCopy(BitConverter.GetBytes(0), 0, effByteArray, 32, 4);
                }
                
                FileOperations.WriteFile(effOutputPath + "/" + eff, effByteArray);
            }
        }

        internal static void CopyBams()
        {
            foreach (FileInfo bam in bamsModRaw)
            {
                // copy to output dir
                FileOperations.WriteFile(bamModPath + "/" + bam, bamOutputPath + "/" + bam);
            }
        }
        
        internal static void CopyMiscs()
        {
            foreach (FileInfo misc in miscsModRaw)
            {
                // copy to output dir
                FileOperations.WriteFile(miscModPath + "/" + misc, miscOutputPath + "/" + misc);
            }
        }
        
        internal static void PatchAndCopyCres()
        {
            String gbb1 = "Stinking Beetle";
            String gbb2 = "Battle Beetle";
            AddTlkEntry(gbb1);
            AddTlkEntry(gbb2);
            
            Hashtable ht = new Hashtable();
            ht.Add("MONSUM1A.CRE", "Gnoll Veteran");
            ht.Add("MONSUM1B.CRE", "Hobgoblin Scout");
            ht.Add("MONSUM1C.CRE", "Half Ogre");
            ht.Add("MONSUM1D.CRE", "Ogrillon");
            ht.Add("MONSUM2A.CRE", "Hobgoblin Elite");
            ht.Add("MONSUM2B.CRE", "Hobgoblin Captain");
            ht.Add("MONSUM2C.CRE", "Hobgoblin Marksman");
            ht.Add("MONSUM2D.CRE", "Hobgoblin Priest");
            ht.Add("MONSUM2E.CRE", "Hobgoblin Wizard");
            ht.Add("MONSUM2F.CRE", "Gnoll Captain");
            ht.Add("MONSUM2G.CRE", "Gnoll Chieftain");
            ht.Add("MONSUM2H.CRE", "Gnoll Slasher");
            ht.Add("MONSUM3A.CRE", "Ogre");
            ht.Add("MONSUM3B.CRE", "Half-Ogre Veteran");
            ht.Add("MONSUM3C.CRE", "Ogre Berserker");
            ht.Add("MONSUM3D.CRE", "Ogre Mage");
            ht.Add("MONSUM4A.CRE", "Ogre Mage");
            ht.Add("MONSUM4B.CRE", "Ogre Chieftain");
            ht.Add("MONSUM4C.CRE", "Ogre Shaman");
            ht.Add("MONSUM5A.CRE", "Greater Ghast");
            ht.Add("MONSUM5B.CRE", "Greater Ghoul");
            ht.Add("MONSUM5C.CRE", "Ghoul Lord");
            ht.Add("MONSUM5D.CRE", "Mummy");
            ht.Add("MONSUM5E.CRE", "Doppelganger");
            ht.Add("MONSUM5F.CRE", "Battle Horror");
            ht.Add("MONSUM5G.CRE", "Doom Guard");
            ht.Add("MONSUM6A.CRE", "Giant Troll");
            ht.Add("MONSUM6B.CRE", "Snow Troll");
            ht.Add("MONSUM6C.CRE", "Troll Shaman");
            ht.Add("MONSUM6D.CRE", "Fire Troll");
            ht.Add("MONSUM7A.CRE", "Greater Doppelganger");
            ht.Add("MONSUM7B.CRE", "Doomsayer");
            ht.Add("MONSUM7C.CRE", "Revenant");
            ht.Add("MONSUM7D.CRE", "Greater Mummy");
            ht.Add("SKELWARR.CRE", "Skeleton Warrior");
            ht.Add("SKELAR04.CRE", "Skeleton Archer");
            ht.Add("SKELAR06.CRE", "Skeleton Archer");
            ht.Add("SKELAR08.CRE", "Skeleton Archer");
            ht.Add("SKELAR10.CRE", "Skeleton Archer");
            ht.Add("ANISUM1A.CRE", "Dread Wolf");
            ht.Add("ANISUM1B.CRE", "Black Bear");
            ht.Add("ANISUM1C.CRE", "Jaguar");
            ht.Add("ANISUM1D.CRE", "Leopard");
            ht.Add("ANISUM2A.CRE", "Winter Wolf");
            ht.Add("ANISUM2B.CRE", "Old Boar");
            ht.Add("ANISUM2C.CRE", "Wild Tiger");
            ht.Add("ANISUM2D.CRE", "Brown Bear");
            ht.Add("ANISUM3A.CRE", "Polar Bear");
            ht.Add("ANISUM3B.CRE", "Stone Snake");
            ht.Add("ANISUM3C.CRE", "Cave Bear");
            ht.Add("ANISUM3D.CRE", "Panther");
            ht.Add("MNTNBEAR.CRE", "Mountain Bear");
            ht.Add("LESSERAE.CRE", "Lesser Air Elemental");
            ht.Add("LESSEREE.CRE", "Lesser Earth Elemental");
            ht.Add("LESSERFE.CRE", "Lesser Fire Elemental");
            ht.Add("LESSERWE.CRE", "Lesser Water Elemental");
            ht.Add("AELEM1.CRE", "Water Elemental");
            ht.Add("AELEM2.CRE", "Greater Water Elemental");
            ht.Add("AELEM3.CRE", "Elder Water Elemental");
            ht.Add("EELEM1.CRE", "Earth Elemental");
            ht.Add("EELEM2.CRE", "Greater Earth Elemental");
            ht.Add("EELEM3.CRE", "Elder Earth Elemental");
            ht.Add("FELEM1.CRE", "Fire Elemental");
            ht.Add("FELEM2.CRE", "Greater Fire Elemental");
            ht.Add("FELEM3.CRE", "Elder Fire Elemental");
            ht.Add("WELEM1.CRE", "Water Elemental");
            ht.Add("WELEM2.CRE", "Greater Water Elemental");
            ht.Add("WELEM3.CRE", "Elder Water Elemental");
            ht.Add("SPIDER1A.CRE", "Giant Spider");
            ht.Add("SPIDER2A.CRE", "Sword Spider");
            ht.Add("SPIDER2B.CRE", "Wraith Spider");
            ht.Add("SPIDER2C.CRE", "Phase Spider");
            ht.Add("SPIDER3A.CRE", "Vortex Spider");
            ht.Add("SPIDER3B.CRE", "Gargantuan Spider");
            ht.Add("SPIDER3C.CRE", "Astral Phase Spider");
            ht.Add("OTYUGH01.CRE", "Otyugh");
            ht.Add("OTYUGH02.CRE", "Greater Otyugh");
            ht.Add("OTYUGH03.CRE", "Neo-Otyugh");
            ht.Add("ISTALKER.CRE", "Invisible Stalker");
            ht.Add("ASHIRUKU.CRE", "Ashirukuru");
            ht.Add("HELMHORR.CRE", "Helmed Horror");
            ht.Add("NISHRUU.CRE", "Nishruu");
            ht.Add("WYVERNGR.CRE", "Greater Wyvern");
            ht.Add("WYVERNLE.CRE", "Wyvern");
            ht.Add("HAKESHAR.CRE", "Hakeashar");
            ht.Add("DEMONKNI.CRE", "Demon Knight");
            ht.Add("EFREETI.CRE", "Efreeti");
            ht.Add("BONEGUAR.CRE", "Boneguard");
            ht.Add("SLIME2A.CRE", "Ochre Jelly");
            ht.Add("SLIME2B.CRE", "Ochre Jelly");
            ht.Add("SLIME3.CRE", "Mustard Jelly");
            ht.Add("SLIME4.CRE", "Fission Slime");
            ht.Add("TANARRI.CRE", "Tanar'ri");
            ht.Add("GLABREZU.CRE", "Glabrezu");
            ht.Add("PITFIEND.CRE", "Pit Fiend");
            ht.Add("BEETLE1B.CRE", "Bombardier Beetle");
            ht.Add("BEETLE1A.CRE", "Boring Beetle");
            ht.Add("BEETLE2B.CRE", gbb1);
            ht.Add("BEETLE2A.CRE", gbb2);
            ht.Add("WOODLAN1.CRE", "Nymph");
            ht.Add("WOODLAN2.CRE", "Hamadryad");
            ht.Add("WOODLAN3.CRE", "Sirine");

            Console.WriteLine("Patching cre files...");
            foreach (FileInfo cre in cresModRaw)
            {
                // creByteArray = FileOperations.ReadFile(creModPath + "/" + cre.Name);
                CreateCreObjects(cre.FullName);
                Console.WriteLine("Patching " + cre.Name + "...");

                // fix display name
                index = 0;
                foreach (DictionaryEntry pair in ht)
                {
                    if (ContainsCaseInsensitive(cre.Name, pair.Key.ToString()))
                    {
                        String creatureName1 = GetTlkStringFromStrRef(creHeaderModded.name);
                        String creatureName2 = GetTlkStringFromStrRef(creHeaderModded.tooltip);
                        // Console.WriteLine(creatureName1 + " " + creHeaderModded.name);
                        // Console.WriteLine(creatureName2 + " " + creHeaderModded.tooltip);
                        if (!creatureName1.Equals(pair.Value.ToString()) || !creatureName2.Equals(pair.Value.ToString()))
                        {
                            Console.WriteLine("Found incorrect cre name, patching...");
                            int correctedName = AddExactTlkEntryIfNotFound(pair.Value.ToString());
                            creHeaderModded.name = correctedName;
                            creHeaderModded.tooltip = correctedName;
                            Console.WriteLine(GetTlkStringFromStrRef(creHeaderModded.name) + "    " + creHeaderModded.name);
                            Console.WriteLine(GetTlkStringFromStrRef(creHeaderModded.tooltip) + "    " + creHeaderModded.tooltip);

                        }
                        else
                        {
                            // Console.WriteLine("Cre name correct, skipping...");
                        }
                    }
                }
                
                // fix script name
                String scriptName = creHeaderModded.scriptName;
                String newScriptName = "fix_summons";
                if (!scriptName.Equals(newScriptName) && creHeaderModded.raceId != 121) // if not a demon
                {
                    Console.WriteLine("Found incorrect script name, patching...");
                    creHeaderModded.scriptName = newScriptName + new string(new char[32 - newScriptName.Length]);
                }
                else
                {
                    // Console.WriteLine("Script name correct, skipping...");
                }

                scriptName = creHeaderModded.scriptDefault;
                newScriptName = "wtasight";
                if (!scriptName.Equals(newScriptName) && creHeaderModded.raceId != 121)  // if not a demon
                {
                    Console.WriteLine("Found incorrect script name, patching...");
                    creHeaderModded.scriptDefault = newScriptName;
                }
                else
                {
                    // Console.WriteLine("Script name correct, skipping...");
                }
                
                // fix xp value
                creHeaderModded.xpKill = 0;

                // fix gender
                creHeaderModded.genderId = 6;
                
                // fix no corpse
                creHeaderModded.creatureFlags = GetBitfieldInt(new int[] {1});
                
                // fix allegiance in the cre file
                Boolean found = nonControllable.Contains(cre.Name.Substring(0, 8).Replace(".", ""));
                if (found)
                {
                    creHeaderModded.enemyAllyId = 28;
                }
                else
                {
                    creHeaderModded.enemyAllyId = 128;
                }
                
                // fix item drops
                foreach (CreItem creItem in creItemsModded)
                {
                    creItem.flags = GetBitfieldInt(new int[] {0, 3});
                }
                
                // give creature a dismiss function
                if (creHeaderModded.raceId != 121) // if not a demon
                {
                    AddCreSpell(16, "SPUNSUMM", 0, 2, 0);
                }
                
                // remove all dialogs
                if (!creHeaderModded.dialogFile.Equals(""))
                {
                    creHeaderModded.dialogFile = new string(new char[8]);
                }
                
                // copy to output dir
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + cre.Name);
            }
        }

        internal static void CopyAllFiles(String src, String dest)
        {
            DirectoryInfo srcDir = new DirectoryInfo(src);
            FileInfo[] srcItems = srcDir.GetFiles();
            foreach (FileInfo srcItem in srcItems)
            {
                File.Copy(srcItem.FullName, dest + "/" + srcItem.Name, true);
            }
        }

        internal static void CheckIfItemsAvailableInGame()
        {
            // FilterFiles();
            CreateTlkObjects();
            String findStr;
            ArrayList strList = new ArrayList();
            foreach (FileInfo sto in stos)
            {
                currentStoFileInfo = sto;
                CreateStoObjects();
                foreach (StoItem stoItem in stoItemsForSaleModded)
                {
                    findStr = stoItem.itmFileName.Replace("\u0000", "");
                    if (!strList.Contains(findStr))
                    {
                        strList.Add(findStr);
                    }
                }
            }
            foreach (FileInfo are in ares)
            {
                currentAreFileInfo = are;
                CreateAreObjects();
                foreach (AreItem areItem in areItemsModded)
                {
                    findStr = areItem.resource.Replace("\u0000", "");
                    if (!strList.Contains(findStr))
                    {
                        strList.Add(findStr);
                    }
                }
            }
            foreach (FileInfo cre in cres)
            {
                currentCreFileInfo = cre;
                CreateCreObjects();
                foreach (CreItem creItem in creItemsModded)
                {
                    findStr = creItem.resource.Replace("\u0000", "");
                    if (!strList.Contains(findStr))
                    {
                        strList.Add(findStr);
                    }
                }
            }

            String[] strings = strList.Cast<string>().ToArray();
            FileOperations.WriteFileAsString(String.Join("\n", strings), @"D:\text.txt");
            
            foreach (FileInfo item in items)
            {
                String searchName = item.Name.Replace(".itm", "").Replace(".ITM", "");
                // Console.WriteLine(searchName);
                Boolean found = false;
                
                currentItemFileInfo = item;
                CreateItmObjects();
            
                if (!ContainsCaseInsensitive(String.Join("      ", strings), searchName) && isDroppable())
                {
                    Console.WriteLine("Could not find item:     \"" + searchName + "\"");
                }
            }
        }
    }
}