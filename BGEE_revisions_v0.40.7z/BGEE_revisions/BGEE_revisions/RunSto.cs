﻿using System;
using System.Collections;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunSto()
        {
            // if (currentStoFileInfo.Name.Contains("INN2616"))
            // {
            //     foreach (StoDrink item in stoDrinks)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.drinkName);
            //     }
            //     
            //     foreach (StoCure item in stoCures)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.splResource);
            //     }
            //     
            //     foreach (StoItem item in stoItemsForSale)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.itmFileName);
            //     }
            //     
            //     foreach (int item in stoItemsPurchasedModded)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item);
            //     }
            // }

            // foreach (StoItem stoItem in stoItemsForSale)
            // {
            //     if (stoItem.amountInStock > 5)
            //     {
            //         curren
            //     }
            // }

            // adjust container sizes
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Ammo Belt"))
            {
                stoHeaderModded.capacity = 5000;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Gem Bag"))
            {
                stoHeaderModded.capacity = 75;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Scroll Case"))
            {
                stoHeaderModded.capacity = 150;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Potion Case"))
            {
                stoHeaderModded.capacity = 125;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Holding"))
            {
                stoHeaderModded.capacity = 250;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // correct wrong string in keyring stores
            if (ContainsCaseInsensitive(currentStoFileInfo.Name, "KEYR"))
            {
                // Console.WriteLine(currentStoFileInfo.Name);
                stoHeaderModded.capacity = 50;
                stoHeaderModded.name = FindExactTlkEntry("Key ring");
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wand Case") ||
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wandcase")
            )
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // remove all items from all containers
            if (stoHeaderModded.type == 5) // if it's a container
            {
                stoHeaderModded.itemsForSaleCount = 0;
                stoHeaderModded.itemsForSaleOffset = 156;
                stoHeaderModded.drinksForSaleCount = 0;
                stoHeaderModded.drinksForSaleOffset = 156;
                stoHeaderModded.curesForSaleCount = 0;
                stoHeaderModded.curesForSaleOffset = 156;
                stoItemsForSaleModded = new ArrayList();
                stoDrinksModded = new ArrayList();
                stoCuresModded = new ArrayList();
                
                // change the offset for the items purchased by the store
                stoHeaderModded.itemsPurchasedOffset = 156;

                // Console.WriteLine(StoHeader.size);
                // Console.WriteLine(stoItemsForSaleModded.Count * StoItem.size);
                // Console.WriteLine(stoDrinksModded.Count * StoDrink.size);
                // Console.WriteLine(stoCuresModded.Count * StoCure.size);
                // Console.WriteLine(stoItemsPurchased.Count * 4);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // create bag27 with starting items
            if (ContainsCaseInsensitive(currentStoFileInfo.Name, "BAG27"))
            {
                AddStoItem("MH#RING1", 0, 0, 0, 1);
                AddStoItem("MH#IOUN7", 0, 0, 0, 1);
                AddStoItem("MH#IOUN5", 0, 0, 0, 1);
                
                // AddStoItem("MH#PLAT1", 0, 0, 0, 1);
                // AddStoItem("MH#SPER1", 0, 0, 0, 1);
                
                // AddStoItem("X#XZRING", 0, 0, 0, 1);
                // AddStoItem("X#TOME", 0, 0, 0, 1);
                // AddStoItem("X#WINAMU", 0, 0, 0, 1);
                // AddStoItem("X#RINGRO", 0, 0, 0, 1);
                // AddStoItem("X#KISPR", 0, 0, 0, 1);
                // AddStoItem("X#JACLUB", 0, 0, 0, 1);
                // AddStoItem("X#IAMUL", 0, 0, 0, 1);
                // AddStoItem("X#GARCH2", 0, 0, 0, 1);
                // AddStoItem("X#FASH01", 0, 0, 0, 1);
                // AddStoItem("X#COAMUL", 0, 0, 0, 1);
                    
                AddStoItem("OHDPOTN1", 1, 0, 0, 5);
                
                AddStoItem("SCRL87", 5, 0, 0, 1);
                AddStoItem("SCRL1H", 5, 0, 0, 1);
                AddStoItem("SCRL1O", 5, 0, 0, 1);
                AddStoItem("SCRL1L", 5, 0, 0, 1);
                AddStoItem("SCRL2B", 5, 0, 0, 1);
                AddStoItem("SCRL1R", 5, 0, 0, 1);
                AddStoItem("SCRL1Y", 5, 0, 0, 1);
                AddStoItem("SCRL5G", 5, 0, 0, 1);
                AddStoItem("SCRL6D", 5, 0, 0, 1);
                AddStoItem("SCRL6J", 5, 0, 0, 1);
                AddStoItem("SCRL6H", 5, 0, 0, 1);
                AddStoItem("SCRL6I", 5, 0, 0, 1);
                AddStoItem("SCRL6O", 5, 0, 0, 1);
                AddStoItem("SCRL6P", 5, 0, 0, 1);
                AddStoItem("SCRL81", 5, 0, 0, 1);
                AddStoItem("SCRL85", 5, 0, 0, 1);
                AddStoItem("SCRL86", 5, 0, 0, 1);
                AddStoItem("SCRL90", 5, 0, 0, 1);
                AddStoItem("SCRL96", 5, 0, 0, 1);
                AddStoItem("SCRL97", 5, 0, 0, 1);
                AddStoItem("SCRL99", 5, 0, 0, 1);
                AddStoItem("SCRLA3", 5, 0, 0, 1);
                AddStoItem("SCRLA5", 5, 0, 0, 1);
                AddStoItem("SCRLA7", 5, 0, 0, 1);
                AddStoItem("MISC82", 0, 0, 0, 1);
                
                // AddStoItem("THRING01", 0, 0, 0, 1);
                // AddStoItem("THRING02", 0, 0, 0, 1);
                // AddStoItem("THDAGG02", 0, 0, 0, 3);
                // AddStoItem("THCLCK01", 0, 0, 0, 1);
                // AddStoItem("THCLCK02", 0, 0, 0, 1);
                // AddStoItem("THBELT01", 0, 0, 0, 1);
                // AddStoItem("THAMUL01", 0, 0, 0, 4);
                // AddStoItem("THBOOT01", 0, 0, 0, 1);
                
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                AddStoItem("MISC07", 32000, 0, 0, 1);
                
                // AddStoItem("A7!TOM01", 0, 0, 0, 1);
                AddStoItem("OHDWAND1", 10, 0, 0, 5);
                // AddStoItem("AROW06", 120, 0, 0, 1);
                // AddStoItem("AROW07", 120, 0, 0, 1);
                // AddStoItem("BOLT05", 120, 0, 0, 1);
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // equalize prizes of all stores (prevent stealing exploit)
            if (
                stoHeaderModded.type == 0 ||
                stoHeaderModded.type == 1 ||
                stoHeaderModded.type == 2 ||
                stoHeaderModded.type == 3
            ) // if it's a store
            {
                stoHeaderModded.sellPriceMarkup = 150;
                stoHeaderModded.buyPriceMarkup = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                stoHeaderModded.type == 0 ||
                stoHeaderModded.type == 1 ||
                stoHeaderModded.type == 2 ||
                stoHeaderModded.type == 3
            ) // if it's a store
            {
                stoHeaderModded.flags = ModExistingBitfield(stoHeaderModded.flags, new int[] {3}, false);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                    stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            ////
            ///
            // correct empty items in containers (NULL.itm, RNDTRS.ITM... etc...)
            Random rnd = new Random();
            foreach (StoItem stoItem in stoItemsForSaleModded)
            {
                // CORRECT NON-EXISTING ITEMS
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(stoItem))) // if the item file doe not exist in the source path, we can assume this item does not exist
                {
                    String newItem = "OHDWAND1"; // WAND OF GLITTERDUST
                    Console.WriteLine("Found non-existing item \"" + stoItem.itmFileName + "\" in \"" + currentStoFileInfo.Name + "\"");
                    
                    stoItem.itmFileName = newItem;
                    stoItem.quantity1 = 1;
                    stoItem.quantity2 = 0;
                    stoItem.quantity3 = 0;
                    stoItem.flags = GetBitfieldInt(new int[] {0});
                    
                    Console.WriteLine("replacing with \"" + newItem + "\"");

                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }

                // OTHER ITEM CHARGE CHANGES
                if (stoItem.itmFileName.Contains("CLCK07")) // cloak of the nymph
                {
                    stoItem.quantity1 = 1;
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            
                // equalize wand charges for all stores (see item mod for wands)
                String fileName = GetItemFileName(stoItem);
                CreateItmObjects(fileName);
                if (itmHeaderModded.itemType == 35) // if it's a wand
                {
                    if (stoItem.quantity1 > 0)
                    {
                        stoItem.quantity1 = 10;
                    }

                    if (stoItem.quantity2 > 0)
                    {
                        stoItem.quantity2 = 10;
                    }

                    if (stoItem.quantity3 > 0)
                    {
                        stoItem.quantity3 = 10;
                    }

                    // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                    if (fileName.Contains("WAND06."))
                    {
                        stoItem.quantity1 = 10;
                        stoItem.quantity2 = 10;
                    }
                    
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            }
        }

        internal static void AddStoItem(String resource, short quantity1, short quantity2, short quantity3, int amount)
        {
            int maxSize = 8;
            int delta = maxSize - resource.Length;
            if (delta < 0)
            {
                throw new Exception("ERROR: NAME LENGTH TOO LARGE");
            }

            stoItemsForSaleModded.Add(new StoItem(resource + new string(new char[delta]), 0, quantity1, quantity2, quantity3, GetBitfieldInt(new int[] {0}), amount, 0));
        }
    }
}