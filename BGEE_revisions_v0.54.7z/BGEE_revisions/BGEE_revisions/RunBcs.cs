﻿using System;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunBcs(BcsParser bcsParser)
        {
            // ADD BUFF SPELLS TO BDDFAI.BCS
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "bddefai"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                // SHIELD
                bcsParser.FindReplaceAll(
                    false,
                    "(?=CR\nCO\nTR\n16427 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16515 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16500 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 12 0 0 0 \"\"OB\nTR\nTR\n16453 0 1 51 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16433 2408 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16439 4194304 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 1 0 0 \"LOCALSBDAI_Disable_Offensive\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16452 0 0 88 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16396 19 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 0 0 0 \"GLOBALDMWWSorcerersBuff\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n3 0 0 0 0\"GLOBALSpellsBad\" \"\" AC\nAC\n160OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#alac\" \"\" AC\nAC\n31OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n2408 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR)",
                    "CR\nCO\nTR\n16427 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16515 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16500 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 12 0 0 0 \"\"OB\nTR\nTR\n16453 0 1 51 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16433 2114 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16439 4194304 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 1 0 0 \"LOCALSBDAI_Disable_Offensive\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16610 126 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16396 19 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 0 0 0 \"GLOBALDMWWSorcerersBuff\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n3 0 0 0 0\"GLOBALSpellsBad\" \"\" AC\nAC\n160OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#alac\" \"\" AC\nAC\n31OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n2114 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR"
                );
                
                // GHOST ARMOR
                bcsParser.FindReplaceAll(
                    false,
                    "(?=CR\nCO\nTR\n16427 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16515 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16500 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 12 0 0 0 \"\"OB\nTR\nTR\n16453 0 1 51 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16433 2408 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16439 4194304 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 1 0 0 \"LOCALSBDAI_Disable_Offensive\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16452 0 0 88 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16396 19 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 0 0 0 \"GLOBALDMWWSorcerersBuff\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n3 0 0 0 0\"GLOBALSpellsBad\" \"\" AC\nAC\n160OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#alac\" \"\" AC\nAC\n31OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n2408 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR)",
                    "CR\nCO\nTR\n16427 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16515 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16500 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 12 0 0 0 \"\"OB\nTR\nTR\n16453 0 1 51 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16433 2317 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16439 4194304 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 1 0 0 \"LOCALSBDAI_Disable_Offensive\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16452 3 1 160 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16396 19 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 0 0 0 \"GLOBALDMWWSorcerersBuff\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n3 0 0 0 0\"GLOBALSpellsBad\" \"\" AC\nAC\n160OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#alac\" \"\" AC\nAC\n31OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n2317 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR"
                );
                
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // MAKE DORN APPEAR EARLIER IN SOD (UNTESTED!)
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "BD2000."))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                // disappear in BD2000 (BOARSKY BRIDGE)
                bcsParser.FindReplaceAll(
                    false,
                    "CR\nCO\nTR\n16399 0 0 0 0 \"bd2000bd_dorn_spawn\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16437 13 0 0 0 \"GLOBALChapter\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16439 4032 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"Dorn\"OB\nTR\nTR\n16607 0 0 0 0 \"dorn\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"bd2000bd_dorn_spawn\" \"\" AC\nAC\n197OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 1545 3215 0 0\"bd2000\" \"\" AC\nAC\n160OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bdresurr\" \"\" AC\nAC\n83OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"\" \"\" AC\nAC\n84OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n12 0 0 0 0\"\" \"\" AC\nAC\n160OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bdrejuve\" \"\" AC\nAC\n153OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n128 0 0 0 0\"\" \"\" AC\nAC\n157OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n19 0 0 0 0\"\" \"\" AC\nAC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"localsbd_joined\" \"\" AC\nAC\n245OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"LOCALS\" \"bd_default_loc\" AC\nAC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"localsbd_retreat\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bddorn\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n4 0 0 0 0\"\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n5 0 0 0 0\"bdshout\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"bdpal01\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n7 0 0 0 0\"\" \"\" AC\nAC\n138OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bddorn\" \"\" AC\nAC\n379OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn_chest\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nAC\n36OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\nCR\nCO\nTR\n16399 0 0 0 0 \"bd2000bd_dorn_spawn\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16437 13 0 0 0 \"GLOBALChapter\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16439 4032 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"Dorn\"OB\nTR\nTR\n16607 0 1 0 0 \"dorn\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"bd2000bd_dorn_spawn\" \"\" AC\nAC\n7OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n12 1545 3215 0 0\"dorn7\" \"\" AC\nAC\n383OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nAC\n157OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n19 0 0 0 0\"\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bddorn\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n4 0 0 0 0\"\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n5 0 0 0 0\"bdshout\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"bdpal01\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n7 0 0 0 0\"\" \"\" AC\nAC\n379OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn_chest\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nAC\n36OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\nCR\nCO\nTR\n16399 1 0 0 0 \"GLOBALBD_HAS_DORNS_SWORD\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16501 0 0 0 0 \"sw2hd1\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn_chest\"OB\nTR\nCO\nRS\nRE\n100AC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n2 0 0 0 0\"GLOBALBD_HAS_DORNS_SWORD\" \"\" AC\nAC\n169OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn_chest\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"sw2hd1\" \"\" AC\nAC\n82OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn_chest\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"sw2h02\" \"\" AC\nAC\n389OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn_chest\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 1 0\"sw2h02\" \"\" AC\nRE\nRS\nCR\n",
                    ""
                );
                
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            // MAKE DORN APPEAR EARLIER IN SOD (UNTESTED!)
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "BD0106."))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                // appear in BD0106 (OLD KEG)
                bcsParser.FindReplaceAll(
                    false, 
                    "(?<=CR\n)(?=SC)", 
                    "CR\nCO\nTR\n16399 0 0 0 0 \"bd0106bd_move_dorn\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16465 0 1 0 0 \"dorn\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16595 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nTR\nCO\nRS\nRE\n100AC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"bd0106bd_move_dorn\" \"\" AC\nAC\n197OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 740 434 0 0\"bd0106\" \"\" AC\nAC\n84OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nAC\n240OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bdrejuve\" \"\" AC\nAC\n153OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n128 0 0 0 0\"\" \"\" AC\nAC\n157OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n10 0 0 0 0\"\" \"\" AC\nAC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"localsbd_joined\" \"\" AC\nAC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"localsbd_retreat\" \"\" AC\nAC\n245OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"LOCALS\" \"bd_default_loc\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bddorn\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n4 0 0 0 0\"\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n5 0 0 0 0\"BDSHOUT\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"bdpal01\" \"\" AC\nAC\n60OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n7 0 0 0 0\"\" \"\" AC\nAC\n138OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dorn\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"bddorn\" \"\" AC\nAC\n36OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\n"
                );
                
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "BALDUR"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                
                // marek's poisoning quest experience value decrease
                bcsParser.FindReplaceAll(
                    false, 
                    "(?<=AC\n164OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n)10000(?= 0 0 0 0\"\" \"\" AC\n)", 
                    "100"
                );
                
                // stop reputation increase / decrease by letting evil chars join
                bcsParser.FindReplaceAll(
                    false, 
                    "(?<=AC\n163OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n)-2(?= 0 0 0 0\"\" \"\" AC\n)", 
                    "0"
                );
                bcsParser.FindReplaceAll(
                    false, 
                    "(?<=AC\n163OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n)2(?= 0 0 0 0\"\" \"\" AC\n)", 
                    "0"
                );
                
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
        
            // jaheira won't attack ramazith
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "JAHEIR"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "(?<=TR\n16436 0 1 0 0 \"GLOBALBD_PLOT\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 )1(?= 0 0 0 \"GLOBALX#JaheiraRamazith\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16439 -2146426897 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16587 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 21 0 0 0 0 \"\"OB\nTR\nTR\n16439 -2146426897 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 21 0 0 0 0 \"\"OB\nTR)", 
                    "99"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // jegg instant forging
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "BDCUTJEG"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "(?<=AC\n353OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n)1200(?= 0 0 0 0\"\" \"\" AC\n)", 
                    "1"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }

            // coldhearth timer expanded, so after killing him, there's plenty time to destroy the phylactery
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "BD1200.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "60(?= 0 0 0 0\"BD1200BD_DOD_COLDHEARTH_RESPAWN_TIMER\" \"\" AC)", 
                    "1200"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // baeloth appears at any player level
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "bainvi.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "TR\n16580 10000 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 21 0 0 0 0 \"\"OB\nTR\n", 
                    ""
                );
                bcsParser.FindReplaceAll(
                    false, 
                    "\\d{4} \\d{4}", 
                    "4721 3045"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // baeloth appears early, not in larswood
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "BG2900.bcs")) // DELETE HIM FROM LARSWOOD
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16399 0 0 0 0 \"GLOBALBAINVI\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"GLOBALBAINVI\" \"\" AC\nAC\n7OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 2038 2947 0 0\"BAINVI\" \"\" AC\nRE\nRS\nCR\n", 
                    ""
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "BG2300.bcs")) // MOVE HIM TO THE FAI OUTSIDE THE STONE WALLS (WHERE HE WILL GO IF KICKED OUT OF THE PARTY)
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "(?<=CR\n)(?=SC)", 
                    "CR\nCO\nTR\n16399 0 0 0 0 \"GLOBALBAINVI\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1 0 0 0 0\"GLOBALBAINVI\" \"\" AC\nAC\n7OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 4721 3045 0 0\"BAINVI\" \"\" AC\nRE\nRS\nCR\n"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "CUTBA01.bcs")) // MOVE HIM TO THE FAI OUTSIDE THE STONE WALLS (WHERE HE WILL GO IF KICKED OUT OF THE PARTY)
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "\\d{4} \\d{4}", 
                    "4721 3045"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // prevent edwin murdering dynaheir
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "EDWIN_.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16436 0 1 0 0 \"GLOBALBD_PLOT\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dynaheir\"OB\nTR\nTR\n16399 6 0 0 0 \"GLOBALX#EdwinDynaheir\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16439 -2146426897 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n131OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dynaheir\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\n", 
                    "0OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // bgsod : edwin & dynaheir in same team
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"BDEDWIN.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16399 2 0 0 0 \"globalbd_edwin_join\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dynaheir\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"minsc\"OB\nTR\nTR\n16597 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n198OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 21 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\n", 
                    ""
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"BDMINSC.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"edwin\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 0 0 0 \"globalbd_edwin_join\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dynaheir\"OB\nTR\nTR\n16597 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n198OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 21 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\n", 
                    ""
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"BDDYNAHE.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"edwin\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 0 0 0 \"globalbd_edwin_join\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16597 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n198OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 21 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\n", 
                    ""
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change golem building times
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"a7!ct0"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "(3600|7200|10800|14400)", 
                    "6"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change golem kill count (once you have the material / level you can upgrade)
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"a7!gl"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "TR\n\\d+ \\d+ 0 0 0 \"LOCALSA7!KillCount\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\n", 
                    ""
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // alter Balduran's Isle Travel Time
            if (
                ContainsCaseInsensitive(currentBcsFileInfo.Name,"ISLON") || 
                ContainsCaseInsensitive(currentBcsFileInfo.Name,"ISLOFF")
            )
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "(158400|180000)", 
                    "7200"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change ridiculous ICHARYRD fight
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "DW#ICHAR"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16449 0 1 0 0 \"calllightning\" \"LOCALS\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 2 0 0 0 \"GLOBALDMWWIcharydStorm\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 0 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16593 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 50 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 51 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 52 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 53 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRS\nCR", 
                    ""
                );
                
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16399 1 0 0 0 \"GLOBALDMWWIcharydStorm\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 0 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16593 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n169OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"minhp1\" \"\" AC\nAC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n2 0 0 0 0\"GLOBALDMWWIcharydStorm\" \"\" AC\nAC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n3746 0 0 0 0\"\" \"\" AC\nAC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1214 0 0 0 0\"\" \"\" AC\nAC\n344OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nAC\n66OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR", 
                    ""
                );
                
                bcsParser.FindReplaceAll(
                    false, 
                    "TR\n16437 3 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16594 3 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 0 1 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR", 
                    ""
                );
                
                bcsParser.FindReplaceAll(
                    false, 
                    "AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1214 0 0 0 0\"\" \"\" AC", 
                    ""
                );
                
                // Console.WriteLine(bcsParser.encryptedFile);
                // Console.WriteLine(bcsOutputPath + "/" + currentBcsFileInfo.Name);
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change reputation decrease scaling
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"MURDER"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));

                String findStr1 = "(?<=163OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n-)\\d+(?= 0 0 0 0\"\" \"\" AC)";
                MatchCollection findInts1 = bcsParser.FindAll(false, findStr1);
                foreach (Match m1 in findInts1)
                {
                    // String newVal = (Int32.Parse(m1.Value) / 2).ToString();
                    bcsParser.FindReplace(
                        false, 
                        findStr1,
                        m1.Value,
                        2.ToString()
                    );
                }
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
        }
    }
}