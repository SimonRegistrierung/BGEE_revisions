﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlk()
        {
            // spl mods
            RunTlkSpl();
            RunTlkItm();
            RunTlkMisc();
            RunTlkDlg();

            // write file
            // FileOperations.WriteFile(tlkHeader, tlkEntries, tlkOutputPath);
        }
        
        internal static void EditExistingTlkEntry(String identifier, String regex, String repl, Boolean isStart, Boolean isEnd)
        {
            Boolean spellFound = false;
            Boolean regexFound = false;
            
            int tlkIndex = 0;
            int[] tlkNewOffsets = new int[tlkHeader.numberOfStrRefs];
            for (int i = 0; i < tlkEntries.Count; i++)
            {
                currentTlkEntry = (TlkEntry) tlkEntries[i];

                Match match = Regex.Match(currentTlkEntry.textString, identifier, RegexOptions.Multiline);
                if (isStart)
                {
                    match = Regex.Match(currentTlkEntry.textString, @"\A" + identifier, RegexOptions.Multiline);
                }

                if (isEnd)
                {
                    match = Regex.Match(currentTlkEntry.textString, identifier + @"\Z", RegexOptions.Multiline);
                }
                
                if (match.Success)
                {
                    Console.WriteLine("Found spell pattern \""+ identifier + "\" in \"" + "currentTlkEntry.textString" + "\", patching...");
                    spellFound = true;
                    String oldString = currentTlkEntry.textString;
                    String newString = "";
                    int newOffsetDeltaNextEntry = 0;
                    MatchCollection matches = Regex.Matches(currentTlkEntry.textString, regex, RegexOptions.Multiline);
                    if (matches.Count != 0)
                    {
                        regexFound = true;
                        Console.WriteLine("Found regex pattern \""+ regex + "\" in \"" + "currentTlkEntry.textString" + "\", patching...");

                        Boolean firstRun = true;
                        int delta = 0;
                        foreach (Match m in matches)
                        {
                            // Console.WriteLine(currentTlkEntry.textString);
                            // Console.WriteLine(delta);
                            // Console.WriteLine("--------------");
                            // Console.WriteLine(m.Value + ":" + m.Length + ":" + m.Index);
                            // Console.WriteLine("OLDTEXT:\n========\n" + m.Value + "\nNEWTEXT:\n========\n" + repl);
                            if (firstRun)
                            {
                                newString = oldString.Remove(m.Index, m.Length).Insert(m.Index, repl);
                                firstRun = false;
                            }
                            else
                            {
                                newString = newString.Remove(m.Index + delta, m.Length).Insert(m.Index + delta, repl);
                            }
                            
                            // UPDATE DELTA (CHECK OLD AND NEW STRING LENGTHS
                            if (newString.Length > oldString.Length)
                            {
                                delta += (newString.Length - oldString.Length);
                            }
                            else if (newString.Length < oldString.Length)
                            {
                                delta -= (oldString.Length - newString.Length);
                            }

                            // Console.WriteLine(currentTlkEntry.textString);
                            // Console.WriteLine(delta);
                        }

                        int newLength = newString.Length;
                        currentTlkEntry.UpdateInstance(0, newLength, newString); // keep the offset for the current tlkEntry
                        
                        // Console.WriteLine(currentTlkEntry.textString);
                    }
                }
            }

            if (!spellFound)
            {
                Console.WriteLine("**** DEBUG RELEVANT: SPELL NOT FOUND ****");
                Console.WriteLine("IDENTIFIER: \"" + identifier + "\"");
                Console.WriteLine("**** **** **** **** **** **** **** **** ****");
            }
            if (!regexFound)
            {
                Console.WriteLine("**** DEBUG RELEVANT: REGEX NOT FOUND ****");
                Console.WriteLine("REGEX: \"" + regex + "\"");
                Console.WriteLine("**** **** **** **** **** **** **** **** ****");
            }
        }

        internal static int FindExactTlkEntry(String findStr)
        {
            index = 0;
            Regex regex = new Regex(@"\A" + findStr + @"\Z");
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            // Console.WriteLine("WARNING: Could not find exact tlk entry:\n" + 
            //                   "\"" + findStr + "\"" +
            //                   "\nAdding item to tlk file...");
            // if we don't find it, add it and return the new index
            // AddTlkEntry(findStr);
            // return tlkHeader.numberOfStrRefs - 1;
            throw new Exception("Did not find first exact tlk entry: \"" + findStr + "\"");
        }
        
        internal static int AddExactTlkEntryIfNotFound(String findStr)
        {
            index = 0;
            Regex regex = new Regex(@"\A" + findStr + @"\Z");
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            Console.WriteLine("WARNING: Could not find exact tlk entry:\n" + 
                              "\"" + findStr + "\"" +
                              "\nAdding item to tlk file...");
            // if we don't find it, add it and return the new index
            AddTlkEntry(findStr);
            return tlkHeader.numberOfStrRefs - 1;
            // throw new Exception("Did not find first exact tlk entry: \"" + findStr + "\"");
        }
        
        internal static int FindFirstMatchingTlkEntry(String findStr)
        {
            index = 0;
            Regex regex = new Regex(findStr);
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            throw new Exception("Did not find first matching tlk entry: \"" + findStr + "\"");
        }
        
        internal static String GetTlkStringFromStrRef(int strRef)
        {
            if (strRef == -1 || strRef > 900000)
            {
                return "";
            }
            else
            {
                try
                {
                    TlkEntry tlkEntry = (TlkEntry)tlkEntries[strRef];
                    return tlkEntry.textString;
                }
                catch (Exception e)
                {
                    return "";
                }
            }
        }
        
        internal static void AddTlkEntry(String addString)
        {
            TlkEntry lastEntry = (TlkEntry)tlkEntries[tlkEntries.Count - 1];
            int offset = lastEntry.offsetToString + lastEntry.stringLength;
            
            tlkEntries.Add(new TlkEntry(addString, (short)GetBitfieldInt(new int[] {0, 2}), offset));
            
            // increase the offset for all tlkentries by the size of the new entry (remember that the properties of the tlks come before the string section itself)
            // structure: header -> tlk props (offsets pointing to the location in the string section) -> string section
            tlkHeader.numberOfStrRefs++;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                tlkEntry.offsetToString += TlkEntry.size;
            }
        }
    }
}