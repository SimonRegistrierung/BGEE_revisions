﻿using System;
using System.Text;

namespace BGEE_revisions
{
    public class AreAnimation
    {
        internal static int size = 76; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String name;
        internal short xCoordinate;
        internal short yCoordinate;
        internal int appearanceSchedule;
        internal String animationResRef;
        internal short bamSequenceNumber;
        internal short bamFrameNumber;
        internal int flags;
        internal short height;
        internal short transparency;
        internal short startingFrame;
        internal byte chanceLooping;
        internal byte skypeCycles;
        internal String palette;
        internal short animationWidth;
        internal short animationHeight;

        internal AreAnimation(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            name = ConvertToStringData(32);
            xCoordinate = ConvertToShortData();
            yCoordinate = ConvertToShortData();
            appearanceSchedule = ConvertToIntData();
            animationResRef = ConvertToStringData(8);
            bamSequenceNumber = ConvertToShortData();
            bamFrameNumber = ConvertToShortData();
            flags = ConvertToIntData();
            height = ConvertToShortData();
            transparency = ConvertToShortData();
            startingFrame = ConvertToShortData();
            chanceLooping = ConvertToByteData();
            skypeCycles = ConvertToByteData();
            palette = ConvertToStringData(8);
            animationWidth = ConvertToShortData();
            animationHeight = ConvertToShortData();
            
            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }

        internal double ConvertToDoubleData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToDouble(byteArray, currentOffset);
        }
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(name);
            CopyBytesToArray(xCoordinate);
            CopyBytesToArray(yCoordinate);
            CopyBytesToArray(appearanceSchedule);
            CopyBytesToArray(animationResRef);
            CopyBytesToArray(bamSequenceNumber);
            CopyBytesToArray(bamFrameNumber);
            CopyBytesToArray(flags);
            CopyBytesToArray(height);
            CopyBytesToArray(transparency);
            CopyBytesToArray(startingFrame);
            CopyBytesToArray(chanceLooping);
            CopyBytesToArray(skypeCycles);
            CopyBytesToArray(palette);
            CopyBytesToArray(animationWidth);
            CopyBytesToArray(animationHeight);
            
            return byteArray;
        }

        internal void CopyBytesToArray(double variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}