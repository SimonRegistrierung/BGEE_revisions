﻿using System;
using System.Collections;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunSto()
        {
            // if (currentStoFileInfo.Name.Contains("INN2616"))
            // {
            //     foreach (StoDrink item in stoDrinks)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.drinkName);
            //     }
            //     
            //     foreach (StoCure item in stoCures)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.splResource);
            //     }
            //     
            //     foreach (StoItem item in stoItemsForSale)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item.itmFileName);
            //     }
            //     
            //     foreach (int item in stoItemsPurchasedModded)
            //     {
            //         Console.WriteLine(currentStoFileInfo.Name + " : " + item);
            //     }
            // }
            
            // decrease charges of multiple items

            foreach (StoItem stoItem in stoItemsForSaleModded)
            {
                if (
                    ContainsCaseInsensitive(stoItem.itmFileName, "AMUL01") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "AMUL15") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "AMUL17") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "BDAMUL21") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "CHALCY3") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "CLCK20") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "IPSION") ||
                    //
                    ContainsCaseInsensitive(stoItem.itmFileName, "CLCK20") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "mh#ring4") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "mh#staf5") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "mh#staf6") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "MISC2P") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "MISC73") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "MISC98") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "OHRCLCK3") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "rgtlsoa") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "RING03") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "RING20") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "ROSSLAND") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "STAF05") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "STAF09") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "STAF16") ||
                    ContainsCaseInsensitive(stoItem.itmFileName, "STAF17")
                )
                {
                    if (stoItem.quantity1 >= 10)
                    {
                        stoItem.quantity1 = 15;
                    }

                    if (stoItem.quantity2 >= 10)
                    {
                        stoItem.quantity2 = 15;
                    }

                    if (stoItem.quantity3 >= 10)
                    {
                        stoItem.quantity3 = 15;
                    }
                    
                    // Console.WriteLine("STO MODDED:" + currentStoFileInfo.Name + "    with item:" + stoItem.itmFileName);
                    
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded,
                        stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            }

            // adjust container sizes
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Ammo Belt"))
            {
                stoHeaderModded.capacity = 2500;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Gem Bag"))
            {
                stoHeaderModded.capacity = 25;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Scroll Case"))
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Potion Case"))
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Holding"))
            {
                stoHeaderModded.capacity = 100;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Key Ring") ||
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Keyring")
                )
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wand Case") ||
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wandcase")
            )
            {
                stoHeaderModded.capacity = 25;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // remove all items from all containers
            if (stoHeaderModded.type == 5) // if it's a container
            {
                stoHeaderModded.itemsForSaleCount = 0;
                stoHeaderModded.itemsForSaleOffset = 156;
                stoHeaderModded.drinksForSaleCount = 0;
                stoHeaderModded.drinksForSaleOffset = 156;
                stoHeaderModded.curesForSaleCount = 0;
                stoHeaderModded.curesForSaleOffset = 156;
                stoItemsForSaleModded = new ArrayList();
                stoDrinksModded = new ArrayList();
                stoCuresModded = new ArrayList();
                
                // change the offset for the items purchased by the store
                stoHeaderModded.itemsPurchasedOffset = 156;

                // Console.WriteLine(StoHeader.size);
                // Console.WriteLine(stoItemsForSaleModded.Count * StoItem.size);
                // Console.WriteLine(stoDrinksModded.Count * StoDrink.size);
                // Console.WriteLine(stoCuresModded.Count * StoCure.size);
                // Console.WriteLine(stoItemsPurchased.Count * 4);
                
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // equalize prizes of all stores (prevent stealing exploit)
            if (
                stoHeaderModded.type == 0 ||
                stoHeaderModded.type == 1 ||
                stoHeaderModded.type == 2 ||
                stoHeaderModded.type == 3
            ) // if it's a store
            {
                stoHeaderModded.sellPriceMarkup = 150;
                stoHeaderModded.buyPriceMarkup = 50;
                FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // correct empty items in containers (NULL.itm, RNDTRS.ITM... etc...)
            foreach (StoItem stoItem in stoItemsForSaleModded)
            {
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(stoItem))) // if the item file doe not exist in the source path, we can assume this item does not exists
                {
                    // Console.WriteLine(stoItem.itmFileName);
                    stoItem.itmFileName = "MISC07" + new string(new char[2]);
                    stoItem.quantity1 = 100;
                    stoItem.quantity2 = 0;
                    stoItem.quantity3 = 0;
                    stoItem.flags = GetBitfieldInt(new int[] {0});
                    
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            }
            
            // correct wrong string in keyring stores
            if (EqualsCaseInsensitive(currentStoFileInfo.Name, "K#KEY0"))
            {
                stoHeaderModded.name = FindExactTlkEntry("Key ring");
            }

            // OTHER ITEM CHARGE CHANGES
            foreach (StoItem stoItem in stoItemsForSaleModded)
            {
                if (stoItem.itmFileName.Contains("CLCK07")) // cloak of the nymph
                {
                    stoItem.quantity1 = 1;
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            }
            
            // equalize wand charges for all stores (see item mod for wands)
            foreach (StoItem stoItem in stoItemsForSaleModded)
            {
                String fileName = GetItemFileName(stoItem);
                CreateItmObjects(fileName);
                if (itmHeaderModded.itemType == 35) // if it's a wand
                {
                    if (stoItem.quantity1 > 0)
                    {
                        stoItem.quantity1 = 10;
                    }

                    if (stoItem.quantity2 > 0)
                    {
                        stoItem.quantity2 = 10;
                    }

                    if (stoItem.quantity3 > 0)
                    {
                        stoItem.quantity3 = 10;
                    }

                    // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                    if (fileName.Contains("WAND06."))
                    {
                        stoItem.quantity1 = 10;
                        stoItem.quantity2 = 10;
                    }
                    
                    FileOperations.WriteFile(stoHeaderModded, stoDrinksModded, stoItemsForSaleModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
                }
            }
        }
    }
}