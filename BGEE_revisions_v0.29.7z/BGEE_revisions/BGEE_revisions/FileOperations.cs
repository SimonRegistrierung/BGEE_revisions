﻿using System;
using System.Collections;
using System.IO;
using System.Text;

namespace BGEE_revisions
{
    internal class FileOperations
    {
        internal static Boolean CheckFilePath(String path)
        {
            if (!File.Exists(path))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        internal static void CheckBasePath(String path)
        {
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        internal static byte[] ReadFile(String filePath)
        {
            if (File.Exists(filePath))
            {
                // NEW METHOD: ALL AT ONCE
                return File.ReadAllBytes(filePath);
            }
            else
            {
                // Console.WriteLine("File doesn't exist!");
                return null;
            }
        }
        
        internal static String ReadFileAsString(String filePath)
        {
            if (File.Exists(filePath))
            {
                return System.IO.File.ReadAllText(filePath);
            }
            else
            {
                throw new FileNotFoundException();
            }
        }

        internal static void WriteFile(String filePath, byte[] byteFile)
        {
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(String sourcePath, String destPath)
        {
            File.Copy(sourcePath, destPath, true);
        }
        
        internal static void WriteFileAsString(String fileContent, String filePath)
        {
            File.WriteAllText(filePath, fileContent);
        }
        
        internal static void WriteFile(ItmHeader itmHeader, ArrayList itmExtHeaders, ArrayList itmEffectFeatBlocks, ArrayList itmAbilityFeatBlocks, String filePath)
        {
            byte[] byteFile = new byte[
                ItmHeader.size + 
                itmExtHeaders.Count * ItmExtHeader.size + 
                itmEffectFeatBlocks.Count * ItmFeatBlock.size + 
                itmAbilityFeatBlocks.Count * ItmFeatBlock.size
            ];
            
            int offset = 0;
            byte[] bytes;
            offset += ItmHeader.size;

            itmHeader.abilitiesOffset = offset;
            itmHeader.abilitiesCount = (short)itmExtHeaders.Count;
            if (itmExtHeaders.Count != 0)
            {
                int effectIndex = 0;
                foreach (ItmExtHeader extHeader in itmExtHeaders)
                {
                    // ONLY FOR THE EXTENDED HEADER ABILITY INDICES
                    // if (filePath.Contains("WAND05"))
                    // {
                    //     Console.WriteLine(filePath + " : " + extHeader.abilitiesIndex + " : " + effectIndex + "   " + itmEffectFeatBlocks.Count);
                    // }
                    
                    extHeader.abilitiesIndex = (short)(itmEffectFeatBlocks.Count + effectIndex);
                    effectIndex += extHeader.abilitiesCount;
                    // Console.WriteLine(filePath + " : " + extHeader.abilitiesCount + " : " + extHeader.projectileAnimation);
                    //
                    bytes = extHeader.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmExtHeader.size;
                    
                    // extHeader.abilitiesIndex = 0;
                }
            }

            itmHeader.effectsOffset = offset;
            itmHeader.effectsCount = (short)itmEffectFeatBlocks.Count;
            if (itmEffectFeatBlocks.Count != 0)
            {
                foreach (ItmFeatBlock featureBlock in itmEffectFeatBlocks)
                {
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmFeatBlock.size;
                }
            }
            
            if (itmAbilityFeatBlocks.Count != 0)
            {
                foreach (ItmFeatBlock featureBlock in itmAbilityFeatBlocks)
                {
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmFeatBlock.size;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            bytes = itmHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(CreHeader creHeader, ArrayList knownSpells, ArrayList memorizedSpellsInfos, ArrayList memorizedSpells, ArrayList effects, ArrayList items, CreItemSlots itemSlots, String filePath)
        {
            byte[] byteFile = new byte[
                CreHeader.size + 
                knownSpells.Count * CreKnownSpell.size + 
                memorizedSpellsInfos.Count * CreMemorizedSpellsInfo.size + 
                memorizedSpells.Count * CreMemorizedSpell.size + 
                effects.Count * CreEffect.size + 
                items.Count * CreItem.size + 
                CreItemSlots.size
            ];
            int offset = 0;
            byte[] bytes;
            offset += CreHeader.size;

            creHeader.knownSpellsOffset = offset;
            creHeader.knownSpellsCount = knownSpells.Count;
            // Console.WriteLine(creHeader.knownSpellsCount);
            // Console.WriteLine(creHeader.knownSpellsOffset);
            if (knownSpells.Count != 0)
            {
                foreach (CreKnownSpell knownSpell in knownSpells)
                {
                    bytes = knownSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreKnownSpell.size;
                }
            }

            creHeader.spellsMemoInfoOffset = offset;
            creHeader.spellsMemoInfoCount = memorizedSpellsInfos.Count;
            // Console.WriteLine(creHeader.spellsMemoInfoOffset);
            if (memorizedSpellsInfos.Count != 0)
            {
                foreach (CreMemorizedSpellsInfo memorizedSpellsInfo in memorizedSpellsInfos)
                {
                    bytes = memorizedSpellsInfo.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpellsInfo.size;
                }
            }
            
            creHeader.memoSpellsOffset = offset;
            creHeader.memoSpellsCount = memorizedSpells.Count;
            if (memorizedSpells.Count != 0)
            {
                foreach (CreMemorizedSpell memorizedSpell in memorizedSpells)
                {
                    bytes = memorizedSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpell.size;
                }
            }
            
            creHeader.effectsOffset = offset;
            creHeader.effectsCount = effects.Count;
            if (effects.Count != 0)
            {
                foreach (CreEffect effect in effects)
                {
                    bytes = effect.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreEffect.size;
                }
            }
            
            creHeader.itemsOffset = offset;
            creHeader.itemsCount = items.Count;
            if (items.Count != 0)
            {
                foreach (CreItem item in items)
                {
                    bytes = item.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreItem.size;
                }
            }
            
            creHeader.itemSlotsOffset = offset;
            bytes = itemSlots.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);

            // add header with altered offsets and counts @ offset 0
            bytes = creHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(SplHeader splHeader, ArrayList extendedHeaders, ArrayList castingFeatureBlocks, ArrayList featureBlocks, String filePath)
        {
            byte[] byteFile = new byte[
                SplHeader.size + 
                extendedHeaders.Count * SplExtendedHeader.size +
                castingFeatureBlocks.Count * SplFeatureBlock.size +
                featureBlocks.Count * SplFeatureBlock.size
            ];

            int offset = 0;
            byte[] bytes;
            offset += SplHeader.size;

            splHeader.extendedHeaderOffset = offset;
            splHeader.extendedHeaderCount = (short)extendedHeaders.Count;
            if (extendedHeaders.Count != 0)
            {
                int spellIndex = 0;
                foreach (SplExtendedHeader extendedHeader in extendedHeaders)
                {
                    // ONLY FOR THE EXTENDED HEADER SPELL INDICES
                    extendedHeader.featureBlockIndex = (short)(castingFeatureBlocks.Count + spellIndex);
                    spellIndex += extendedHeader.featureBlockCount;
                    //
                    bytes = extendedHeader.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplExtendedHeader.size;
                    
                    // Console.WriteLine(filePath + ":" + extendedHeader.featureBlockOffset);
                }
            }

            splHeader.castingFeatureBlockCount = (short)castingFeatureBlocks.Count;
            if (castingFeatureBlocks.Count != 0)
            {
                foreach (SplFeatureBlock castingFeatureBlock in castingFeatureBlocks)
                {
                    bytes = castingFeatureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplFeatureBlock.size;
                }
            }

            if (featureBlocks.Count != 0)
            {
                foreach (SplFeatureBlock featureBlock in featureBlocks)
                {
                    // Console.WriteLine(featureBlock.resource);
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplFeatureBlock.size;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            bytes = splHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);
            
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(TlkHeader tlkHeader, ArrayList tlkEntries, String filePath)
        {
            int strSize = 0;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                strSize += tlkEntry.stringLength;
            }
            
            byte[] byteFile = new byte[
                TlkHeader.size + 
                tlkEntries.Count * TlkEntry.size + 
                strSize
            ];
            
            byte[] bytes;
            int offset;

            tlkHeader.numberOfStrRefs = tlkEntries.Count;
            tlkHeader.offsetToStringData = TlkHeader.size + tlkEntries.Count * TlkEntry.size;
            
            ///
            /// COPYING
            ///
            
            // copy tlkHeader to byte file
            offset = 0;
            System.Buffer.BlockCopy(tlkHeader.GetByteData(), 0, byteFile, offset, TlkHeader.size);

            // correct offsets for each individual tlkEntry Text offsets & copy the tlk entry OBJECTS to byte file
            offset = TlkHeader.size;
            int offsetToString = 0; // offset to string data is relative to the string section, not absolute to the full file size!
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                tlkEntry.stringLength = tlkEntry.textString.Length;
                tlkEntry.offsetToString = offsetToString; // offset to string data is relative to the string section, not absolute to the full file size!
                
                bytes = tlkEntry.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, TlkEntry.size);
                
                offset += TlkEntry.size;
                offsetToString += tlkEntry.stringLength;
            }
            
            // copy the tlk entry STRING SECTION to byte file
            offset = tlkHeader.offsetToStringData; 
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                System.Buffer.BlockCopy(tlkEntry.textByteData, 0, byteFile, offset + tlkEntry.offsetToString, tlkEntry.stringLength);
            }
            
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(DlgHeader header, ArrayList stateTables, ArrayList transitionTables, ArrayList stateTriggers, ArrayList transitionTriggers, ArrayList actionTables, byte[] stringSection, String filePath)
        {
            byte[] byteFile = new byte[
                DlgHeader.size + 
                stateTables.Count * DlgStateTable.size + 
                transitionTables.Count * DlgTransitionTable.size + 
                stateTriggers.Count * DlgStateTrigger.size +  
                transitionTriggers.Count * DlgTransitionTrigger.size + 
                actionTables.Count * DlgActionTable.size +
                stringSection.Length
            ];
            
            int offset = 0;
            byte[] bytes;
            offset += DlgHeader.size;
            
            header.offsetToStateTables = offset;
            header.numberOfStates = stateTables.Count;
            if (stateTables.Count != 0)
            {
                foreach (DlgStateTable stateTable in stateTables)
                {
                    bytes = stateTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgStateTable.size;
                }
            }

            header.offsetToTransitionTables = offset;
            header.numberOfTransitions = transitionTables.Count;
            if (transitionTables.Count != 0)
            {
                foreach (DlgTransitionTable transitionTable in transitionTables)
                {
                    bytes = transitionTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgTransitionTable.size;
                }
            }

            header.offsetToStateTriggerTables = offset;
            header.numberOfStateTriggers = stateTriggers.Count;
            if (stateTriggers.Count != 0)
            {
                foreach (DlgStateTrigger stateTrigger in stateTriggers)
                {
                    bytes = stateTrigger.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgStateTrigger.size;
                }
            }
            
            header.offsetToTransitionTriggerTables = offset;
            header.numberOfTransitionTriggers = transitionTriggers.Count;
            if (transitionTriggers.Count != 0)
            {
                foreach (DlgTransitionTrigger transitionTrigger in transitionTriggers)
                {
                    bytes = transitionTrigger.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgTransitionTrigger.size;
                }
            }
            
            header.offsetToActionTables = offset;
            header.numberOfActions = actionTables.Count;
            if (actionTables.Count != 0)
            {
                foreach (DlgActionTable actionTable in actionTables)
                {
                    bytes = actionTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgActionTable.size;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);
            
            System.Buffer.BlockCopy(stringSection, 0, byteFile, offset, stringSection.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(WmpHeader header, ArrayList worldMapEntries, ArrayList areaEntries, ArrayList areaLinkEntries, String filePath)
        {
            byte[] byteFile = new byte[
                WmpHeader.size + 
                worldMapEntries.Count * WmpWorldMapEntry.size + 
                areaEntries.Count * WmpAreaEntry.size + 
                areaLinkEntries.Count * WmpAreaLinkEntry.size
            ];
            
            int offset = 0;
            byte[] bytes;
            offset += WmpHeader.size;
            
            header.worldmapEntriesOffset = offset;
            header.worldmapEntriesCount = worldMapEntries.Count;
            if (worldMapEntries.Count != 0)
            {
                foreach (WmpWorldMapEntry worldmapEntry in worldMapEntries)
                {
                    bytes = worldmapEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpWorldMapEntry.size;

                    worldmapEntry.areaEntriesOffset = WmpWorldMapEntry.size * worldMapEntries.Count;
                    worldmapEntry.areaEntriesCount = areaEntries.Count;
                    worldmapEntry.areaLinkEntriesOffset = WmpWorldMapEntry.size * worldMapEntries.Count + WmpAreaEntry.size * areaEntries.Count;
                    worldmapEntry.areaLinkEntriesCount = areaLinkEntries.Count;
                }
            }

            if (areaEntries.Count != 0)
            {
                foreach (WmpAreaEntry areaEntry in areaEntries)
                {
                    bytes = areaEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpAreaEntry.size;
                }
            }
            
            if (areaLinkEntries.Count != 0)
            {
                foreach (WmpAreaLinkEntry areaLinkEntry in areaLinkEntries)
                {
                    bytes = areaLinkEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpAreaLinkEntry.size;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(StoHeader header, ArrayList drinks, ArrayList itemsForSale, ArrayList cures, ArrayList itemsPurchased, String filePath)
        {
            byte[] byteFile = new byte[
                StoHeader.size +
                drinks.Count * StoDrink.size + 
                itemsForSale.Count * StoItem.size +
                cures.Count * StoCure.size +
                itemsPurchased.Count * 4
            ];

            int offset = 0;
            byte[] bytes;
            offset += StoHeader.size;

            header.drinksForSaleOffset = offset;
            header.drinksForSaleCount = drinks.Count;
            if (drinks.Count != 0)
            {
                foreach (StoDrink drink in drinks)
                {
                    bytes = drink.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoDrink.size;
                }
            }
            
            header.itemsForSaleOffset = offset;
            header.itemsForSaleCount = itemsForSale.Count;
            if (itemsForSale.Count != 0)
            {
                foreach (StoItem item in itemsForSale)
                {
                    bytes = item.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoItem.size;
                }
            }
            
            header.curesForSaleOffset = offset;
            header.curesForSaleCount = cures.Count;
            if (cures.Count != 0)
            {
                foreach (StoCure cure in cures)
                {
                    bytes = cure.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoCure.size;
                }
            }
            
            header.itemsPurchasedOffset = offset;
            header.itemsPurchasedCount = itemsPurchased.Count;
            if (itemsPurchased.Count != 0)
            {
                foreach (int item in itemsPurchased)
                {
                    System.Buffer.BlockCopy(BitConverter.GetBytes(item), 0, byteFile, offset, 4);
                    offset += 4;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(
            AreHeader areHeaderModded,
            ArrayList areActorsModded,
            ArrayList areTriggersModded,
            ArrayList areSpawnPointsModded,
            ArrayList areEntrancesModded,
            ArrayList areContainersModded,
            ArrayList areItemsModded,
            ArrayList areVerticesModded,
            ArrayList areAmbientsModded,
            ArrayList areVariablesModded,
            byte[] areExploredBitmasksModded,
            ArrayList areDoorsModded,
            ArrayList areAnimationsModded,
            ArrayList areTiledObjectsModded,
            AreSong areSongModded,
            AreRestEncounter areRestEncounterModded,
            ArrayList areAutomapNotesModded,
            ArrayList areProjectileTrapsModded,
            String filePath
        )
        {
            byte[] byteFile = new byte[
                AreHeader.size +
                areActorsModded.Count * AreActor.size + 
                areTriggersModded.Count * AreTrigger.size + 
                areSpawnPointsModded.Count * AreSpawnPoint.size +
                areEntrancesModded.Count * AreEntrance.size +
                areContainersModded.Count * AreContainer.size +
                areItemsModded.Count * AreItem.size +
                areVerticesModded.Count * AreVertex.size +
                areAmbientsModded.Count * AreAmbient.size +
                areVariablesModded.Count * AreVariable.size +
                areExploredBitmasksModded.Length +
                areDoorsModded.Count * AreDoor.size +
                areAnimationsModded.Count * AreAnimation.size +
                areTiledObjectsModded.Count * AreTiledObject.size +
                AreSong.size +
                AreRestEncounter.size +
                areAutomapNotesModded.Count * AreAutomapNote.size +
                areProjectileTrapsModded.Count * AreProjectileTrap.size
            ];

            int offset = 0;
            byte[] bytes;
            offset += AreHeader.size;

            areHeaderModded.offsetActors = offset;
            areHeaderModded.numberOfActors = (short)areActorsModded.Count;
            if (areActorsModded.Count != 0)
            {
                foreach (AreActor element in areActorsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreActor.size;
                }
            }
            
            areHeaderModded.offsetTriggers = offset;
            areHeaderModded.numberOfTrigger = (short)areTriggersModded.Count;
            if (areTriggersModded.Count != 0)
            {
                foreach (AreTrigger element in areTriggersModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreTrigger.size;
                }
            }
            
            areHeaderModded.offsetSpawnPoints = offset;
            areHeaderModded.numberOfSpawnPoints = (short)areSpawnPointsModded.Count;
            if (areSpawnPointsModded.Count != 0)
            {
                foreach (AreSpawnPoint element in areSpawnPointsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreSpawnPoint.size;
                }
            }
            
            areHeaderModded.offsetEntrances = offset;
            areHeaderModded.numberOfEntraces = (short)areEntrancesModded.Count;
            if (areEntrancesModded.Count != 0)
            {
                foreach (AreEntrance element in areEntrancesModded)
                {
                    // Console.WriteLine(areHeaderModded.offsetEntrances + offset);
                    // Console.WriteLine(filePath + ":" + element.name);
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreEntrance.size;
                }
            }
            
            areHeaderModded.offsetContainers = offset;
            areHeaderModded.numberOfContainers = (short)areContainersModded.Count;
            if (areContainersModded.Count != 0)
            {
                foreach (AreContainer element in areContainersModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreContainer.size;
                }
            }
            
            areHeaderModded.offsetItems = offset;
            areHeaderModded.numberOfItems = (short)areItemsModded.Count;
            if (areItemsModded.Count != 0)
            {
                foreach (AreItem element in areItemsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreItem.size;
                }
            }
            
            areHeaderModded.offsetVertices = offset;
            areHeaderModded.numberOfVertices = (short)areVerticesModded.Count;
            if (areVerticesModded.Count != 0)
            {
                foreach (AreVertex element in areVerticesModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreVertex.size;
                }
            }
            
            areHeaderModded.offsetAmbients = offset;
            areHeaderModded.numberOfAmbients = (short)areAmbientsModded.Count;
            if (areAmbientsModded.Count != 0)
            {
                foreach (AreAmbient element in areAmbientsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreAmbient.size;
                }
            }
            
            areHeaderModded.offsetVariables = offset;
            areHeaderModded.numberOfVariables = (short)areVariablesModded.Count;
            if (areVariablesModded.Count != 0)
            {
                foreach (AreVariable element in areVariablesModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreVariable.size;
                }
            }

            areHeaderModded.exploredBitmaskOffset = offset;
            areHeaderModded.exploredBitmaskSize = areExploredBitmasksModded.Length;
            if (areExploredBitmasksModded.Length != 0)
            {
                // Console.WriteLine(byteFile.Length + " " + areHeaderModded.exploredBitmaskOffset + " " + areHeaderModded.exploredBitmaskSize);
                System.Buffer.BlockCopy(areExploredBitmasksModded, 0, byteFile, offset, areHeaderModded.exploredBitmaskSize);
                offset += areHeaderModded.exploredBitmaskSize;
            }
            
            areHeaderModded.offsetDoors = offset;
            areHeaderModded.numberOfDoors = (short)areDoorsModded.Count;
            if (areDoorsModded.Count != 0)
            {
                foreach (AreDoor element in areDoorsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreDoor.size;
                }
            }
            
            areHeaderModded.offsetAnimations = offset;
            areHeaderModded.numberOfAnimations = (short)areAnimationsModded.Count;
            if (areAnimationsModded.Count != 0)
            {
                foreach (AreAnimation element in areAnimationsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreAnimation.size;
                }
            }
            
            areHeaderModded.offsetTiledObjects = offset;
            areHeaderModded.numberOfTiledObjects = (short)areTiledObjectsModded.Count;
            if (areTiledObjectsModded.Count != 0)
            {
                foreach (AreTiledObject element in areTiledObjectsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreTiledObject.size;
                }
            }
            
            areHeaderModded.songsOffset = offset;
            bytes = areSongModded.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += AreSong.size;
            
            areHeaderModded.restEncountersOffset = offset;
            bytes = areRestEncounterModded.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += AreRestEncounter.size;

            areHeaderModded.automapNotesOffset = offset;
            areHeaderModded.numberOfAutomapNotes = (short)areAutomapNotesModded.Count;
            if (areAutomapNotesModded.Count != 0)
            {
                foreach (AreAutomapNote element in areAutomapNotesModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreAutomapNote.size;
                }
            }
            
            areHeaderModded.offsetProjectileTraps = offset;
            areHeaderModded.numberOfProjectileTraps = (short)areProjectileTrapsModded.Count;
            if (areProjectileTrapsModded.Count != 0)
            {
                foreach (AreProjectileTrap element in areProjectileTrapsModded)
                {
                    bytes = element.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += AreProjectileTrap.size;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            bytes = areHeaderModded.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
    }
}