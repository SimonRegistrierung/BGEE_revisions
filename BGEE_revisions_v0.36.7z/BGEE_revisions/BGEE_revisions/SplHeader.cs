﻿using System;
using System.Text;

namespace BGEE_revisions
{
    // Signature (‘SPL  ’)
    // Version (‘V1 ‘)
    // Spell Name - Unidentified (strref)
    // Spell Name - Identified (strref) (usually -1)
    // Completion Sound
    // Flags
    // Spell type: 0 = Special 1 = Wizard 2 = Cleric 3 = Psionic 4 = Innate 5 = Bardsong
    // Exclusion Flags
    // Casting Graphics
    // Min Level (unused)
    // Primary Type (School) (IWD: school.2da, BG2:mschool.2da)
    // Min Strength (unused)
    // Secondary Type (BG2:msectype.2da)
    // Min Strength Bonus (unused)
    // Usability 1 (unused)
    // Min Int (unused)
    // Usability 2 (unused)
    // Min Dex (unused)
    // Usability 3 (unused)
    // Min Wis (unused)
    // Usability 4 (unused)
    // Min Con (unused)
    // Min Cha (unused)
    // Spell level
    // Stack amount (unused)
    // Spellbook icon (BAM). The engine replaces the last character of this filename with a C.
    // Lore to ID (unused)
    // Ground icon (unused)
    // Weight (unused)
    // Spell Description - Unidentified (strref)
    // Spell Description - Identified (strref) (usually -1)
    // Description icon (unused)
    // Enchantment (unused)
    // Extended Header offset
    // Extended Header count
    // Feature Block Table offset
    // Casting Feature Block offset (these feature blocks may not use target type 2)
    // Casting Feature Block count
    
    internal class SplHeader
    {
        internal static int size = 114; // header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String signature;
        internal String version;
        internal int spellNameUnId;
        internal int spellNameId;
        internal String castingSound;
        internal int flags;
        internal short spellType;
        internal int exclusionFlags;
        internal short castingGraphics;
        internal byte unused1;
        internal byte primaryTypeSchool;
        internal byte unused2;
        internal byte secondaryTypeSchool;
        internal byte[] unused3;
        internal int spellLevel;
        internal byte[] unused4;
        internal String spellBookIcon;
        internal byte[] unused5;
        internal byte[] unused6;
        internal byte[] unused7;
        internal int spellDescriptionUnId;
        internal int spellDescriptionId;
        internal String descriptionIcon;
        internal byte[] unused8;
        internal int extendedHeaderOffset;
        internal short extendedHeaderCount;
        internal int featureBlockTableOffset;
        internal short castingFeatureBlockIndex;
        internal short castingFeatureBlockCount;

        internal SplHeader(byte[] byteArray)
        {
            baseOffset = 0; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            signature = ConvertToStringData(4);
            version = ConvertToStringData(4);
            spellNameUnId = ConvertToIntData();
            spellNameId = ConvertToIntData();
            castingSound = ConvertToStringData(8);
            flags = ConvertToIntData();
            spellType = ConvertToShortData();
            exclusionFlags = ConvertToIntData();
            castingGraphics = ConvertToShortData();
            unused1 = ConvertToByteData();
            primaryTypeSchool = ConvertToByteData();
            unused2 = ConvertToByteData();
            secondaryTypeSchool = ConvertToByteData();
            unused3 = ConvertToUnknownData(12);
            spellLevel = ConvertToIntData();
            unused4 = ConvertToUnknownData(2);
            spellBookIcon = ConvertToStringData(8);
            unused5 = ConvertToUnknownData(2);
            unused6 = ConvertToUnknownData(8);
            unused7 = ConvertToUnknownData(4);
            spellDescriptionUnId = ConvertToIntData();
            spellDescriptionId = ConvertToIntData();
            descriptionIcon = ConvertToStringData(8);
            unused8 = ConvertToUnknownData(4);
            extendedHeaderOffset = ConvertToIntData();
            extendedHeaderCount = ConvertToShortData();
            featureBlockTableOffset = ConvertToIntData();
            castingFeatureBlockIndex = ConvertToShortData();
            castingFeatureBlockCount = ConvertToShortData();

            size = baseOffset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(signature);
            CopyBytesToArray(version);
            CopyBytesToArray(spellNameUnId);
            CopyBytesToArray(spellNameId);
            CopyBytesToArray(castingSound);
            CopyBytesToArray(flags);
            CopyBytesToArray(spellType);
            CopyBytesToArray(exclusionFlags);
            CopyBytesToArray(castingGraphics);
            CopyBytesToArray(unused1);
            CopyBytesToArray(primaryTypeSchool);
            CopyBytesToArray(unused2);
            CopyBytesToArray(secondaryTypeSchool);
            CopyBytesToArray(unused3);
            CopyBytesToArray(spellLevel);
            CopyBytesToArray(unused4);
            CopyBytesToArray(spellBookIcon);
            CopyBytesToArray(unused5);
            CopyBytesToArray(unused6);
            CopyBytesToArray(unused7);
            CopyBytesToArray(spellDescriptionUnId);
            CopyBytesToArray(spellDescriptionId);
            CopyBytesToArray(descriptionIcon);
            CopyBytesToArray(unused8);
            CopyBytesToArray(extendedHeaderOffset);
            CopyBytesToArray(extendedHeaderCount);
            CopyBytesToArray(featureBlockTableOffset);
            CopyBytesToArray(castingFeatureBlockIndex);
            CopyBytesToArray(castingFeatureBlockCount);

            return byteArray;
        }
        
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine(signature);
            Console.WriteLine(version);
            Console.WriteLine(spellNameUnId);
            Console.WriteLine(spellNameId);
            Console.WriteLine(castingSound);
            Console.WriteLine(flags);
            Console.WriteLine(spellType);
            Console.WriteLine(exclusionFlags);
            Console.WriteLine(castingGraphics);
            Console.WriteLine(unused1);
            Console.WriteLine(primaryTypeSchool);
            Console.WriteLine(unused2);
            Console.WriteLine(secondaryTypeSchool);
            Console.WriteLine(unused3);
            Console.WriteLine(spellLevel);
            Console.WriteLine(unused4);
            Console.WriteLine(spellBookIcon);
            Console.WriteLine(unused5);
            Console.WriteLine(unused6);
            Console.WriteLine(unused7);
            Console.WriteLine(spellDescriptionUnId);
            Console.WriteLine(spellDescriptionId);
            Console.WriteLine(descriptionIcon);
            Console.WriteLine(unused8);
            Console.WriteLine(extendedHeaderOffset);
            Console.WriteLine(extendedHeaderCount);
            Console.WriteLine(featureBlockTableOffset);
            Console.WriteLine(castingFeatureBlockIndex);
            Console.WriteLine(castingFeatureBlockCount);
        }
    }
}