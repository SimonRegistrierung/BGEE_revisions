﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace BGEE_revisions
{
    internal class ItmFeatBlock
    {
        internal static int size = 48; // feature block size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal short opcodeNumber;
        internal byte targetType;
        internal byte power;
        internal int parameter1;
        internal int parameter2;
        internal short parameter21;
        internal short parameter22;
        internal byte parameter23;
        internal byte parameter24;
        internal byte parameter25;
        internal byte parameter26;
        internal byte timingMode;
        internal byte resistance;
        internal int duration;
        internal byte probability1;
        internal byte probability2;
        internal String resource;
        internal int diceThrown;
        internal int diceSides;
        internal int savingThrowType;
        internal int savingThrowBonus;
        internal int stackingId;

        // manual FeatureBlock Generation
        internal ItmFeatBlock(short opcodeNumber, byte targetType, byte power, int parameter1, int parameter2, byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource, int diceThrown, int diceSides, int savingThrowType, int savingThrowBonus, int stackingId)
        {
            this.opcodeNumber = opcodeNumber;
            this.targetType = targetType;
            this.power = power;
            this.parameter1 = parameter1;
            this.parameter2 = parameter2;
            this.timingMode = timingMode;
            this.resistance = resistance;
            this.duration = duration;
            this.probability1 = probability1;
            this.probability2 = probability2;
            this.resource = resource;
            this.diceThrown = diceThrown;
            this.diceSides = diceSides;
            this.savingThrowType = savingThrowType;
            this.savingThrowBonus = savingThrowBonus;
            this.stackingId = stackingId;
        }
        
        // manual FeatureBlock Generation
        internal ItmFeatBlock(short opcodeNumber, byte targetType, byte power, int parameter1, short parameter21, short parameter22, byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource, int diceThrown, int diceSides, int savingThrowType, int savingThrowBonus, int stackingId)
        {
            this.opcodeNumber = opcodeNumber;
            this.targetType = targetType;
            this.power = power;
            this.parameter1 = parameter1;
            this.parameter21 = parameter21;
            this.parameter22 = parameter22;
            this.timingMode = timingMode;
            this.resistance = resistance;
            this.duration = duration;
            this.probability1 = probability1;
            this.probability2 = probability2;
            this.resource = resource;
            this.diceThrown = diceThrown;
            this.diceSides = diceSides;
            this.savingThrowType = savingThrowType;
            this.savingThrowBonus = savingThrowBonus;
            this.stackingId = stackingId;
        }
        // manual FeatureBlock Generation
        internal ItmFeatBlock(short opcodeNumber, byte targetType, byte power, int parameter1, byte parameter23, byte parameter24, byte parameter25, byte parameter26, byte timingMode, byte resistance, int duration, byte probability1, byte probability2, String resource, int diceThrown, int diceSides, int savingThrowType, int savingThrowBonus, int stackingId)
        {
            this.opcodeNumber = opcodeNumber;
            this.targetType = targetType;
            this.power = power;
            this.parameter1 = parameter1;
            this.parameter23 = parameter23;
            this.parameter24 = parameter24;
            this.parameter25 = parameter25;
            this.parameter26 = parameter26;
            this.timingMode = timingMode;
            this.resistance = resistance;
            this.duration = duration;
            this.probability1 = probability1;
            this.probability2 = probability2;
            this.resource = resource;
            this.diceThrown = diceThrown;
            this.diceSides = diceSides;
            this.savingThrowType = savingThrowType;
            this.savingThrowBonus = savingThrowBonus;
            this.stackingId = stackingId;
        }
        
        // automatic FeatureBlock Generation
        internal ItmFeatBlock(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            opcodeNumber = ConvertToShortData();
            targetType = ConvertToByteData();
            power = ConvertToByteData();
            parameter1 = ConvertToIntData();
            if (opcodeNumber == 12 || opcodeNumber == 233)
            {
                parameter21 = ConvertToShortData();
                parameter22 = ConvertToShortData();
            }
            else if (opcodeNumber == 50 || opcodeNumber == 61)
            {
                parameter23 = ConvertToByteData();
                parameter24 = ConvertToByteData();
                parameter25 = ConvertToByteData();
                parameter26 = ConvertToByteData();
            }
            else
            {
                parameter2 = ConvertToIntData();
            }
            timingMode = ConvertToByteData();
            resistance = ConvertToByteData();
            duration = ConvertToIntData();
            probability1 = ConvertToByteData();
            probability2 = ConvertToByteData();
            resource = ConvertToStringData(8);
            diceThrown = ConvertToIntData();
            diceSides = ConvertToIntData();
            savingThrowType = ConvertToIntData();
            savingThrowBonus = ConvertToIntData();
            stackingId = ConvertToIntData();

            size = baseOffset - offset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }
        
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal long ConvertToLongData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 8; // increase baseOffset 8 bytes
            return BitConverter.ToInt64(byteArray, currentOffset);
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }
        
        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(opcodeNumber);
            CopyBytesToArray(targetType);
            CopyBytesToArray(power);
            CopyBytesToArray(parameter1);
            if (opcodeNumber == 12 || opcodeNumber == 233)
            {
                CopyBytesToArray(parameter21);
                CopyBytesToArray(parameter22);
            }
            else if (opcodeNumber == 50 || opcodeNumber == 61)
            {
                CopyBytesToArray(parameter23);
                CopyBytesToArray(parameter24);
                CopyBytesToArray(parameter25);
                CopyBytesToArray(parameter26);
            }
            else
            {
                CopyBytesToArray(parameter2);
            }
            
            CopyBytesToArray(timingMode);
            CopyBytesToArray(resistance);
            CopyBytesToArray(duration);
            CopyBytesToArray(probability1);
            CopyBytesToArray(probability2);
            CopyBytesToArray(resource);
            CopyBytesToArray(diceThrown);
            CopyBytesToArray(diceSides);
            CopyBytesToArray(savingThrowType);
            CopyBytesToArray(savingThrowBonus);
            CopyBytesToArray(stackingId);
            
            return byteArray;
        }
        
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(long variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
        
        internal void PrintValues()
        {
            Console.WriteLine("opcodeNumber:\t" + opcodeNumber);
            Console.WriteLine("targetType:\t" + targetType);
            Console.WriteLine("power:\t" + power);
            Console.WriteLine("parameter1:\t" + parameter1);
            Console.WriteLine("parameter2:\t" + parameter2);
            Console.WriteLine("timingMode:\t" + timingMode);
            Console.WriteLine("resistance:\t" + resistance);
            Console.WriteLine("duration:\t" + duration);
            Console.WriteLine("probability1:\t" + probability1);
            Console.WriteLine("probability2:\t" + probability2);
            Console.WriteLine("resource:\t" + resource);
            Console.WriteLine("diceThrown:\t" + diceThrown);
            Console.WriteLine("diceSides:\t" + diceSides);
            Console.WriteLine("savingThrowType:\t" + savingThrowType);
            Console.WriteLine("savingThrowBonus:\t" + savingThrowBonus);
            Console.WriteLine("stackingId:\t" + stackingId);
        }
    }
}