﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        public static void RunIds()
        {
            // add frost ray
            if (ContainsCaseInsensitive(currentIdsFileInfo.Name, "PROJECTL."))
            {
                proFrostRayId = (short)(idsFile.lastId + 1);
                // Console.WriteLine(proFrostRayId);
                idsFile.AddNewLine(proFrostRayId + " " + "frostray");
                proFrostRayId++; // increase by one to facilitate the inclusion in the spell/item header (an id of 10, needs to be referenced as 11 in the header file)
                FileOperations.WriteFileAsString(idsFile.rawContent, idsOutputPath + "/" + currentIdsFileInfo.Name);
            }
        }
    }
}