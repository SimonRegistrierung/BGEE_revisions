﻿using System;
using System.Text;

namespace BGEE_revisions
{
    // Offset	Size (data type)	Description
    // 0x0000	4 (dword)	offset from start of file to state trigger string.
    // 0x0004	4 (dword)	length in bytes of the state trigger string.
    internal class DlgStateTrigger
    {
        internal static int size = 8; // header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal int strOffset;
        internal int strLength;
        internal String str;
        internal byte[] strByteData;

        internal DlgStateTrigger(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            strOffset = ConvertToIntData();
            strLength = ConvertToIntData();
            str = ConvertToStringData(strOffset, strLength);
            strByteData = addByteData(byteArray);

            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }
        
        internal byte[] addByteData(byte[] originalByteArray)
        {
            byte[] byteData = new byte[strLength];
            System.Buffer.BlockCopy(originalByteArray, strOffset, byteData,0,strLength);
            return byteData;
        }
        internal String ConvertToStringData(int offset, int stringLength)
        {
            return Encoding.ASCII.GetString(byteArray, offset, stringLength);
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(strOffset);
            CopyBytesToArray(strLength);

            return byteArray;
        }
        internal byte[] GetByteStringData()
        {
            return strByteData;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
        
        internal void UpdateInstance(int newOffset, String newString)
        {
            strLength = newString.Length;
            strOffset = newOffset;
            str = newString;
            strByteData = new byte[strLength];
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(str), 0, strByteData, 0, strLength);
        }

        internal void PrintValues()
        {
            Console.WriteLine("offsetToStateTriggerString:\t" + strOffset);
            Console.WriteLine("lengthOfStateTriggerString:\t" + strLength);
            Console.WriteLine("stateTriggerString:\t" + str);
        }
    }
}