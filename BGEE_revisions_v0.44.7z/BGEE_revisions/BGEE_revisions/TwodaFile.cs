﻿using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal class TwodaFile
    {
        internal String rawContent;
        internal int fileType;
        internal ArrayList twodaLines = new ArrayList();
        
        internal int numAbilities;

        internal String lineId = @"(^)(.*)($)";
        internal String spellLineId = @"(^\d+)( |\t)+(.+)($)";
        internal String abilityLineId = @"(^)(ABILITY)(\d+)?.*$";
        internal String generalId = "2DA *V1.0";
        internal String exception = "Could not identify 2da file type";
        
        internal Boolean identified = false;
        
        internal TwodaFile(String content)
        {
            rawContent = content;
            Identify();
            // foreach (TwodaLine twodaLine in twodaLines)
            // {
            //     Console.WriteLine(twodaLine.isContent + " " + twodaLine.content);
            // }
        }
        
        internal void Identify()
        {
            MatchCollection mc = Regex.Matches(rawContent, lineId, RegexOptions.Multiline);
            int lineCount = mc.Count;
            int lineIndex = 0;
            if (lineCount > 0) // identify the lines
            {
                if (Regex.Match(rawContent, spellLineId, RegexOptions.Multiline).Success) // if it' a spell File
                {
                    identified = true;
                    fileType = 0;
                    foreach (Match m in mc)
                    {
                        if (Regex.Match(m.Value, spellLineId, RegexOptions.Multiline).Success) // if it' a spell File
                        {
                            twodaLines.Add(new TwodaLine(lineIndex, true, m.Value));
                        }
                        else
                        {
                            twodaLines.Add(new TwodaLine(lineIndex, false, m.Value));
                        }
                        lineIndex++;
                    }
                }
                else if (Regex.Match(rawContent, abilityLineId, RegexOptions.Multiline).Success) // if it' a spell File
                {
                    identified = true;
                    fileType = 1;
                    foreach (Match m in mc)
                    {
                        if (Regex.Match(m.Value, abilityLineId, RegexOptions.Multiline).Success) // if it' a ability File
                        {
                            twodaLines.Add(new TwodaLine(lineIndex, true, m.Value));
                        }
                        else
                        {
                            twodaLines.Add(new TwodaLine(lineIndex, false, m.Value));
                        }
                        lineIndex++;
                    }
                }
                else if (Regex.Match(rawContent, generalId, RegexOptions.Multiline).Success) // if it' a spell File
                {
                    identified = true;
                    fileType = 2;
                    foreach (Match m in mc)
                    {
                        if (Regex.Match(m.Value, "^.*$", RegexOptions.Multiline).Success) // if it' a ability File
                        {
                            twodaLines.Add(new TwodaLine(lineIndex, true, m.Value));
                        }
                        else
                        {
                            twodaLines.Add(new TwodaLine(lineIndex, false, m.Value));
                        }
                        lineIndex++;
                    }
                }
                else
                {
                    identified = false;
                    fileType = 3;
                    foreach (Match m in mc)
                    {
                        twodaLines.Add(new TwodaLine(lineIndex, true, m.Value));
                        lineIndex++;
                    }
                }
            }

            // if we could not identify the file type
            // if (!identified)
            // {
            //     throw new Exception(exception);
            // }
        }

        internal void RemoveEmptyLines()
        {
            for (int i = twodaLines.Count - 1; i >= 0; i--)
            {
                TwodaLine currentLine = (TwodaLine) twodaLines[i];
                if (Regex.Match(currentLine.content, "^( )*?$", RegexOptions.Multiline).Success)
                {
                    // Console.WriteLine("Removed Line");
                    twodaLines.RemoveAt(i);
                }
            }
        }

        internal void UpdateRawContent()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (TwodaLine twodaLine in twodaLines)
            {
                stringBuilder.Append(twodaLine.content + "\n");
            }

            rawContent = stringBuilder.ToString();
            RemoveEmptyLines();
        }

        internal void UpdateLine(String newContent, int index)
        {
            TwodaLine currentLine = (TwodaLine)twodaLines[index];
            currentLine.content = newContent;
            twodaLines[index] = currentLine;

            UpdateRawContent();
        }

        internal void AddLine(TwodaLine newLine)
        {
            if (Regex.Match(newLine.content, @"ABILITY\d+", RegexOptions.Multiline).Success)
            {
                Match m = Regex.Match(newLine.content, @"ABILITY\d+", RegexOptions.Multiline);
                newLine.content = newLine.content.Replace(m.Value, "ABILITY ");
            }
            twodaLines.Add(newLine);
            
            UpdateRawContent();
        }
    }
}