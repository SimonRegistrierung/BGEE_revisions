﻿using System;

namespace BGEE_revisions
{
    internal class TwodaLine
    {
        internal int index;
        internal Boolean isContent; // 0 = no moddable content , 1 moddable content
        internal String content;
        
        internal TwodaLine(int index, Boolean isContent, String content)
        {
            this.index = index;
            this.isContent = isContent;
            this.content = content;
        }
    }
}