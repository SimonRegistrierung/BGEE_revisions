﻿using System;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlk()
        {
            // spl mods
            RunTlkSpl();
            RunTlkItm();
            RunTlkMisc();

            // write file
            FileOperations.WriteFile(tlkHeader, tlkEntries, tlkOutputPath);
        }
        
        internal static void EditExistingTlkEntry(String identifier, String regex, String repl, Boolean isStart, Boolean isEnd)
        {
            Boolean spellFound = false;
            Boolean regexFound = false;
            
            int tlkIndex = 0;
            int[] tlkNewOffsets = new int[tlkHeader.numberOfStrRefs];
            for (int i = 0; i < tlkEntries.Count; i++)
            {
                TlkEntry currentTlkEntry = (TlkEntry) tlkEntries[i];

                Match match = Regex.Match(currentTlkEntry.textString, identifier, RegexOptions.Multiline);
                if (isStart)
                {
                    match = Regex.Match(currentTlkEntry.textString, @"\A" + identifier, RegexOptions.Multiline);
                }

                if (isEnd)
                {
                    match = Regex.Match(currentTlkEntry.textString, identifier + @"\Z", RegexOptions.Multiline);
                }
                
                if (match.Success)
                {
                    // Console.WriteLine("Found spell...");
                    spellFound = true;
                    String oldString = currentTlkEntry.textString;
                    String newString = "";
                    int newOffsetDeltaNextEntry = 0;
                    MatchCollection matches = Regex.Matches(currentTlkEntry.textString, regex, RegexOptions.Multiline);
                    if (matches.Count != 0)
                    {
                        regexFound = true;
                        Console.WriteLine("Found regex pattern, patching...");

                        Boolean firstRun = true;
                        foreach (Match m in matches)
                        {
                            // Console.WriteLine("OLDTEXT:\n========\n" + m.Value + "\nNEWTEXT:\n========\n" + repl);
                            if (firstRun)
                            {
                                newString = oldString.Remove(m.Index, m.Length).Insert(m.Index, repl);
                            }
                            else
                            {
                                newString = newString.Remove(m.Index, m.Length).Insert(m.Index, repl);
                            }

                            firstRun = false;
                        }

                        int newLength = newString.Length;
                        currentTlkEntry.UpdateInstance(0, newLength, newString); // keep the offset for the current tlkEntry
                    }
                }
            }

            if (!spellFound || !regexFound)
            {
                Console.WriteLine("**** DEBUG RELEVANT: NOTHING FOUND ****");
            }
        }
        
        internal static void EditExistingTlkEntry(int tlkIndex, String findStr, String repl)
        {
            TlkEntry currentTlkEntry = (TlkEntry)tlkEntries[tlkIndex];
            Boolean firstRun = true;
            String oldString = currentTlkEntry.textString;
            String newString = currentTlkEntry.textString.Replace(findStr, repl);
            
            // Console.WriteLine(tlkIndex);
            
            // error control: check if the old string length calculated via the string is different from the pre-set size within the byte file
            // we need to make sure here, that the preset size takes precedence over the newly calculated length of the string via C#
            //
            int newLength = 0;
            if (oldString.Length != currentTlkEntry.stringLength)
            {
                if (newString.Length < oldString.Length)
                {
                    newLength = currentTlkEntry.stringLength - (oldString.Length - newString.Length);
                }
                else if (newString.Length > oldString.Length)
                {
                    newLength = currentTlkEntry.stringLength + (newString.Length - oldString.Length);
                }
                else
                {
                    newLength = currentTlkEntry.stringLength;
                }
            }
            else
            {
                newLength = newString.Length;
            }
            currentTlkEntry.UpdateInstance(0, newLength, newString); // keep the offset for the current tlkEntry
        }
        
        internal static int FindFirstExactTlkEntry(String findStr)
        {
            index = 0;
            Regex regex = new Regex(@"\A" + findStr + @"\Z");
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            // Console.WriteLine("WARNING: Could not find exact tlk entry:\n" + 
            //                   "\"" + findStr + "\"" +
            //                   "\nAdding item to tlk file...");
            // if we don't find it, add it and return the new index
            // AddTlkEntry(findStr);
            // return tlkHeader.numberOfStrRefs - 1;
            throw new Exception("Did not find first exact tlk entry: \"" + findStr + "\"");
        }
        
        internal static int AddExactTlkEntryIfNotFound(String findStr)
        {
            index = 0;
            Regex regex = new Regex(@"\A" + findStr + @"\Z");
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            Console.WriteLine("WARNING: Could not find exact tlk entry:\n" + 
                              "\"" + findStr + "\"" +
                              "\nAdding item to tlk file...");
            // if we don't find it, add it and return the new index
            AddTlkEntry(findStr);
            return tlkHeader.numberOfStrRefs - 1;
            // throw new Exception("Did not find first exact tlk entry: \"" + findStr + "\"");
        }
        
        internal static int FindFirstMatchingTlkEntry(String findStr)
        {
            index = 0;
            Regex regex = new Regex(findStr);
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                Match match = regex.Match(tlkEntry.textString);
                if (match.Success)
                {
                    return index;
                }
                index++;
            }
            throw new Exception("Did not find first matching tlk entry: \"" + findStr + "\"");
        }
        
        internal static String GetTlkStringFromStrRef(int strRef)
        {
            if (strRef == -1)
            {
                return "";
            }
            else
            {
                TlkEntry tlkEntry = (TlkEntry)tlkEntries[strRef];
                return tlkEntry.textString;
            }
        }
        
        internal static void AddTlkEntry(String addString)
        {
            TlkEntry lastEntry = (TlkEntry)tlkEntries[tlkEntries.Count - 1];
            int offset = lastEntry.offsetToString + lastEntry.stringLength;
            
            tlkEntries.Add(new TlkEntry(addString, (short)GetBitfieldInt(new int[] {0, 2}), offset));
            
            // increase the offset for all tlkentries by the size of the new entry (remember that the properties of the tlks come before the string section itself)
            // structure: header -> tlk props (offsets pointing to the location in the string section) -> string section
            tlkHeader.numberOfStrRefs++;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                tlkEntry.offsetToString += TlkEntry.size;
            }
        }
    }
}