﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static String newFileContent;
        
        internal static void RunTwoda()
        {
            // if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "MXSPL"))
            // {
            //     // Console.WriteLine(currentTwodaFileInfo.Name + "    " + twodaFile.twodaLines.Count);
            //     // foreach (TwodaLine twodaLine in twodaFile.twodaLines)
            //     // {
            //     //     Console.WriteLine(twodaLine.content + "     " + twodaLine.isContent);
            //     // }
            //     if (
            //         currentTwodaFileInfo.Name.Contains("BRD") ||
            //         currentTwodaFileInfo.Name.Contains("DD") ||
            //         currentTwodaFileInfo.Name.Contains("DRU") ||
            //         currentTwodaFileInfo.Name.Contains("PRS") ||
            //         currentTwodaFileInfo.Name.Contains("SHM") ||
            //         currentTwodaFileInfo.Name.Contains("SRC") ||
            //         currentTwodaFileInfo.Name.Contains("WIZ")
            //     )
            //     {
            //         // give spell casters +5 spells
            //         IncreaseSpells(@"(BRD|DD|DRU|PRS|SHM|SRC|WIZ)\.", 5);
            //         FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            //     }
            //     
            //     if (
            //         currentTwodaFileInfo.Name.Contains("PAL") ||
            //         currentTwodaFileInfo.Name.Contains("RAN")
            //     )
            //     {
            //         // give fighters +2 spells
            //         IncreaseSpells(@"(PAL|RAN)\.", 2);
            //         FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            //     }
            // }
            //
            // // give sorcs and shamans 10/12 spells per spell level
            // if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "SPL") && ContainsCaseInsensitive(currentTwodaFileInfo.Name, "KN."))
            // {
            //     IncreaseSpells(@"(splshmkn|splsrckn|SPLSHMKN|SPLSRCKN)\.(2da|2DA)", 7);
            //     FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            // }
            
            // double innate ability count
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "CLAB"))
            {
                DoubleInnateAbilities(@"(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO)(.*)\.(2da|2DA)");
                // Console.WriteLine("got here");
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // make edwins amulet removable
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "ITEM_USE"))
            {
                RemoveLine("MISC89");
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
        }
    }
}