﻿namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlk()
        {
            // spl mods
            RunTlkSpl();
            RunTlkItm();
            RunTlkMisc();

            // write file
            FileOperations.WriteFile(tlkHeader, tlkEntries, tlkOutputPath);
        }
    }
}