﻿using System;
using System.Linq;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunCre()
        {
            // mod shandalar
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "SHANDAL2."))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resMagic = 0;
                creHeaderModded.resMagicCold = 0;
                creHeaderModded.resMagicFire = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                creHeaderModded.currentHp = 72;
                creHeaderModded.maxHp = 72;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod borda
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "BORDA."))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resMagic = 0;
                creHeaderModded.resMagicCold = 0;
                creHeaderModded.resMagicFire = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod DRELIK
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "DRELIK."))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resMagic = 0;
                creHeaderModded.resMagicCold = 0;
                creHeaderModded.resMagicFire = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod drizzt
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "DRIZZ"))
            {
                creHeaderModded.resAcid = 0;
                creHeaderModded.resCold = 0;
                creHeaderModded.resFire = 0;
                creHeaderModded.resElectricity = 0;
                creHeaderModded.resCrushing = 0;
                creHeaderModded.resMissile = 0;
                creHeaderModded.resPiercing = 0;
                creHeaderModded.resSlashing = 0;
                creHeaderModded.dex = 12;
                creHeaderModded.acNatural = 10;
                creHeaderModded.acEffective = 10;
                creHeaderModded.repLossKilled = 0;
                creHeaderModded.classId = 1;

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // mod MARL
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "MARL."))
            {
                creHeaderModded.xpKill = 900;
                
                // creItemSlotsModded.PrintValues();
                // Console.WriteLine("==============");
                // creItemSlots.PrintValues();

                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // patch super low saving throws of creatures
            if (creHeaderModded.sound75 == -1 && creHeaderModded.sound76 == 0)
            {
                if (creHeaderModded.saveSpell < 7)
                {
                    creHeaderModded.saveSpell = 7;
                }
                if (creHeaderModded.saveBreath < 7)
                {
                    creHeaderModded.saveBreath = 7;
                }
                if (creHeaderModded.saveDeath < 7)
                {
                    creHeaderModded.saveDeath = 7;
                }
                if (creHeaderModded.savePoly < 7)
                {
                    creHeaderModded.savePoly = 7;
                }
                if (creHeaderModded.saveWands < 7)
                {
                    creHeaderModded.saveWands = 7;
                }
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // remove see through invisibility for enemies
            for (int i = creEffectsModded.Count - 1; i >= 0; i--)
            {
                CreEffect currentCreEffect = (CreEffect)creEffectsModded[i];
                if (currentCreEffect.opcode == 193)
                {
                    RemoveCreEffect(i);
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
            }
            
            // patch flaming fists to regular fighters (it's silly that you lose reputation for killing them, when they are hostile against you in Baldur's Gate after the killings of Rieltar & co (simple because you can't avoid killing them and have to bend over backwards just to prevent this from happening if you don't play evil.
            if (creHeaderModded.classId == 156 || creHeaderModded.classId == 212)
            {
                creHeaderModded.classId = 2;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }

            // prevent all non-innocent npc from affecting your rep when killed
            if (creHeaderModded.repLossKilled != 0)
            {
                creHeaderModded.repLossKilled = 0;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // prevent amnian and flaming fist soldiers from being innocent byte name
            String[] names = new[]
            {
                "Amnian", 
                "Amnish", 
                "Thayan", 
                "Bodyguard", 
                "Flaming Fist Enforcer", 
                "Flaming Fist Scout", 
                "Flaming Fist Mercenary", 
                "Flaming Fist Officer", 
                "Flaming Fist Veteran", 
                "Flaming Fist Watcher", 
                "Flaming Fist Sergeant", 
            };
            if (names.Contains(GetTlkStringFromStrRef(creHeaderModded.name)))
            {
                creHeaderModded.classId = 2;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make misc people CLERICS since they use cleric spells
            names = new[]
            {
                "Flaming Fist Healer",  
            };
            if (
                    names.Contains(GetTlkStringFromStrRef(creHeaderModded.name)) ||
                    ContainsCaseInsensitive(currentCreFileInfo.Name, "UNSHEY.")
                )
            {
                creHeaderModded.classId = 3;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make misc people DRUIDS since they use classes 
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "LASKAL"))
            {
                creHeaderModded.classId = 11;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make misc people THIEVES since they use classes 
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "BREVLI.") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "BHEREN.")
            )
            {
                creHeaderModded.classId = 205;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // // Double golems health points
            // if (ContainsCaseInsensitive(currentCreFileInfo.Name, "a7!gl"))
            // {
            //     creHeaderModded.currentHp = Convert.ToInt16(creHeaderModded.currentHp * 2);
            //     creHeaderModded.maxHp = Convert.ToInt16(creHeaderModded.maxHp * 2);
            // }
            
            // remove backstab modifier for enemies
            for (int i = creEffectsModded.Count - 1; i >= 0; i--)
            {
                CreEffect currentCreEffect = (CreEffect)creEffectsModded[i];
                if (currentCreEffect.opcode == 263)
                {
                    RemoveCreEffect(i);
                    FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                        creOutputPath + "/" + currentCreFileInfo.Name);
                }
            }
            
            // make dorn somewhat tankier 
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "DORN"))
            {
                creHeaderModded.con = 18;
                creHeaderModded.dex = 14;
                creHeaderModded.wis = 13;
                creHeaderModded.cha = 11;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                                        creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                                        creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // make minsc a more competitive with the other fighters 
            if (ContainsCaseInsensitive(currentCreFileInfo.Name, "MINSC"))
            {
                creHeaderModded.con = 18;
                creHeaderModded.strBonus = 99;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            
            // patch planetar & devas to be more nice-looking
            if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DQ#GRSOL") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FANGEL01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOL01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOL04") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLA2") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLA2") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLA3") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "FINSOLAR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SOLAR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "SOLAR01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDPPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDSOLAR") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDSPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANET01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANGOOD") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHDSPLAN") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVAGOOD") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVAST01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVMON01")
            )
            {
                creHeaderModded.animId = 32589;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
            else if (
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANEVIL") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "PLANWISH") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHBCEL02") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHBCEL03") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "OHBDVA01") ||
                ContainsCaseInsensitive(currentCreFileInfo.Name, "DEVAEVIL")
            )
            {
                creHeaderModded.animId = 32585;
                FileOperations.WriteFile(creHeaderModded, creKnownSpellsModded, creMemorizedSpellsInfosModded,
                    creMemorizedSpellsModded, creEffectsModded, creItemsModded, creItemSlotsModded,
                    creOutputPath + "/" + currentCreFileInfo.Name);
            }
        }
    }
}