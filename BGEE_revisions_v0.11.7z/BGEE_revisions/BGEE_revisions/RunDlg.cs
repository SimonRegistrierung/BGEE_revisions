﻿using System;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunDlg()
        {
            // Jared's Always gives Boots of the North
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "JARED."))
            {
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""HelpJared"",""GLOBAL"",1\)\r\nEraseJournalEntry\(227184\)", 
                    "SetGlobal(\"HelpJared\",\"GLOBAL\",1)\r\nGivePartyGold(50)\r\nGiveItem(\"BOOT03\",LastTalkedToBy)\r\nEraseJournalEntry(227184)"
                    );
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""HelpJared"",""GLOBAL"",1\)\r\nGivePartyGold\(50\)\r\nEraseJournalEntry\(227184\)", 
                    "SetGlobal(\"HelpJared\",\"GLOBAL\",1)\r\nGivePartyGold(50)\r\nGiveItem(\"BOOT03\",LastTalkedToBy)\r\nEraseJournalEntry(227184)"
                );
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""HelpJared"",""GLOBAL"",1\)\r\nGiveItem\(""BOOT03"",LastTalkedToBy\)\r\nEraseJournalEntry\(227184\)", 
                    "SetGlobal(\"HelpJared\",\"GLOBAL\",1)\r\nGivePartyGold(50)\r\nGiveItem(\"BOOT03\",LastTalkedToBy)\r\nEraseJournalEntry(227184)"
                );

                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // Melicamp never dies
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "THALAN."))
            {
                ReplaceDlgActionTableString(
                    @"ClearAllActions\(\)\r\nStartCutSceneMode\(\)\r\nTakePartyItem\(""MISC50""\)\r\nDestroyItem\(""MISC50""\)\r\nSetGlobal\(""TransformedChicken"",""GLOBAL"",1\)\r\nApplySpellRES\(""portswa2"",""Melicamp""\)\r\nWait\(1\)\r\nFaceObject\(""Melicamp""\)\r\nSmallWait\(1\)\r\nForceSpell\(""Melicamp"",EFFECT_ONLY\)\r\nSmallWait\(10\)\r\nCreateVisualEffectObject\(""SPPOLYMP"",""Melicamp""\)\r\nCreateVisualEffectObject\(""POLYBACK"",""Melicamp""\)\r\nWait\(1\)\r\nActionOverride\(""Melicamp"",Polymorph\(MAGE_MALE_HUMAN\)\)\r\nWait\(1\)\r\nKill\(""Melicamp""\)\r\nWait\(2\)\r\nEndCutSceneMode\(\)\r\nStartDialogNoSet\(LastTalkedToBy\)\r\n",
                    "ClearAllActions()\r\nStartCutSceneMode()\r\nTakePartyItem(\"MISC50\")\r\nDestroyItem(\"MISC50\")\r\nSetGlobal(\"TransformedChicken\",\"GLOBAL\",1)\r\nApplySpellRES(\"portswa2\",\"Melicamp\")\r\nWait(1)\r\nFaceObject(\"Melicamp\")\r\nSmallWait(1)\r\nForceSpell(\"Melicamp\",EFFECT_ONLY)\r\nSmallWait(10)\r\nCreateVisualEffectObject(\"SPPOLYMP\",\"Melicamp\")\r\nCreateVisualEffectObject(\"POLYBACK\",\"Melicamp\")\r\nWait(1)\r\nActionOverride(\"Melicamp\",Polymorph(MAGE_MALE_HUMAN))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,INITIAL_MEETING))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,BATTLE_CRY1))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,212354,DAMAGE))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,212348,DYING))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON1))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,220283,SELECT_COMMON2))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON3))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON4))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON5))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON6))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,PICKED_POCKET))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,HIDDEN_IN_SHADOWS))\r\nWait(2)\r\nEndCutSceneMode()\r\nStartDialogNoSet(LastTalkedToBy)\r\n"
                    );
                
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // minor golems always auto-attack on sight
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "A7!CMD3."))
            {
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""Command"",""LOCALS"",0\)",
                    "SetGlobal(\"Command\",\"LOCALS\",1)"
                );
                
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // time modding (make some dialogs' timers instant)
            if (Regex.IsMatch(currentDlgFileInfo.Name, "(THALAN|JARED|ARKION|NEMPHR|TAEROM|X#DRIZZT|MH#PHEND|MH#BROKK)", RegexOptions.Multiline))
            {
                ReplaceDlgActionTableString(
                    @"(?<=,)(\w+_(DAY|HOUR|MINUTE)|XAROM_TIMER|600)(S)?(?=\))",
                    "1"
                );
            
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // make golems accessible early for mages
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "A7!SMDLG."))
            {
                for (int i = 0; i < dlgTransitionTriggersModded.Count; i++)
                {
                    if (FindDlgTransitionTriggerString(@"(?<=\!)Kit\(LastTalkedToBy,MAGESCHOOL_TRANSMUTER\)", i))
                    {
                        // Console.WriteLine("got here");
                        for (int j = 7; j < 40; j++)
                        {
                            ReplaceDlgTransitionTriggerString(
                                @"(?<=ClassLevelGT\(LastTalkedToBy,WIZARD,)" + j.ToString(),
                                (j - 6).ToString()
                            );
                        }
                    }
                }

                for (int i = 0; i < dlgTransitionTriggersModded.Count; i++)
                {
                    if (FindDlgTransitionTriggerString(@"(?<!\!)Kit\(LastTalkedToBy,MAGESCHOOL_TRANSMUTER\)", i))
                    {
                        // Console.WriteLine("got here");
                        for (int j = 5; j < 40; j++)
                        {
                            ReplaceDlgTransitionTriggerString(
                                @"(?<=ClassLevelGT\(LastTalkedToBy,WIZARD,)" + j.ToString(),
                                (j - 4).ToString()
                            );
                        }
                    }
                }

                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // check for dialog errors (more than one function in one line)
            String regexStr = @"(?<=\)) (?=\w)";
            String regexRepl = "\r\n";
            Boolean isModded1 = false;
            Boolean isModded2 = false;
            Boolean isModded3 = false;
            for (int i = 0; i < dlgStateTriggers.Count; i++)
            {
                currentDlgStateTrigger = (DlgStateTrigger) dlgStateTriggersModded[i];
                if (Regex.IsMatch(currentDlgStateTrigger.str, regexStr, RegexOptions.Multiline))
                {
                    ReplaceDlgStateTriggerString(regexStr, regexRepl);
                    isModded1 = true;
                }
            }
            for (int i = 0; i < dlgTransitionTriggers.Count; i++)
            {
                currentDlgTransitionTrigger = (DlgTransitionTrigger) dlgTransitionTriggersModded[i];
                if (Regex.IsMatch(currentDlgTransitionTrigger.str, regexStr, RegexOptions.Multiline))
                {
                    ReplaceDlgTransitionTriggerString(regexStr, regexRepl);
                    isModded2 = true;
                }
            }
            for (int i = 0; i < dlgActionTablesModded.Count; i++)
            {
                currentDlgActionTable = (DlgActionTable) dlgActionTablesModded[i];
                if (Regex.IsMatch(currentDlgActionTable.str, regexStr, RegexOptions.Multiline))
                {
                    ReplaceDlgActionTableString(regexStr, regexRepl);
                    isModded3 = true;
                }
            }

            if (isModded1 || isModded2 || isModded3)
            {
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
        }
    }
}