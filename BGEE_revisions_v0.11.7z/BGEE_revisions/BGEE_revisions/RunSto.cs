﻿using System;
using System.Collections;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunSto()
        {
            // adjust container sizes
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Ammo Belt"))
            {
                stoHeaderModded.capacity = 2500;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Gem Bag"))
            {
                stoHeaderModded.capacity = 25;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Scroll Case"))
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Potion Case"))
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name), "Holding"))
            {
                stoHeaderModded.capacity = 100;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Key Ring") ||
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Keyring")
                )
            {
                stoHeaderModded.capacity = 50;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            if (
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wand Case") ||
                ContainsCaseInsensitive(GetTlkStringFromStrRef(stoHeaderModded.name),"Wandcase")
            )
            {
                stoHeaderModded.capacity = 25;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // remove all items from all containers
            if (stoHeaderModded.type == 5) // if it's a container
            {
                stoHeaderModded.itemsForSaleCount = 0;
                stoHeaderModded.itemsForSaleOffset = 156;
                stoHeaderModded.drinksForSaleCount = 0;
                stoHeaderModded.drinksForSaleOffset = 156;
                stoHeaderModded.curesForSaleCount = 0;
                stoHeaderModded.curesForSaleOffset = 156;
                stoItemsForSaleModded = new ArrayList();
                stoDrinksModded = new ArrayList();
                stoCuresModded = new ArrayList();
                
                // change the offset for the items purchased by the store
                stoHeaderModded.itemsPurchasedOffset = 156;

                // Console.WriteLine(StoHeader.size);
                // Console.WriteLine(stoItemsForSaleModded.Count * StoItem.size);
                // Console.WriteLine(stoDrinksModded.Count * StoDrink.size);
                // Console.WriteLine(stoCuresModded.Count * StoCure.size);
                // Console.WriteLine(stoItemsPurchased.Count * 4);
                
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
            
            // equalize prizes of all stores (prevent stealing exploit)
            if (stoHeaderModded.type == 0) // if it's a store
            {
                stoHeaderModded.sellPriceMarkup = 150;
                stoHeaderModded.buyPriceMarkup = 50;
                FileOperations.WriteFile(stoHeaderModded, stoItemsForSaleModded, stoDrinksModded, stoCuresModded, stoItemsPurchasedModded, stoOutputPath + "/" + currentStoFileInfo.Name);
            }
        }
    }
}