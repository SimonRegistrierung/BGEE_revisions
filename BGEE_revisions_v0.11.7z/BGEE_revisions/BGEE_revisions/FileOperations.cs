﻿using System;
using System.Collections;
using System.IO;
using System.Text;

namespace BGEE_revisions
{
    internal class FileOperations
    {
        internal static Boolean CheckFilePath(String path)
        {
            if (!File.Exists(path))
            {
                return false;
            }
            return false;
        }

        internal static void CheckBasePath(String path)
        {
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        internal static byte[] ReadFile(String filePath)
        {
            if (File.Exists(filePath))
            {
                // NEW METHOD: ALL AT ONCE
                return File.ReadAllBytes(filePath);
            }
            else
            {
                // Console.WriteLine("File doesn't exist!");
                return null;
            }
        }
        
        internal static String ReadFileAsString(String filePath)
        {
            if (File.Exists(filePath))
            {
                return System.IO.File.ReadAllText(filePath);
            }
            else
            {
                throw new FileNotFoundException();
            }
        }

        internal static void WriteFile(String filePath, byte[] byteFile)
        {
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(String sourcePath, String destPath)
        {
            File.Copy(sourcePath, destPath, true);
        }
        
        internal static void WriteFileAsString(String fileContent, String filePath)
        {
            File.WriteAllText(filePath, fileContent);
        }
        
        internal static void WriteFile(ItmHeader itmHeader, ArrayList itmExtHeaders, ArrayList itmEffectFeatBlocks, ArrayList itmAbilityFeatBlocks, String filePath)
        {
            byte[] byteFile = new byte[
                ItmHeader.size + 
                itmExtHeaders.Count * ItmExtHeader.size + 
                itmEffectFeatBlocks.Count * ItmFeatBlock.size + 
                itmAbilityFeatBlocks.Count * ItmFeatBlock.size
            ];
            int offset = 0;

            byte[] bytes = itmHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += ItmHeader.size;

            if (itmExtHeaders.Count != 0)
            {
                foreach (ItmExtHeader extHeader in itmExtHeaders)
                {
                    bytes = extHeader.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmExtHeader.size;
                }
            }

            if (itmEffectFeatBlocks.Count != 0)
            {
                foreach (ItmFeatBlock featureBlock in itmEffectFeatBlocks)
                {
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmFeatBlock.size;
                }
            }
            
            if (itmAbilityFeatBlocks.Count != 0)
            {
                foreach (ItmFeatBlock featureBlock in itmAbilityFeatBlocks)
                {
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += ItmFeatBlock.size;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(CreHeader creHeader, ArrayList knownSpells, ArrayList memorizedSpellsInfos, ArrayList memorizedSpells, ArrayList effects, ArrayList items, CreItemSlots itemSlots, String filePath)
        {
            byte[] byteFile = new byte[
                CreHeader.size + 
                knownSpells.Count * CreKnownSpell.size + 
                memorizedSpellsInfos.Count * CreMemorizedSpellsInfo.size + 
                memorizedSpells.Count * CreMemorizedSpell.size + 
                effects.Count * CreEffect.size + 
                items.Count * CreItem.size + 
                CreItemSlots.size
            ];
            int offset = 0;
            byte[] bytes = creHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += CreHeader.size;
            
            if (knownSpells.Count != 0)
            {
                foreach (CreKnownSpell knownSpell in knownSpells)
                {
                    bytes = knownSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreKnownSpell.size;
                }
            }

            if (memorizedSpellsInfos.Count != 0)
            {
                foreach (CreMemorizedSpellsInfo memorizedSpellsInfo in memorizedSpellsInfos)
                {
                    bytes = memorizedSpellsInfo.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpellsInfo.size;
                }
            }
            
            if (memorizedSpells.Count != 0)
            {
                foreach (CreMemorizedSpell memorizedSpell in memorizedSpells)
                {
                    bytes = memorizedSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpell.size;
                }
            }
            
            if (effects.Count != 0)
            {
                foreach (CreEffect effect in effects)
                {
                    bytes = effect.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreEffect.size;
                }
            }
            
            if (items.Count != 0)
            {
                foreach (CreItem item in items)
                {
                    bytes = item.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreItem.size;
                }
            }
            
            bytes = itemSlots.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(SplHeader splHeader, ArrayList extendedHeaders, ArrayList castingFeatureBlocks, ArrayList featureBlocks, String filePath)
        {
            byte[] byteFile = new byte[
                SplHeader.size + 
                extendedHeaders.Count * SplExtendedHeader.size +
                castingFeatureBlocks.Count * SplFeatureBlock.size +
                featureBlocks.Count * SplFeatureBlock.size
            ];

            int offset = 0;

            byte[] bytes = splHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += SplHeader.size;
            
            if (extendedHeaders.Count != 0)
            {
                foreach (SplExtendedHeader extendedHeader in extendedHeaders)
                {
                    bytes = extendedHeader.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplExtendedHeader.size;
                }
            }

            if (castingFeatureBlocks.Count != 0)
            {
                foreach (SplFeatureBlock castingFeatureBlock in castingFeatureBlocks)
                {
                    bytes = castingFeatureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplFeatureBlock.size;
                }
            }

            if (featureBlocks.Count != 0)
            {
                foreach (SplFeatureBlock featureBlock in featureBlocks)
                {
                    // Console.WriteLine(featureBlock.resource);
                    bytes = featureBlock.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += SplFeatureBlock.size;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(TlkHeader tlkHeader, ArrayList tlkEntries, String filePath)
        {
            int strSize = 0;
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                strSize += tlkEntry.stringLength;
            }
            
            byte[] byteFile = new byte[
                TlkHeader.size + 
                tlkEntries.Count * TlkEntry.size + 
                strSize
            ];
            byte[] tlkHeaderBytes = tlkHeader.GetByteData();
            
            int offset = 0;
            System.Buffer.BlockCopy(tlkHeader.GetByteData(), 0, byteFile, offset, TlkHeader.size);
            offset += TlkHeader.size;
            
            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                System.Buffer.BlockCopy(tlkEntry.GetByteData(tlkHeader.offsetToStringData), 0, byteFile, offset, TlkEntry.size);
                offset += TlkEntry.size;
                // tlkEntry.PrintValues();
                // Console.WriteLine(tlkEntry.stringLength);
            }

            foreach (TlkEntry tlkEntry in tlkEntries)
            {
                System.Buffer.BlockCopy(tlkEntry.textByteData, 0, byteFile, offset, tlkEntry.stringLength);
                offset += tlkEntry.stringLength;
                // Console.WriteLine("index: " + index + "    " + tlkEntry.textString.Length);
            }
            
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(DlgHeader header, ArrayList stateTables, ArrayList transitionTables, ArrayList stateTriggers, ArrayList transitionTriggers, ArrayList actionTables, byte[] stringSection, String filePath)
        {
            byte[] byteFile = new byte[
                DlgHeader.size + 
                stateTables.Count * DlgStateTable.size + 
                transitionTables.Count * DlgTransitionTable.size + 
                stateTriggers.Count * DlgStateTrigger.size +  
                transitionTriggers.Count * DlgTransitionTrigger.size + 
                actionTables.Count * DlgActionTable.size +
                stringSection.Length
            ];
            int offset = 0;

            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += DlgHeader.size;

            if (stateTables.Count != 0)
            {
                foreach (DlgStateTable stateTable in stateTables)
                {
                    bytes = stateTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgStateTable.size;
                }
            }

            if (transitionTables.Count != 0)
            {
                foreach (DlgTransitionTable transitionTable in transitionTables)
                {
                    bytes = transitionTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgTransitionTable.size;
                }
            }

            if (stateTriggers.Count != 0)
            {
                foreach (DlgStateTrigger stateTrigger in stateTriggers)
                {
                    bytes = stateTrigger.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgStateTrigger.size;
                }
            }
            
            if (transitionTriggers.Count != 0)
            {
                foreach (DlgTransitionTrigger transitionTrigger in transitionTriggers)
                {
                    bytes = transitionTrigger.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgTransitionTrigger.size;
                }
            }
            
            if (actionTables.Count != 0)
            {
                foreach (DlgActionTable actionTable in actionTables)
                {
                    bytes = actionTable.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += DlgActionTable.size;
                }
            }
            
            System.Buffer.BlockCopy(stringSection, 0, byteFile, offset, stringSection.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(WmpHeader header, ArrayList worldMapEntries, ArrayList areaEntries, ArrayList areaLinkEntries, String filePath)
        {
            byte[] byteFile = new byte[
                WmpHeader.size + 
                worldMapEntries.Count * WmpWorldMapEntry.size + 
                areaEntries.Count * WmpAreaEntry.size + 
                areaLinkEntries.Count * WmpAreaLinkEntry.size
            ];
            int offset = 0;

            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += WmpHeader.size;
            
            if (worldMapEntries.Count != 0)
            {
                foreach (WmpWorldMapEntry worldmapEntry in worldMapEntries)
                {
                    bytes = worldmapEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpWorldMapEntry.size;
                }
            }
            
            if (areaEntries.Count != 0)
            {
                foreach (WmpAreaEntry areaEntry in areaEntries)
                {
                    bytes = areaEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpAreaEntry.size;
                }
            }
            
            if (areaLinkEntries.Count != 0)
            {
                foreach (WmpAreaLinkEntry areaLinkEntry in areaLinkEntries)
                {
                    bytes = areaLinkEntry.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += WmpAreaLinkEntry.size;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(StoHeader header, ArrayList itemsForSale, ArrayList drinks, ArrayList cures, ArrayList itemsPurchased, String filePath)
        {
            int offset = 0;
            byte[] byteFile = new byte[
                StoHeader.size +
                itemsForSale.Count * StoItem.size + 
                drinks.Count * StoDrink.size + 
                cures.Count * StoCure.size +
                itemsPurchased.Count * 4
            ];

            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += StoHeader.size;

            if (itemsForSale.Count != 0)
            {
                foreach (StoItem item in itemsForSale)
                {
                    bytes = item.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoItem.size;
                }
            }
            
            if (drinks.Count != 0)
            {
                foreach (StoDrink drink in drinks)
                {
                    bytes = drink.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoDrink.size;
                }
            }
            
            if (cures.Count != 0)
            {
                foreach (StoCure cure in cures)
                {
                    bytes = cure.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += StoCure.size;
                }
            }
            
            if (itemsPurchased.Count != 0)
            {
                foreach (int item in itemsPurchased)
                {
                    System.Buffer.BlockCopy(BitConverter.GetBytes(item), 0, byteFile, offset, 4);
                    offset += 4;
                }
            }

            File.WriteAllBytes(filePath, byteFile);
        }
    }
}