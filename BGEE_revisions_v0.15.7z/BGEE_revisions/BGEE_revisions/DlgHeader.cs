﻿using System;
using System.Text;

namespace BGEE_revisions
{
    // Offset	Size (data type)	Description
    // 0x0000	4 (char array)	Signature ('DLG ')
    // 0x0004	4 (char array)	Version ('V1.0')
    // 0x0008	4 (dword)	Number of states
    // 0x000c	4 (dword)	Offset of state table from start of file
    // 0x0010	4 (dword)	Number of transitions
    // 0x0014	4 (dword)	Offset of transition table from start of file
    // 0x0018	4 (dword)	Offset of state trigger table from start of file
    // 0x001c	4 (dword)	Number of state triggers
    // 0x0020	4 (dword)	Offset of transition trigger table from start of file
    // 0x0024	4 (dword)	Number of transition triggers
    // 0x0028	4 (dword)	Offset of action table from start of file
    // 0x002c	4 (dword)	Number of actions
    // 0x0030	4 (dword)	Flags specifying what the creature does when the dialog is interrupted by a hostile action from a EA < GOODCUTOFF creature.
    //
        // Bit 0: Enemy()
        // Bit 1: EscapeArea()
        // Bit 2: nothing (but since the action was hostile, it behaves similar to bit 0)
    // In addition, all these bits trigger the not-pause behaviour.
    // Hostile action is something like an effect from a spell with the hostile flag, damage effect, a simple attack or a failed pickpocket action.
    //
    // Note: This field does not exist in DLG files used in BG1.
    
    internal class DlgHeader
    {
        internal static int size = 52; // header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String signature;
        internal String version;
        internal int numberOfStates;
        internal int offsetToStateTables;
        internal int numberOfTransitions;
        internal int offsetToTransitionTables;
        internal int offsetToStateTriggerTables;
        internal int numberOfStateTriggers;
        internal int offsetToTransitionTriggerTables;
        internal int numberOfTransitionTriggers;
        internal int offsetToActionTables;
        internal int numberOfActions;
        internal int flags;

        internal DlgHeader(byte[] byteArray)
        {
            baseOffset = 0; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            signature = ConvertToStringData(4);
            version = ConvertToStringData(4);
            numberOfStates = ConvertToIntData();
            offsetToStateTables = ConvertToIntData();
            numberOfTransitions = ConvertToIntData();
            offsetToTransitionTables = ConvertToIntData();
            offsetToStateTriggerTables = ConvertToIntData();
            numberOfStateTriggers = ConvertToIntData();
            offsetToTransitionTriggerTables = ConvertToIntData();
            numberOfTransitionTriggers = ConvertToIntData();
            offsetToActionTables = ConvertToIntData();
            numberOfActions = ConvertToIntData();
            flags = ConvertToIntData();

            this.byteArray = null; // clear the byteList;
        }

        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(signature);
            CopyBytesToArray(version);
            CopyBytesToArray(numberOfStates);
            CopyBytesToArray(offsetToStateTables);
            CopyBytesToArray(numberOfTransitions);
            CopyBytesToArray(offsetToTransitionTables);
            CopyBytesToArray(offsetToStateTriggerTables);
            CopyBytesToArray(numberOfStateTriggers);
            CopyBytesToArray(offsetToTransitionTriggerTables);
            CopyBytesToArray(numberOfTransitionTriggers);
            CopyBytesToArray(offsetToActionTables);
            CopyBytesToArray(numberOfActions);
            CopyBytesToArray(flags);

            return byteArray;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine("signature:\t" + signature);
            Console.WriteLine("version:\t" + version);
            Console.WriteLine("numberOfStates:\t" + numberOfStates);
            Console.WriteLine("offsetToStateTables:\t" + offsetToStateTables);
            Console.WriteLine("numberOfTransitions:\t" + numberOfTransitions);
            Console.WriteLine("offsetToTransitionTables:\t" + offsetToTransitionTables);
            Console.WriteLine("offsetToStateTriggerTables:\t" + offsetToStateTriggerTables);
            Console.WriteLine("numberOfStateTriggers:\t" + numberOfStateTriggers);
            Console.WriteLine("offsetToTransitionTriggerTables:\t" + offsetToTransitionTriggerTables);
            Console.WriteLine("numberOfTransitionTriggers:\t" + numberOfTransitionTriggers);
            Console.WriteLine("offsetToActionTables:\t" + offsetToActionTables);
            Console.WriteLine("numberOfActions:\t" + numberOfActions);
            Console.WriteLine("flags:\t" + flags);
        }
    }
}