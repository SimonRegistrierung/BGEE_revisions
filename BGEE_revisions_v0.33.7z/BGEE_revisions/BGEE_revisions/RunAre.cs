﻿using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunAre()
        {
            Random rnd = new Random();

            foreach (AreItem areItem in areItemsModded)
            {
                // CORRECT NON-EXISTING ITEMS
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(areItem))) // if the item file doe not exist in the source path, we can assume this item does not exist
                {
                    String newItem = GetRandomItem();
                    Console.WriteLine("Found non-existing item \"" + areItem.resource + "\" in \"" + currentAreFileInfo.Name + "\"");
                    
                    int result = rnd.Next(1, 101); // get a value from 1 - 100
                    if (result < 80) // if the value is lower than 80, replace with money
                    {
                        areItem.resource = "MISC07" + new string(new char[2]);
                        areItem.quantity1 = (short)rnd.Next(25, 250);
                        areItem.quantity2 = 0;
                        areItem.quantity3 = 0;
                    }
                    else // if the value is equal or higher than 80 pick a random item
                    {
                        areItem.resource = newItem;
                        areItem.quantity1 = 1;
                        areItem.quantity2 = 0;
                        areItem.quantity3 = 0;
                    }

                    Console.WriteLine("replacing with \"" + areItem.resource + "\"");

                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }

                // EQUALIZE WAND CHARGES 
                String fileName = GetItemFileName(areItem);
                // Console.WriteLine("-----");
                // Console.WriteLine(fileName);
                // Console.WriteLine("-----");
                CreateItmObjects(fileName);
                if (itmHeaderModded.itemType == 35) // if it's a wand
                {
                    if (areItem.quantity1 > 0)
                    {
                        areItem.quantity1 = 10;
                    }

                    if (areItem.quantity2 > 0)
                    {
                        areItem.quantity2 = 10;
                    }

                    if (areItem.quantity3 > 0)
                    {
                        areItem.quantity3 = 10;
                    }

                    // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                    if (fileName.Contains("WAND06."))
                    {
                        areItem.quantity1 = 10;
                        areItem.quantity2 = 10;
                    }
                
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
                
                // CLOAK OF NYMPH CHARGES
                if (areItem.resource.Contains("CLCK07")) // cloak of the nymph
                {
                    areItem.quantity1 = 1;
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }
            
            // make all creatures spawn/be available at all day and night times
            // foreach (AreActor areActor in areActorsModded)
            // {
            //     if (areActor.appearanceSchedule != -1)
            //     {
            //         // Console.WriteLine(currentAreFileInfo.Name + " : " + currentAreActor.name);
            //         areActor.appearanceSchedule = -1;
            //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            //     }
            // }
        }
    }
}