﻿namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunTlkMisc()
        {
            //
            /// SPELL DESCRIPTIONS & NAME CHANGES
            //
            // MODDING 
            // Chaos Sorcerer
            // EditTlkExistingEntry("CHAOS SORCERER:", @"Saves vs\. Spell", "Saving Throws");
            // EditTlkExistingEntry("CHAOS SORCERER:", @"\+5% Magic Resistance", "+25% Magic Resistance");
            // EditTlkExistingEntry("CHAOS SORCERER:", @"– May cast fewer spells per level per day\.\n", "");
            
            // ASSASSIN MOD
            EditExistingTlkEntry("ASSASSIN:", 
                @"– May use the Poison Weapon ability. Gains one use at level 1 and an additional use every 4 levels thereafter.", 
                "– Natural Invisibility: Gains one use at level 1 and an additional use every 3 levels thereafter.\n– May use the Poison Weapon ability. Gains one use at level 1 and an additional use every 4 levels thereafter.", true , false);
        }
    }
}