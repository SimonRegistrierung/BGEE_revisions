﻿using System;
using System.Text;

namespace BGEE_revisions
{
    internal class ItmHeader
    {
        internal static int size = 114; // header size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String signature;
        internal String version;
        internal int nameUnId;
        internal int nameId;
        internal String replItem;
        internal int flags;
        internal short itemType;
        internal int exclusionFlags;
        internal String itemAnimation;
        internal short minLevel;
        internal short minStr;
        internal byte minStrBonus;
        internal byte usability1;
        internal byte minInt;
        internal byte usability2;
        internal byte minDex;
        internal byte usability3;
        internal byte minWis;
        internal byte usability4;
        internal byte minCon;
        internal byte weapProf;
        internal short minCha;
        internal int price;
        internal short stackAmount;
        internal String invIcon;
        internal short loreToId;
        internal String groundIcon;
        internal int weight;
        internal int descUnId;
        internal int descId;
        internal String descIcon;
        internal int enchantment;
        internal int abilitiesOffset;
        internal short abilitiesCount;
        internal int effectsOffset;
        internal short firstEffectIndex;
        internal short effectsCount;

        internal ItmHeader(byte[] byteArray)
        {
            baseOffset = 0; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            signature = ConvertToStringData(4);
            version = ConvertToStringData(4);
            nameUnId = ConvertToIntData();
            nameId = ConvertToIntData();
            replItem = ConvertToStringData(8);
            flags = ConvertToIntData();
            itemType = ConvertToShortData();
            exclusionFlags = ConvertToIntData();
            itemAnimation = ConvertToStringData(2);
            minLevel = ConvertToShortData();
            minStr = ConvertToShortData();
            minStrBonus = ConvertToByteData();
            usability1 = ConvertToByteData();
            minInt = ConvertToByteData();
            usability2 = ConvertToByteData();
            minDex = ConvertToByteData();
            usability3 = ConvertToByteData();
            minWis = ConvertToByteData();
            usability4 = ConvertToByteData();
            minCon = ConvertToByteData();
            weapProf = ConvertToByteData();
            minCha = ConvertToShortData();
            price = ConvertToIntData();
            stackAmount = ConvertToShortData();
            invIcon = ConvertToStringData(8);
            loreToId = ConvertToShortData();
            groundIcon = ConvertToStringData(8);
            weight = ConvertToIntData();
            descUnId = ConvertToIntData();
            descId = ConvertToIntData();
            descIcon = ConvertToStringData(8);
            enchantment = ConvertToIntData();
            abilitiesOffset = ConvertToIntData();
            abilitiesCount = ConvertToShortData();
            effectsOffset = ConvertToIntData();
            firstEffectIndex = ConvertToShortData();
            effectsCount = ConvertToShortData();

            size = baseOffset;

            this.byteArray = null; // clear the byteList;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(signature);
            CopyBytesToArray(version);
            CopyBytesToArray(nameUnId);
            CopyBytesToArray(nameId);
            CopyBytesToArray(replItem);
            CopyBytesToArray(flags);
            CopyBytesToArray(itemType);
            CopyBytesToArray(exclusionFlags);
            CopyBytesToArray(itemAnimation);
            CopyBytesToArray(minLevel);
            CopyBytesToArray(minStr);
            CopyBytesToArray(minStrBonus);
            CopyBytesToArray(usability1);
            CopyBytesToArray(minInt);
            CopyBytesToArray(usability2);
            CopyBytesToArray(minDex);
            CopyBytesToArray(usability3);
            CopyBytesToArray(minWis);
            CopyBytesToArray(usability4);
            CopyBytesToArray(minCon);
            CopyBytesToArray(weapProf);
            CopyBytesToArray(minCha);
            CopyBytesToArray(price);
            CopyBytesToArray(stackAmount);
            CopyBytesToArray(invIcon);
            CopyBytesToArray(loreToId);
            CopyBytesToArray(groundIcon);
            CopyBytesToArray(weight);
            CopyBytesToArray(descUnId);
            CopyBytesToArray(descId);
            CopyBytesToArray(descIcon);
            CopyBytesToArray(enchantment);
            CopyBytesToArray(abilitiesOffset);
            CopyBytesToArray(abilitiesCount);
            CopyBytesToArray(effectsOffset);
            CopyBytesToArray(firstEffectIndex);
            CopyBytesToArray(effectsCount);

            return byteArray;
        }
        
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void PrintValues()
        {
            Console.WriteLine(signature);
            Console.WriteLine(version);
            Console.WriteLine(nameUnId);
            Console.WriteLine(nameId);
            Console.WriteLine(replItem);
            Console.WriteLine(flags);
            Console.WriteLine(itemType);
            Console.WriteLine(exclusionFlags);
            Console.WriteLine(itemAnimation);
            Console.WriteLine(minLevel);
            Console.WriteLine(minStr);
            Console.WriteLine(minStrBonus);
            Console.WriteLine(usability1);
            Console.WriteLine(minInt);
            Console.WriteLine(usability2);
            Console.WriteLine(minDex);
            Console.WriteLine(usability3);
            Console.WriteLine(minWis);
            Console.WriteLine(usability4);
            Console.WriteLine(minCon);
            Console.WriteLine(weapProf);
            Console.WriteLine(minCha);
            Console.WriteLine(price);
            Console.WriteLine(stackAmount);
            Console.WriteLine(invIcon);
            Console.WriteLine(loreToId);
            Console.WriteLine(groundIcon);
            Console.WriteLine(weight);
            Console.WriteLine(descUnId);
            Console.WriteLine(descId);
            Console.WriteLine(descIcon);
            Console.WriteLine(enchantment);
            Console.WriteLine(abilitiesOffset);
            Console.WriteLine(abilitiesCount);
            Console.WriteLine(effectsOffset);
            Console.WriteLine(firstEffectIndex);
            Console.WriteLine(effectsCount);
        }
    }
}