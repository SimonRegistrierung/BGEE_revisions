﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunAre()
        {
            // correct empty items in containers (NULL.itm, RNDTRS.ITM... etc...)
            foreach (AreItem areItem in areItemsModded)
            {
                if (!FileOperations.CheckFilePath(itmInputPath + "/" + GetItemFileName(areItem))) // if the item file doe not exist in the source path, we can assume this item does not exists
                {
                    // Console.WriteLine(areItem.resource);
                    areItem.resource = "MISC07" + new string(new char[2]);
                    areItem.quantity1 = 100;
                    areItem.quantity2 = 0;
                    areItem.quantity3 = 0;
                    areItem.flags = GetBitfieldInt(new int[] {0});
                    
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }
            
            // make all creatures spawn/be available at all day and night times
            // foreach (AreActor areActor in areActorsModded)
            // {
            //     if (areActor.appearanceSchedule != -1)
            //     {
            //         // Console.WriteLine(currentAreFileInfo.Name + " : " + currentAreActor.name);
            //         areActor.appearanceSchedule = -1;
            //         FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
            //     }
            // }
            
            // OTHER ITEM CHARGE CHANGES
            foreach (AreItem areItem in areItemsModded)
            {
                if (areItem.resource.Contains("CLCK07")) // cloak of the nymph
                {
                    areItem.quantity1 = 1;
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }

            // equalize wand charges for all areas (see item mod for wands)
            foreach (AreItem areItem in areItemsModded)
            {
                String fileName = GetItemFileName(areItem);
                CreateItmObjects(fileName);
                if (itmHeaderModded.itemType == 35) // if it's a wand
                {
                    if (areItem.quantity1 > 0)
                    {
                        areItem.quantity1 = 10;
                    }

                    if (areItem.quantity2 > 0)
                    {
                        areItem.quantity2 = 10;
                    }

                    if (areItem.quantity3 > 0)
                    {
                        areItem.quantity3 = 10;
                    }

                    // SPECIAL RULES FOR THE UPDATED WAND OF FROST
                    if (fileName.Contains("WAND06."))
                    {
                        areItem.quantity1 = 10;
                        areItem.quantity2 = 10;
                    }
                    
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }
            
            // decrease charges of multiple items
            foreach (AreItem areItem in areItemsModded)
            {
                if (
                    ContainsCaseInsensitive(areItem.resource, "AMUL01") ||
                    ContainsCaseInsensitive(areItem.resource, "AMUL15") ||
                    ContainsCaseInsensitive(areItem.resource, "AMUL17") ||
                    ContainsCaseInsensitive(areItem.resource, "BDAMUL21") ||
                    ContainsCaseInsensitive(areItem.resource, "CHALCY3") ||
                    ContainsCaseInsensitive(areItem.resource, "CLCK20") ||
                    ContainsCaseInsensitive(areItem.resource, "IPSION") ||
                    //
                    ContainsCaseInsensitive(areItem.resource, "CLCK20") ||
                    ContainsCaseInsensitive(areItem.resource, "mh#ring4") ||
                    ContainsCaseInsensitive(areItem.resource, "mh#staf5") ||
                    ContainsCaseInsensitive(areItem.resource, "mh#staf6") ||
                    ContainsCaseInsensitive(areItem.resource, "MISC2P") ||
                    ContainsCaseInsensitive(areItem.resource, "MISC73") ||
                    ContainsCaseInsensitive(areItem.resource, "MISC98") ||
                    ContainsCaseInsensitive(areItem.resource, "OHRCLCK3") ||
                    ContainsCaseInsensitive(areItem.resource, "rgtlsoa") ||
                    ContainsCaseInsensitive(areItem.resource, "RING03") ||
                    ContainsCaseInsensitive(areItem.resource, "RING20") ||
                    ContainsCaseInsensitive(areItem.resource, "ROSSLAND") ||
                    ContainsCaseInsensitive(areItem.resource, "STAF05") ||
                    ContainsCaseInsensitive(areItem.resource, "STAF09") ||
                    ContainsCaseInsensitive(areItem.resource, "STAF16") ||
                    ContainsCaseInsensitive(areItem.resource, "STAF17")
                )
                {
                    if (areItem.quantity1 >= 10)
                    {
                        areItem.quantity1 = 15;
                    }

                    if (areItem.quantity2 >= 10)
                    {
                        areItem.quantity2 = 15;
                    }

                    if (areItem.quantity3 >= 10)
                    {
                        areItem.quantity3 = 15;
                    }
                    
                    // Console.WriteLine("STO MODDED:" + currentStoFileInfo.Name + "    with item:" + stoItem.itmFileName);
                    
                    FileOperations.WriteFile(areHeaderModded, areActorsModded, areTriggersModded, areSpawnPointsModded, areEntrancesModded, areContainersModded, areItemsModded, areVerticesModded, areAmbientsModded, areVariablesModded, areExploredBitmasksModded, areDoorsModded, areAnimationsModded, areTiledObjectsModded, areSongModded, areRestEncounterModded, areAutomapNotesModded, areProjectileTrapsModded, areOutputPath + "/" + currentAreFileInfo.Name);
                }
            }
        }
    }
}