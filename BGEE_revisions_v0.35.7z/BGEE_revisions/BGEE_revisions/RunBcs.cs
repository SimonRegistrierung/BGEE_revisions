﻿using System;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunBcs(BcsParser bcsParser)
        {
            // prevent edwin murdering dynaheir
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "EDWIN_.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16436 0 1 0 0 \"GLOBALBD_PLOT\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16451 0 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dynaheir\"OB\nTR\nTR\n16399 6 0 0 0 \"GLOBALX#EdwinDynaheir\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16439 -2146426897 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n131OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dynaheir\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\n", 
                    "0OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // bgsod : edwin & dynaheir in same team
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"BDEDWIN.bcs"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16399 1 0 0 0 \"globalbd_edwin_talk\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 1 0 0 0 \"bd1000bd_edwin_talk_again\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16395 128 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nTR\nTR\n16437 3 0 0 0 \"bd1000BD_edwin_move\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16408 15 0 0 0 \"\" \"\" OB\n2 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16412 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"dynaheir\"OB\nTR\nTR\n16412 0 1 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"minsc\"OB\nTR\nCO\nRS\nRE\n100AC\n198OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR\n", 
                    "0OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change golem building times
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"a7!ct0"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "(3600|7200|10800|14400)", 
                    "6"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // alter Balduran's Isle Travel Time
            if (
                ContainsCaseInsensitive(currentBcsFileInfo.Name,"ISLON") || 
                ContainsCaseInsensitive(currentBcsFileInfo.Name,"ISLOFF")
            )
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "(158400|180000)", 
                    "7200"
                );
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change ridiculous ICHARYRD fight
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name, "DW#ICHAR"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16449 0 1 0 0 \"calllightning\" \"LOCALS\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 2 0 0 0 \"GLOBALDMWWIcharydStorm\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 0 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16593 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 50 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 51 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 52 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRE\n100AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n2 0 0 0 0 0 0 53 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"dw#ichar\" \"\" AC\nAC\n115OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n6 0 0 0 0\"LOCALScalllightning\" \"\" AC\nRE\nRS\nCR", 
                    ""
                );
                
                bcsParser.FindReplaceAll(
                    false, 
                    "CR\nCO\nTR\n16399 1 0 0 0 \"GLOBALDMWWIcharydStorm\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 0 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16593 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16436 2 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nCO\nRS\nRE\n100AC\n169OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"minhp1\" \"\" AC\nAC\n30OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n2 0 0 0 0\"GLOBALDMWWIcharydStorm\" \"\" AC\nAC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n3746 0 0 0 0\"\" \"\" AC\nAC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1214 0 0 0 0\"\" \"\" AC\nAC\n344OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nAC\n66OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n0 0 0 0 0\"\" \"\" AC\nRE\nRS\nCR", 
                    ""
                );
                
                bcsParser.FindReplaceAll(
                    false, 
                    "TR\n16437 3 0 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16521 2 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16594 3 0 0 0 \"\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR\nTR\n16399 0 1 0 0 \"GLOBALDMWW_genai_difficulty\" \"\" OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nTR", 
                    ""
                );
                
                bcsParser.FindReplaceAll(
                    false, 
                    "AC\n181OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 1 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n1214 0 0 0 0\"\" \"\" AC", 
                    ""
                );
                
                // Console.WriteLine(bcsParser.encryptedFile);
                // Console.WriteLine(bcsOutputPath + "/" + currentBcsFileInfo.Name);
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
            
            // change reputation decrease scaling
            if (ContainsCaseInsensitive(currentBcsFileInfo.Name,"MURDER"))
            {
                bcsParser.LoadScript(FileOperations.ReadFile(currentBcsFileInfo.FullName));

                String findStr1 = "(?<=163OB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\nOB\n0 0 0 0 0 0 0 0 0 0 0 0 \"\"OB\n-)\\d+(?= 0 0 0 0\"\" \"\" AC)";
                MatchCollection findInts1 = bcsParser.FindAll(false, findStr1);
                foreach (Match m1 in findInts1)
                {
                    // String newVal = (Int32.Parse(m1.Value) / 2).ToString();
                    bcsParser.FindReplace(
                        false, 
                        findStr1,
                        m1.Value,
                        2.ToString()
                    );
                }
                FileOperations.WriteFileAsString(bcsParser.encryptedFile, bcsOutputPath + "/" + currentBcsFileInfo.Name);
            }
        }
    }
}