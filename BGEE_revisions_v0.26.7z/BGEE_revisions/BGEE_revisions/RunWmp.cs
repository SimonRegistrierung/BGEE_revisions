﻿using System;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunWmp()
        {
            // SET TRAVEL TIME TO 0
            foreach (WmpAreaLinkEntry areaLinkEntry in wmpAreaLinkEntriesModded)
            {
                if (areaLinkEntry.travelTime > 0)
                {
                    areaLinkEntry.travelTime = 0;   
                }
            }
            // Console.WriteLine(wmpHeader.signature);
            FileOperations.WriteFile(wmpHeaderModded, wmpWorldMapEntriesModded, wmpAreaEntriesModded, wmpAreaLinkEntriesModded, wmpOutputPath + "/" + currentWmpFileInfo.Name);
            
        }
    }
}