﻿using System;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static void RunDlg()
        {
            // Thalantyr doesn't need wands to create the snow storm bow
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "THALAN"))
            {
                ReplaceDlgActionTableString(
                    @"TakePartyItemNum\(""wand03"",1\)\r\nDestroyItem\(""wand03""\)", 
                    "TakePartyItemNum(\"potn39\",1)\r\nDestroyItem(\"potn39\")"
                );
                
                ReplaceDlgActionTableString(
                    @"TakePartyItemNum\(""wand06"",1\)\r\nDestroyItem\(""wand06""\)", 
                    "TakePartyItemNum(\"potn22\",1)\r\nDestroyItem(\"potn22\")"
                );
                
                ReplaceDlgActionTableString(
                    @"TakePartyItemNum\(""wand07"",1\)\r\nDestroyItem\(""wand07""\)", 
                    "TakePartyItemNum(\"potn31\",1)\r\nDestroyItem(\"potn31\")"
                );

                ReplaceDlgResponseTriggerString(
                    @"PartyHasItem\(""wand03""\)\r\nPartyHasItem\(""wand06""\)\r\nPartyHasItem\(""wand07""\)", 
                    "PartyHasItem(\"potn39\")\r\nPartyHasItem(\"potn22\")\r\nPartyHasItem(\"potn31\")"
                );
                
                // Console.WriteLine(FindDlgResponseTriggerString("wand07"));
                
                // DIALOG OF THALANTYR IS CHANGED IN RUNTLKDLG!

                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // Dorn Reputation increase / decrease
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "DORN"))
            {
                ReplaceDlgActionTableString(
                    @"ReputationInc(-2)\r\n", 
                    ""
                );

                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // Jared's Always gives Boots of the North
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "JARED."))
            {
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""HelpJared"",""GLOBAL"",1\)\r\nEraseJournalEntry\(227184\)", 
                    "SetGlobal(\"HelpJared\",\"GLOBAL\",1)\r\nGivePartyGold(50)\r\nGiveItem(\"BOOT03\",LastTalkedToBy)\r\nEraseJournalEntry(227184)"
                    );
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""HelpJared"",""GLOBAL"",1\)\r\nGivePartyGold\(50\)\r\nEraseJournalEntry\(227184\)", 
                    "SetGlobal(\"HelpJared\",\"GLOBAL\",1)\r\nGivePartyGold(50)\r\nGiveItem(\"BOOT03\",LastTalkedToBy)\r\nEraseJournalEntry(227184)"
                );
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""HelpJared"",""GLOBAL"",1\)\r\nGiveItem\(""BOOT03"",LastTalkedToBy\)\r\nEraseJournalEntry\(227184\)", 
                    "SetGlobal(\"HelpJared\",\"GLOBAL\",1)\r\nGivePartyGold(50)\r\nGiveItem(\"BOOT03\",LastTalkedToBy)\r\nEraseJournalEntry(227184)"
                );

                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // Melicamp never dies
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "THALAN."))
            {
                ReplaceDlgActionTableString(
                    @"ClearAllActions\(\)\r\nStartCutSceneMode\(\)\r\nTakePartyItem\(""MISC50""\)\r\nDestroyItem\(""MISC50""\)\r\nSetGlobal\(""TransformedChicken"",""GLOBAL"",1\)\r\nApplySpellRES\(""portswa2"",""Melicamp""\)\r\nWait\(1\)\r\nFaceObject\(""Melicamp""\)\r\nSmallWait\(1\)\r\nForceSpell\(""Melicamp"",EFFECT_ONLY\)\r\nSmallWait\(10\)\r\nCreateVisualEffectObject\(""SPPOLYMP"",""Melicamp""\)\r\nCreateVisualEffectObject\(""POLYBACK"",""Melicamp""\)\r\nWait\(1\)\r\nActionOverride\(""Melicamp"",Polymorph\(MAGE_MALE_HUMAN\)\)\r\nWait\(1\)\r\nKill\(""Melicamp""\)\r\nWait\(2\)\r\nEndCutSceneMode\(\)\r\nStartDialogNoSet\(LastTalkedToBy\)\r\n",
                    "ClearAllActions()\r\nStartCutSceneMode()\r\nTakePartyItem(\"MISC50\")\r\nDestroyItem(\"MISC50\")\r\nSetGlobal(\"TransformedChicken\",\"GLOBAL\",1)\r\nApplySpellRES(\"portswa2\",\"Melicamp\")\r\nWait(1)\r\nFaceObject(\"Melicamp\")\r\nSmallWait(1)\r\nForceSpell(\"Melicamp\",EFFECT_ONLY)\r\nSmallWait(10)\r\nCreateVisualEffectObject(\"SPPOLYMP\",\"Melicamp\")\r\nCreateVisualEffectObject(\"POLYBACK\",\"Melicamp\")\r\nWait(1)\r\nActionOverride(\"Melicamp\",Polymorph(MAGE_MALE_HUMAN))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,INITIAL_MEETING))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,BATTLE_CRY1))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,212354,DAMAGE))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,212348,DYING))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON1))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,220283,SELECT_COMMON2))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON3))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON4))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON5))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,211082,SELECT_COMMON6))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,PICKED_POCKET))\r\nActionOverride(\"Melicamp\",SetPlayerSound(Myself,-1,HIDDEN_IN_SHADOWS))\r\nWait(2)\r\nEndCutSceneMode()\r\nStartDialogNoSet(LastTalkedToBy)\r\n"
                    );
                
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // minor golems always auto-attack on sight
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "A7!CMD3."))
            {
                ReplaceDlgActionTableString(
                    @"SetGlobal\(""Command"",""LOCALS"",0\)",
                    "SetGlobal(\"Command\",\"LOCALS\",1)"
                );
                
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // time modding (make some dialogs' timers instant)
            if (Regex.IsMatch(currentDlgFileInfo.Name, "(THALAN|JARED|ARKION|NEMPHR|TAEROM|X#DRIZZT|MH#PHEND|MH#BROKK)", RegexOptions.Multiline))
            {
                ReplaceDlgActionTableString(
                    @"(?<=,)(\w+_(DAY|HOUR|MINUTE)|XAROM_TIMER|600)(S)?(?=\))",
                    "1"
                );
            
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // make golems accessible early for mages
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "A7!SMDLG."))
            {
                for (int i = 0; i < dlgTransitionTriggersModded.Count; i++)
                {
                    if (FindDlgTransitionTriggerString(@"(?<=\!)Kit\(LastTalkedToBy,MAGESCHOOL_TRANSMUTER\)", i))
                    {
                        // Console.WriteLine("got here");
                        for (int j = 7; j < 40; j++)
                        {
                            ReplaceDlgTransitionTriggerString(
                                @"(?<=ClassLevelGT\(LastTalkedToBy,WIZARD,)" + j.ToString(),
                                (j - 6).ToString()
                            );
                        }
                    }
                }

                for (int i = 0; i < dlgTransitionTriggersModded.Count; i++)
                {
                    if (FindDlgTransitionTriggerString(@"(?<!\!)Kit\(LastTalkedToBy,MAGESCHOOL_TRANSMUTER\)", i))
                    {
                        // Console.WriteLine("got here");
                        for (int j = 5; j < 40; j++)
                        {
                            ReplaceDlgTransitionTriggerString(
                                @"(?<=ClassLevelGT\(LastTalkedToBy,WIZARD,)" + j.ToString(),
                                (j - 4).ToString()
                            );
                        }
                    }
                }

                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // always get quest from arkion regardless of alignment/reputation
            if (ContainsCaseInsensitive(currentDlgFileInfo.Name, "ARKION."))
            {
                if (FindDlgStateTriggerString(@"(?<=Global\(""bd_arkion_quest"",""GLOBAL"",)\d+(?=\)\r\nReactionGT\(LastTalkedToBy,NEUTRAL_UPPER\))", 0))
                {
                    ReplaceDlgStateTriggerString(@"(?<=Global\(""bd_arkion_quest"",""GLOBAL"",)\d+(?=\)\r\nReactionGT\(LastTalkedToBy,NEUTRAL_UPPER\))", 99.ToString());
                }
                if (FindDlgStateTriggerString(@"(?<=Global\(""bd_arkion_quest"",""GLOBAL"",0\)\r\n)ReactionLT\(LastTalkedToBy,FRIENDLY_LOWER\)", 3))
                {
                    ReplaceDlgStateTriggerString(@"(?<=Global\(""bd_arkion_quest"",""GLOBAL"",0\)\r\n)ReactionLT\(LastTalkedToBy,FRIENDLY_LOWER\)", "");
                }
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
            
            // npc pairs no longer automatically separated
            if (
                ContainsCaseInsensitive(currentDlgFileInfo.Name, "KHALID") ||
                ContainsCaseInsensitive(currentDlgFileInfo.Name, "JAHEI") ||
                ContainsCaseInsensitive(currentDlgFileInfo.Name, "XZAR") ||
                ContainsCaseInsensitive(currentDlgFileInfo.Name, "MONTA") ||
                ContainsCaseInsensitive(currentDlgFileInfo.Name, "DYNAH") ||
                ContainsCaseInsensitive(currentDlgFileInfo.Name, "MINSC") ||
                ContainsCaseInsensitive(currentDlgFileInfo.Name, "MINCS")
            )
            {
                String[] names = {"dynaheir", "minsc", "montaron", "xzar", "Dynaheir", "Minsc", "Montaron", "Xzar", "MINSC", "DYNAHEIR", "MONTARON", "XZAR", "Jaheira", "Khalid", "jaheira", "khalid", "JAHEIRA", "KHALID"};
                if (dlgHeaderModded.numberOfActions > 0)
                {
                    Boolean found = false;
                    foreach (String name in names)
                    {
                        for (int i = 0; i < dlgHeaderModded.numberOfActions; i++)
                        {
                            if (FindDlgActionTableString(@"ActionOverride\(""" + name + @"""", i))
                            {
                                found = true;
                                ReplaceDlgActionTableString(@"ActionOverride\(""" + name + @""".*\r\n", "");
                            }
                        }
                    }

                    if (found)
                    {
                        GenerateDlgStringSection();
                        FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
                    }
                }
            }

            // check for dialog errors (more than one function in one line)
            String regexStr = @"(?<=\)) (?=\w)";
            String regexRepl = "\r\n";
            Boolean isModded1 = false;
            Boolean isModded2 = false;
            Boolean isModded3 = false;
            for (int i = 0; i < dlgStateTriggers.Count; i++)
            {
                currentDlgStateTrigger = (DlgStateTrigger) dlgStateTriggersModded[i];
                if (Regex.IsMatch(currentDlgStateTrigger.str, regexStr, RegexOptions.Multiline))
                {
                    ReplaceDlgStateTriggerString(regexStr, regexRepl);
                    isModded1 = true;
                }
            }
            for (int i = 0; i < dlgTransitionTriggers.Count; i++)
            {
                currentDlgTransitionTrigger = (DlgTransitionTrigger) dlgTransitionTriggersModded[i];
                if (Regex.IsMatch(currentDlgTransitionTrigger.str, regexStr, RegexOptions.Multiline))
                {
                    ReplaceDlgTransitionTriggerString(regexStr, regexRepl);
                    isModded2 = true;
                }
            }
            for (int i = 0; i < dlgActionTablesModded.Count; i++)
            {
                currentDlgActionTable = (DlgActionTable) dlgActionTablesModded[i];
                if (Regex.IsMatch(currentDlgActionTable.str, regexStr, RegexOptions.Multiline))
                {
                    ReplaceDlgActionTableString(regexStr, regexRepl);
                    isModded3 = true;
                }
            }

            if (isModded1 || isModded2 || isModded3)
            {
                GenerateDlgStringSection();
                FileOperations.WriteFile(dlgHeaderModded, dlgStateTablesModded, dlgTransitionTablesModded, dlgStateTriggersModded, dlgTransitionTriggersModded, dlgActionTablesModded, dlgStringSectionModded, dlgOutputPath + "/"+ currentDlgFileInfo.Name);
            }
        }
        
        /// <summary>
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        ///
        /// 
        /// </summary>
        
        internal static void GenerateDlgStringSection()
        {
            int byteSize = 0;
            foreach (DlgStateTrigger stateTrigger in dlgStateTriggersModded)
            {
                byteSize += stateTrigger.strLength;
            }
            foreach (DlgTransitionTrigger transitionTrigger in dlgTransitionTriggersModded)
            {
                byteSize += transitionTrigger.strLength;
            }
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                byteSize += actionTable.strLength;
            }
            
            dlgStringSectionModded = new byte[byteSize];
            int offset = 0;
            foreach (DlgStateTrigger stateTrigger in dlgStateTriggersModded)
            {
                System.Buffer.BlockCopy(stateTrigger.GetByteStringData(), 0, dlgStringSectionModded, offset,stateTrigger.strLength);
                offset += stateTrigger.strLength;
            }
            foreach (DlgTransitionTrigger transitionTrigger in dlgTransitionTriggersModded)
            {
                System.Buffer.BlockCopy(transitionTrigger.GetByteStringData(), 0, dlgStringSectionModded, offset,transitionTrigger.strLength);
                offset += transitionTrigger.strLength;
            }
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                System.Buffer.BlockCopy(actionTable.GetByteStringData(), 0, dlgStringSectionModded, offset,actionTable.strLength);
                offset += actionTable.strLength;
            }
        }

        // FIND/REPLACE ACTION TABLE
        internal static void ReplaceDlgActionTableString(String findRegexStr, String replStr)
        {
            int cumulativeDeltaNegative = 0;
            int cumulativeDeltaPositive = 0;
            
            Boolean isFirstMod = true;

            for (int i = 0; i < dlgActionTablesModded.Count; i++)
            {
                currentDlgActionTable = (DlgActionTable) dlgActionTablesModded[i];
                String oldText = currentDlgActionTable.str;
                int oldLength = currentDlgActionTable.strLength;
                int oldOffset = currentDlgActionTable.strOffset;
                int newOffset = oldOffset + cumulativeDeltaNegative + cumulativeDeltaPositive;
                int oldNewDelta = 0;

                if (Regex.IsMatch(oldText, findRegexStr))
                {
                    String newText = Regex.Replace(oldText, findRegexStr, replStr);

                    int newLength = newText.Length;
                    // Console.WriteLine(oldLength + "    " + newLength);
                    if (newLength < oldLength)
                    {
                        oldNewDelta = oldLength - newLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgActionTable.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgActionTable.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaNegative -= oldNewDelta;
                    }
                    else if (newLength > oldLength)
                    {
                        oldNewDelta = newLength - oldLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgActionTable.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgActionTable.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaPositive += oldNewDelta;
                    }
                    else // if old and new string have the same length
                    {
                        currentDlgActionTable.UpdateInstance(newOffset, newText);
                    }
                }
                else
                {
                    currentDlgActionTable.UpdateInstance(newOffset, oldText); // if there is no match only the offset needs to be updated  
                }
            }
        }

        internal static Boolean FindDlgActionTableString(String findRegexStr, int index)
        {
            currentDlgActionTable = (DlgActionTable) dlgActionTablesModded[index];
            if (Regex.IsMatch(currentDlgActionTable.str, findRegexStr))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // FIND/REPLACE TRANSITION TRIGGER
        
        internal static void ReplaceDlgTransitionTriggerString(String findRegexStr, String replStr)
        {
            int cumulativeDeltaNegative = 0;
            int cumulativeDeltaPositive = 0;
            
            Boolean isFirstMod = true;

            for (int i = 0; i < dlgTransitionTriggersModded.Count; i++)
            {
                currentDlgTransitionTrigger = (DlgTransitionTrigger) dlgTransitionTriggersModded[i];
                String oldText = currentDlgTransitionTrigger.str;
                int oldLength = currentDlgTransitionTrigger.strLength;
                int oldOffset = currentDlgTransitionTrigger.strOffset;
                int newOffset = oldOffset + cumulativeDeltaNegative + cumulativeDeltaPositive;
                int oldNewDelta = 0;

                if (Regex.IsMatch(oldText, findRegexStr))
                {
                    String newText = Regex.Replace(oldText, findRegexStr, replStr);

                    int newLength = newText.Length;
                    // Console.WriteLine(oldLength + "    " + newLength);
                    if (newLength < oldLength)
                    {
                        oldNewDelta = oldLength - newLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgTransitionTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaNegative -= oldNewDelta;
                    }
                    else if (newLength > oldLength)
                    {
                        oldNewDelta = newLength - oldLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgTransitionTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaPositive += oldNewDelta;
                    }
                    else // if old and new string have the same length
                    {
                        currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                    }
                }
                else
                {
                    currentDlgTransitionTrigger.UpdateInstance(newOffset, oldText); // if there is no match only the offset needs to be updated  
                }

                // dlgTransitionTriggersModded[i] = currentDlgTransitionTrigger;
            }
            
            // !!!!!!!!!!!!!!!!!
            // we also have to update the offsets for each of the action tables, because these come next in the file structure
            // !!!!!!!!!!!!!!!!!
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                actionTable.strOffset += cumulativeDeltaNegative + cumulativeDeltaPositive;
            }
        }
        
        internal static Boolean FindDlgTransitionTriggerString(String findRegexStr, int index)
        {
            currentDlgTransitionTrigger = (DlgTransitionTrigger) dlgTransitionTriggersModded[index];
            if (Regex.IsMatch(currentDlgTransitionTrigger.str, findRegexStr))
            {
                // Console.WriteLine(currentDlgFileInfo.Name + "    " + dlgTransitionTriggersModded.Count);
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // FIND/REPLACE State TRIGGER
        
        internal static void ReplaceDlgStateTriggerString(String findRegexStr, String replStr)
        {
            int cumulativeDeltaNegative = 0;
            int cumulativeDeltaPositive = 0;
            
            Boolean isFirstMod = true;

            for (int i = 0; i < dlgStateTriggersModded.Count; i++)
            {
                currentDlgStateTrigger = (DlgStateTrigger) dlgStateTriggersModded[i];
                String oldText = currentDlgStateTrigger.str;
                int oldLength = currentDlgStateTrigger.strLength;
                int oldOffset = currentDlgStateTrigger.strOffset;
                int newOffset = oldOffset + cumulativeDeltaNegative + cumulativeDeltaPositive;
                int oldNewDelta = 0;

                if (Regex.IsMatch(oldText, findRegexStr))
                {
                    String newText = Regex.Replace(oldText, findRegexStr, replStr);

                    int newLength = newText.Length;
                    // Console.WriteLine(oldLength + "    " + newLength);
                    if (newLength < oldLength)
                    {
                        oldNewDelta = oldLength - newLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgStateTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgStateTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaNegative -= oldNewDelta;
                    }
                    else if (newLength > oldLength)
                    {
                        oldNewDelta = newLength - oldLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgStateTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgStateTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaPositive += oldNewDelta;
                    }
                    else // if old and new string have the same length
                    {
                        currentDlgStateTrigger.UpdateInstance(newOffset, newText);
                    }
                }
                else
                {
                    currentDlgStateTrigger.UpdateInstance(newOffset, oldText); // if there is no match only the offset needs to be updated  
                }

                // dlgStateTriggersModded[i] = currentDlgStateTrigger;
            }
            
            // !!!!!!!!!!!!!!!!!
            // we also have to update the offsets for each of the action tables, because these come next in the file structure
            // !!!!!!!!!!!!!!!!!
            foreach (DlgTransitionTrigger transitionTrigger in dlgTransitionTriggersModded)
            {
                transitionTrigger.strOffset += cumulativeDeltaNegative + cumulativeDeltaPositive;
            }
            foreach (DlgActionTable actionTable in dlgActionTablesModded)
            {
                actionTable.strOffset += cumulativeDeltaNegative + cumulativeDeltaPositive;
            }
        }
        
        internal static Boolean FindDlgStateTriggerString(String findRegexStr, int index)
        {
            currentDlgStateTrigger = (DlgStateTrigger) dlgStateTriggersModded[index];
            if (Regex.IsMatch(currentDlgStateTrigger.str, findRegexStr))
            {
                // Console.WriteLine(currentDlgFileInfo.Name + "    " + dlgStateTriggersModded.Count);
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // FIND/REPLACE RESPONSE TRIGGER
        internal static void ReplaceDlgResponseTriggerString(String findRegexStr, String replStr)
        {
            int cumulativeDeltaNegative = 0;
            int cumulativeDeltaPositive = 0;
            
            Boolean isFirstMod = true;

            for (int i = 0; i < dlgTransitionTriggersModded.Count; i++)
            {
                currentDlgTransitionTrigger = (DlgTransitionTrigger)dlgTransitionTriggersModded[i];
                String oldText = currentDlgTransitionTrigger.str;
                int oldLength = currentDlgTransitionTrigger.strLength;
                int oldOffset = currentDlgTransitionTrigger.strOffset;
                int newOffset = oldOffset + cumulativeDeltaNegative + cumulativeDeltaPositive;
                int oldNewDelta = 0;

                if (Regex.IsMatch(oldText, findRegexStr))
                {
                    String newText = Regex.Replace(oldText, findRegexStr, replStr);

                    int newLength = newText.Length;
                    // Console.WriteLine(oldLength + "    " + newLength);
                    if (newLength < oldLength)
                    {
                        oldNewDelta = oldLength - newLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgTransitionTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaNegative -= oldNewDelta;
                    }
                    else if (newLength > oldLength)
                    {
                        oldNewDelta = newLength - oldLength;
                        // Console.WriteLine(oldOffset);
                        // Console.WriteLine(oldNewDelta);
                        if (isFirstMod)
                        {
                            currentDlgTransitionTrigger.UpdateInstance(oldOffset, newText); // first instance only needs the text length and text to be updated, not the offset   
                            isFirstMod = false;
                        }
                        else
                        {
                            // Console.WriteLine(newOffset + " = " + oldOffset + " - " + oldNewDelta + " + " + cumulativeDeltaNegative);
                            // Console.WriteLine(newOffset);
                            currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                        }

                        cumulativeDeltaPositive += oldNewDelta;
                    }
                    else // if old and new string have the same length
                    {
                        currentDlgTransitionTrigger.UpdateInstance(newOffset, newText);
                    }
                }
                else
                {
                    currentDlgTransitionTrigger.UpdateInstance(newOffset, oldText); // if there is no match only the offset needs to be updated  
                }
            }
        }

        internal static Boolean FindDlgResponseTriggerString(String findRegexStr, int index)
        {
            currentDlgActionTable = (DlgActionTable) dlgActionTablesModded[index];
            if (Regex.IsMatch(currentDlgActionTable.str, findRegexStr))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        
        internal static Boolean FindDlgResponseTriggerString(String findRegexStr)
        {
            foreach (DlgTransitionTrigger dlgTransitionTrigger in dlgTransitionTriggers)
            {
                // Console.WriteLine(dlgTransitionTrigger.str);
                if (Regex.IsMatch(dlgTransitionTrigger.str, findRegexStr))
                {
                    return true;
                }
            }

            return false;
        }
    }
}