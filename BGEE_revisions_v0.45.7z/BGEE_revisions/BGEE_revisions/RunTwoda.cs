﻿using System;
using System.Collections;
using System.Text.RegularExpressions;

namespace BGEE_revisions
{
    internal partial class Program
    {
        internal static String newFileContent;
        
        internal static void RunTwoda()
        {
            // replace all references to RNDTRS08+09 (THEY ARE NON EXISTENT)
            if (
                ContainsCaseInsensitive(twodaFile.rawContent, "rndtre08") || 
                ContainsCaseInsensitive(twodaFile.rawContent, "rndtre09")
            )
            {
                twodaFile.rawContent =
                    twodaFile.rawContent.Replace("rndtre08", "rndtre07").Replace("rndtre09", "rndtre07");
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // GIVE INQUISITOR SPELLCASTING ABILITIES (BECAUSE DISPEL MAGIC HAS BEEN NERFED BY SCS AND IT'S NOT A GREAT ABILITY ANYWAY)
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "CLABPA03"))
            {
                RemoveLine("SPCL234");
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }

            // ALTER SPELLS PER DAY
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "MXSPL"))
            {
                // Console.WriteLine(currentTwodaFileInfo.Name + "    " + twodaFile.twodaLines.Count);
                // foreach (TwodaLine twodaLine in twodaFile.twodaLines)
                // {
                //     Console.WriteLine(twodaLine.content + "     " + twodaLine.isContent);
                // }
                if (
                    currentTwodaFileInfo.Name.Contains("BRD") ||
                    currentTwodaFileInfo.Name.Contains("DD") ||
                    currentTwodaFileInfo.Name.Contains("DRU") ||
                    currentTwodaFileInfo.Name.Contains("PRS") ||
                    currentTwodaFileInfo.Name.Contains("SHM") ||
                    currentTwodaFileInfo.Name.Contains("SRC") ||
                    currentTwodaFileInfo.Name.Contains("WIZ")
                )
                {
                    // give spell casters +5 spells
                    IncreaseSpells(@"(BRD|DD|DRU|PRS|SHM|SRC|WIZ)\.", 5);
                    FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
                }
                
                if (
                    currentTwodaFileInfo.Name.Contains("PAL") ||
                    currentTwodaFileInfo.Name.Contains("RAN")
                )
                {
                    // give fighters +2 spells
                    IncreaseSpells(@"(PAL|RAN)\.", 2);
                    FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
                }
            }
            
            // give sorcs and shamans +3 spells per spell level
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "SPL") && ContainsCaseInsensitive(currentTwodaFileInfo.Name, "KN."))
            {
                IncreaseSpells(@"(splshmkn|splsrckn|SPLSHMKN|SPLSRCKN)\.(2da|2DA)", 3);
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // double innate ability count
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "CLAB"))
            {
                DoubleInnateAbilities(@"(CLAB|clab)(ba|BA|dr|DR|fi|FI|pa|PA|pr|PR|rn|RN|sh|SH|so|SO|th|TH|ma|MA|sh|SH|so|SO)(.*)\.(2da|2DA)");
                // Console.WriteLine("got here");
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // make edwins amulet removable
            // if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "ITEM_USE"))
            // {
            //     RemoveLine("MISC89");
            //     FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            // }
            
            // CHANGE MAX WEAPON PROFS FOR EACH CLASS
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "weapprof."))
            {
                ChangeMaxProfs("LARGE_SWORD", "	0	5	0	0	0	3	0	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	0	3	0	2	0	0	0	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("SMALL_SWORD", "	1	5	0	2	2	3	0	3	5	5	5	5	2	1	2	5	5	3	1	1	1	1	1	1	1	1	5	5	5	3	3	3	1	3	0	2	2	3	2	2	2	0	0	0	0	0	0	3	4	1	3	2	2	1	3	3	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("BOW", "	0	5	0	0	0	3	0	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	0	0	3	3	1	3	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	0	3	0	2	0	0	0	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("SPEAR", "	0	5	0	0	0	3	2	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	4	0	0	0	0	0	0	2	2	2	0	0	0	0	4	0	3	0	2	0	0	0	2	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("BLUNT", "	1	5	2	2	2	3	2	3	5	5	5	5	2	2	2	5	5	3	1	1	1	1	1	1	1	1	5	5	5	3	3	3	1	3	0	2	2	3	2	2	2	2	2	2	2	2	2	3	4	1	3	2	2	1	3	3	0	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("SPIKED", "	0	5	2	0	0	3	2	3	5	5	5	5	0	2	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	2	2	2	2	2	2	0	4	0	3	0	2	0	0	0	0	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("AXE", "	0	5	0	0	0	3	0	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	0	3	0	5	0	0	0	2	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	0	0	0	5	5	5");
                ChangeMaxProfs("MISSILE", "	1	5	2	2	2	3	2	3	5	5	5	5	2	2	2	5	5	3	1	1	1	1	1	1	1	1	1	5	0	0	3	3	1	3	0	2	2	3	2	2	2	2	2	2	2	2	2	3	4	1	3	2	2	1	3	3	0	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("BASTARDSWORD", "	0	5	0	0	0	3	0	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	0	3	0	2	0	0	0	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	0	0	0	5	0	0	0	5	5	5");
                ChangeMaxProfs("LONGSWORD", "	0	5	0	2	2	3	0	3	5	5	5	5	2	0	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	2	2	3	2	2	2	0	0	0	0	0	0	3	4	0	3	2	2	0	3	3	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	0	0	0	5	0	0	0	5	5	5");
                ChangeMaxProfs("SHORTSWORD", "	0	5	0	2	2	3	0	3	5	5	5	5	2	0	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	2	2	3	2	2	2	0	0	0	0	0	0	3	4	0	3	2	2	0	3	3	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	0	0	0	5	0	0	0	5	5	5");
                ChangeMaxProfs("AXE", "	0	5	0	0	0	3	0	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	0	3	0	5	0	0	0	2	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	0	0	0	5	0	0	0	5	5	5");
                ChangeMaxProfs("TWOHANDEDSWORD", "	0	5	0	0	0	3	0	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	0	3	0	2	0	0	0	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	0	0	0	5	0	0	0	5	5	5");
                ChangeMaxProfs("KATANA", "	0	5	0	2	2	3	0	3	5	5	5	5	2	0	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	2	2	3	2	2	2	0	0	0	0	0	0	3	4	0	3	2	2	0	3	3	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	5	5	5	5	0	0	0	5	5	5");
                ChangeMaxProfs("SCIMITARWAKISASHININJATO", "	0	5	0	2	2	3	0	3	5	5	5	5	2	0	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	2	2	3	2	2	2	0	0	0	0	0	0	3	4	0	3	2	2	0	3	3	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("DAGGER", "	1	5	0	2	2	3	0	3	5	5	5	5	2	2	2	5	5	3	1	1	1	1	1	1	1	1	5	5	5	3	3	3	1	3	0	2	2	3	2	2	2	0	0	0	0	0	0	3	4	1	3	2	2	1	3	3	2	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("WARHAMMER", "	0	5	2	0	0	3	0	3	5	5	5	5	0	2	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	4	0	0	0	0	0	0	0	0	0	2	2	2	0	4	0	3	0	5	0	0	0	0	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("CLUB", "	0	5	2	2	2	3	2	3	5	5	5	5	2	2	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	4	2	2	3	2	2	2	2	2	2	2	2	2	3	4	0	3	2	2	0	3	3	2	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("SPEAR", "	0	5	0	0	0	3	2	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	4	0	0	0	0	0	0	2	2	2	0	0	0	0	4	0	3	0	2	0	0	0	2	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("HALBERD", "	0	5	0	0	0	3	0	3	5	5	5	5	0	0	0	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	0	3	0	2	0	0	0	0	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("FLAILMORNINGSTAR", "	0	5	2	0	0	3	0	3	5	5	5	5	0	2	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	2	2	2	0	4	0	3	0	2	0	0	0	0	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("MACE", "	0	5	2	0	0	3	0	3	5	5	5	5	0	2	2	5	5	3	0	0	0	0	0	0	0	0	5	5	5	3	3	3	1	3	0	0	0	0	0	0	0	0	0	0	2	2	2	0	4	0	3	0	2	0	0	0	0	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	5	5	5	5	0	0	0	5	5	5");
                ChangeMaxProfs("QUARTERSTAFF", "	1	5	2	2	2	3	2	3	5	5	5	5	2	2	2	5	5	3	1	1	1	1	1	1	1	1	5	5	5	3	3	3	1	3	4	2	2	3	2	2	2	2	2	2	2	2	2	3	4	1	3	2	2	1	3	3	2	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("CROSSBOW", "	0	5	2	2	2	3	0	3	5	5	5	5	2	2	2	5	5	3	0	0	0	0	0	0	0	0	1	5	0	0	3	3	5	3	4	2	2	1	2	2	2	0	0	0	2	2	2	0	4	0	3	2	2	0	0	0	0	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("LONGBOW", "	0	5	0	2	2	3	2	3	5	5	5	5	2	0	2	5	5	3	0	0	0	0	0	0	0	0	1	5	0	0	3	3	5	3	4	2	2	0	2	2	2	2	2	2	0	0	0	0	4	0	3	0	2	0	0	0	2	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("SHORTBOW", "	0	5	0	2	2	3	2	3	5	5	5	5	2	2	2	5	5	3	0	0	0	0	0	0	0	0	1	5	0	0	3	3	5	3	4	2	2	1	2	2	2	2	2	2	0	0	0	0	4	0	3	2	2	0	0	0	2	0	0	0	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("DART", "	1	5	2	2	2	3	2	3	5	5	5	5	2	2	2	5	5	3	1	1	1	1	1	1	1	1	1	5	0	0	3	3	5	3	4	2	2	1	2	2	2	2	2	2	2	2	2	3	4	1	3	2	2	1	3	3	2	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("SLING", "	1	5	2	2	2	3	2	3	5	5	5	5	2	2	2	5	5	3	1	1	1	1	1	1	1	1	1	5	0	0	3	3	5	3	4	2	2	1	2	2	2	2	2	2	2	2	2	3	4	1	3	2	2	1	3	3	2	0	2	2	5	5	5	5	5	5	5	5	5	5	5	5	5	2	2	2	3	3	3	5	0	0	0	5	5	5");
                ChangeMaxProfs("2HANDED", "	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	0	0	0	2	2	2");
                ChangeMaxProfs("SWORDANDSHIELD", "	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	0	0	0	2	2	2");
                ChangeMaxProfs("SINGLEWEAPON", "	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	2	0	0	0	2	2	2");
                ChangeMaxProfs("2WEAPON", "	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	3	0	0	0	3	3	3");

                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // CHANGE WEAPON PROFS PER LEVEL
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "profs."))
            {
                ChangeProfsPerLevel("MAGE", "1", "6");
                ChangeProfsPerLevel("FIGHTER", "4", "3");
                ChangeProfsPerLevel("CLERIC", "2", "4");
                ChangeProfsPerLevel("THIEF", "2", "4");
                ChangeProfsPerLevel("BARD", "2", "4");
                ChangeProfsPerLevel("PALADIN", "4", "3");
                ChangeProfsPerLevel("DRUID", "2", "4");
                ChangeProfsPerLevel("RANGER", "4", "3");
                ChangeProfsPerLevel("FIGHTER_MAGE", "4", "3");
                ChangeProfsPerLevel("FIGHTER_CLERIC", "4", "3");
                ChangeProfsPerLevel("FIGHTER_THIEF", "4", "3");
                ChangeProfsPerLevel("FIGHTER_MAGE_THIEF", "4", "3");
                ChangeProfsPerLevel("MAGE_THIEF", "2", "4");
                ChangeProfsPerLevel("CLERIC_MAGE", "2", "4");
                ChangeProfsPerLevel("CLERIC_THIEF", "2", "4");
                ChangeProfsPerLevel("FIGHTER_DRUID", "4", "3");
                ChangeProfsPerLevel("FIGHTER_MAGE_CLERIC", "4", "3");
                ChangeProfsPerLevel("CLERIC_RANGER", "4", "3");
                ChangeProfsPerLevel("SORCERER", "1", "6");
                ChangeProfsPerLevel("MONK", "2", "4");
                ChangeProfsPerLevel("SHAMAN", "2", "4");
                
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // CHANGE HP PER CLASS
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "hpclass."))
            {
                ChangeHpClass("FIGHTER", "HPWAR");
                ChangeHpClass("BERSERKER", "HPWAR");
                ChangeHpClass("WIZARD_SLAYER", "HPWAR");
                ChangeHpClass("KENSAI", "HPWAR");
                ChangeHpClass("DWARVEN_DEFENDER", "HPBARB");
                ChangeHpClass("RANGER", "HPWAR");
                ChangeHpClass("ARCHER", "HPWAR");
                ChangeHpClass("STALKER", "HPWAR");
                ChangeHpClass("BEAST_MASTER", "HPWAR");
                ChangeHpClass("PALADIN", "HPWAR");
                ChangeHpClass("CAVALIER", "HPWAR");
                ChangeHpClass("INQUISITOR", "HPWAR");
                ChangeHpClass("UNDEAD_HUNTER", "HPWAR");
                ChangeHpClass("BLACKGUARD", "HPWAR");
                ChangeHpClass("CLERIC", "HPPRS");
                ChangeHpClass("TALOS", "HPPRS");
                ChangeHpClass("HELM", "HPPRS");
                ChangeHpClass("LATHANDER", "HPPRS");
                ChangeHpClass("DRUID", "HPPRS");
                ChangeHpClass("TOTEMIC_DRUID", "HPPRS");
                ChangeHpClass("SHAPESHIFTER", "HPPRS");
                ChangeHpClass("BEAST_FRIEND", "HPPRS");
                ChangeHpClass("MAGE", "HPWIZ");
                ChangeHpClass("ABJURER", "HPWIZ");
                ChangeHpClass("CONJURER", "HPWIZ");
                ChangeHpClass("DIVINER", "HPWIZ");
                ChangeHpClass("ENCHANTER", "HPWIZ");
                ChangeHpClass("ILLUSIONIST", "HPWIZ");
                ChangeHpClass("INVOKER", "HPWIZ");
                ChangeHpClass("NECROMANCER", "HPWIZ");
                ChangeHpClass("TRANSMUTER", "HPWIZ");
                ChangeHpClass("WILDMAGE", "HPWIZ");
                ChangeHpClass("THIEF", "HPROG");
                ChangeHpClass("ASSASIN", "HPROG");
                ChangeHpClass("BOUNTY_HUNTER", "HPROG");
                ChangeHpClass("SWASHBUCKLER", "HPROG");
                ChangeHpClass("SHADOWDANCER", "HPROG");
                ChangeHpClass("BARD", "HPROG");
                ChangeHpClass("BLADE", "HPROG");
                ChangeHpClass("JESTER", "HPROG");
                ChangeHpClass("SKALD", "HPROG");
                ChangeHpClass("SORCERER", "HPWIZ");
                ChangeHpClass("DRAGON_DISCIPLE", "HPDD");
                ChangeHpClass("MONK", "HPMONK");
                ChangeHpClass("DARK_MOON", "HPMONK");
                ChangeHpClass("SUN_SOUL", "HPMONK");
                ChangeHpClass("BARBARIAN", "HPBARB");
                ChangeHpClass("FIGHTER_MAGE", "HPWAR");
                ChangeHpClass("FIGHTER_CLERIC", "HPWAR");
                ChangeHpClass("FIGHTER_THIEF", "HPWAR");
                ChangeHpClass("FIGHTER_MAGE_THIEF", "HPWAR");
                ChangeHpClass("MAGE_THIEF", "HPROG");
                ChangeHpClass("CLERIC_MAGE", "HPPRS");
                ChangeHpClass("CLERIC_THIEF", "HPPRS");
                ChangeHpClass("FIGHTER_DRUID", "HPWAR");
                ChangeHpClass("FIGHTER_MAGE_CLERIC", "HPWAR");
                ChangeHpClass("CLERIC_RANGER", "HPWAR");
                ChangeHpClass("SHAMAN", "HPPRS");
                ChangeHpClass("OHTYR", "HPPRS");
                ChangeHpClass("OHTEMPUS", "HPPRS");
                ChangeHpClass("FERALAN", "HPWAR");
                ChangeHpClass("BL_KNCJAS", "HPWAR");
                ChangeHpClass("BL_KNCJSW", "HPWAR");
                ChangeHpClass("BL_BZCJAS", "HPWAR");
                ChangeHpClass("BL_BZCJSW", "HPWAR");
                ChangeHpClass("BL_KNCJLA", "HPWAR");
                ChangeHpClass("BL_KNCJTP", "HPWAR");
                ChangeHpClass("BL_KNCJTY", "HPWAR");
                ChangeHpClass("BL_BZCJLA", "HPWAR");
                ChangeHpClass("BL_BZCJTP", "HPWAR");
                ChangeHpClass("BL_BZCJTY", "HPWAR");
                ChangeHpClass("BL_WSWM", "HPWAR");
                ChangeHpClass("BL_KNCJ##", "HPWAR");
                ChangeHpClass("BL_BZCJ##", "HPWAR");
                ChangeHpClass("BL_DDLA", "HPBARB");
                ChangeHpClass("BL_DDTP", "HPBARB");
                ChangeHpClass("BL_DDTY", "HPBARB");
                ChangeHpClass("BL_LAST", "HPWAR");
                ChangeHpClass("BL_TPST", "HPWAR");
                ChangeHpClass("BL_TYST", "HPWAR");
                ChangeHpClass("BL_KNSW", "HPWAR");
                ChangeHpClass("BL_KNSD", "HPWAR");
                ChangeHpClass("BL_BZWMAS", "HPWAR");
                ChangeHpClass("BL_KNILAS", "HPWAR");
                ChangeHpClass("BL_BZWMTP", "HPWAR");
                
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // EQUALIZE THAC0 FOR THIEVES/PRIESTS
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "THAC0"))
            {
                ChangeThac0("THIEF", "20   20   20   18   18   18   16   16   16   14   14   14   12   12   12   10   10   10    8    8    8    6    6    6    4    4    4    2    2    2    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1");
                ChangeThac0("BARD", "20   20   20   18   18   18   16   16   16   14   14   14   12   12   12   10   10   10    8    8    8    6    6    6    4    4    4    2    2    2    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1");
                ChangeThac0("MAGE_THIEF", "20   20   20   18   18   18   16   16   16   14   14   14   12   12   12   10   10   10    8    8    8    6    6    6    4    4    4    2    2    2    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1    1");
                
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
            
            // INCREASE PROFS PER LEVEL
            if (ContainsCaseInsensitive(currentTwodaFileInfo.Name, "PROFSMAX"))
            {
                for (int i = 0; i < twodaFile.twodaLines.Count; i++)
                {
                    TwodaLine currentLine = (TwodaLine)twodaFile.twodaLines[i];
                    currentLine.content = currentLine.content.Replace("2          5          3          4          5", "2          5          4          5          5");
                    twodaFile.UpdateLine(currentLine.content, i);
                }
                
                FileOperations.WriteFileAsString(twodaFile.rawContent, twodaOutputPath + "/" + currentTwodaFileInfo.Name);
            }
        }

        internal static void ChangeMaxProfs(String identifier, String profs)
        {
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.content.Contains(identifier))
                {
                    Regex regex = new Regex(@"(?<=^" + identifier + @"\s+\d{1,3}\s+\d{4,6}\s+\d{4,6}\s+).+", RegexOptions.Multiline);
                    Match match = regex.Match(currentLine.content);
                    // Console.WriteLine(currentLine.content);
                    if (match.Success)
                    {
                        String newRow = currentLine.content.Replace(match.Value, profs.Replace("\t", "                        "));
                        twodaFile.UpdateLine(newRow, i);
                    }
                }
            }
        }
        internal static void ChangeProfsPerLevel(String identifier, String startingPoints, String pointsPerLevel)
        {
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.content.Contains(identifier))
                {
                    Regex regex = new Regex(@"(?<=^" + identifier + @")\s+.+", RegexOptions.Multiline);
                    Match match = regex.Match(currentLine.content);
                    // Console.WriteLine(currentLine.content);
                    if (match.Success)
                    {
                        String newRow = currentLine.content.Replace(match.Value, "     " + startingPoints + "     " + pointsPerLevel);
                        twodaFile.UpdateLine(newRow, i);
                    }
                }
            }
        }
        
        internal static void ChangeHpClass(String identifier, String newHpClass)
        {
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.content.Contains(identifier))
                {
                    Regex regex = new Regex(@"(?<=^" + identifier + @")\s+.+", RegexOptions.Multiline);
                    Match match = regex.Match(currentLine.content);
                    // Console.WriteLine(currentLine.content);
                    if (match.Success)
                    {
                        String newRow = currentLine.content.Replace(match.Value, "     " + newHpClass);
                        twodaFile.UpdateLine(newRow, i);
                    }
                }
            }
        }
        
        internal static void ChangeThac0(String identifier, String newThac0)
        {
            // Console.WriteLine(twodaFile.twodaLines.Count);
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.content.Contains(identifier))
                {
                    Regex regex = new Regex(@"(?<=^" + identifier + @")\s+.+", RegexOptions.Multiline);
                    Match match = regex.Match(currentLine.content);
                    // Console.WriteLine(currentLine.content);
                    if (match.Success)
                    {
                        String newRow = currentLine.content.Replace(match.Value, "     " + newThac0);
                        twodaFile.UpdateLine(newRow, i);
                    }
                }
            }
        }
        
        internal static void IncreaseSpells(String regexStr, int xSpells)
        {
            // *********************************************************
            // +x spells for class x
            // *********************************************************

            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.isContent)
                {
                    MatchCollection singleSpellMatches = Regex.Matches(currentLine.content, @"(?<=\d+( |\t)+)\d+(?=(\d+|\n|\r|$| |\t))", RegexOptions.Multiline);
                    int offset = 0;
                    String newRow = currentLine.content;
                    foreach (Match sm in singleSpellMatches)
                    {
                        int oldNum = Int32.Parse(sm.Value);
                        if (oldNum != 0)
                        {
                            int newNum = oldNum + xSpells;
                            // String newRow = r.Value.Remove(sm.Index, sm.Length).Insert(sm.Index, (Int32.Parse(sm.Value) * 2).ToString());
                            newRow = newRow.Remove(sm.Index + offset, sm.Length)
                                .Insert(sm.Index + offset, newNum.ToString());
                            if (oldNum.ToString().Length < newNum.ToString().Length)
                            {
                                offset += newNum.ToString().Length - oldNum.ToString().Length;
                            }
                        }
                    }
                    twodaFile.UpdateLine(newRow, i);
                }
            }
        }
        
        internal static void DoubleInnateAbilities(String regexStr)
        {
            ArrayList newLines = new ArrayList();
            
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.isContent)
                {
                    String newContent = "";
                    if (Regex.Match(currentLine.content, @"(?<= )GA_.*?(?= )", RegexOptions.Multiline).Success) // if we find a general ability in the line
                    {
                        newContent = currentLine.content;
                        MatchCollection mc = Regex.Matches(currentLine.content, "(?<= )AP_.*?(?= )", RegexOptions.Multiline);
                        if (mc.Count > 0)
                        {
                            foreach (Match m in mc)
                            {
                                newContent = currentLine.content.Replace(m.Value, "****      ");
                            }
                        }

                        newLines.Add(new TwodaLine(currentLine.index, true, newContent));
                    }
                }
            }

            foreach (TwodaLine newLine in newLines)
            {
                twodaFile.AddLine(newLine);
            }
        }

        internal static void RemoveLine(String pattern)
        {
            for (int i = 0; i < twodaFile.twodaLines.Count; i++)
            {
                TwodaLine currentLine = (TwodaLine) twodaFile.twodaLines[i];
                if (currentLine.content.Contains(pattern))
                {
                    twodaFile.twodaLines.RemoveAt(i);
                }
            }
            twodaFile.UpdateRawContent();
        }
        
        // MISC FUNCTIONS
        internal static int FindInSmTables(String findStr)
        {
            // Console.WriteLine(twodaInputDirectory.FullName + "/SMTABLES.2DA");
            String file = FileOperations.ReadFileAsString(twodaInputDirectory.FullName + "/SMTABLES.2DA");
            MatchCollection lines = Regex.Matches(file, @"^.*$", RegexOptions.Multiline);
            foreach (Match line in lines)
            {
                if (Regex.Match(line.Value, findStr, RegexOptions.Multiline).Success)
                {
                    // Console.WriteLine(line.Value);
                    Match num = Regex.Match(line.Value, @"(?<=^)\d+(?=_)", RegexOptions.Multiline);
                    return Int32.Parse(num.Value);
                }
            }

            return 0;
        }
    }
}